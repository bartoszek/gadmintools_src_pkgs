/* GADMIN-CONTROL-PANEL - a GTK+ control panel for GAdmintools.
 * Copyright (C) 2010 - 2014 Magnus Loef <magnus-swe@telia.com> 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
*/


#include "../config.h"
#include <gtk/gtk.h>
#include "interface.h"
#include "support.h"


int main(int argc, char *argv[])
{
  GtkWidget *main_window;

#ifdef ENABLE_NLS
  bindtextdomain (GETTEXT_PACKAGE, PACKAGE_LOCALE_DIR);
  bind_textdomain_codeset (GETTEXT_PACKAGE, "UTF-8");
  textdomain (GETTEXT_PACKAGE);
#endif

  gtk_init(&argc, &argv);

  add_pixmap_directory(PIXMAPS_DIRECTORY);

  main_window = create_main_window();
  gtk_widget_show(main_window);

  /* Window (x) close button */
  g_signal_connect(GTK_WIDGET(main_window), "destroy",
                   G_CALLBACK(gtk_main_quit), NULL);

  gtk_main ();

  return 0;
}
