/* GADMIN-NFS-SERVER - An easy to use GTK+ frontend for the NFS server.
 * Copyright (C) 2014 - 2014 Magnus Loef <magnus-swe@telia.com> 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
*/


#include <gtk/gtk.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "widgets.h"
#include "gettext.h"
#include "allocate.h"
#include "commented.h"


void populate_dir_treeview(struct w *widgets)
{
    FILE *fp;
    GtkTreeIter iter;
    gchar *utf8=NULL;
    GtkTreePath *path;
    gboolean edit=0;
    int set_cursorpath=0;
    long file_size=0;
    char *line, *dir;

    gtk_list_store_clear(widgets->scope_store);

    if((fp=fopen(NFSD_CONF, "r"))==NULL)
    {
       return;
    }
    fseek(fp, 0, SEEK_END);
    file_size = ftell(fp);
    rewind(fp);

    line = allocate(file_size+1);
    dir  = allocate(file_size+1);

    if( file_size > 1 )
    while(fgets(line, file_size, fp)!=NULL)
    {
	if( strstr(line, "/") && ! commented(line) )
	{
	    sscanf(line, "%s", dir);
	    gtk_list_store_append(GTK_LIST_STORE(widgets->scope_store), &iter);

	    utf8 = g_locale_to_utf8(dir, strlen(dir), NULL, NULL, NULL);
	    gtk_list_store_set(GTK_LIST_STORE(widgets->scope_store), &iter, 0, utf8, -1);

	    set_cursorpath = 1;
	}
    }
    fclose(fp);
    free(line);
    free(dir);

    if( utf8!=NULL )
      g_free(utf8);

    if( ! set_cursorpath )
      return;

    path = gtk_tree_path_new_first();
    gtk_tree_view_set_cursor(GTK_TREE_VIEW(widgets->scope_treeview), path, NULL, edit);
    gtk_tree_path_free(path);
}
