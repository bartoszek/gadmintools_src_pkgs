
#ifndef TRANSFORM_H
#define TRANSFORM_H

char * transform_install_variables(char *install_file);

char * transform_version(char *version);

#endif
