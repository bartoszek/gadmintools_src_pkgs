
#ifndef INSTALL_PACKAGE_H
#define INSTALL_PACKAGE_H

int path_exists_in_install_log(char *filepath);

void rebuild_file_list(char *package);

void clean_file_list(char *package);

int install_package(char *package);

int installed_ok(char *package, char *install_cmds, int install_mode);

#endif
