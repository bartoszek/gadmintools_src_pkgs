
#ifndef DIR_HANDLING_H
#define DIR_HANDLING_H

#include "globals.h"

int num_processes_running(char *process);

void setup_global_paths();

void create_build_directory(char *dirpath);

void clean_build_dirs();
void clean_build_directory_root();
void clean_build_directory_temp();

#endif
