

for i in `ls src/`
do
    sed -e 's/GADMIN_DHCPD/GADMIN_NFS/g' src/$i > src/$i.new;
    mv src/$i.new src/$i;
done
