
#ifndef UNPACK_PACKAGE_H
#define UNPACK_PACKAGE_H

int unpack_package(char *package);

#endif
