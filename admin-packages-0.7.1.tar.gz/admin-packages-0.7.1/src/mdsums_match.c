/*
 * Admin-Packages - A Package manager for sources.
 * Copyright (C) 2009 - 2011 Magnus Loef <magnus-swe@telia.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307, USA.
 *
 */


#include "../config.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include "allocate.h"
#include "mdsums_match.h"
#include "globals.h"
#include "file_exists.h"
#include "get_package_info.h"
#include "run_command.h"

extern char build_directory[MAX_TEMP_PATH];
char mdsum_temp[MAX_TEMP_PATH];
char mdsum_pkg[MAX_TEMP_PATH];


extern char global_newest_url;
extern int global_mdsum_check;


int mdsums_match(char *file)
{
    FILE *fp;
    long file_size = 0;
    int matches = 0;
    int i=0, got_pkg_sum=0, got_list_sum=0;
    char *tmp, *mdsum_list, *mdsum_file;
    char *line, *cmd;

    /* mdsum checking is turned off */
    if( ! global_mdsum_check )
        return 1;

    if( file == NULL )
    {
        printf("Error: file name is NULL in mdsums_match\n");
        return 0;
    }

    if( strlen(file) < 2 )
    {
        printf("File name length passed to mdsum function was < 2 chars\n");
        return 0;
    }

    if( ! file_exists(mdsum_temp) )
    {
        printf("Missing file: %s\n", mdsum_temp);
        return 0;
    }

    cmd = allocate(strlen(MDSUM_PATH)+strlen(build_directory)+strlen(file)+strlen(mdsum_pkg)+10);

    sprintf(cmd, "%s %s/%s > %s", MDSUM_PATH, build_directory, file, mdsum_pkg);
    if( ! run_command(cmd) )
    {
        free(cmd);
        printf("Could not generate mdsum for file: %s\n", file);
        return 0;
    }
    free(cmd);

    printf("Checking mdsums for file: %s\n", file);

    /* Read the generated package mdsum from file
     * It should look something like this:
     * dfgdg9834923sdf9234ajsdj filename (Linux)
     * MD5 (package.version.compression) = 4564356dfve44q2rdzsdf (*BSD, OSX, Solaris)
     */
    if((fp=fopen(mdsum_pkg, "r"))==NULL)
    {
        perror("fopen");
        printf("Fatal error opening file [%s]\n", mdsum_pkg);
        return 0;
    }

    fseek(fp, 0, SEEK_END);
    file_size = ftell(fp);
    rewind(fp);

    line = allocate(file_size+1);
    tmp = allocate(MAX_MDSUM_LINE+1);
    mdsum_file = allocate(MAX_MDSUM_LINE+1);
    mdsum_list = allocate(MAX_MDSUM_LINE+1);

    /* Mdsum the package to a file, get the line matching 
     * package_name-version.compression, isolate the mdsum */
    if( file_size > 1 )
    while(fgets(line, file_size, fp)!=NULL)
    {
        if( strlen(line) > MAX_MDSUM_LINE-1 )
        {
            printf("A line in the generated md5sum file exceeds: %i\n", MAX_MDSUM_LINE);
            printf("Skipping it\n");
            continue;
        }

        if( ! strstr(line, file) )
            continue;

#if defined USE_FREEBSD || defined USE_OPENBSD || defined USE_NETBSD || defined USE_OSX || defined USE_SOLARIS
        for(i=strlen(line)-1; line[i]!='\0'; i--)
        {
            if( i > 5 && line[i-1]==' ')
            {
                sprintf(mdsum_file, "%s", &line[i]);
                got_pkg_sum = 1;
                break;
            }
        }
#else
        /* Linux */
        for(i=0; line[i]!='\0'; i++)
        {
            if( i > 5 && line[i]==' ' )
            {
                sprintf(mdsum_file, "%s", line);
                mdsum_file[i]='\0';
                got_pkg_sum = 1;
                break;
            }
        }
#endif
        if( got_pkg_sum )
            break;
    }
    fclose(fp);
    free(line);
    free(tmp); 

    /* Now we should have the md5 sum for the file in mdsum_file */

    /* Read the mdsum from the downloaded list of sums
     * Comapare this sum to the generated file sum */
    if((fp=fopen(mdsum_temp, "r"))==NULL)
    {
        perror("fopen");
        printf("Fatal error opening file [%s]\n", mdsum_temp);
        return 0;
    }
    fseek(fp, 0, SEEK_END);
    file_size=ftell(fp);
    rewind(fp);

    line = allocate(file_size);
    tmp = allocate(MAX_MDSUM_LINE+1);

    if( file_size > 1 )
    while(fgets(line, file_size, fp)!=NULL)
    {
        if( strlen(line) > MAX_MDSUM_LINE-1 )
        {
            printf("A line in the md5sum list file exceeds: %i\n", MAX_MDSUM_LINE-1);
            printf("Skipping it\n");
            continue;
        }

        if( ! strstr(line, file) )
            continue;
        else
        {
            // printf("Found the file in the mdsum list\n");
            break;
        }
    }
    fclose(fp);

    for(i=0; line[i]!='\0'; i++)
    {
        if( i > 5 && line[i]==' ' )
        {
            sprintf(mdsum_list, "%s", &line[0]);
            got_list_sum = 1;
            mdsum_list[i]='\0';
            printf("The list md5sum is: [%s]\n", mdsum_list);
            printf("The file md5sum is: [%s]\n", mdsum_file);
            break;
        }
    }

    free(line);
    free(tmp);

    if( strcmp(mdsum_list, mdsum_file) == 0 )
        matches = 1;
    else
        matches = 0;

    if( strlen(mdsum_list) < 10 || strlen(mdsum_file) < 10 )
    {
        printf("The mdsum lines are too short, less then 10 chars\n");
        matches = 0;
    }

    if( ! got_pkg_sum )
    {
        printf("Could not get generated md5sum for file: %s\n", file);
        matches = 0;
    }
    else
    if( ! got_list_sum )
    {
       printf("Remote md5sum list does not contain file: %s\n", file);
       matches = 0;
    }

    free(mdsum_file);
    free(mdsum_list);

    if( unlink(mdsum_pkg) ==-1 )
        printf("mdcheck could not unlink: %s\n", mdsum_pkg);

    return matches;
}
