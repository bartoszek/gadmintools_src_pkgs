#
# Regular cron jobs for the gadmin-desktop package
#
0 4	* * *	root	[ -x /usr/bin/gadmin-desktop_maintenance ] && /usr/bin/gadmin-desktop_maintenance
