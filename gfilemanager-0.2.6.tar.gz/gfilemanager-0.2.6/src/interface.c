/*
 * REDIGERA INTE DENNA FIL - den är genererad av Glade.
 */

#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>

#include <gdk/gdkkeysyms.h>
#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"

#define GLADE_HOOKUP_OBJECT(component,widget,name) \
  gtk_object_set_data_full (GTK_OBJECT (component), name, \
    gtk_widget_ref (widget), (GtkDestroyNotify) gtk_widget_unref)

#define GLADE_HOOKUP_OBJECT_NO_REF(component,widget,name) \
  gtk_object_set_data (GTK_OBJECT (component), name, widget)

GtkWidget*
create_main_window (void)
{
  GtkWidget *main_window;
  GtkWidget *vbox1;
  GtkWidget *toolbar1;
  GtkWidget *tmp_toolbar_icon;
  GtkWidget *scan_button;
  GtkWidget *label18;
  GtkWidget *combo1;
  GtkWidget *ip_entry;
  GtkWidget *label50;
  GtkWidget *connect_button;
  GtkWidget *disconnect_button;
  GtkWidget *run_info_button;
  GtkWidget *help_button;
  GtkWidget *settings_button;
  GtkWidget *quit_button;
  GtkWidget *toolbar2;
  GtkWidget *label3;
  GtkWidget *label51;
  GtkWidget *user_entry;
  GtkWidget *label4;
  GtkWidget *password_entry;
  GtkWidget *label36;
  GtkWidget *hbuttonbox4;
  GtkWidget *label49;
  GtkWidget *share_entry;
  GtkWidget *label48;
  GtkWidget *hbox3;
  GtkWidget *label69;
  GtkWidget *left_path_entry;
  GtkWidget *label11;
  GtkWidget *right_path_entry;
  GtkWidget *label70;
  GtkWidget *hbox2;
  GtkWidget *toolbar5;
  GtkWidget *hbox1;
  GtkWidget *label19;
  GtkWidget *scrolledwindow1;
  GtkWidget *left_treeview;
  GtkWidget *vbuttonbox1;
  GtkWidget *scrolledwindow2;
  GtkWidget *right_treeview;
  GtkWidget *hbox26;
  GtkWidget *left_status_entry;
  GtkWidget *update_both_button;
  GtkWidget *alignment12;
  GtkWidget *hbox36;
  GtkWidget *image12;
  GtkWidget *label63;
  GtkWidget *right_status_entry;

  main_window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_widget_set_name (main_window, "main_window");
  gtk_widget_set_usize (main_window, -2, 440);
  gtk_window_set_title (GTK_WINDOW (main_window), _("Gfilemanager"));
  gtk_window_set_position (GTK_WINDOW (main_window), GTK_WIN_POS_CENTER);

  vbox1 = gtk_vbox_new (FALSE, 0);
  gtk_widget_set_name (vbox1, "vbox1");
  gtk_widget_show (vbox1);
  gtk_container_add (GTK_CONTAINER (main_window), vbox1);

  toolbar1 = gtk_toolbar_new ();
  gtk_widget_set_name (toolbar1, "toolbar1");
  gtk_widget_show (toolbar1);
  gtk_box_pack_start (GTK_BOX (vbox1), toolbar1, FALSE, TRUE, 0);
  gtk_toolbar_set_style (GTK_TOOLBAR (toolbar1), GTK_TOOLBAR_BOTH);

  tmp_toolbar_icon = gtk_image_new_from_stock ("gtk-find", gtk_toolbar_get_icon_size (GTK_TOOLBAR (toolbar1)));
  scan_button = gtk_toolbar_append_element (GTK_TOOLBAR (toolbar1),
                                GTK_TOOLBAR_CHILD_BUTTON,
                                NULL,
                                _("Computers"),
                                NULL, NULL,
                                tmp_toolbar_icon, NULL, NULL);
  gtk_label_set_use_underline (GTK_LABEL (((GtkToolbarChild*) (g_list_last (GTK_TOOLBAR (toolbar1)->children)->data))->label), TRUE);
  gtk_widget_set_name (scan_button, "scan_button");
  gtk_widget_show (scan_button);

  label18 = gtk_label_new ("");
  gtk_widget_set_name (label18, "label18");
  gtk_widget_show (label18);
  gtk_toolbar_append_widget (GTK_TOOLBAR (toolbar1), label18, NULL, NULL);
  gtk_widget_set_usize (label18, 12, -2);
  gtk_label_set_justify (GTK_LABEL (label18), GTK_JUSTIFY_LEFT);

  combo1 = gtk_combo_new ();
  gtk_object_set_data (GTK_OBJECT (GTK_COMBO (combo1)->popwin),
                       "GladeParentKey", combo1);
  gtk_widget_set_name (combo1, "combo1");
  gtk_widget_show (combo1);
  gtk_toolbar_append_widget (GTK_TOOLBAR (toolbar1), combo1, NULL, NULL);

  ip_entry = GTK_COMBO (combo1)->entry;
  gtk_widget_set_name (ip_entry, "ip_entry");
  gtk_widget_show (ip_entry);
  gtk_widget_set_usize (ip_entry, 143, -2);
  GTK_WIDGET_SET_FLAGS (ip_entry, GTK_CAN_DEFAULT);

  label50 = gtk_label_new ("");
  gtk_widget_set_name (label50, "label50");
  gtk_widget_show (label50);
  gtk_toolbar_append_widget (GTK_TOOLBAR (toolbar1), label50, NULL, NULL);
  gtk_widget_set_usize (label50, 15, -2);
  gtk_label_set_justify (GTK_LABEL (label50), GTK_JUSTIFY_LEFT);

  tmp_toolbar_icon = gtk_image_new_from_stock ("gtk-yes", gtk_toolbar_get_icon_size (GTK_TOOLBAR (toolbar1)));
  connect_button = gtk_toolbar_append_element (GTK_TOOLBAR (toolbar1),
                                GTK_TOOLBAR_CHILD_BUTTON,
                                NULL,
                                _("Connect"),
                                NULL, NULL,
                                tmp_toolbar_icon, NULL, NULL);
  gtk_label_set_use_underline (GTK_LABEL (((GtkToolbarChild*) (g_list_last (GTK_TOOLBAR (toolbar1)->children)->data))->label), TRUE);
  gtk_widget_set_name (connect_button, "connect_button");
  gtk_widget_show (connect_button);

  tmp_toolbar_icon = gtk_image_new_from_stock ("gtk-no", gtk_toolbar_get_icon_size (GTK_TOOLBAR (toolbar1)));
  disconnect_button = gtk_toolbar_append_element (GTK_TOOLBAR (toolbar1),
                                GTK_TOOLBAR_CHILD_BUTTON,
                                NULL,
                                _("Disconnect"),
                                NULL, NULL,
                                tmp_toolbar_icon, NULL, NULL);
  gtk_label_set_use_underline (GTK_LABEL (((GtkToolbarChild*) (g_list_last (GTK_TOOLBAR (toolbar1)->children)->data))->label), TRUE);
  gtk_widget_set_name (disconnect_button, "disconnect_button");
  gtk_widget_show (disconnect_button);

  tmp_toolbar_icon = gtk_image_new_from_stock ("gtk-convert", gtk_toolbar_get_icon_size (GTK_TOOLBAR (toolbar1)));
  run_info_button = gtk_toolbar_append_element (GTK_TOOLBAR (toolbar1),
                                GTK_TOOLBAR_CHILD_BUTTON,
                                NULL,
                                _("Run/info"),
                                NULL, NULL,
                                tmp_toolbar_icon, NULL, NULL);
  gtk_label_set_use_underline (GTK_LABEL (((GtkToolbarChild*) (g_list_last (GTK_TOOLBAR (toolbar1)->children)->data))->label), TRUE);
  gtk_widget_set_name (run_info_button, "run_info_button");
  gtk_widget_show (run_info_button);

  tmp_toolbar_icon = gtk_image_new_from_stock ("gtk-dialog-info", gtk_toolbar_get_icon_size (GTK_TOOLBAR (toolbar1)));
  help_button = gtk_toolbar_append_element (GTK_TOOLBAR (toolbar1),
                                GTK_TOOLBAR_CHILD_BUTTON,
                                NULL,
                                _("Help"),
                                NULL, NULL,
                                tmp_toolbar_icon, NULL, NULL);
  gtk_label_set_use_underline (GTK_LABEL (((GtkToolbarChild*) (g_list_last (GTK_TOOLBAR (toolbar1)->children)->data))->label), TRUE);
  gtk_widget_set_name (help_button, "help_button");
  gtk_widget_show (help_button);

  tmp_toolbar_icon = gtk_image_new_from_stock ("gtk-preferences", gtk_toolbar_get_icon_size (GTK_TOOLBAR (toolbar1)));
  settings_button = gtk_toolbar_append_element (GTK_TOOLBAR (toolbar1),
                                GTK_TOOLBAR_CHILD_BUTTON,
                                NULL,
                                _("Settings"),
                                NULL, NULL,
                                tmp_toolbar_icon, NULL, NULL);
  gtk_label_set_use_underline (GTK_LABEL (((GtkToolbarChild*) (g_list_last (GTK_TOOLBAR (toolbar1)->children)->data))->label), TRUE);
  gtk_widget_set_name (settings_button, "settings_button");
  gtk_widget_show (settings_button);

  tmp_toolbar_icon = gtk_image_new_from_stock ("gtk-quit", gtk_toolbar_get_icon_size (GTK_TOOLBAR (toolbar1)));
  quit_button = gtk_toolbar_append_element (GTK_TOOLBAR (toolbar1),
                                GTK_TOOLBAR_CHILD_BUTTON,
                                NULL,
                                _("Quit"),
                                NULL, NULL,
                                tmp_toolbar_icon, NULL, NULL);
  gtk_label_set_use_underline (GTK_LABEL (((GtkToolbarChild*) (g_list_last (GTK_TOOLBAR (toolbar1)->children)->data))->label), TRUE);
  gtk_widget_set_name (quit_button, "quit_button");
  gtk_widget_show (quit_button);
  gtk_widget_set_usize (quit_button, 76, -2);

  toolbar2 = gtk_toolbar_new ();
  gtk_widget_set_name (toolbar2, "toolbar2");
  gtk_widget_show (toolbar2);
  gtk_box_pack_start (GTK_BOX (vbox1), toolbar2, FALSE, FALSE, 0);
  gtk_toolbar_set_style (GTK_TOOLBAR (toolbar2), GTK_TOOLBAR_BOTH);

  label3 = gtk_label_new (_(" Username:  "));
  gtk_widget_set_name (label3, "label3");
  gtk_widget_show (label3);
  gtk_toolbar_append_widget (GTK_TOOLBAR (toolbar2), label3, NULL, NULL);
  gtk_label_set_justify (GTK_LABEL (label3), GTK_JUSTIFY_LEFT);

  label51 = gtk_label_new ("");
  gtk_widget_set_name (label51, "label51");
  gtk_widget_show (label51);
  gtk_toolbar_append_widget (GTK_TOOLBAR (toolbar2), label51, NULL, NULL);
  gtk_widget_set_usize (label51, 1, -2);
  gtk_label_set_justify (GTK_LABEL (label51), GTK_JUSTIFY_LEFT);

  user_entry = gtk_entry_new ();
  gtk_widget_set_name (user_entry, "user_entry");
  gtk_widget_show (user_entry);
  gtk_toolbar_append_widget (GTK_TOOLBAR (toolbar2), user_entry, NULL, NULL);
  gtk_widget_set_usize (user_entry, 107, -2);
  GTK_WIDGET_SET_FLAGS (user_entry, GTK_CAN_DEFAULT);

  label4 = gtk_label_new (_(" Password: "));
  gtk_widget_set_name (label4, "label4");
  gtk_widget_show (label4);
  gtk_toolbar_append_widget (GTK_TOOLBAR (toolbar2), label4, NULL, NULL);
  gtk_label_set_justify (GTK_LABEL (label4), GTK_JUSTIFY_LEFT);

  password_entry = gtk_entry_new ();
  gtk_widget_set_name (password_entry, "password_entry");
  gtk_widget_show (password_entry);
  gtk_toolbar_append_widget (GTK_TOOLBAR (toolbar2), password_entry, NULL, NULL);
  gtk_widget_set_usize (password_entry, 115, -2);
  GTK_WIDGET_SET_FLAGS (password_entry, GTK_CAN_DEFAULT);
  gtk_entry_set_visibility (GTK_ENTRY (password_entry), FALSE);

  label36 = gtk_label_new ("");
  gtk_widget_set_name (label36, "label36");
  gtk_widget_show (label36);
  gtk_toolbar_append_widget (GTK_TOOLBAR (toolbar2), label36, NULL, NULL);
  gtk_widget_set_usize (label36, 4, -2);
  gtk_label_set_justify (GTK_LABEL (label36), GTK_JUSTIFY_LEFT);

  hbuttonbox4 = gtk_hbutton_box_new ();
  gtk_widget_set_name (hbuttonbox4, "hbuttonbox4");
  gtk_widget_show (hbuttonbox4);
  gtk_toolbar_append_widget (GTK_TOOLBAR (toolbar2), hbuttonbox4, NULL, NULL);
  gtk_button_box_set_spacing (GTK_BUTTON_BOX (hbuttonbox4), 0);

  label49 = gtk_label_new (_(" Share: "));
  gtk_widget_set_name (label49, "label49");
  gtk_widget_show (label49);
  gtk_toolbar_append_widget (GTK_TOOLBAR (toolbar2), label49, NULL, NULL);
  gtk_label_set_justify (GTK_LABEL (label49), GTK_JUSTIFY_LEFT);

  share_entry = gtk_entry_new ();
  gtk_widget_set_name (share_entry, "share_entry");
  gtk_widget_show (share_entry);
  gtk_toolbar_append_widget (GTK_TOOLBAR (toolbar2), share_entry, NULL, NULL);
  gtk_widget_set_usize (share_entry, 231, -2);
  gtk_widget_set_sensitive (share_entry, FALSE);
  GTK_WIDGET_SET_FLAGS (share_entry, GTK_CAN_DEFAULT);
  gtk_entry_set_editable (GTK_ENTRY (share_entry), FALSE);

  label48 = gtk_label_new ("");
  gtk_widget_set_name (label48, "label48");
  gtk_widget_show (label48);
  gtk_toolbar_append_widget (GTK_TOOLBAR (toolbar2), label48, NULL, NULL);
  gtk_widget_set_usize (label48, 4, -2);
  gtk_label_set_justify (GTK_LABEL (label48), GTK_JUSTIFY_LEFT);

  hbox3 = gtk_hbox_new (FALSE, 0);
  gtk_widget_set_name (hbox3, "hbox3");
  gtk_widget_show (hbox3);
  gtk_box_pack_start (GTK_BOX (vbox1), hbox3, FALSE, TRUE, 0);

  label69 = gtk_label_new ("");
  gtk_widget_set_name (label69, "label69");
  gtk_widget_show (label69);
  gtk_box_pack_start (GTK_BOX (hbox3), label69, FALSE, FALSE, 0);
  gtk_widget_set_usize (label69, 13, -2);
  gtk_label_set_justify (GTK_LABEL (label69), GTK_JUSTIFY_LEFT);

  left_path_entry = gtk_entry_new ();
  gtk_widget_set_name (left_path_entry, "left_path_entry");
  gtk_widget_show (left_path_entry);
  gtk_box_pack_start (GTK_BOX (hbox3), left_path_entry, TRUE, TRUE, 0);
  gtk_widget_set_usize (left_path_entry, 70, -2);
  gtk_widget_set_sensitive (left_path_entry, FALSE);
  GTK_WIDGET_UNSET_FLAGS (left_path_entry, GTK_CAN_FOCUS);
  gtk_entry_set_editable (GTK_ENTRY (left_path_entry), FALSE);
  gtk_entry_set_text (GTK_ENTRY (left_path_entry), _("/"));

  label11 = gtk_label_new (_(" "));
  gtk_widget_set_name (label11, "label11");
  gtk_widget_show (label11);
  gtk_box_pack_start (GTK_BOX (hbox3), label11, FALSE, FALSE, 0);
  gtk_widget_set_usize (label11, 13, -2);
  gtk_label_set_justify (GTK_LABEL (label11), GTK_JUSTIFY_LEFT);

  right_path_entry = gtk_entry_new ();
  gtk_widget_set_name (right_path_entry, "right_path_entry");
  gtk_widget_show (right_path_entry);
  gtk_box_pack_start (GTK_BOX (hbox3), right_path_entry, TRUE, TRUE, 0);
  gtk_widget_set_usize (right_path_entry, 69, -2);
  gtk_widget_set_sensitive (right_path_entry, FALSE);
  GTK_WIDGET_UNSET_FLAGS (right_path_entry, GTK_CAN_FOCUS);
  gtk_entry_set_editable (GTK_ENTRY (right_path_entry), FALSE);
  gtk_entry_set_text (GTK_ENTRY (right_path_entry), _("/"));

  label70 = gtk_label_new ("");
  gtk_widget_set_name (label70, "label70");
  gtk_widget_show (label70);
  gtk_box_pack_start (GTK_BOX (hbox3), label70, FALSE, FALSE, 0);
  gtk_widget_set_usize (label70, 18, -2);
  gtk_label_set_justify (GTK_LABEL (label70), GTK_JUSTIFY_LEFT);

  hbox2 = gtk_hbox_new (FALSE, 0);
  gtk_widget_set_name (hbox2, "hbox2");
  gtk_widget_show (hbox2);
  gtk_box_pack_start (GTK_BOX (vbox1), hbox2, FALSE, TRUE, 0);

  toolbar5 = gtk_toolbar_new ();
  gtk_widget_set_name (toolbar5, "toolbar5");
  gtk_widget_show (toolbar5);
  gtk_box_pack_start (GTK_BOX (hbox2), toolbar5, FALSE, FALSE, 0);
  gtk_toolbar_set_style (GTK_TOOLBAR (toolbar5), GTK_TOOLBAR_BOTH);

  hbox1 = gtk_hbox_new (FALSE, 0);
  gtk_widget_set_name (hbox1, "hbox1");
  gtk_widget_show (hbox1);
  gtk_box_pack_start (GTK_BOX (vbox1), hbox1, TRUE, TRUE, 0);

  label19 = gtk_label_new ("");
  gtk_widget_set_name (label19, "label19");
  gtk_widget_show (label19);
  gtk_box_pack_start (GTK_BOX (hbox1), label19, FALSE, FALSE, 0);
  gtk_widget_set_usize (label19, 13, -2);
  gtk_label_set_justify (GTK_LABEL (label19), GTK_JUSTIFY_LEFT);

  scrolledwindow1 = gtk_scrolled_window_new (NULL, NULL);
  gtk_widget_set_name (scrolledwindow1, "scrolledwindow1");
  gtk_widget_show (scrolledwindow1);
  gtk_box_pack_start (GTK_BOX (hbox1), scrolledwindow1, TRUE, TRUE, 0);
  gtk_widget_set_usize (scrolledwindow1, 77, -2);
  gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (scrolledwindow1), GTK_POLICY_AUTOMATIC, GTK_POLICY_ALWAYS);

  left_treeview = gtk_tree_view_new ();
  gtk_widget_set_name (left_treeview, "left_treeview");
  gtk_widget_show (left_treeview);
  gtk_container_add (GTK_CONTAINER (scrolledwindow1), left_treeview);
  gtk_tree_view_set_rules_hint (GTK_TREE_VIEW (left_treeview), TRUE);

  vbuttonbox1 = gtk_vbutton_box_new ();
  gtk_widget_set_name (vbuttonbox1, "vbuttonbox1");
  gtk_widget_show (vbuttonbox1);
  gtk_box_pack_start (GTK_BOX (hbox1), vbuttonbox1, FALSE, FALSE, 0);
  gtk_button_box_set_spacing (GTK_BUTTON_BOX (vbuttonbox1), 0);

  scrolledwindow2 = gtk_scrolled_window_new (NULL, NULL);
  gtk_widget_set_name (scrolledwindow2, "scrolledwindow2");
  gtk_widget_show (scrolledwindow2);
  gtk_box_pack_start (GTK_BOX (hbox1), scrolledwindow2, TRUE, TRUE, 0);
  gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (scrolledwindow2), GTK_POLICY_AUTOMATIC, GTK_POLICY_ALWAYS);

  right_treeview = gtk_tree_view_new ();
  gtk_widget_set_name (right_treeview, "right_treeview");
  gtk_widget_show (right_treeview);
  gtk_container_add (GTK_CONTAINER (scrolledwindow2), right_treeview);
  gtk_tree_view_set_rules_hint (GTK_TREE_VIEW (right_treeview), TRUE);

  hbox26 = gtk_hbox_new (FALSE, 0);
  gtk_widget_set_name (hbox26, "hbox26");
  gtk_widget_show (hbox26);
  gtk_box_pack_start (GTK_BOX (vbox1), hbox26, FALSE, FALSE, 0);

  left_status_entry = gtk_entry_new ();
  gtk_widget_set_name (left_status_entry, "left_status_entry");
  gtk_widget_show (left_status_entry);
  gtk_box_pack_start (GTK_BOX (hbox26), left_status_entry, TRUE, TRUE, 0);
  gtk_widget_set_sensitive (left_status_entry, FALSE);

  update_both_button = gtk_button_new ();
  gtk_widget_set_name (update_both_button, "update_both_button");
  gtk_widget_show (update_both_button);
  gtk_box_pack_start (GTK_BOX (hbox26), update_both_button, FALSE, FALSE, 0);

  alignment12 = gtk_alignment_new (0.5, 0.5, 0, 0);
  gtk_widget_set_name (alignment12, "alignment12");
  gtk_widget_show (alignment12);
  gtk_container_add (GTK_CONTAINER (update_both_button), alignment12);

  hbox36 = gtk_hbox_new (FALSE, 2);
  gtk_widget_set_name (hbox36, "hbox36");
  gtk_widget_show (hbox36);
  gtk_container_add (GTK_CONTAINER (alignment12), hbox36);

  image12 = gtk_image_new_from_stock ("gtk-refresh", GTK_ICON_SIZE_BUTTON);
  gtk_widget_set_name (image12, "image12");
  gtk_widget_show (image12);
  gtk_box_pack_start (GTK_BOX (hbox36), image12, FALSE, FALSE, 0);

  label63 = gtk_label_new_with_mnemonic ("");
  gtk_widget_set_name (label63, "label63");
  gtk_widget_show (label63);
  gtk_box_pack_start (GTK_BOX (hbox36), label63, FALSE, FALSE, 0);
  gtk_label_set_justify (GTK_LABEL (label63), GTK_JUSTIFY_LEFT);

  right_status_entry = gtk_entry_new ();
  gtk_widget_set_name (right_status_entry, "right_status_entry");
  gtk_widget_show (right_status_entry);
  gtk_box_pack_start (GTK_BOX (hbox26), right_status_entry, TRUE, TRUE, 0);
  gtk_widget_set_usize (right_status_entry, 162, -2);
  gtk_widget_set_sensitive (right_status_entry, FALSE);
  gtk_entry_set_editable (GTK_ENTRY (right_status_entry), FALSE);

  gtk_signal_connect (GTK_OBJECT (scan_button), "clicked",
                      GTK_SIGNAL_FUNC (on_scan_button_clicked),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (connect_button), "clicked",
                      GTK_SIGNAL_FUNC (on_connect_button_clicked),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (disconnect_button), "clicked",
                      GTK_SIGNAL_FUNC (on_disconnect_button_clicked),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (run_info_button), "clicked",
                      GTK_SIGNAL_FUNC (on_run_info_button_clicked),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (help_button), "clicked",
                      GTK_SIGNAL_FUNC (on_help_button_clicked),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (settings_button), "clicked",
                      GTK_SIGNAL_FUNC (on_settings_button_clicked),
                      NULL);
  gtk_signal_connect_object (GTK_OBJECT (quit_button), "clicked",
                             GTK_SIGNAL_FUNC (gtk_widget_destroy),
                             GTK_OBJECT (main_window));
  gtk_signal_connect (GTK_OBJECT (left_treeview), "map",
                      GTK_SIGNAL_FUNC (on_left_treeview_map),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (left_treeview), "button_press_event",
                      GTK_SIGNAL_FUNC (on_left_treeview_button_press_event),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (right_treeview), "button_press_event",
                      GTK_SIGNAL_FUNC (on_right_treeview_button_press_event),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (update_both_button), "clicked",
                      GTK_SIGNAL_FUNC (on_update_both_button_clicked),
                      NULL);

  /* Store pointers to all widgets, for use by lookup_widget(). */
  GLADE_HOOKUP_OBJECT_NO_REF (main_window, main_window, "main_window");
  GLADE_HOOKUP_OBJECT (main_window, vbox1, "vbox1");
  GLADE_HOOKUP_OBJECT (main_window, toolbar1, "toolbar1");
  GLADE_HOOKUP_OBJECT (main_window, scan_button, "scan_button");
  GLADE_HOOKUP_OBJECT (main_window, label18, "label18");
  GLADE_HOOKUP_OBJECT (main_window, combo1, "combo1");
  GLADE_HOOKUP_OBJECT (main_window, ip_entry, "ip_entry");
  GLADE_HOOKUP_OBJECT (main_window, label50, "label50");
  GLADE_HOOKUP_OBJECT (main_window, connect_button, "connect_button");
  GLADE_HOOKUP_OBJECT (main_window, disconnect_button, "disconnect_button");
  GLADE_HOOKUP_OBJECT (main_window, run_info_button, "run_info_button");
  GLADE_HOOKUP_OBJECT (main_window, help_button, "help_button");
  GLADE_HOOKUP_OBJECT (main_window, settings_button, "settings_button");
  GLADE_HOOKUP_OBJECT (main_window, quit_button, "quit_button");
  GLADE_HOOKUP_OBJECT (main_window, toolbar2, "toolbar2");
  GLADE_HOOKUP_OBJECT (main_window, label3, "label3");
  GLADE_HOOKUP_OBJECT (main_window, label51, "label51");
  GLADE_HOOKUP_OBJECT (main_window, user_entry, "user_entry");
  GLADE_HOOKUP_OBJECT (main_window, label4, "label4");
  GLADE_HOOKUP_OBJECT (main_window, password_entry, "password_entry");
  GLADE_HOOKUP_OBJECT (main_window, label36, "label36");
  GLADE_HOOKUP_OBJECT (main_window, hbuttonbox4, "hbuttonbox4");
  GLADE_HOOKUP_OBJECT (main_window, label49, "label49");
  GLADE_HOOKUP_OBJECT (main_window, share_entry, "share_entry");
  GLADE_HOOKUP_OBJECT (main_window, label48, "label48");
  GLADE_HOOKUP_OBJECT (main_window, hbox3, "hbox3");
  GLADE_HOOKUP_OBJECT (main_window, label69, "label69");
  GLADE_HOOKUP_OBJECT (main_window, left_path_entry, "left_path_entry");
  GLADE_HOOKUP_OBJECT (main_window, label11, "label11");
  GLADE_HOOKUP_OBJECT (main_window, right_path_entry, "right_path_entry");
  GLADE_HOOKUP_OBJECT (main_window, label70, "label70");
  GLADE_HOOKUP_OBJECT (main_window, hbox2, "hbox2");
  GLADE_HOOKUP_OBJECT (main_window, toolbar5, "toolbar5");
  GLADE_HOOKUP_OBJECT (main_window, hbox1, "hbox1");
  GLADE_HOOKUP_OBJECT (main_window, label19, "label19");
  GLADE_HOOKUP_OBJECT (main_window, scrolledwindow1, "scrolledwindow1");
  GLADE_HOOKUP_OBJECT (main_window, left_treeview, "left_treeview");
  GLADE_HOOKUP_OBJECT (main_window, vbuttonbox1, "vbuttonbox1");
  GLADE_HOOKUP_OBJECT (main_window, scrolledwindow2, "scrolledwindow2");
  GLADE_HOOKUP_OBJECT (main_window, right_treeview, "right_treeview");
  GLADE_HOOKUP_OBJECT (main_window, hbox26, "hbox26");
  GLADE_HOOKUP_OBJECT (main_window, left_status_entry, "left_status_entry");
  GLADE_HOOKUP_OBJECT (main_window, update_both_button, "update_both_button");
  GLADE_HOOKUP_OBJECT (main_window, alignment12, "alignment12");
  GLADE_HOOKUP_OBJECT (main_window, hbox36, "hbox36");
  GLADE_HOOKUP_OBJECT (main_window, image12, "image12");
  GLADE_HOOKUP_OBJECT (main_window, label63, "label63");
  GLADE_HOOKUP_OBJECT (main_window, right_status_entry, "right_status_entry");

  gtk_widget_grab_default (ip_entry);
  return main_window;
}

GtkWidget*
create_help_window (void)
{
  GtkWidget *help_window;
  GtkWidget *scrolledwindow3;
  GtkWidget *textview1;

  help_window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_widget_set_name (help_window, "help_window");
  gtk_window_set_title (GTK_WINDOW (help_window), _("Gfilemanager help"));
  gtk_window_set_position (GTK_WINDOW (help_window), GTK_WIN_POS_CENTER);
  gtk_window_set_destroy_with_parent (GTK_WINDOW (help_window), TRUE);

  scrolledwindow3 = gtk_scrolled_window_new (NULL, NULL);
  gtk_widget_set_name (scrolledwindow3, "scrolledwindow3");
  gtk_widget_show (scrolledwindow3);
  gtk_container_add (GTK_CONTAINER (help_window), scrolledwindow3);

  textview1 = gtk_text_view_new ();
  gtk_widget_set_name (textview1, "textview1");
  gtk_widget_show (textview1);
  gtk_container_add (GTK_CONTAINER (scrolledwindow3), textview1);
  gtk_widget_set_usize (textview1, 568, 190);
  gtk_text_view_set_editable (GTK_TEXT_VIEW (textview1), FALSE);
  gtk_text_view_set_cursor_visible (GTK_TEXT_VIEW (textview1), FALSE);
  gtk_text_view_set_left_margin (GTK_TEXT_VIEW (textview1), 15);
  gtk_text_view_set_right_margin (GTK_TEXT_VIEW (textview1), 15);
  gtk_text_buffer_set_text (gtk_text_view_get_buffer (GTK_TEXT_VIEW (textview1)),
	_("\n                                             How Gfilemanager works:\n\nTo connect to a samba server: \n\nPress the computer search button to scan the network and choose the server that you\nwant to connect to from the list, type the username and password then press connect.\nYou can skip the scan and just type the servers name in the box.\nThis should let you browse the remote computer.\nFor the scan to work you must have a hostentry in /etc/hosts that looks something like this:\n192.168.0.35 computer.domain computer\n\nGeneral information:\nWhen you doubleclick the left button it will browse the directories up and down,\nclicking on \"..\" will step up one directory as usual.\nWhen you doubleclick the second or third button it will show an action window\nwhere you can select cancel, rename, delete, mkdir or copy.\n\nThe copy button will copy the selected file or directory to the place\nyou are at in the other browser window.\n\nTo rename a file or directory you change its name and then press the rename button.\nTo make a directory you specify the new directory name and then press mkdir.\nNote: You cant use any of these chars in any of them: ? $ / \\ : * < > \" |\n\nIf you doubleclick the left mouse button on a file it will perform an action on it,\nif it has a mimetype (.txt .doc .xls .sdw .sxw .jpg. png .gif .ogg .mp3 .avi .mpg etc).\n\n\nFirewalling:\n\nGfilemanager scans the network id (x.x.y.1-254) to see if any samba ports are open\nusing the portrange ~ 40000-50000 (not needed if you type the hostname yourself).\nThe y range can be adjusted in the settings.\n\nWhen you press connect it sends a broadcast on the broadcast address (x.x.x.255).\nThis must work and you can test it by doing this in a terminal: \nnmblookup X  where X is the name of a samba server on your network.\n\n\nKnown bugs:\n1. Locale specific filenames can be shown by an empty line and cant be downloaded \n    (but if you download the directory above, it will also download the \"broken\" files).\n\n2. Directories with subdirectories cant be deleted recursively. \n\nCreator: Magnus-swe <magnus-swe@telia.com>\n"), -1);

  /* Store pointers to all widgets, for use by lookup_widget(). */
  GLADE_HOOKUP_OBJECT_NO_REF (help_window, help_window, "help_window");
  GLADE_HOOKUP_OBJECT (help_window, scrolledwindow3, "scrolledwindow3");
  GLADE_HOOKUP_OBJECT (help_window, textview1, "textview1");

  return help_window;
}

GtkWidget*
create_right_actions_window (void)
{
  GtkWidget *right_actions_window;
  GtkWidget *vbox2;
  GtkWidget *label14;
  GtkWidget *hseparator1;
  GtkWidget *hbox5;
  GtkWidget *right_rename_entry;
  GtkWidget *right_rename_button;
  GtkWidget *hseparator2;
  GtkWidget *hbox6;
  GtkWidget *right_mkdir_entry;
  GtkWidget *right_mkdir_button;
  GtkWidget *hseparator8;
  GtkWidget *hbox24;
  GtkWidget *right_addfile_entry;
  GtkWidget *right_addfile_button;
  GtkWidget *hseparator3;
  GtkWidget *hbuttonbox2;
  GtkWidget *right_delete_button;
  GtkWidget *right_cancel_button;
  GtkWidget *right_download_button;

  right_actions_window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_widget_set_name (right_actions_window, "right_actions_window");
  gtk_window_set_title (GTK_WINDOW (right_actions_window), _("Right actions"));
  gtk_window_set_position (GTK_WINDOW (right_actions_window), GTK_WIN_POS_CENTER);
  gtk_window_set_modal (GTK_WINDOW (right_actions_window), TRUE);
  gtk_window_set_destroy_with_parent (GTK_WINDOW (right_actions_window), TRUE);

  vbox2 = gtk_vbox_new (FALSE, 0);
  gtk_widget_set_name (vbox2, "vbox2");
  gtk_widget_show (vbox2);
  gtk_container_add (GTK_CONTAINER (right_actions_window), vbox2);

  label14 = gtk_label_new (_("File/directory:"));
  gtk_widget_set_name (label14, "label14");
  gtk_widget_show (label14);
  gtk_box_pack_start (GTK_BOX (vbox2), label14, FALSE, FALSE, 0);
  gtk_label_set_justify (GTK_LABEL (label14), GTK_JUSTIFY_LEFT);

  hseparator1 = gtk_hseparator_new ();
  gtk_widget_set_name (hseparator1, "hseparator1");
  gtk_widget_show (hseparator1);
  gtk_box_pack_start (GTK_BOX (vbox2), hseparator1, FALSE, FALSE, 2);

  hbox5 = gtk_hbox_new (FALSE, 0);
  gtk_widget_set_name (hbox5, "hbox5");
  gtk_widget_show (hbox5);
  gtk_box_pack_start (GTK_BOX (vbox2), hbox5, TRUE, TRUE, 0);

  right_rename_entry = gtk_entry_new ();
  gtk_widget_set_name (right_rename_entry, "right_rename_entry");
  gtk_widget_show (right_rename_entry);
  gtk_box_pack_start (GTK_BOX (hbox5), right_rename_entry, TRUE, TRUE, 0);

  right_rename_button = gtk_button_new_with_mnemonic (_("Rename"));
  gtk_widget_set_name (right_rename_button, "right_rename_button");
  gtk_widget_show (right_rename_button);
  gtk_box_pack_start (GTK_BOX (hbox5), right_rename_button, TRUE, TRUE, 3);

  hseparator2 = gtk_hseparator_new ();
  gtk_widget_set_name (hseparator2, "hseparator2");
  gtk_widget_show (hseparator2);
  gtk_box_pack_start (GTK_BOX (vbox2), hseparator2, FALSE, FALSE, 2);

  hbox6 = gtk_hbox_new (FALSE, 0);
  gtk_widget_set_name (hbox6, "hbox6");
  gtk_widget_show (hbox6);
  gtk_box_pack_start (GTK_BOX (vbox2), hbox6, TRUE, TRUE, 0);

  right_mkdir_entry = gtk_entry_new ();
  gtk_widget_set_name (right_mkdir_entry, "right_mkdir_entry");
  gtk_widget_show (right_mkdir_entry);
  gtk_box_pack_start (GTK_BOX (hbox6), right_mkdir_entry, TRUE, TRUE, 0);
  gtk_widget_set_usize (right_mkdir_entry, 190, -2);

  right_mkdir_button = gtk_button_new_with_mnemonic (_("New directory"));
  gtk_widget_set_name (right_mkdir_button, "right_mkdir_button");
  gtk_widget_show (right_mkdir_button);
  gtk_box_pack_start (GTK_BOX (hbox6), right_mkdir_button, TRUE, TRUE, 3);

  hseparator8 = gtk_hseparator_new ();
  gtk_widget_set_name (hseparator8, "hseparator8");
  gtk_widget_show (hseparator8);
  gtk_box_pack_start (GTK_BOX (vbox2), hseparator8, FALSE, FALSE, 2);

  hbox24 = gtk_hbox_new (FALSE, 0);
  gtk_widget_set_name (hbox24, "hbox24");
  gtk_widget_show (hbox24);
  gtk_box_pack_start (GTK_BOX (vbox2), hbox24, TRUE, TRUE, 0);

  right_addfile_entry = gtk_entry_new ();
  gtk_widget_set_name (right_addfile_entry, "right_addfile_entry");
  gtk_widget_show (right_addfile_entry);
  gtk_box_pack_start (GTK_BOX (hbox24), right_addfile_entry, TRUE, TRUE, 0);

  right_addfile_button = gtk_button_new_with_mnemonic (_("New file"));
  gtk_widget_set_name (right_addfile_button, "right_addfile_button");
  gtk_widget_show (right_addfile_button);
  gtk_box_pack_start (GTK_BOX (hbox24), right_addfile_button, TRUE, TRUE, 3);

  hseparator3 = gtk_hseparator_new ();
  gtk_widget_set_name (hseparator3, "hseparator3");
  gtk_widget_show (hseparator3);
  gtk_box_pack_start (GTK_BOX (vbox2), hseparator3, FALSE, FALSE, 2);

  hbuttonbox2 = gtk_hbutton_box_new ();
  gtk_widget_set_name (hbuttonbox2, "hbuttonbox2");
  gtk_widget_show (hbuttonbox2);
  gtk_box_pack_start (GTK_BOX (vbox2), hbuttonbox2, TRUE, TRUE, 0);
  gtk_button_box_set_layout (GTK_BUTTON_BOX (hbuttonbox2), GTK_BUTTONBOX_EDGE);
  gtk_button_box_set_spacing (GTK_BUTTON_BOX (hbuttonbox2), 0);

  right_delete_button = gtk_button_new_with_mnemonic (_("Delete"));
  gtk_widget_set_name (right_delete_button, "right_delete_button");
  gtk_widget_show (right_delete_button);
  gtk_container_add (GTK_CONTAINER (hbuttonbox2), right_delete_button);
  GTK_WIDGET_SET_FLAGS (right_delete_button, GTK_CAN_DEFAULT);

  right_cancel_button = gtk_button_new_with_mnemonic (_("Cancel"));
  gtk_widget_set_name (right_cancel_button, "right_cancel_button");
  gtk_widget_show (right_cancel_button);
  gtk_container_add (GTK_CONTAINER (hbuttonbox2), right_cancel_button);
  GTK_WIDGET_SET_FLAGS (right_cancel_button, GTK_CAN_DEFAULT);

  right_download_button = gtk_button_new_with_mnemonic (_(" < Copy"));
  gtk_widget_set_name (right_download_button, "right_download_button");
  gtk_widget_show (right_download_button);
  gtk_container_add (GTK_CONTAINER (hbuttonbox2), right_download_button);
  GTK_WIDGET_SET_FLAGS (right_download_button, GTK_CAN_DEFAULT);

  gtk_signal_connect (GTK_OBJECT (right_rename_button), "clicked",
                      GTK_SIGNAL_FUNC (on_right_rename_button_clicked),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (right_mkdir_button), "clicked",
                      GTK_SIGNAL_FUNC (on_right_mkdir_button_clicked),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (right_addfile_button), "clicked",
                      GTK_SIGNAL_FUNC (on_right_addfile_button_clicked),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (right_delete_button), "clicked",
                      GTK_SIGNAL_FUNC (on_right_delete_button_clicked),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (right_cancel_button), "clicked",
                      GTK_SIGNAL_FUNC (on_right_cancel_button_clicked),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (right_download_button), "clicked",
                      GTK_SIGNAL_FUNC (on_right_download_button_clicked),
                      NULL);

  /* Store pointers to all widgets, for use by lookup_widget(). */
  GLADE_HOOKUP_OBJECT_NO_REF (right_actions_window, right_actions_window, "right_actions_window");
  GLADE_HOOKUP_OBJECT (right_actions_window, vbox2, "vbox2");
  GLADE_HOOKUP_OBJECT (right_actions_window, label14, "label14");
  GLADE_HOOKUP_OBJECT (right_actions_window, hseparator1, "hseparator1");
  GLADE_HOOKUP_OBJECT (right_actions_window, hbox5, "hbox5");
  GLADE_HOOKUP_OBJECT (right_actions_window, right_rename_entry, "right_rename_entry");
  GLADE_HOOKUP_OBJECT (right_actions_window, right_rename_button, "right_rename_button");
  GLADE_HOOKUP_OBJECT (right_actions_window, hseparator2, "hseparator2");
  GLADE_HOOKUP_OBJECT (right_actions_window, hbox6, "hbox6");
  GLADE_HOOKUP_OBJECT (right_actions_window, right_mkdir_entry, "right_mkdir_entry");
  GLADE_HOOKUP_OBJECT (right_actions_window, right_mkdir_button, "right_mkdir_button");
  GLADE_HOOKUP_OBJECT (right_actions_window, hseparator8, "hseparator8");
  GLADE_HOOKUP_OBJECT (right_actions_window, hbox24, "hbox24");
  GLADE_HOOKUP_OBJECT (right_actions_window, right_addfile_entry, "right_addfile_entry");
  GLADE_HOOKUP_OBJECT (right_actions_window, right_addfile_button, "right_addfile_button");
  GLADE_HOOKUP_OBJECT (right_actions_window, hseparator3, "hseparator3");
  GLADE_HOOKUP_OBJECT (right_actions_window, hbuttonbox2, "hbuttonbox2");
  GLADE_HOOKUP_OBJECT (right_actions_window, right_delete_button, "right_delete_button");
  GLADE_HOOKUP_OBJECT (right_actions_window, right_cancel_button, "right_cancel_button");
  GLADE_HOOKUP_OBJECT (right_actions_window, right_download_button, "right_download_button");

  gtk_widget_grab_focus (right_rename_entry);
  return right_actions_window;
}

GtkWidget*
create_left_actions_window (void)
{
  GtkWidget *left_actions_window;
  GtkWidget *vbox3;
  GtkWidget *label15;
  GtkWidget *hseparator4;
  GtkWidget *hbox9;
  GtkWidget *left_rename_entry;
  GtkWidget *left_rename_button;
  GtkWidget *hseparator5;
  GtkWidget *hbox10;
  GtkWidget *left_mkdir_entry;
  GtkWidget *left_mkdir_button;
  GtkWidget *hseparator7;
  GtkWidget *hbox23;
  GtkWidget *left_addfile_entry;
  GtkWidget *left_addfile_button;
  GtkWidget *hseparator6;
  GtkWidget *hbuttonbox1;
  GtkWidget *left_delete_button;
  GtkWidget *left_cancel_button;
  GtkWidget *left_upload_button;

  left_actions_window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_widget_set_name (left_actions_window, "left_actions_window");
  gtk_window_set_title (GTK_WINDOW (left_actions_window), _("Left actions"));
  gtk_window_set_position (GTK_WINDOW (left_actions_window), GTK_WIN_POS_CENTER);
  gtk_window_set_modal (GTK_WINDOW (left_actions_window), TRUE);
  gtk_window_set_destroy_with_parent (GTK_WINDOW (left_actions_window), TRUE);

  vbox3 = gtk_vbox_new (FALSE, 0);
  gtk_widget_set_name (vbox3, "vbox3");
  gtk_widget_show (vbox3);
  gtk_container_add (GTK_CONTAINER (left_actions_window), vbox3);

  label15 = gtk_label_new (_("File/directory:"));
  gtk_widget_set_name (label15, "label15");
  gtk_widget_show (label15);
  gtk_box_pack_start (GTK_BOX (vbox3), label15, FALSE, FALSE, 0);
  gtk_label_set_justify (GTK_LABEL (label15), GTK_JUSTIFY_LEFT);

  hseparator4 = gtk_hseparator_new ();
  gtk_widget_set_name (hseparator4, "hseparator4");
  gtk_widget_show (hseparator4);
  gtk_box_pack_start (GTK_BOX (vbox3), hseparator4, FALSE, FALSE, 2);

  hbox9 = gtk_hbox_new (FALSE, 0);
  gtk_widget_set_name (hbox9, "hbox9");
  gtk_widget_show (hbox9);
  gtk_box_pack_start (GTK_BOX (vbox3), hbox9, TRUE, TRUE, 0);

  left_rename_entry = gtk_entry_new ();
  gtk_widget_set_name (left_rename_entry, "left_rename_entry");
  gtk_widget_show (left_rename_entry);
  gtk_box_pack_start (GTK_BOX (hbox9), left_rename_entry, TRUE, TRUE, 0);
  gtk_widget_set_usize (left_rename_entry, 158, -2);

  left_rename_button = gtk_button_new_with_mnemonic (_("Rename"));
  gtk_widget_set_name (left_rename_button, "left_rename_button");
  gtk_widget_show (left_rename_button);
  gtk_box_pack_start (GTK_BOX (hbox9), left_rename_button, TRUE, TRUE, 3);

  hseparator5 = gtk_hseparator_new ();
  gtk_widget_set_name (hseparator5, "hseparator5");
  gtk_widget_show (hseparator5);
  gtk_box_pack_start (GTK_BOX (vbox3), hseparator5, FALSE, FALSE, 2);

  hbox10 = gtk_hbox_new (FALSE, 0);
  gtk_widget_set_name (hbox10, "hbox10");
  gtk_widget_show (hbox10);
  gtk_box_pack_start (GTK_BOX (vbox3), hbox10, TRUE, TRUE, 0);

  left_mkdir_entry = gtk_entry_new ();
  gtk_widget_set_name (left_mkdir_entry, "left_mkdir_entry");
  gtk_widget_show (left_mkdir_entry);
  gtk_box_pack_start (GTK_BOX (hbox10), left_mkdir_entry, TRUE, TRUE, 0);
  gtk_widget_set_usize (left_mkdir_entry, 190, -2);

  left_mkdir_button = gtk_button_new_with_mnemonic (_("New directory"));
  gtk_widget_set_name (left_mkdir_button, "left_mkdir_button");
  gtk_widget_show (left_mkdir_button);
  gtk_box_pack_start (GTK_BOX (hbox10), left_mkdir_button, TRUE, TRUE, 3);

  hseparator7 = gtk_hseparator_new ();
  gtk_widget_set_name (hseparator7, "hseparator7");
  gtk_widget_show (hseparator7);
  gtk_box_pack_start (GTK_BOX (vbox3), hseparator7, FALSE, FALSE, 2);

  hbox23 = gtk_hbox_new (FALSE, 0);
  gtk_widget_set_name (hbox23, "hbox23");
  gtk_widget_show (hbox23);
  gtk_box_pack_start (GTK_BOX (vbox3), hbox23, TRUE, TRUE, 0);

  left_addfile_entry = gtk_entry_new ();
  gtk_widget_set_name (left_addfile_entry, "left_addfile_entry");
  gtk_widget_show (left_addfile_entry);
  gtk_box_pack_start (GTK_BOX (hbox23), left_addfile_entry, TRUE, TRUE, 0);
  gtk_widget_set_usize (left_addfile_entry, 158, -2);

  left_addfile_button = gtk_button_new_with_mnemonic (_("New file"));
  gtk_widget_set_name (left_addfile_button, "left_addfile_button");
  gtk_widget_show (left_addfile_button);
  gtk_box_pack_start (GTK_BOX (hbox23), left_addfile_button, TRUE, TRUE, 3);

  hseparator6 = gtk_hseparator_new ();
  gtk_widget_set_name (hseparator6, "hseparator6");
  gtk_widget_show (hseparator6);
  gtk_box_pack_start (GTK_BOX (vbox3), hseparator6, FALSE, FALSE, 2);

  hbuttonbox1 = gtk_hbutton_box_new ();
  gtk_widget_set_name (hbuttonbox1, "hbuttonbox1");
  gtk_widget_show (hbuttonbox1);
  gtk_box_pack_start (GTK_BOX (vbox3), hbuttonbox1, TRUE, TRUE, 0);
  gtk_button_box_set_layout (GTK_BUTTON_BOX (hbuttonbox1), GTK_BUTTONBOX_EDGE);
  gtk_button_box_set_spacing (GTK_BUTTON_BOX (hbuttonbox1), 0);

  left_delete_button = gtk_button_new_with_mnemonic (_("Delete"));
  gtk_widget_set_name (left_delete_button, "left_delete_button");
  gtk_widget_show (left_delete_button);
  gtk_container_add (GTK_CONTAINER (hbuttonbox1), left_delete_button);
  GTK_WIDGET_SET_FLAGS (left_delete_button, GTK_CAN_DEFAULT);

  left_cancel_button = gtk_button_new_with_mnemonic (_("Cancel"));
  gtk_widget_set_name (left_cancel_button, "left_cancel_button");
  gtk_widget_show (left_cancel_button);
  gtk_container_add (GTK_CONTAINER (hbuttonbox1), left_cancel_button);
  GTK_WIDGET_SET_FLAGS (left_cancel_button, GTK_CAN_DEFAULT);

  left_upload_button = gtk_button_new_with_mnemonic (_("Copy >"));
  gtk_widget_set_name (left_upload_button, "left_upload_button");
  gtk_widget_show (left_upload_button);
  gtk_container_add (GTK_CONTAINER (hbuttonbox1), left_upload_button);
  GTK_WIDGET_SET_FLAGS (left_upload_button, GTK_CAN_DEFAULT);

  gtk_signal_connect (GTK_OBJECT (left_rename_button), "clicked",
                      GTK_SIGNAL_FUNC (on_left_rename_button_clicked),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (left_mkdir_button), "clicked",
                      GTK_SIGNAL_FUNC (on_left_mkdir_button_clicked),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (left_addfile_button), "clicked",
                      GTK_SIGNAL_FUNC (on_left_addfile_button_clicked),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (left_delete_button), "clicked",
                      GTK_SIGNAL_FUNC (on_left_delete_button_clicked),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (left_cancel_button), "clicked",
                      GTK_SIGNAL_FUNC (on_left_cancel_button_clicked),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (left_upload_button), "clicked",
                      GTK_SIGNAL_FUNC (on_left_upload_button_clicked),
                      NULL);

  /* Store pointers to all widgets, for use by lookup_widget(). */
  GLADE_HOOKUP_OBJECT_NO_REF (left_actions_window, left_actions_window, "left_actions_window");
  GLADE_HOOKUP_OBJECT (left_actions_window, vbox3, "vbox3");
  GLADE_HOOKUP_OBJECT (left_actions_window, label15, "label15");
  GLADE_HOOKUP_OBJECT (left_actions_window, hseparator4, "hseparator4");
  GLADE_HOOKUP_OBJECT (left_actions_window, hbox9, "hbox9");
  GLADE_HOOKUP_OBJECT (left_actions_window, left_rename_entry, "left_rename_entry");
  GLADE_HOOKUP_OBJECT (left_actions_window, left_rename_button, "left_rename_button");
  GLADE_HOOKUP_OBJECT (left_actions_window, hseparator5, "hseparator5");
  GLADE_HOOKUP_OBJECT (left_actions_window, hbox10, "hbox10");
  GLADE_HOOKUP_OBJECT (left_actions_window, left_mkdir_entry, "left_mkdir_entry");
  GLADE_HOOKUP_OBJECT (left_actions_window, left_mkdir_button, "left_mkdir_button");
  GLADE_HOOKUP_OBJECT (left_actions_window, hseparator7, "hseparator7");
  GLADE_HOOKUP_OBJECT (left_actions_window, hbox23, "hbox23");
  GLADE_HOOKUP_OBJECT (left_actions_window, left_addfile_entry, "left_addfile_entry");
  GLADE_HOOKUP_OBJECT (left_actions_window, left_addfile_button, "left_addfile_button");
  GLADE_HOOKUP_OBJECT (left_actions_window, hseparator6, "hseparator6");
  GLADE_HOOKUP_OBJECT (left_actions_window, hbuttonbox1, "hbuttonbox1");
  GLADE_HOOKUP_OBJECT (left_actions_window, left_delete_button, "left_delete_button");
  GLADE_HOOKUP_OBJECT (left_actions_window, left_cancel_button, "left_cancel_button");
  GLADE_HOOKUP_OBJECT (left_actions_window, left_upload_button, "left_upload_button");

  gtk_widget_grab_focus (left_rename_entry);
  return left_actions_window;
}

GtkWidget*
create_status_window (void)
{
  GtkWidget *status_window;
  GtkWidget *vbox4;
  GtkWidget *label17;
  GtkWidget *scan_progress;
  GtkWidget *scan_entry;
  GtkWidget *cancel_scan_button;
  GtkWidget *alignment3;
  GtkWidget *hbox27;
  GtkWidget *image3;
  GtkWidget *label53;

  status_window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_widget_set_name (status_window, "status_window");
  gtk_widget_set_usize (status_window, 450, 94);
  gtk_window_set_title (GTK_WINDOW (status_window), _("Scanning the network for samba servers."));
  gtk_window_set_position (GTK_WINDOW (status_window), GTK_WIN_POS_CENTER);
  gtk_window_set_destroy_with_parent (GTK_WINDOW (status_window), TRUE);

  vbox4 = gtk_vbox_new (FALSE, 0);
  gtk_widget_set_name (vbox4, "vbox4");
  gtk_widget_show (vbox4);
  gtk_container_add (GTK_CONTAINER (status_window), vbox4);

  label17 = gtk_label_new (_("  "));
  gtk_widget_set_name (label17, "label17");
  gtk_widget_show (label17);
  gtk_box_pack_start (GTK_BOX (vbox4), label17, FALSE, FALSE, 0);
  gtk_label_set_justify (GTK_LABEL (label17), GTK_JUSTIFY_LEFT);

  scan_progress = gtk_progress_bar_new ();
  gtk_widget_set_name (scan_progress, "scan_progress");
  gtk_widget_show (scan_progress);
  gtk_box_pack_start (GTK_BOX (vbox4), scan_progress, FALSE, FALSE, 0);
  gtk_progress_bar_set_pulse_step (GTK_PROGRESS_BAR (scan_progress), 0.05);
  gtk_progress_set_show_text (GTK_PROGRESS (scan_progress), TRUE);

  scan_entry = gtk_entry_new ();
  gtk_widget_set_name (scan_entry, "scan_entry");
  gtk_widget_show (scan_entry);
  gtk_box_pack_start (GTK_BOX (vbox4), scan_entry, FALSE, FALSE, 0);
  gtk_widget_set_sensitive (scan_entry, FALSE);
  gtk_entry_set_editable (GTK_ENTRY (scan_entry), FALSE);

  cancel_scan_button = gtk_button_new ();
  gtk_widget_set_name (cancel_scan_button, "cancel_scan_button");
  gtk_widget_show (cancel_scan_button);
  gtk_box_pack_start (GTK_BOX (vbox4), cancel_scan_button, FALSE, FALSE, 0);

  alignment3 = gtk_alignment_new (0.5, 0.5, 0, 0);
  gtk_widget_set_name (alignment3, "alignment3");
  gtk_widget_show (alignment3);
  gtk_container_add (GTK_CONTAINER (cancel_scan_button), alignment3);
  GTK_WIDGET_SET_FLAGS (alignment3, GTK_CAN_FOCUS);
  GTK_WIDGET_SET_FLAGS (alignment3, GTK_CAN_DEFAULT);

  hbox27 = gtk_hbox_new (FALSE, 2);
  gtk_widget_set_name (hbox27, "hbox27");
  gtk_widget_show (hbox27);
  gtk_container_add (GTK_CONTAINER (alignment3), hbox27);

  image3 = gtk_image_new_from_stock ("gtk-cancel", GTK_ICON_SIZE_BUTTON);
  gtk_widget_set_name (image3, "image3");
  gtk_widget_show (image3);
  gtk_box_pack_start (GTK_BOX (hbox27), image3, FALSE, FALSE, 0);

  label53 = gtk_label_new_with_mnemonic (_("Cancel"));
  gtk_widget_set_name (label53, "label53");
  gtk_widget_show (label53);
  gtk_box_pack_start (GTK_BOX (hbox27), label53, FALSE, FALSE, 0);
  gtk_label_set_justify (GTK_LABEL (label53), GTK_JUSTIFY_LEFT);

  gtk_signal_connect (GTK_OBJECT (status_window), "map",
                      GTK_SIGNAL_FUNC (on_status_window_map),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (cancel_scan_button), "clicked",
                      GTK_SIGNAL_FUNC (on_cancel_scan_button_clicked),
                      NULL);

  /* Store pointers to all widgets, for use by lookup_widget(). */
  GLADE_HOOKUP_OBJECT_NO_REF (status_window, status_window, "status_window");
  GLADE_HOOKUP_OBJECT (status_window, vbox4, "vbox4");
  GLADE_HOOKUP_OBJECT (status_window, label17, "label17");
  GLADE_HOOKUP_OBJECT (status_window, scan_progress, "scan_progress");
  GLADE_HOOKUP_OBJECT (status_window, scan_entry, "scan_entry");
  GLADE_HOOKUP_OBJECT (status_window, cancel_scan_button, "cancel_scan_button");
  GLADE_HOOKUP_OBJECT (status_window, alignment3, "alignment3");
  GLADE_HOOKUP_OBJECT (status_window, hbox27, "hbox27");
  GLADE_HOOKUP_OBJECT (status_window, image3, "image3");
  GLADE_HOOKUP_OBJECT (status_window, label53, "label53");

  gtk_widget_grab_focus (alignment3);
  gtk_widget_grab_default (alignment3);
  return status_window;
}

GtkWidget*
create_settings_window (void)
{
  GtkWidget *settings_window;
  GtkWidget *vbox5;
  GtkWidget *scrolledwindow4;
  GtkWidget *viewport1;
  GtkWidget *vbox6;
  GtkWidget *label24;
  GtkWidget *hbox13;
  GtkWidget *label25;
  GtkWidget *label29;
  GtkWidget *music_entry;
  GtkWidget *hbox14;
  GtkWidget *label26;
  GtkWidget *label30;
  GtkWidget *video_entry;
  GtkWidget *hbox15;
  GtkWidget *label27;
  GtkWidget *label34;
  GtkWidget *graphics_entry;
  GtkWidget *hbox16;
  GtkWidget *label28;
  GtkWidget *label31;
  GtkWidget *text_entry;
  GtkWidget *hbox17;
  GtkWidget *label32;
  GtkWidget *label33;
  GtkWidget *document_entry;
  GtkWidget *hbox18;
  GtkWidget *label35;
  GtkWidget *spreadsheet_entry;
  GtkWidget *hbox25;
  GtkWidget *label46;
  GtkWidget *label47;
  GtkWidget *html_entry;
  GtkWidget *hbox22;
  GtkWidget *label44;
  GtkWidget *label45;
  GtkWidget *sourcecode_entry;
  GtkWidget *label40;
  GtkWidget *hbox19;
  GtkWidget *label39;
  GtkWidget *hidden_checkbutton;
  GtkWidget *hbox21;
  GtkWidget *label41;
  GtkWidget *label43;
  GtkObject *scanrange_spinbutton_adj;
  GtkWidget *scanrange_spinbutton;
  GtkWidget *label42;
  GtkWidget *label52;
  GtkObject *scantimeout_spinbutton_adj;
  GtkWidget *scantimeout_spinbutton;
  GtkWidget *label22;
  GtkWidget *hbuttonbox3;
  GtkWidget *settings_cancel_button;
  GtkWidget *alignment2;
  GtkWidget *hbox12;
  GtkWidget *image2;
  GtkWidget *label21;
  GtkWidget *settings_ok_button;
  GtkWidget *alignment1;
  GtkWidget *hbox11;
  GtkWidget *image1;
  GtkWidget *label20;
  GtkWidget *label23;

  settings_window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_widget_set_name (settings_window, "settings_window");
  gtk_widget_set_usize (settings_window, 540, 290);
  gtk_window_set_title (GTK_WINDOW (settings_window), _("Gfilemanager Settings"));
  gtk_window_set_position (GTK_WINDOW (settings_window), GTK_WIN_POS_CENTER);
  gtk_window_set_destroy_with_parent (GTK_WINDOW (settings_window), TRUE);

  vbox5 = gtk_vbox_new (FALSE, 0);
  gtk_widget_set_name (vbox5, "vbox5");
  gtk_widget_show (vbox5);
  gtk_container_add (GTK_CONTAINER (settings_window), vbox5);

  scrolledwindow4 = gtk_scrolled_window_new (NULL, NULL);
  gtk_widget_set_name (scrolledwindow4, "scrolledwindow4");
  gtk_widget_show (scrolledwindow4);
  gtk_box_pack_start (GTK_BOX (vbox5), scrolledwindow4, TRUE, TRUE, 0);
  gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (scrolledwindow4), GTK_POLICY_NEVER, GTK_POLICY_ALWAYS);

  viewport1 = gtk_viewport_new (NULL, NULL);
  gtk_widget_set_name (viewport1, "viewport1");
  gtk_widget_show (viewport1);
  gtk_container_add (GTK_CONTAINER (scrolledwindow4), viewport1);

  vbox6 = gtk_vbox_new (FALSE, 0);
  gtk_widget_set_name (vbox6, "vbox6");
  gtk_widget_show (vbox6);
  gtk_container_add (GTK_CONTAINER (viewport1), vbox6);

  label24 = gtk_label_new (_("  Select your preferred programs to open different files."));
  gtk_widget_set_name (label24, "label24");
  gtk_widget_show (label24);
  gtk_box_pack_start (GTK_BOX (vbox6), label24, FALSE, FALSE, 0);
  gtk_label_set_justify (GTK_LABEL (label24), GTK_JUSTIFY_LEFT);

  hbox13 = gtk_hbox_new (FALSE, 0);
  gtk_widget_set_name (hbox13, "hbox13");
  gtk_widget_show (hbox13);
  gtk_box_pack_start (GTK_BOX (vbox6), hbox13, TRUE, TRUE, 0);

  label25 = gtk_label_new (_(" Music:"));
  gtk_widget_set_name (label25, "label25");
  gtk_widget_show (label25);
  gtk_box_pack_start (GTK_BOX (hbox13), label25, FALSE, FALSE, 0);
  gtk_label_set_justify (GTK_LABEL (label25), GTK_JUSTIFY_LEFT);

  label29 = gtk_label_new ("");
  gtk_widget_set_name (label29, "label29");
  gtk_widget_show (label29);
  gtk_box_pack_start (GTK_BOX (hbox13), label29, FALSE, FALSE, 0);
  gtk_widget_set_usize (label29, 42, -2);
  gtk_label_set_justify (GTK_LABEL (label29), GTK_JUSTIFY_LEFT);

  music_entry = gtk_entry_new ();
  gtk_widget_set_name (music_entry, "music_entry");
  gtk_widget_show (music_entry);
  gtk_box_pack_start (GTK_BOX (hbox13), music_entry, TRUE, TRUE, 0);

  hbox14 = gtk_hbox_new (FALSE, 0);
  gtk_widget_set_name (hbox14, "hbox14");
  gtk_widget_show (hbox14);
  gtk_box_pack_start (GTK_BOX (vbox6), hbox14, TRUE, TRUE, 0);

  label26 = gtk_label_new (_(" Video: "));
  gtk_widget_set_name (label26, "label26");
  gtk_widget_show (label26);
  gtk_box_pack_start (GTK_BOX (hbox14), label26, FALSE, FALSE, 0);
  gtk_label_set_justify (GTK_LABEL (label26), GTK_JUSTIFY_LEFT);

  label30 = gtk_label_new ("");
  gtk_widget_set_name (label30, "label30");
  gtk_widget_show (label30);
  gtk_box_pack_start (GTK_BOX (hbox14), label30, FALSE, FALSE, 0);
  gtk_widget_set_usize (label30, 40, -2);
  gtk_label_set_justify (GTK_LABEL (label30), GTK_JUSTIFY_LEFT);

  video_entry = gtk_entry_new ();
  gtk_widget_set_name (video_entry, "video_entry");
  gtk_widget_show (video_entry);
  gtk_box_pack_start (GTK_BOX (hbox14), video_entry, TRUE, TRUE, 0);

  hbox15 = gtk_hbox_new (FALSE, 0);
  gtk_widget_set_name (hbox15, "hbox15");
  gtk_widget_show (hbox15);
  gtk_box_pack_start (GTK_BOX (vbox6), hbox15, FALSE, FALSE, 0);

  label27 = gtk_label_new (_(" Graphics: "));
  gtk_widget_set_name (label27, "label27");
  gtk_widget_show (label27);
  gtk_box_pack_start (GTK_BOX (hbox15), label27, FALSE, FALSE, 0);
  gtk_label_set_justify (GTK_LABEL (label27), GTK_JUSTIFY_LEFT);

  label34 = gtk_label_new ("");
  gtk_widget_set_name (label34, "label34");
  gtk_widget_show (label34);
  gtk_box_pack_start (GTK_BOX (hbox15), label34, FALSE, FALSE, 0);
  gtk_widget_set_usize (label34, 21, -2);
  gtk_label_set_justify (GTK_LABEL (label34), GTK_JUSTIFY_LEFT);

  graphics_entry = gtk_entry_new ();
  gtk_widget_set_name (graphics_entry, "graphics_entry");
  gtk_widget_show (graphics_entry);
  gtk_box_pack_start (GTK_BOX (hbox15), graphics_entry, TRUE, TRUE, 0);

  hbox16 = gtk_hbox_new (FALSE, 0);
  gtk_widget_set_name (hbox16, "hbox16");
  gtk_widget_show (hbox16);
  gtk_box_pack_start (GTK_BOX (vbox6), hbox16, TRUE, TRUE, 0);

  label28 = gtk_label_new (_(" Text: "));
  gtk_widget_set_name (label28, "label28");
  gtk_widget_show (label28);
  gtk_box_pack_start (GTK_BOX (hbox16), label28, FALSE, FALSE, 0);
  gtk_label_set_justify (GTK_LABEL (label28), GTK_JUSTIFY_LEFT);

  label31 = gtk_label_new ("");
  gtk_widget_set_name (label31, "label31");
  gtk_widget_show (label31);
  gtk_box_pack_start (GTK_BOX (hbox16), label31, FALSE, FALSE, 0);
  gtk_widget_set_usize (label31, 47, -2);
  gtk_label_set_justify (GTK_LABEL (label31), GTK_JUSTIFY_LEFT);

  text_entry = gtk_entry_new ();
  gtk_widget_set_name (text_entry, "text_entry");
  gtk_widget_show (text_entry);
  gtk_box_pack_start (GTK_BOX (hbox16), text_entry, TRUE, TRUE, 0);

  hbox17 = gtk_hbox_new (FALSE, 0);
  gtk_widget_set_name (hbox17, "hbox17");
  gtk_widget_show (hbox17);
  gtk_box_pack_start (GTK_BOX (vbox6), hbox17, TRUE, TRUE, 0);

  label32 = gtk_label_new (_(" Document:"));
  gtk_widget_set_name (label32, "label32");
  gtk_widget_show (label32);
  gtk_box_pack_start (GTK_BOX (hbox17), label32, FALSE, FALSE, 0);
  gtk_label_set_justify (GTK_LABEL (label32), GTK_JUSTIFY_LEFT);

  label33 = gtk_label_new ("");
  gtk_widget_set_name (label33, "label33");
  gtk_widget_show (label33);
  gtk_box_pack_start (GTK_BOX (hbox17), label33, FALSE, FALSE, 0);
  gtk_widget_set_usize (label33, 18, -2);
  gtk_label_set_justify (GTK_LABEL (label33), GTK_JUSTIFY_LEFT);

  document_entry = gtk_entry_new ();
  gtk_widget_set_name (document_entry, "document_entry");
  gtk_widget_show (document_entry);
  gtk_box_pack_start (GTK_BOX (hbox17), document_entry, TRUE, TRUE, 0);

  hbox18 = gtk_hbox_new (FALSE, 0);
  gtk_widget_set_name (hbox18, "hbox18");
  gtk_widget_show (hbox18);
  gtk_box_pack_start (GTK_BOX (vbox6), hbox18, TRUE, TRUE, 0);

  label35 = gtk_label_new (_(" Spreadsheet: "));
  gtk_widget_set_name (label35, "label35");
  gtk_widget_show (label35);
  gtk_box_pack_start (GTK_BOX (hbox18), label35, FALSE, FALSE, 0);
  gtk_label_set_justify (GTK_LABEL (label35), GTK_JUSTIFY_LEFT);

  spreadsheet_entry = gtk_entry_new ();
  gtk_widget_set_name (spreadsheet_entry, "spreadsheet_entry");
  gtk_widget_show (spreadsheet_entry);
  gtk_box_pack_start (GTK_BOX (hbox18), spreadsheet_entry, TRUE, TRUE, 0);

  hbox25 = gtk_hbox_new (FALSE, 0);
  gtk_widget_set_name (hbox25, "hbox25");
  gtk_widget_show (hbox25);
  gtk_box_pack_start (GTK_BOX (vbox6), hbox25, TRUE, TRUE, 0);

  label46 = gtk_label_new (_(" Webcode:"));
  gtk_widget_set_name (label46, "label46");
  gtk_widget_show (label46);
  gtk_box_pack_start (GTK_BOX (hbox25), label46, FALSE, FALSE, 0);
  gtk_label_set_justify (GTK_LABEL (label46), GTK_JUSTIFY_LEFT);

  label47 = gtk_label_new (_(" "));
  gtk_widget_set_name (label47, "label47");
  gtk_widget_show (label47);
  gtk_box_pack_start (GTK_BOX (hbox25), label47, FALSE, FALSE, 0);
  gtk_widget_set_usize (label47, 23, -2);
  gtk_label_set_justify (GTK_LABEL (label47), GTK_JUSTIFY_LEFT);

  html_entry = gtk_entry_new ();
  gtk_widget_set_name (html_entry, "html_entry");
  gtk_widget_show (html_entry);
  gtk_box_pack_start (GTK_BOX (hbox25), html_entry, TRUE, TRUE, 0);

  hbox22 = gtk_hbox_new (FALSE, 0);
  gtk_widget_set_name (hbox22, "hbox22");
  gtk_widget_show (hbox22);
  gtk_box_pack_start (GTK_BOX (vbox6), hbox22, TRUE, TRUE, 0);

  label44 = gtk_label_new (_(" Sourcecode:"));
  gtk_widget_set_name (label44, "label44");
  gtk_widget_show (label44);
  gtk_box_pack_start (GTK_BOX (hbox22), label44, FALSE, FALSE, 0);
  gtk_label_set_justify (GTK_LABEL (label44), GTK_JUSTIFY_LEFT);

  label45 = gtk_label_new ("");
  gtk_widget_set_name (label45, "label45");
  gtk_widget_show (label45);
  gtk_box_pack_start (GTK_BOX (hbox22), label45, FALSE, FALSE, 0);
  gtk_widget_set_usize (label45, 8, -2);
  gtk_label_set_justify (GTK_LABEL (label45), GTK_JUSTIFY_LEFT);

  sourcecode_entry = gtk_entry_new ();
  gtk_widget_set_name (sourcecode_entry, "sourcecode_entry");
  gtk_widget_show (sourcecode_entry);
  gtk_box_pack_start (GTK_BOX (hbox22), sourcecode_entry, TRUE, TRUE, 0);

  label40 = gtk_label_new (_("Extended browser features.                                    "));
  gtk_widget_set_name (label40, "label40");
  gtk_widget_show (label40);
  gtk_box_pack_start (GTK_BOX (vbox6), label40, FALSE, FALSE, 0);
  gtk_label_set_justify (GTK_LABEL (label40), GTK_JUSTIFY_LEFT);

  hbox19 = gtk_hbox_new (FALSE, 0);
  gtk_widget_set_name (hbox19, "hbox19");
  gtk_widget_show (hbox19);
  gtk_box_pack_start (GTK_BOX (vbox6), hbox19, TRUE, TRUE, 0);

  label39 = gtk_label_new (_(" Show hidden files/directories:"));
  gtk_widget_set_name (label39, "label39");
  gtk_widget_show (label39);
  gtk_box_pack_start (GTK_BOX (hbox19), label39, FALSE, FALSE, 0);
  gtk_label_set_justify (GTK_LABEL (label39), GTK_JUSTIFY_LEFT);

  hidden_checkbutton = gtk_check_button_new_with_mnemonic ("");
  gtk_widget_set_name (hidden_checkbutton, "hidden_checkbutton");
  gtk_widget_show (hidden_checkbutton);
  gtk_box_pack_start (GTK_BOX (hbox19), hidden_checkbutton, FALSE, FALSE, 0);

  hbox21 = gtk_hbox_new (FALSE, 0);
  gtk_widget_set_name (hbox21, "hbox21");
  gtk_widget_show (hbox21);
  gtk_box_pack_start (GTK_BOX (vbox6), hbox21, TRUE, TRUE, 0);

  label41 = gtk_label_new (_(" Scan to X.X. "));
  gtk_widget_set_name (label41, "label41");
  gtk_widget_show (label41);
  gtk_box_pack_start (GTK_BOX (hbox21), label41, FALSE, FALSE, 0);
  gtk_label_set_justify (GTK_LABEL (label41), GTK_JUSTIFY_LEFT);

  label43 = gtk_label_new ("");
  gtk_widget_set_name (label43, "label43");
  gtk_widget_show (label43);
  gtk_box_pack_start (GTK_BOX (hbox21), label43, FALSE, FALSE, 0);
  gtk_widget_set_usize (label43, 1, -2);
  gtk_label_set_justify (GTK_LABEL (label43), GTK_JUSTIFY_LEFT);

  scanrange_spinbutton_adj = gtk_adjustment_new (0, 0, 254, 1, 10, 10);
  scanrange_spinbutton = gtk_spin_button_new (GTK_ADJUSTMENT (scanrange_spinbutton_adj), 1, 0);
  gtk_widget_set_name (scanrange_spinbutton, "scanrange_spinbutton");
  gtk_widget_show (scanrange_spinbutton);
  gtk_box_pack_start (GTK_BOX (hbox21), scanrange_spinbutton, FALSE, FALSE, 0);

  label42 = gtk_label_new (_(" .X"));
  gtk_widget_set_name (label42, "label42");
  gtk_widget_show (label42);
  gtk_box_pack_start (GTK_BOX (hbox21), label42, FALSE, FALSE, 0);
  gtk_label_set_justify (GTK_LABEL (label42), GTK_JUSTIFY_LEFT);

  label52 = gtk_label_new (_("  Scan-timeout per host in microseconds: "));
  gtk_widget_set_name (label52, "label52");
  gtk_widget_show (label52);
  gtk_box_pack_start (GTK_BOX (hbox21), label52, FALSE, FALSE, 0);
  gtk_label_set_justify (GTK_LABEL (label52), GTK_JUSTIFY_LEFT);

  scantimeout_spinbutton_adj = gtk_adjustment_new (100000, 1, 100000, 1, 10, 10);
  scantimeout_spinbutton = gtk_spin_button_new (GTK_ADJUSTMENT (scantimeout_spinbutton_adj), 1, 0);
  gtk_widget_set_name (scantimeout_spinbutton, "scantimeout_spinbutton");
  gtk_widget_show (scantimeout_spinbutton);
  gtk_box_pack_start (GTK_BOX (hbox21), scantimeout_spinbutton, FALSE, FALSE, 0);
  gtk_widget_set_usize (scantimeout_spinbutton, 79, -2);

  label22 = gtk_label_new ("");
  gtk_widget_set_name (label22, "label22");
  gtk_widget_show (label22);
  gtk_box_pack_start (GTK_BOX (vbox5), label22, FALSE, FALSE, 0);
  gtk_widget_set_usize (label22, -2, 16);
  gtk_label_set_justify (GTK_LABEL (label22), GTK_JUSTIFY_LEFT);

  hbuttonbox3 = gtk_hbutton_box_new ();
  gtk_widget_set_name (hbuttonbox3, "hbuttonbox3");
  gtk_widget_show (hbuttonbox3);
  gtk_box_pack_start (GTK_BOX (vbox5), hbuttonbox3, FALSE, FALSE, 0);
  gtk_button_box_set_layout (GTK_BUTTON_BOX (hbuttonbox3), GTK_BUTTONBOX_SPREAD);
  gtk_button_box_set_spacing (GTK_BUTTON_BOX (hbuttonbox3), 2);

  settings_cancel_button = gtk_button_new ();
  gtk_widget_set_name (settings_cancel_button, "settings_cancel_button");
  gtk_widget_show (settings_cancel_button);
  gtk_container_add (GTK_CONTAINER (hbuttonbox3), settings_cancel_button);
  GTK_WIDGET_SET_FLAGS (settings_cancel_button, GTK_CAN_DEFAULT);

  alignment2 = gtk_alignment_new (0.5, 0.5, 0, 0);
  gtk_widget_set_name (alignment2, "alignment2");
  gtk_widget_show (alignment2);
  gtk_container_add (GTK_CONTAINER (settings_cancel_button), alignment2);

  hbox12 = gtk_hbox_new (FALSE, 2);
  gtk_widget_set_name (hbox12, "hbox12");
  gtk_widget_show (hbox12);
  gtk_container_add (GTK_CONTAINER (alignment2), hbox12);

  image2 = gtk_image_new_from_stock ("gtk-cancel", GTK_ICON_SIZE_BUTTON);
  gtk_widget_set_name (image2, "image2");
  gtk_widget_show (image2);
  gtk_box_pack_start (GTK_BOX (hbox12), image2, FALSE, FALSE, 0);

  label21 = gtk_label_new_with_mnemonic (_("Cancel"));
  gtk_widget_set_name (label21, "label21");
  gtk_widget_show (label21);
  gtk_box_pack_start (GTK_BOX (hbox12), label21, FALSE, FALSE, 0);
  gtk_label_set_justify (GTK_LABEL (label21), GTK_JUSTIFY_LEFT);

  settings_ok_button = gtk_button_new ();
  gtk_widget_set_name (settings_ok_button, "settings_ok_button");
  gtk_widget_show (settings_ok_button);
  gtk_container_add (GTK_CONTAINER (hbuttonbox3), settings_ok_button);
  GTK_WIDGET_SET_FLAGS (settings_ok_button, GTK_CAN_DEFAULT);

  alignment1 = gtk_alignment_new (0.5, 0.5, 0, 0);
  gtk_widget_set_name (alignment1, "alignment1");
  gtk_widget_show (alignment1);
  gtk_container_add (GTK_CONTAINER (settings_ok_button), alignment1);

  hbox11 = gtk_hbox_new (FALSE, 2);
  gtk_widget_set_name (hbox11, "hbox11");
  gtk_widget_show (hbox11);
  gtk_container_add (GTK_CONTAINER (alignment1), hbox11);

  image1 = gtk_image_new_from_stock ("gtk-ok", GTK_ICON_SIZE_BUTTON);
  gtk_widget_set_name (image1, "image1");
  gtk_widget_show (image1);
  gtk_box_pack_start (GTK_BOX (hbox11), image1, FALSE, FALSE, 0);

  label20 = gtk_label_new_with_mnemonic (_("OK"));
  gtk_widget_set_name (label20, "label20");
  gtk_widget_show (label20);
  gtk_box_pack_start (GTK_BOX (hbox11), label20, FALSE, FALSE, 0);
  gtk_label_set_justify (GTK_LABEL (label20), GTK_JUSTIFY_LEFT);

  label23 = gtk_label_new ("");
  gtk_widget_set_name (label23, "label23");
  gtk_widget_show (label23);
  gtk_box_pack_start (GTK_BOX (vbox5), label23, FALSE, FALSE, 0);
  gtk_widget_set_usize (label23, -2, 16);
  gtk_label_set_justify (GTK_LABEL (label23), GTK_JUSTIFY_LEFT);

  gtk_signal_connect (GTK_OBJECT (settings_window), "map",
                      GTK_SIGNAL_FUNC (on_settings_window_map),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (hidden_checkbutton), "toggled",
                      GTK_SIGNAL_FUNC (on_hidden_checkbutton_toggled),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (scanrange_spinbutton), "value_changed",
                      GTK_SIGNAL_FUNC (on_scanrange_spinbutton_value_changed),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (scantimeout_spinbutton), "value_changed",
                      GTK_SIGNAL_FUNC (on_scantimeout_spinbutton_value_changed),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (settings_cancel_button), "clicked",
                      GTK_SIGNAL_FUNC (on_settings_cancel_button_clicked),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (settings_ok_button), "clicked",
                      GTK_SIGNAL_FUNC (on_settings_ok_button_clicked),
                      NULL);

  /* Store pointers to all widgets, for use by lookup_widget(). */
  GLADE_HOOKUP_OBJECT_NO_REF (settings_window, settings_window, "settings_window");
  GLADE_HOOKUP_OBJECT (settings_window, vbox5, "vbox5");
  GLADE_HOOKUP_OBJECT (settings_window, scrolledwindow4, "scrolledwindow4");
  GLADE_HOOKUP_OBJECT (settings_window, viewport1, "viewport1");
  GLADE_HOOKUP_OBJECT (settings_window, vbox6, "vbox6");
  GLADE_HOOKUP_OBJECT (settings_window, label24, "label24");
  GLADE_HOOKUP_OBJECT (settings_window, hbox13, "hbox13");
  GLADE_HOOKUP_OBJECT (settings_window, label25, "label25");
  GLADE_HOOKUP_OBJECT (settings_window, label29, "label29");
  GLADE_HOOKUP_OBJECT (settings_window, music_entry, "music_entry");
  GLADE_HOOKUP_OBJECT (settings_window, hbox14, "hbox14");
  GLADE_HOOKUP_OBJECT (settings_window, label26, "label26");
  GLADE_HOOKUP_OBJECT (settings_window, label30, "label30");
  GLADE_HOOKUP_OBJECT (settings_window, video_entry, "video_entry");
  GLADE_HOOKUP_OBJECT (settings_window, hbox15, "hbox15");
  GLADE_HOOKUP_OBJECT (settings_window, label27, "label27");
  GLADE_HOOKUP_OBJECT (settings_window, label34, "label34");
  GLADE_HOOKUP_OBJECT (settings_window, graphics_entry, "graphics_entry");
  GLADE_HOOKUP_OBJECT (settings_window, hbox16, "hbox16");
  GLADE_HOOKUP_OBJECT (settings_window, label28, "label28");
  GLADE_HOOKUP_OBJECT (settings_window, label31, "label31");
  GLADE_HOOKUP_OBJECT (settings_window, text_entry, "text_entry");
  GLADE_HOOKUP_OBJECT (settings_window, hbox17, "hbox17");
  GLADE_HOOKUP_OBJECT (settings_window, label32, "label32");
  GLADE_HOOKUP_OBJECT (settings_window, label33, "label33");
  GLADE_HOOKUP_OBJECT (settings_window, document_entry, "document_entry");
  GLADE_HOOKUP_OBJECT (settings_window, hbox18, "hbox18");
  GLADE_HOOKUP_OBJECT (settings_window, label35, "label35");
  GLADE_HOOKUP_OBJECT (settings_window, spreadsheet_entry, "spreadsheet_entry");
  GLADE_HOOKUP_OBJECT (settings_window, hbox25, "hbox25");
  GLADE_HOOKUP_OBJECT (settings_window, label46, "label46");
  GLADE_HOOKUP_OBJECT (settings_window, label47, "label47");
  GLADE_HOOKUP_OBJECT (settings_window, html_entry, "html_entry");
  GLADE_HOOKUP_OBJECT (settings_window, hbox22, "hbox22");
  GLADE_HOOKUP_OBJECT (settings_window, label44, "label44");
  GLADE_HOOKUP_OBJECT (settings_window, label45, "label45");
  GLADE_HOOKUP_OBJECT (settings_window, sourcecode_entry, "sourcecode_entry");
  GLADE_HOOKUP_OBJECT (settings_window, label40, "label40");
  GLADE_HOOKUP_OBJECT (settings_window, hbox19, "hbox19");
  GLADE_HOOKUP_OBJECT (settings_window, label39, "label39");
  GLADE_HOOKUP_OBJECT (settings_window, hidden_checkbutton, "hidden_checkbutton");
  GLADE_HOOKUP_OBJECT (settings_window, hbox21, "hbox21");
  GLADE_HOOKUP_OBJECT (settings_window, label41, "label41");
  GLADE_HOOKUP_OBJECT (settings_window, label43, "label43");
  GLADE_HOOKUP_OBJECT (settings_window, scanrange_spinbutton, "scanrange_spinbutton");
  GLADE_HOOKUP_OBJECT (settings_window, label42, "label42");
  GLADE_HOOKUP_OBJECT (settings_window, label52, "label52");
  GLADE_HOOKUP_OBJECT (settings_window, scantimeout_spinbutton, "scantimeout_spinbutton");
  GLADE_HOOKUP_OBJECT (settings_window, label22, "label22");
  GLADE_HOOKUP_OBJECT (settings_window, hbuttonbox3, "hbuttonbox3");
  GLADE_HOOKUP_OBJECT (settings_window, settings_cancel_button, "settings_cancel_button");
  GLADE_HOOKUP_OBJECT (settings_window, alignment2, "alignment2");
  GLADE_HOOKUP_OBJECT (settings_window, hbox12, "hbox12");
  GLADE_HOOKUP_OBJECT (settings_window, image2, "image2");
  GLADE_HOOKUP_OBJECT (settings_window, label21, "label21");
  GLADE_HOOKUP_OBJECT (settings_window, settings_ok_button, "settings_ok_button");
  GLADE_HOOKUP_OBJECT (settings_window, alignment1, "alignment1");
  GLADE_HOOKUP_OBJECT (settings_window, hbox11, "hbox11");
  GLADE_HOOKUP_OBJECT (settings_window, image1, "image1");
  GLADE_HOOKUP_OBJECT (settings_window, label20, "label20");
  GLADE_HOOKUP_OBJECT (settings_window, label23, "label23");

  return settings_window;
}

GtkWidget*
create_archive_window (void)
{
  GtkWidget *archive_window;
  GtkWidget *vbox7;
  GtkWidget *label57;
  GtkWidget *scrolledwindow5;
  GtkWidget *archive_textview;
  GtkWidget *hbuttonbox5;
  GtkWidget *archive_install_button;
  GtkWidget *alignment9;
  GtkWidget *hbox33;
  GtkWidget *image9;
  GtkWidget *label60;
  GtkWidget *archive_close_button;
  GtkWidget *alignment11;
  GtkWidget *hbox35;
  GtkWidget *image11;
  GtkWidget *label62;

  archive_window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_widget_set_name (archive_window, "archive_window");
  gtk_widget_set_usize (archive_window, 610, 300);
  gtk_window_set_title (GTK_WINDOW (archive_window), _("Gfilemanager archive handler"));
  gtk_window_set_position (GTK_WINDOW (archive_window), GTK_WIN_POS_CENTER);

  vbox7 = gtk_vbox_new (FALSE, 0);
  gtk_widget_set_name (vbox7, "vbox7");
  gtk_widget_show (vbox7);
  gtk_container_add (GTK_CONTAINER (archive_window), vbox7);

  label57 = gtk_label_new (_("Archive Information:"));
  gtk_widget_set_name (label57, "label57");
  gtk_widget_show (label57);
  gtk_box_pack_start (GTK_BOX (vbox7), label57, FALSE, FALSE, 0);
  gtk_label_set_justify (GTK_LABEL (label57), GTK_JUSTIFY_LEFT);

  scrolledwindow5 = gtk_scrolled_window_new (NULL, NULL);
  gtk_widget_set_name (scrolledwindow5, "scrolledwindow5");
  gtk_widget_show (scrolledwindow5);
  gtk_box_pack_start (GTK_BOX (vbox7), scrolledwindow5, TRUE, TRUE, 0);
  gtk_widget_set_usize (scrolledwindow5, 400, 160);
  gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (scrolledwindow5), GTK_POLICY_AUTOMATIC, GTK_POLICY_ALWAYS);
  gtk_scrolled_window_set_shadow_type (GTK_SCROLLED_WINDOW (scrolledwindow5), GTK_SHADOW_IN);

  archive_textview = gtk_text_view_new ();
  gtk_widget_set_name (archive_textview, "archive_textview");
  gtk_widget_show (archive_textview);
  gtk_container_add (GTK_CONTAINER (scrolledwindow5), archive_textview);
  gtk_container_set_border_width (GTK_CONTAINER (archive_textview), 5);
  gtk_text_view_set_editable (GTK_TEXT_VIEW (archive_textview), FALSE);
  gtk_text_view_set_cursor_visible (GTK_TEXT_VIEW (archive_textview), FALSE);
  gtk_text_view_set_left_margin (GTK_TEXT_VIEW (archive_textview), 5);
  gtk_text_view_set_right_margin (GTK_TEXT_VIEW (archive_textview), 5);

  hbuttonbox5 = gtk_hbutton_box_new ();
  gtk_widget_set_name (hbuttonbox5, "hbuttonbox5");
  gtk_widget_show (hbuttonbox5);
  gtk_box_pack_start (GTK_BOX (vbox7), hbuttonbox5, FALSE, FALSE, 0);
  gtk_button_box_set_layout (GTK_BUTTON_BOX (hbuttonbox5), GTK_BUTTONBOX_SPREAD);
  gtk_button_box_set_spacing (GTK_BUTTON_BOX (hbuttonbox5), 0);

  archive_install_button = gtk_button_new ();
  gtk_widget_set_name (archive_install_button, "archive_install_button");
  gtk_widget_show (archive_install_button);
  gtk_container_add (GTK_CONTAINER (hbuttonbox5), archive_install_button);
  GTK_WIDGET_SET_FLAGS (archive_install_button, GTK_CAN_DEFAULT);

  alignment9 = gtk_alignment_new (0.5, 0.5, 0, 0);
  gtk_widget_set_name (alignment9, "alignment9");
  gtk_widget_show (alignment9);
  gtk_container_add (GTK_CONTAINER (archive_install_button), alignment9);

  hbox33 = gtk_hbox_new (FALSE, 2);
  gtk_widget_set_name (hbox33, "hbox33");
  gtk_widget_show (hbox33);
  gtk_container_add (GTK_CONTAINER (alignment9), hbox33);

  image9 = gtk_image_new_from_stock ("gtk-add", GTK_ICON_SIZE_BUTTON);
  gtk_widget_set_name (image9, "image9");
  gtk_widget_show (image9);
  gtk_box_pack_start (GTK_BOX (hbox33), image9, FALSE, FALSE, 0);

  label60 = gtk_label_new_with_mnemonic (_("Install"));
  gtk_widget_set_name (label60, "label60");
  gtk_widget_show (label60);
  gtk_box_pack_start (GTK_BOX (hbox33), label60, FALSE, FALSE, 0);
  gtk_label_set_justify (GTK_LABEL (label60), GTK_JUSTIFY_LEFT);

  archive_close_button = gtk_button_new ();
  gtk_widget_set_name (archive_close_button, "archive_close_button");
  gtk_widget_show (archive_close_button);
  gtk_container_add (GTK_CONTAINER (hbuttonbox5), archive_close_button);
  GTK_WIDGET_SET_FLAGS (archive_close_button, GTK_CAN_DEFAULT);

  alignment11 = gtk_alignment_new (0.5, 0.5, 0, 0);
  gtk_widget_set_name (alignment11, "alignment11");
  gtk_widget_show (alignment11);
  gtk_container_add (GTK_CONTAINER (archive_close_button), alignment11);

  hbox35 = gtk_hbox_new (FALSE, 2);
  gtk_widget_set_name (hbox35, "hbox35");
  gtk_widget_show (hbox35);
  gtk_container_add (GTK_CONTAINER (alignment11), hbox35);

  image11 = gtk_image_new_from_stock ("gtk-cancel", GTK_ICON_SIZE_BUTTON);
  gtk_widget_set_name (image11, "image11");
  gtk_widget_show (image11);
  gtk_box_pack_start (GTK_BOX (hbox35), image11, FALSE, FALSE, 0);

  label62 = gtk_label_new_with_mnemonic (_("Close"));
  gtk_widget_set_name (label62, "label62");
  gtk_widget_show (label62);
  gtk_box_pack_start (GTK_BOX (hbox35), label62, FALSE, FALSE, 0);
  gtk_label_set_justify (GTK_LABEL (label62), GTK_JUSTIFY_LEFT);

  gtk_signal_connect (GTK_OBJECT (archive_textview), "map",
                      GTK_SIGNAL_FUNC (on_archive_textview_map),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (archive_install_button), "clicked",
                      GTK_SIGNAL_FUNC (on_archive_install_button_clicked),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (archive_close_button), "clicked",
                      GTK_SIGNAL_FUNC (on_archive_close_button_clicked),
                      NULL);

  /* Store pointers to all widgets, for use by lookup_widget(). */
  GLADE_HOOKUP_OBJECT_NO_REF (archive_window, archive_window, "archive_window");
  GLADE_HOOKUP_OBJECT (archive_window, vbox7, "vbox7");
  GLADE_HOOKUP_OBJECT (archive_window, label57, "label57");
  GLADE_HOOKUP_OBJECT (archive_window, scrolledwindow5, "scrolledwindow5");
  GLADE_HOOKUP_OBJECT (archive_window, archive_textview, "archive_textview");
  GLADE_HOOKUP_OBJECT (archive_window, hbuttonbox5, "hbuttonbox5");
  GLADE_HOOKUP_OBJECT (archive_window, archive_install_button, "archive_install_button");
  GLADE_HOOKUP_OBJECT (archive_window, alignment9, "alignment9");
  GLADE_HOOKUP_OBJECT (archive_window, hbox33, "hbox33");
  GLADE_HOOKUP_OBJECT (archive_window, image9, "image9");
  GLADE_HOOKUP_OBJECT (archive_window, label60, "label60");
  GLADE_HOOKUP_OBJECT (archive_window, archive_close_button, "archive_close_button");
  GLADE_HOOKUP_OBJECT (archive_window, alignment11, "alignment11");
  GLADE_HOOKUP_OBJECT (archive_window, hbox35, "hbox35");
  GLADE_HOOKUP_OBJECT (archive_window, image11, "image11");
  GLADE_HOOKUP_OBJECT (archive_window, label62, "label62");

  return archive_window;
}

GtkWidget*
create_run_info_window (void)
{
  GtkWidget *run_info_window;
  GtkWidget *vbox8;
  GtkWidget *label64;
  GtkWidget *scrolledwindow6;
  GtkWidget *disc_treeview;
  GtkWidget *label65;
  GtkWidget *label66;
  GtkWidget *hseparator9;
  GtkWidget *scrolledwindow7;
  GtkWidget *run_command_textview;
  GtkWidget *hbox38;
  GtkWidget *label67;
  GtkWidget *run_command_entry;
  GtkWidget *label68;
  GtkWidget *hbuttonbox6;
  GtkWidget *run_command_button;
  GtkWidget *close_run_info_button;

  run_info_window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_widget_set_name (run_info_window, "run_info_window");
  gtk_window_set_title (GTK_WINDOW (run_info_window), _("Run / info."));
  gtk_window_set_position (GTK_WINDOW (run_info_window), GTK_WIN_POS_CENTER);

  vbox8 = gtk_vbox_new (FALSE, 0);
  gtk_widget_set_name (vbox8, "vbox8");
  gtk_widget_show (vbox8);
  gtk_container_add (GTK_CONTAINER (run_info_window), vbox8);

  label64 = gtk_label_new (_("DiscUsage."));
  gtk_widget_set_name (label64, "label64");
  gtk_widget_show (label64);
  gtk_box_pack_start (GTK_BOX (vbox8), label64, FALSE, FALSE, 0);
  gtk_label_set_justify (GTK_LABEL (label64), GTK_JUSTIFY_LEFT);

  scrolledwindow6 = gtk_scrolled_window_new (NULL, NULL);
  gtk_widget_set_name (scrolledwindow6, "scrolledwindow6");
  gtk_widget_show (scrolledwindow6);
  gtk_box_pack_start (GTK_BOX (vbox8), scrolledwindow6, FALSE, TRUE, 0);
  gtk_widget_set_usize (scrolledwindow6, 574, 130);

  disc_treeview = gtk_tree_view_new ();
  gtk_widget_set_name (disc_treeview, "disc_treeview");
  gtk_widget_show (disc_treeview);
  gtk_container_add (GTK_CONTAINER (scrolledwindow6), disc_treeview);
  gtk_tree_view_set_rules_hint (GTK_TREE_VIEW (disc_treeview), TRUE);
  gtk_tree_view_set_enable_search (GTK_TREE_VIEW (disc_treeview), FALSE);

  label65 = gtk_label_new ("");
  gtk_widget_set_name (label65, "label65");
  gtk_widget_show (label65);
  gtk_box_pack_start (GTK_BOX (vbox8), label65, FALSE, FALSE, 0);
  gtk_widget_set_usize (label65, -2, 16);
  gtk_label_set_justify (GTK_LABEL (label65), GTK_JUSTIFY_LEFT);

  label66 = gtk_label_new (_("Run a command like:   locate -i *.ogg -n 30"));
  gtk_widget_set_name (label66, "label66");
  gtk_widget_show (label66);
  gtk_box_pack_start (GTK_BOX (vbox8), label66, FALSE, FALSE, 0);
  gtk_label_set_justify (GTK_LABEL (label66), GTK_JUSTIFY_LEFT);

  hseparator9 = gtk_hseparator_new ();
  gtk_widget_set_name (hseparator9, "hseparator9");
  gtk_widget_show (hseparator9);
  gtk_box_pack_start (GTK_BOX (vbox8), hseparator9, FALSE, TRUE, 0);
  gtk_widget_set_usize (hseparator9, -2, 6);

  scrolledwindow7 = gtk_scrolled_window_new (NULL, NULL);
  gtk_widget_set_name (scrolledwindow7, "scrolledwindow7");
  gtk_widget_show (scrolledwindow7);
  gtk_box_pack_start (GTK_BOX (vbox8), scrolledwindow7, TRUE, TRUE, 0);
  gtk_widget_set_usize (scrolledwindow7, -2, 130);

  run_command_textview = gtk_text_view_new ();
  gtk_widget_set_name (run_command_textview, "run_command_textview");
  gtk_widget_show (run_command_textview);
  gtk_container_add (GTK_CONTAINER (scrolledwindow7), run_command_textview);
  gtk_text_view_set_pixels_above_lines (GTK_TEXT_VIEW (run_command_textview), 5);
  gtk_text_view_set_pixels_below_lines (GTK_TEXT_VIEW (run_command_textview), 5);
  gtk_text_view_set_left_margin (GTK_TEXT_VIEW (run_command_textview), 5);
  gtk_text_view_set_right_margin (GTK_TEXT_VIEW (run_command_textview), 5);

  hbox38 = gtk_hbox_new (FALSE, 0);
  gtk_widget_set_name (hbox38, "hbox38");
  gtk_widget_show (hbox38);
  gtk_box_pack_start (GTK_BOX (vbox8), hbox38, FALSE, TRUE, 0);

  label67 = gtk_label_new (_(" Command: "));
  gtk_widget_set_name (label67, "label67");
  gtk_widget_show (label67);
  gtk_box_pack_start (GTK_BOX (hbox38), label67, FALSE, FALSE, 0);
  gtk_label_set_justify (GTK_LABEL (label67), GTK_JUSTIFY_LEFT);

  run_command_entry = gtk_entry_new ();
  gtk_widget_set_name (run_command_entry, "run_command_entry");
  gtk_widget_show (run_command_entry);
  gtk_box_pack_start (GTK_BOX (hbox38), run_command_entry, TRUE, TRUE, 0);
  GTK_WIDGET_SET_FLAGS (run_command_entry, GTK_CAN_DEFAULT);
  gtk_entry_set_activates_default (GTK_ENTRY (run_command_entry), TRUE);

  label68 = gtk_label_new ("");
  gtk_widget_set_name (label68, "label68");
  gtk_widget_show (label68);
  gtk_box_pack_start (GTK_BOX (hbox38), label68, FALSE, FALSE, 0);
  gtk_widget_set_usize (label68, 18, -2);
  gtk_label_set_justify (GTK_LABEL (label68), GTK_JUSTIFY_LEFT);

  hbuttonbox6 = gtk_hbutton_box_new ();
  gtk_widget_set_name (hbuttonbox6, "hbuttonbox6");
  gtk_widget_show (hbuttonbox6);
  gtk_box_pack_start (GTK_BOX (vbox8), hbuttonbox6, FALSE, FALSE, 0);
  gtk_button_box_set_layout (GTK_BUTTON_BOX (hbuttonbox6), GTK_BUTTONBOX_SPREAD);
  gtk_button_box_set_spacing (GTK_BUTTON_BOX (hbuttonbox6), 0);

  run_command_button = gtk_button_new_with_mnemonic (_("Run"));
  gtk_widget_set_name (run_command_button, "run_command_button");
  gtk_widget_show (run_command_button);
  gtk_container_add (GTK_CONTAINER (hbuttonbox6), run_command_button);
  GTK_WIDGET_SET_FLAGS (run_command_button, GTK_CAN_DEFAULT);

  close_run_info_button = gtk_button_new_with_mnemonic (_("Close"));
  gtk_widget_set_name (close_run_info_button, "close_run_info_button");
  gtk_widget_show (close_run_info_button);
  gtk_container_add (GTK_CONTAINER (hbuttonbox6), close_run_info_button);
  GTK_WIDGET_SET_FLAGS (close_run_info_button, GTK_CAN_DEFAULT);

  gtk_signal_connect (GTK_OBJECT (run_info_window), "map",
                      GTK_SIGNAL_FUNC (on_run_info_window_map),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (run_command_button), "clicked",
                      GTK_SIGNAL_FUNC (on_run_command_button_clicked),
                      NULL);
  gtk_signal_connect (GTK_OBJECT (close_run_info_button), "clicked",
                      GTK_SIGNAL_FUNC (on_close_run_info_button_clicked),
                      NULL);

  /* Store pointers to all widgets, for use by lookup_widget(). */
  GLADE_HOOKUP_OBJECT_NO_REF (run_info_window, run_info_window, "run_info_window");
  GLADE_HOOKUP_OBJECT (run_info_window, vbox8, "vbox8");
  GLADE_HOOKUP_OBJECT (run_info_window, label64, "label64");
  GLADE_HOOKUP_OBJECT (run_info_window, scrolledwindow6, "scrolledwindow6");
  GLADE_HOOKUP_OBJECT (run_info_window, disc_treeview, "disc_treeview");
  GLADE_HOOKUP_OBJECT (run_info_window, label65, "label65");
  GLADE_HOOKUP_OBJECT (run_info_window, label66, "label66");
  GLADE_HOOKUP_OBJECT (run_info_window, hseparator9, "hseparator9");
  GLADE_HOOKUP_OBJECT (run_info_window, scrolledwindow7, "scrolledwindow7");
  GLADE_HOOKUP_OBJECT (run_info_window, run_command_textview, "run_command_textview");
  GLADE_HOOKUP_OBJECT (run_info_window, hbox38, "hbox38");
  GLADE_HOOKUP_OBJECT (run_info_window, label67, "label67");
  GLADE_HOOKUP_OBJECT (run_info_window, run_command_entry, "run_command_entry");
  GLADE_HOOKUP_OBJECT (run_info_window, label68, "label68");
  GLADE_HOOKUP_OBJECT (run_info_window, hbuttonbox6, "hbuttonbox6");
  GLADE_HOOKUP_OBJECT (run_info_window, run_command_button, "run_command_button");
  GLADE_HOOKUP_OBJECT (run_info_window, close_run_info_button, "close_run_info_button");

  gtk_widget_grab_focus (run_command_entry);
  gtk_widget_grab_default (run_command_entry);
  return run_info_window;
}

