/* GAdmin-Antivirus - An easy to use GTK+ frontend for clamav antivirus.
 * Copyright (C) 2010 - 2014 Magnus Loef <magnus-swe@telia.com> 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
*/



#include "../config.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <gtk/gtk.h>
#include "gettext.h"
#include "widgets.h"
#include "show_info.h"
#include "make_settings_checkbuttons.h"
#include "make_settings_entries.h"
#include "make_settings_spinbuttons.h"
#include "make_settings_combos.h"
#include "create_settings_tab.h"
#include "scan_menu.h"
#include "save_scan_settings.h"


/* Adds file or directory path to the treeview */
void
show_path_filesel(struct w *widgets)
{
    GtkWidget *dialog;
    GtkTreeIter iter;
    int dlg_ret = 0;
    gchar *utf8 = NULL;
    gchar *path = NULL;

    /* Show the filechooser dialog */
    dialog = gtk_file_chooser_dialog_new(_("Select directory"),
        NULL,
        GTK_FILE_CHOOSER_ACTION_SELECT_FOLDER,
        _("Cancel"), GTK_RESPONSE_CANCEL, _("Ok"),
        GTK_RESPONSE_ACCEPT, NULL);

    dlg_ret = gtk_dialog_run(GTK_DIALOG(dialog));

    if(dlg_ret == GTK_RESPONSE_ACCEPT)
    {
        path = gtk_file_chooser_get_current_folder(GTK_FILE_CHOOSER(dialog));
    }

    if(path == NULL)
    {
        printf("Filechooser: Got no path.\n");
        gtk_widget_destroy(dialog);
        return;
    }

    utf8 = g_locale_to_utf8(path, strlen(path), NULL, NULL, NULL);

    /* Insert the scan source in the treeview row */
    gtk_list_store_append(GTK_LIST_STORE(widgets->scan_store), &iter);
    gtk_list_store_set(widgets->scan_store, &iter, 0, utf8, -1);
    if(utf8 != NULL)
        g_free(utf8);

    g_free(path);

    /* Check the enable scan checkbutton[3] in the treeview */
    gtk_list_store_set(widgets->scan_store, &iter, 3, TRUE, -1);

    gtk_widget_destroy(dialog);

    /* Save the scan selection ... */
    save_scan_settings(widgets);
}
