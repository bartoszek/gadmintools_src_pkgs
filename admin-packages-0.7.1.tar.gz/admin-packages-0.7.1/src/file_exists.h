
#ifndef FILE_EXISTS_H
#define FILE_EXISTS_H

int file_exists(char *file);

#endif
