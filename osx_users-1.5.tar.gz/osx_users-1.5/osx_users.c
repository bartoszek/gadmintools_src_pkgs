/*
 * Userhandling functions for Mac OSX
 * Copyright (C) 2004: Magnus-swe <magnus-swe@telia.com>
 *
 * Ryan Werber: testing, bugreporting and suggestions.
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307, USA.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include <errno.h>
#include <limits.h>

#ifndef _XOPEN_SOURCE
#define _XOPEN_SOURCE
#endif


/* Comment out the line below to test it on Linux */
#define USE_DARWIN 1

#if ! defined USE_DARWIN
    #ifndef _CRYPT_H
    #include <crypt.h>
    #endif
#endif


/* The minimum acceptable password length */
#define MIN_PASS_LENGTH 6

/* Define to 1 if you can use MD5 encrypted passwords */
/* Otherwise DES passwords will be used */
#define HAVE_CRYPT 1

/* This file will be created from nidump passwd /
 * itll then be read and removed (cant use /etc/passwd) */
#define GP_OSX_PASS_DUMP "/etc/gp_osx_passdump"

/* Program version */
#define OSX_USERS_VERSION "1.5"



char *
encrypt_password( char *password )
{
    /* Make an encrypted password using the DES or MD5 algoritm */
    int i=0, where=0, randlen=8; /* The max MD5 random stringsize is 8 */
    char *rnd_string;
    char salt[13]=""; /* The total salt length is 12 if MD5 */

    /* 64 chars */
    char *arr[]={"A","B","C","D","E","F","G","H","I","J","K",
		 "L","M","N","O","P","Q","R","S","T","U","V",
		 "W","X","Y","Z","a","b","c","d","e","f","g",
		 "h","i","j","k","l","m","n","o","p","q","r",
		 "s","t","u","v","w","x","y","z","0","1","2",
		 "3","4","5","6","7","8","9",".","/"};
    
    srand((unsigned)time(NULL));

    rnd_string=(char *)malloc(9);
    bzero(rnd_string, 9);
    
    while( i < randlen )
    {
	where=rand()%64;
	strcat(rnd_string, arr[where]);
	i++;
    }

    if( HAVE_CRYPT )
    {
	/* For this to work it must have linked with -lcrypt */
	sprintf(salt, "$1$%s$", rnd_string);
    }
    else
      {
	 /* We cant use MD5 salting and the salt can only be 2 chars */
	 sprintf(salt, "%s", &rnd_string[6]);
      }

    free(rnd_string);

    return crypt(password, salt);
}


int
is_digitz(char *buf)
{
    int i=0, match=0;
    for(i=0; buf[i]!='\0'; i++)
    {
        if( buf[i]=='\n' || buf[i]=='\r')
        {
           i--;
	   break;
        }
	if( buf[i]=='0' || buf[i]=='1' || buf[i]=='2' || buf[i]=='3' || buf[i]=='4' 
	 || buf[i]=='5' || buf[i]=='6' || buf[i]=='7' || buf[i]=='8' || buf[i]=='9' )
	 match++;	 
    }

    if( match && match==i )
    {
       return 1;
    }
    else
       return 0;    
}


int 
niutil_run_command( char *command )
{
    /* Run a command */
    FILE * fp;
    int i=0;

    if((fp=popen(command, "r"))==NULL)
    {
        printf("\nError running %s\n", command);
    }
    else
      {
	  pclose(fp);
	  i=1;
      }

    return i;
}


int
file_exists( char *entity )
{
    FILE *fp;
    int i=0;

    if((fp=fopen(entity, "r"))==NULL)
    {
	/* We dont need to show this here */
    }
    else
      {
	  fclose(fp);
	  i=1;
      }

    return i;
}


int
unlink_file()
{
    char *command;
    int unlink=0;

    if( ! file_exists(GP_OSX_PASS_DUMP) )
    {
	printf("Unlink: the file [%s] does not exist.\n", GP_OSX_PASS_DUMP);
	unlink=1;
    }
    else
      {
	  command=(char *)malloc(8192);
	  bzero(command, 8192);

	  /* Remove the temporary file */
	  sprintf(command, "rm -f /etc/%s", GP_OSX_PASS_DUMP);
	  if( ! niutil_run_command(command) )
	  {
    	     printf("Error running: %s\n", command);
	     free(command);
	     exit (1);
	  }
    	  
	  free(command);
          unlink=1;
      }

    return unlink;
}


int
niutil_user_exists( char *username )
{
    /* Checks if the system user exists */
    FILE *fp;
    long size_buffer;
    int x, user_exists=0;
    char tempname[4096]="";
    char *check_buffer, *command;

    command=(char *)malloc(8192);
    bzero(command, 8192);

    sprintf(command, "/usr/bin/nidump passwd / > %s", GP_OSX_PASS_DUMP);

    if( ! niutil_run_command(command) )
    {
	free(command);
        return user_exists;
    }

    free(command);

    /* Checks if the user exists in passwd */
    if((fp=fopen(GP_OSX_PASS_DUMP,"r"))==NULL)
    {
	printf("Cannot open the nidump:ed passwd file.\n");
    	return user_exists;
    }
    else
      {
	    fseek(fp, 0, SEEK_END);
	    size_buffer = ftell(fp);
	    rewind(fp);
	    check_buffer=(char *)malloc(size_buffer);
	    bzero(check_buffer, size_buffer);
	    while(fgets(check_buffer, size_buffer, fp)!=NULL)
	    {
		for(x=0; check_buffer[x]; x++)
		{
		    if(check_buffer[x]==':')
		    {
			sprintf(tempname, check_buffer);
			tempname[x]='\0';
			if( ! strcmp(username, tempname) )
			{
			    user_exists=1;
			    break;
			}
		    }
		    if( check_buffer[x]=='\0' || check_buffer[x]=='\n' )
		    break;
		}
		if( user_exists )
		  break;
	    }
	    free(check_buffer);
	    fclose(fp);
      }

    unlink_file();
    return user_exists;
}


int
get_free_uid_above_500_()
{
    FILE *fp;
    int i=0, begin=0, end=0, colon=0;
    long length, uid=0, num=0;
    char *command, *buffy, *tempuid, *gp_err=NULL;
    
    command=(char *)malloc(8192);
    bzero(command, 8192);

    sprintf(command, "/usr/bin/nidump passwd / > %s", GP_OSX_PASS_DUMP);
    
    if( ! niutil_run_command(command) )
    {
	free(command);
        return uid;
    }

    free(command);


    if( ! file_exists(GP_OSX_PASS_DUMP) )
    {
	printf("\nError: passwd file not found: %s\n", GP_OSX_PASS_DUMP);
	unlink_file();
        return uid;
    } 


    /* Determine what gid is free and above 500 */
    if((fp=fopen(GP_OSX_PASS_DUMP, "r"))==NULL)
    {
	unlink_file();
	return uid;    
    }

    fseek(fp, 0, SEEK_END);
    length=ftell(fp);
    rewind(fp);
        
    buffy=(char *)malloc(length);
    bzero(buffy, length);

    tempuid=(char *)malloc(8192);
    bzero(tempuid, 8192);

    while(fgets(buffy, length, fp)!=NULL)
    {
	/* Dont acctept bad input */
	if( strlen(buffy) < 3 || strlen(buffy) > 1024 )
	  continue;

	colon=0; num=0;
	begin=0; end=0;
	
	/* Get the beginning of the gid */
	for(i=0; buffy[i]!='\0'; i++)
	{
	    if( buffy[i]==':' )
	      colon++;
		  
	    /* We have found the beginning of the uid */
	    if( colon==2 )
	    {
	        begin=++i;
	        break;
	    }
	}

	/* Get the end of the uid */
	for(i=i; buffy[i]!='\0'; i++)
	{
	    end++;
	    if( buffy[i]==':' )
	    {
		--end;
		sprintf(tempuid, &buffy[begin]);
		/* Terminate it after the last digit */
		tempuid[end]='\0';

		/* Collect the greatest uid */
		if( is_digitz(tempuid) )
		{
		    /* Conversion to a valid long uid_t */
		    num = (uid_t) strtol(tempuid, &gp_err, 10);
		    if( gp_err && *gp_err )
		      printf("Error Converting a valid long uid\n");
		    else		    
		    if( num > uid )
		      uid=num;

		    if(LONG_MIN==num)
		      printf("LONG_MIN Conversion for uid\n");

		    if(LONG_MAX==num)
		      printf("LONG_MAX Conversion for uid\n");

		    if(errno==ERANGE)
		      printf("Conversion out of range for uid\n");
		}
		/* No need to report a non digit or a negative value */
		break;
	    }
	}
    }

    free(buffy);
    free(tempuid);

    unlink_file();

    /* Add 1 to uid */
    uid++;

    if( uid <= 499 )
      return 500;
    else
      return uid;
}


int
get_free_gid_above_500_()
{
    FILE *fp;
    int i=0, begin=0, end=0, colon=0;
    long length, gid=0, num=0;
    char *command, *buffy, *tempgid, *gp_err=NULL;
    
    command=(char *)malloc(8192);
    bzero(command, 8192);

    sprintf(command, "/usr/bin/nidump passwd / > %s", GP_OSX_PASS_DUMP);
    
    if( ! niutil_run_command(command) )
    {
	free(command);
        return gid;
    }

    free(command);


    if( ! file_exists(GP_OSX_PASS_DUMP) )
    {
	printf("\nError: passwd file not found: %s\n", GP_OSX_PASS_DUMP);
        return gid;
    } 

    /* Determine what gid is free and above 500 */
    if((fp=fopen(GP_OSX_PASS_DUMP, "r"))==NULL)
    {
	return gid;    
    }

    fseek(fp, 0, SEEK_END);
    length=ftell(fp);
    rewind(fp);
        
    buffy=(char *)malloc(length);
    bzero(buffy, length);

    tempgid=(char *)malloc(8192);
    bzero(tempgid, 8192);

    while(fgets(buffy, length, fp)!=NULL)
    {
	/* Dont acctept bad input */
	if( strlen(buffy) < 3 || strlen(buffy) > 1024 )
	  continue;

	colon=0; num=0;
	begin=0; end=0;
	
	/* Get the beginning of the gid */
	for(i=0; buffy[i]!='\0'; i++)
	{
	    if( buffy[i]==':' )
	      colon++;
		  
	    /* We have found the beginning of the gid */
	    if( colon==3 )
	    {
	        begin=++i;
	        break;
	    }
	}

	/* Get the end of the gid */	    
	for(i=i; buffy[i]!='\0'; i++)
	{
	    end++;
	    if( buffy[i]==':' )
	    {
		--end;
		sprintf(tempgid, &buffy[begin]);
		/* Terminate it after the last digit */
		tempgid[end]='\0';
		    
		/* Collect the greatest gid */
		if( is_digitz(tempgid) )
		{
		    /* Conversion to a valid long gid_t */
		    num = (gid_t) strtol(tempgid, &gp_err, 10);
		    if( gp_err && *gp_err )
		      printf("Error Converting a valid long gid \n");
		    else		    
		    if( num > gid )
		      gid=num;

		    if(LONG_MIN==num)
		      printf("LONG_MIN Conversion error for gid\n");

		    if(LONG_MAX==num)
		      printf("LONG_MAX Conversion error for gid\n");

		    if(errno==ERANGE)
		      printf("Conversion out of range for gid\n");
		}
		/* No need to report a non digit or a negative value */
		break;
	    }
	}
    }

    free(buffy);
    free(tempgid);

    unlink_file();

    /* Add 1 to gid */
    gid++;

    if( gid <= 499 )
      return 500;
    else
      return gid;
}


int
niutil_useradd( char *username )
{
    char *command;
    long uid=0, gid=0, gp_id=0;

    command=(char *)malloc(8192);
    bzero(command, 8192);

    /* Create the new users database record */
    sprintf(command, "/usr/bin/niutil -create / /users/%s", username);
    if( ! niutil_run_command(command) )
    {
	printf("Error running: %s\n", command);
	free(command);
	exit (1);
    }

    /* Add a comment for this user */
    sprintf(command, "/usr/bin/niutil -createprop / /users/%s realname %s", username, "ftp-user");
    if( ! niutil_run_command(command) )
    {
        printf("Error running: %s\n", command);
	free(command);
	exit (1);
    }

    if( ! (gid=get_free_gid_above_500_()) )
    {
        printf("\nError: get_free_gid\n");
	free(command);
	exit (1);
    }

    if( ! (uid=get_free_uid_above_500_()) )
    {
        printf("\nError: get_free_uid\n");
	free(command);
        exit (1);
    }

    /* We want the uid and gid to be the same */
    if( uid > gid )
      gp_id=uid;
    else
      gp_id=gid;

    /* Set this users gid */
    sprintf(command, "/usr/bin/niutil -createprop / /users/%s gid %li", username, gp_id);
    if( ! niutil_run_command(command) )
    {
        printf("Error running: %s\n", command);
	free(command);
	exit (1);
    }

    /* Set this users uid */
    sprintf(command, "/usr/bin/niutil -createprop / /users/%s uid %li", username, gp_id);
    if( ! niutil_run_command(command) )
    {
        printf("Error running: %s\n", command);
	free(command);
	exit (1);
    }

    /* Set this users homedirectory (if this directory is created it should be removed) */    
    sprintf(command, "/usr/bin/niutil -createprop / /users/%s home %s", username, "/home/GProftpdNoDir");
    if( ! niutil_run_command(command) )
    {
        printf("Error running: %s\n", command);
	free(command);
	exit (1);
    }

    /* Set the name of the user (this seems a bit off) */
    sprintf(command, "/usr/bin/niutil -createprop / /users/%s name %s", username, username);
    if( ! niutil_run_command(command) )
    {
        printf("Error running: %s\n", command);
	free(command);
	exit (1);
    }
		
    /* Set the users shell */
    sprintf(command, "/usr/bin/niutil -createprop / /users/%s shell %s", username, "/usr/bin/false");
    if( ! niutil_run_command(command) )
    {
        printf("Error running: %s\n", command);
	free(command);
	exit (1);
    }

    /*	dont set these to make it unlimited ??? */
    /*	/usr/bin/niutil -createprop . /users/username change changetime */
    /*	/usr/bin/niutil -createprop . /users/username expire expiretime */

    free(command);

    /* Return true if the user exists */
    return niutil_user_exists(username);
}


int
niutil_userdel( char *username )
{
    int i=0;
    char *command;

    /* Verify that the user really exists */
    if( ! niutil_user_exists(username) )
      return i;

    
    command=(char *)malloc(8192);
    bzero(command, 8192);

    sprintf(command, "/usr/bin/niutil -destroy / /users/%s", username);
    if( ! niutil_run_command(command) )
    {
       printf("Error running: %s\n", command);
    }
    else
      i=1;

    free(command);

    return i;
}


int
niutil_password( char *username, char *password)
{
    /* Password a user */
    int i=0;
    char *command, *encrypted_pass;

    /*	Verify that the user really exists */
    if( ! niutil_user_exists(username) )
      return i;

    /* Crypt returns a static pointer to a static buffer so it should not be freed */
    encrypted_pass=encrypt_password(password);

    if( encrypted_pass==NULL )
    {
	printf("\nCrypt failed.\n");
	exit (1);
    }

    command=(char *)malloc(8192);
    bzero(command, 8192);

    /* 'Encrypted Password' otherwise the shell might swallow it */
    sprintf(command, "/usr/bin/niutil -createprop / /users/%s passwd '%s'", username, encrypted_pass);
    if( ! niutil_run_command(command) )
    {
       printf("Error running: %s\n", command);
       free(command);
       exit (1);
    }
    else
      i=1;

    free(command);

    return i;
}


void
show_help()
{
    printf("osx_users: %s Author: Magnus-swe\n", OSX_USERS_VERSION);
    printf("Usage: osx_users [add username] [del username] [pass username new_password]\n");
}


int
main(int argc, char *argv[])
{
    char *username;
    
    /* Only uid 0 can run this program */
    if( ! getuid() == 0 )
    {
	printf("\nYou have to be root to run this program.\n");
	exit (1);
    }

    /* First check if niutil exists in /usr/bin */
    if( ! file_exists("/usr/bin/niutil") )
    {
	printf("\nFatal error: /usr/bin/niutil doesnt exist.\n");
	exit (1);
    }

    /* We must have argv 0, 1 and 2 */
    if( argv[0]==NULL || argv[1]==NULL || argv[2]==NULL )
    {
	show_help();
        printf("\nToo few arguments.\n");
	exit (1);
    }

    /* Do not allow argv's greater then 1024 for 0, 1 and 2 */
    if( strlen(argv[0]) > 1024 || strlen(argv[1]) > 1024 || strlen(argv[2]) > 1024  )
    {
       show_help();
       printf("\nNo young skywalker.. argv does _not_ walk that way !\n");
       exit (1);
    }  

    /* If argv 3 (pass) is used it cant be greater then 1024 or less then MIN_PASS_LENGTH */
    if( argv[3]!=NULL )
    {
	if( strlen(argv[3]) > 1024 )
	{
	    show_help();
    	    printf("\nNo young skywalker.. argv does _not_ walk that way !\n");
	    exit (1);
	}

	if( strlen(argv[3]) < MIN_PASS_LENGTH )
	{
	    show_help();
	    printf("\nThe minimum password length is %i\n", MIN_PASS_LENGTH);
	    exit (1);
	}
    }

    /* We have determined that inputs are valid.. */
    username=(char *)malloc(8192);
    bzero(username, 8192);
    sprintf(username, "%s", argv[2]);

    /* Add a user */
    if( strstr(argv[1], "add") && argv[2]!=NULL )
    {
	/* Do nothing if the user exists */
	if( niutil_user_exists(username) )
	{
	    printf("\nThe user: [%s] already existed\n", username);
	    free(username);
	    exit (1);
	}

	/* Add the new user */
	if( niutil_useradd(username) )
	  printf("\nThe user has been added\n");
	else
	  printf("\nError: user not added\n");
    }	
    else
    if( strstr(argv[1], "del") && argv[2]!=NULL )
    {
	/* Do nothing if the user doesnt exist */
	if( ! niutil_user_exists(username) )
	{
	    printf("\nThe user: [%s] didnt exist\n", username);
	    free(username);
	    exit (1);
	}

	/* Delete the user */
	if( niutil_userdel(username) )
	  printf("\nThe user has been deleted\n");
	else
	  printf("\nError: The user was not deleted\n");
    }	
    else
    if( argv[0]!=NULL && strstr(argv[1], "pass") && argv[2]!=NULL && argv[3]!=NULL )
    {
	/* Do nothing if the user doesnt exist */
	if( ! niutil_user_exists(username) )
	{
	    printf("\nThe user: [%s] didnt exist\n", username);
	    free(username);
	    exit (1);
	}
	    
	/* Change password for the user */
	if( niutil_password(username, argv[3]) )
	  printf("\nThe user has been passworded\n");
	else
	  printf("\nError: could not password the user\n");
    }	
    else
      show_help();  
    
    free(username);

    return 0;
}
