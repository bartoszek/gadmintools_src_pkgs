
#ifndef MAKE_INSTALL_LIST_FROM_PACKAGE_H
#define MAKE_INSTALL_LIST_FROM_PACKAGE_H

void make_install_list_from_package(char *package);

void make_uninstall_list_from_package(char *package);

#endif
