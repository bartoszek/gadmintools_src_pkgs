
#ifndef SHOW_HELP_H
#define SHOW_HELP_H

void show_help();

#endif
