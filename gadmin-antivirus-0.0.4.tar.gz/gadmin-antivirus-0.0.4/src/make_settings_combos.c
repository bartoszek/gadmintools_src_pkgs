/* GAdmin-Antivirus - An easy to use GTK+ frontend for clamav antivirus.
 * Copyright (C) 2010 - 2014 Magnus Loef <magnus-swe@telia.com> 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
*/


#include <gtk/gtk.h>
#include "make_settings_combos.h"

GtkWidget *
make_label_combo_button(GtkGrid *grid,
    GtkWidget * button,
    const gchar * label_text,
    gint left_attach, gint right_attach, gint top_attach, gint bottom_attach,
    gint combo_length)
{
    GtkWidget *label, *pad_label;
    GtkWidget *combo;
    GtkWidget *hbox;

    hbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 2);
    label = gtk_label_new(label_text);
    combo = gtk_combo_box_text_new();
    pad_label = gtk_label_new("\t\t");

    gtk_box_pack_start(GTK_BOX(hbox), label, FALSE, FALSE, 0);

    gtk_box_pack_start(GTK_BOX(hbox), combo, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(hbox), pad_label, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(hbox), button, FALSE, FALSE, 0);

    gtk_grid_attach(grid, hbox, 0, 1, right_attach, bottom_attach);

    gtk_misc_set_alignment(GTK_MISC(label), 0, 0.5);
    gtk_misc_set_padding(GTK_MISC(label), 20, 0);

    gtk_widget_show(label);
    gtk_widget_show(combo);
    gtk_widget_show(pad_label);

    return combo;
}
