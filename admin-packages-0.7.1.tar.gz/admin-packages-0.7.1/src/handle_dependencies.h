

#ifndef handle_dependencies_H
#define handle_dependencies_H

void handle_install_dependencies(char *package);

void handle_uninstall_dependencies(char *package);

#endif
