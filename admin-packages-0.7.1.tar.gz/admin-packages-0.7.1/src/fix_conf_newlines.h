
#ifndef FIX_CONF_NEWLINES_H
#define FIX_CONF_NEWLINES_H

void fix_conf_newlines();

#endif
