/*
 * Admin-Packages - A Package manager for sources.
 * Copyright (C) 2009 - 2011 Magnus Loef <magnus-swe@telia.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307, USA.
 *
 */


#include "../config.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "allocate.h"
#include "set_proxy.h"
#include "show_help.h"


int set_proxy(char *proxy)
{
    FILE *fp;
    char *line, *new_conf, *new_line;
    long file_size = 0;

    if( proxy == NULL || strlen(proxy) < 4 )
    {
        show_help();
        printf("--set-proxy requires an argument with a length greater then 3.\n");
        exit(1);
    }
    if((fp=fopen(WGET_RC, "r"))==NULL)
    {
       printf("Proxy settings file not found: [%s]\n", WGET_RC);
       exit(1);
    }
    fseek(fp, 0, SEEK_END);
    file_size = ftell(fp);
    rewind(fp);

    line = allocate(file_size+3);
    /* 100 extra for "http_proxy=..." or "ftp_proxy=..." or "use_proxy=" lines */
    new_conf = allocate(file_size+strlen(proxy)*2+100);

    if( file_size > 1 )
    while(fgets(line, file_size, fp)!=NULL)
    {
        /* Delete the old proxy settings */
        if( strstr(line, "http_proxy")
        ||  strstr(line, "ftp_proxy" )
        ||  strstr(line, "use_proxy" ) )
        {
        }
        else
            strcat(new_conf, line);
    }
    fclose(fp);
    free(line);

    /* Write the new conf.. +50 for the static proxies */
    new_line = allocate(strlen(proxy)+50);

    if((fp=fopen(WGET_RC, "w+"))==NULL)
    {
        printf("The proxy file is not writable: [%s]\n", WGET_RC);
        exit(1);
    }
    fputs(new_conf, fp);

    /* Disable proxy usage if the argument is "none" */
    if( strcmp(proxy, "none") == 0 )
    {
        sprintf(new_line, "%s", "http_proxy = my.proxy.org:30000/\n");
        fputs(new_line, fp);

        sprintf(new_line, "%s", "ftp_proxy = my.proxy.org:30000/\n");
        fputs(new_line, fp);

        sprintf(new_line, "%s", "use_proxy = off\n");
        fputs(new_line, fp);

        printf("Proxy usage disabled.\n");
    }
    else /* Set the specified proxy settings */
    {
        sprintf(new_line, "http_proxy = %s/\n", proxy);
        fputs(new_line, fp);

        sprintf(new_line, "ftp_proxy = %s/\n", proxy);
        fputs(new_line, fp);

        sprintf(new_line, "use_proxy = on\n");
        fputs(new_line, fp);

        printf("Using proxy: [%s]\n", proxy);
    }
    fclose(fp);
    free(new_conf);
    free(new_line);

    return 1;
}
