
#ifndef HAVE_EQUAL_OR_HIGHER_VERSION_H
#define HAVE_EQUAL_OR_HIGHER_VERSION_H

int have_equal_or_higher_version(char *package, char *required_version);

#endif
