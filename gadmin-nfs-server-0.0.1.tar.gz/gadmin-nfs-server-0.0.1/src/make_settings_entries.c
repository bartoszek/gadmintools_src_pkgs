/* GADMIN-NFS-SERVER - An easy to use GTK+ frontend for the NFS server.
 * Copyright (C) 2014 - 2014 Magnus Loef <magnus-swe@telia.com> 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
*/



#include <gtk/gtk.h>
#include "make_settings_entries.h"


/*
gtk_grid_attach (GtkGrid *grid,
                 GtkWidget *child,
                 gint left,
                 gint top,
                 gint width,
                 gint height);
*/

GtkWidget *make_entry_with_label(GtkGrid *table,
                                 const gchar *label_text,
                                 gint left,
                                 gint top,
                                 gint width,
                                 gint height,
                                 gint entry_length)
{
    GtkWidget *entry;
    GtkWidget *label;

    label = gtk_label_new(label_text);
    entry = gtk_entry_new();

printf("Left: %d Top: %d Width: %d height %d\n", left, top, width, height);

    gtk_grid_attach(table, label, left, top, width, height);
    gtk_grid_attach(table, entry, left + 1, top + 1, width, height);

    gtk_misc_set_alignment(GTK_MISC(label), 0, 0.5);
    gtk_misc_set_padding(GTK_MISC(label), 2, 2);

    gtk_entry_set_max_length(GTK_ENTRY(entry), entry_length);
    gtk_widget_set_size_request(entry, entry_length, -1);

    gtk_widget_show(entry);
    gtk_widget_show(label);
 
    return entry;
}
