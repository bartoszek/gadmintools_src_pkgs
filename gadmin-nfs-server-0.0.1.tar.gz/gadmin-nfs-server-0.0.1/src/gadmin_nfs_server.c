/* GADMIN-NFS-SERVER - An easy to use GTK+ frontend for the NFS server.
 * Copyright (C) 2014 - 2014 Magnus Loef <magnus-swe@telia.com> 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
*/



#include "../config.h"
#include <gtk/gtk.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include "gettext.h"
#include "widgets.h"
#include "locate_icons.h"
#include "allocate.h"
#include "functions.h"

/* Use as externs */
char global_netmask[1024]="";
char global_subnet[1024]="";
char global_nic[1024]="";

char global_ipaddr[1024]="";
char global_hwaddr[1024]="";
char global_hostname[1024]="";

int del_row_num = 0;
int num_ranges = 0;
int activated = 0;
int info_window_exit_main = 0;
int MAX_READ_POPEN = 8192;

#include "create_main_window.h"
#include "create_directory_tab.h"
#include "populate_dir_treeview.h"
#include "select_first_dir.h"
#include "populate_clients.h"
#include "set_num_clients.h"
#include "status_update.h"
#include "gadmin_nfs_server.h"


int main(int argc, char *argv[])
{
    int i = 0;
    gchar *info;

#ifdef ENABLE_NLS
    bindtextdomain(GETTEXT_PACKAGE, PACKAGE_LOCALE_DIR);
    bind_textdomain_codeset(GETTEXT_PACKAGE, "UTF-8");
    textdomain(GETTEXT_PACKAGE);
#endif

//    gtk_set_locale();
    gtk_init(&argc, &argv);

    wid *widgets = g_malloc (sizeof (wid));

    /* Non root usage */
    if( ! getuid() == 0 )
    {
	/* For setting a different exit method in the info window */
	info_window_exit_main = 1;

        info = g_strdup_printf("You must be root to run: %s\nThis window will close in 10 seconds.\n", PACKAGE);
        show_info(info);
        g_free(info);

	/* Users can close the info window earlier then the timeout */
	for(i=0; i<10; i++)
	{
    	    while(gtk_events_pending())
                  gtk_main_iteration();

	    /* Set when close info window is clicked */
	    if( info_window_exit_main == 2 )
	      break;

    	    usleep(100000*10);
    	}

	g_free(widgets); /* The g_ptr_array has not yet been allocated */
	return 0;
    }

    create_main_window(widgets);

    create_directory_tab(widgets);

    /* Pointer arrays for the dynamic range widgets */
    widgets->ranges_hbox_array = g_ptr_array_new();
    widgets->ranges_from_entry_array = g_ptr_array_new();
    widgets->ranges_to_entry_array = g_ptr_array_new();
    widgets->ranges_del_button_array = g_ptr_array_new();

    gtk_widget_show_all(widgets->main_window);

    /* Populate the scope treeview */
    populate_dir_treeview(widgets);
    select_first_dir(widgets);

    /* Populate scope ranges */
    set_num_clients();
    populate_clients(widgets, global_nic, global_subnet, global_netmask);

    /* Start the online/offline timer */
//    gtk_timeout_add(1000, (GtkFunction) status_update, widgets);
//    gtk_timeout_add(1000, G_CALLBACK(status_update), widgets);
g_timeout_add(1000, (GSourceFunc) status_update, widgets);

// GSignalFunc(gtk_main_quit)
    /* Window (x) close button */
    g_signal_connect(GTK_WIDGET(widgets->main_window), "destroy",
                                   G_CALLBACK(gtk_main_quit), NULL); //, gtk_main_quit, NULL);

    /* Start the main loop */
    gtk_main();

    g_ptr_array_free(widgets->ranges_hbox_array, TRUE);
    g_ptr_array_free(widgets->ranges_from_entry_array, TRUE);
    g_ptr_array_free(widgets->ranges_to_entry_array, TRUE);
    g_ptr_array_free(widgets->ranges_del_button_array, TRUE);
    g_free(widgets);

    return 0;
}
