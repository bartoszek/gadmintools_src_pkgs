
#ifndef MDSUMS_MATCH_H
#define MDSUMS_MATCH_H

int mdsums_match(char *file);

#endif
