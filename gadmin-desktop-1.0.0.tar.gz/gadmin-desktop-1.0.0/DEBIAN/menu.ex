?package(gadmin-desktop):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="gadmin-desktop" command="/usr/bin/gadmin-desktop"
