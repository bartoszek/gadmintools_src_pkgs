/* GAdmin-Rsync - An easy to use GTK+ frontend for the rsync backup client and server.
 * Copyright (C) 2007 - 2014 Magnus Loef <magnus-swe@telia.com> 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
*/



#include <gtk/gtk.h>

#ifndef restore_menu_H
#define restore_menu_H

extern struct w *widgets;

void show_restore_menu(struct w *widgets);

void restore_menu_forward_clicked(struct w *widgets);

void show_restore_local_src_filesel(struct w *widgets);
void restore_local_src_filesel_ok(struct w *widgets);

void show_restore_local_dst_filesel(struct w *widgets);
void restore_local_dst_filesel_ok(struct w *widgets);

#endif
