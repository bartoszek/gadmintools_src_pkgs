
#ifndef BINARY_PACKAGES_H
#define BINARY_PACKAGES_H

int create_binary_package(char *package);

int install_binary_package(char *package);

#endif
