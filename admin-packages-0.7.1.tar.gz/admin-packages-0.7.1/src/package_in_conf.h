
#ifndef PACKAGE_IN_CONF_H
#define PACKAGE_IN_CONF_H

int package_in_local_conf(char *package);
int package_in_tmp_conf(char *package);

#endif
