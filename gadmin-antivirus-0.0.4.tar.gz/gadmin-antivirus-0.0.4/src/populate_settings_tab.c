/* GAdmin-Antivirus - An easy to use GTK+ frontend for clamav antivirus.
 * Copyright (C) 2010 - 2014 Magnus Loef <magnus-swe@telia.com> 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
*/



#include "../config.h"
#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include "gettext.h"
#include "widgets.h"
#include "show_info.h"
#include "create_settings_tab.h"
#include "populate_settings_tab.h"
#include "functions.h"

#define MAX_TIME_LINE 100

extern gchar *global_settings_dir;
extern gchar *global_scan_name;

/* Show info about missing paths once */
int path_err = 0;

extern gulong scan_combo_changed_signal;



/* Populates the scan selection combo and returns number of selections */
int
populate_scan_combo(struct w *widgets)
{
    int i = 0, x = 0, count = 0;
    struct dirent **namelist;
    gchar *conf_file, *utf8 = NULL;
    GtkTreeModel *model;

    /* Need to block the changed signal for this widget. */
    g_signal_handler_block(GTK_WIDGET(widgets->settings_combo[0]),
        scan_combo_changed_signal);

    /* Get selected scan name from the combo */
    global_scan_name =
      gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(widgets->settings_combo[0]));

    /* Clear the "scan name" combo */
    model = gtk_combo_box_get_model(GTK_COMBO_BOX(widgets->settings_combo[0]));

    gtk_list_store_clear(GTK_LIST_STORE(model));

    /* Read the settings dir */
    i = scandir(global_settings_dir, &namelist, 0, alphasort);
    if(i < 0)
    {
        perror("scandir");
        return 0;
    }

    for(x = 0; x < i; x++)
    {
        /* Skip the directory up/down dots */
        if(strcmp(namelist[x]->d_name, ".") == 0
            || strcmp(namelist[x]->d_name, "..") == 0)
        {
            free(namelist[x]);
            continue;
        }

        /* Insert "scan names" into the scan selection combo */
        utf8 =
            g_locale_to_utf8(namelist[x]->d_name, strlen(namelist[x]->d_name),
            NULL, NULL, NULL);

        gtk_combo_box_text_append_text(
                  GTK_COMBO_BOX_TEXT(widgets->settings_combo[0]), utf8);

        /* If no selected "scan name", set this as selected in the combo */
        if(count == 0 && global_scan_name == NULL)
        {
            count++;

            gtk_combo_box_set_active(
                        GTK_COMBO_BOX(widgets->settings_combo[0]), 0);

            /* Save the path for treeview population */
            conf_file = g_strdup_printf("%s/%s", global_settings_dir,
                                                  namelist[x]->d_name);
            global_scan_name = g_strdup_printf("%s", namelist[x]->d_name);
        }

        /* If theres a selected "scan name", set it as selected if found */
        if(global_scan_name != NULL
            && strcmp(global_scan_name, namelist[x]->d_name) == 0)
        {
            gtk_combo_box_set_active(GTK_COMBO_BOX(widgets->settings_combo[0]),
                                                                        x - 2);

            /* Save the path for treeview population */
            conf_file = g_strdup_printf("%s/%s", global_settings_dir,
                                                  namelist[x]->d_name);
            global_scan_name = g_strdup_printf("%s", namelist[x]->d_name);
        }
        g_free(utf8);
        free(namelist[x]);

        count++;
    }
    free(namelist);

    /* Unblock the signal */
    g_signal_handler_unblock(GTK_WIDGET(widgets->settings_combo[0]),
                                           scan_combo_changed_signal);

    return count;
}


/* Populates the settings tab */
void
populate_settings_tab(struct w *widgets)
{
    FILE *fp;
    long opt_pos = 0, conf_size = 0;
    char *line, *opt, *new_buffer, *timebuf;
    gchar *conf_file = NULL, *utf8 = NULL;
    GtkTreeIter iter;
    int prev_newline = 0, one_time = 0, i = 0, x = 0;

    /* Clear the treeview */
    gtk_list_store_clear(GTK_LIST_STORE(widgets->scan_store));

    /* Deselect all toggle buttons */
    for(i = 0; i < 10; i++)
        gtk_toggle_button_set_active(
                GTK_TOGGLE_BUTTON(widgets->schedule_check_button[i]), FALSE);

    /* Set it to any month by default */
    gtk_toggle_button_set_active(
                GTK_TOGGLE_BUTTON(widgets->schedule_check_button[1]), TRUE);

    /* Populate the scan combo */
    if(populate_scan_combo(widgets))
    {
        conf_file = g_strdup_printf("%s/%s", global_settings_dir,
                                                 global_scan_name);
    }
    else
    {
        /* No selections found. Create a new scan dialog. */
        create_new_scan_window(widgets);
        if(conf_file != NULL)
            g_free(conf_file);

        return;
    }

    /* Populate the scan treeview from the settings file */
    if((fp = fopen(conf_file, "r")) == NULL)
    {
        g_free(conf_file);
        return;
    }
    fseek(fp, 0, SEEK_END);
    conf_size = ftell(fp);
    rewind(fp);

    line = allocate(conf_size + 1);
    new_buffer = allocate(conf_size + 1);
    opt = allocate(16384 + 1);
    timebuf = allocate(MAX_TIME_LINE + 1);

    if(conf_size > 1)
        while(fgets(line, conf_size, fp) != NULL)
        {
            if(commented(line))
                continue;

            if(strlen(line) > 16384)
                continue;

            if(!strstr(line, "schedule_"))
            {
                /* Append a row once if the data length is valid */
                if(!one_time && strlen(line) > 3)
                {
                    gtk_list_store_append(GTK_LIST_STORE(widgets->scan_store),
                        &iter);
                    one_time++;

                    set_treeview_path_first(
                                        GTK_TREE_VIEW(widgets->scan_treeview));
                }

                /* Record previous newline */
                if(line[0] == '\n')
                {
                    prev_newline = 1;
                    continue;
                }

                /* Append a row if the previous one was a
                   newline and we have a valid data length */
                if(prev_newline && strlen(line) > 3)
                {
                    gtk_list_store_append(GTK_LIST_STORE(widgets->scan_store),
                        &iter);
                    prev_newline = 0;
                }
            }

            /* Remove newline chars */
            opt_pos = get_option_pos(line, 1);
            snprintf(opt, 16384, "%s", &line[opt_pos]);
            if(opt[strlen(opt) - 1] == '\n')
                opt[strlen(opt) - 1] = '\0';

            /* Scan path */
            if(strstr(line, "scan_path"))
            {
                utf8 = g_locale_to_utf8(opt, strlen(opt), NULL, NULL, NULL);
                gtk_list_store_set(widgets->scan_store, &iter, 0, utf8, -1);
                if(utf8 != NULL)
                    g_free(utf8);
            }
            /* Include files */
            if(strstr(line, "include_files"))
            {
                utf8 = g_locale_to_utf8(opt, strlen(opt), NULL, NULL, NULL);
                gtk_list_store_set(widgets->scan_store, &iter, 1, utf8, -1);
                if(utf8 != NULL)
                    g_free(utf8);
            }
            /* Exclude files */
            if(strstr(line, "exclude_files"))
            {
                utf8 = g_locale_to_utf8(opt, strlen(opt), NULL, NULL, NULL);
                gtk_list_store_set(widgets->scan_store, &iter, 2, utf8, -1);
                if(utf8 != NULL)
                    g_free(utf8);
            }
            /* Include value */
            if(strstr(line, "include_value"))
            {
                if(strstr(line, "1"))
                   gtk_list_store_set(widgets->scan_store, &iter, 3, TRUE, -1);
                else
                   gtk_list_store_set(widgets->scan_store, &iter, 3, FALSE, -1);
            }

            /* Is scheduling used... */
            if(strstr(line, "schedule_"))
                gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON
                    (widgets->schedule_check_button[0]), TRUE);

            /* Schedule month day */
            if(strstr(line, "schedule_month_day"))
            {
                timebuf[0] = '\0';
                x = 1;          /* Default value */

                /* Get and insert the month day */
                for(i = 0; i < 5 && opt[i] != '\0'; i++)
                {
                    timebuf[i] = opt[i];
                }
                if(timebuf[strlen(timebuf) - 1] == '\n')
                    timebuf[strlen(timebuf) - 1] = '\0';

                x = atoi(timebuf);
                gtk_spin_button_set_value(GTK_SPIN_BUTTON
                    (widgets->schedule_spin_button[0]), x);

                /* Uncheck shedule every month day */
                gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON
                    (widgets->schedule_check_button[1]), FALSE);
            }
            /* Schedule every month day is enabled */
            if(strstr(line, "schedule_every_month_day"))
            {
                gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON
                    (widgets->schedule_check_button[1]), TRUE);
            }
            /* Schedule days */
            if(strstr(line, "schedule_days"))
            {
                for(i = 0; opt[i] != '\0'; i++)
                {
                    if(i < 9)
                    {
                        /* Checkbuttons are 2-8 */
                        if(opt[i] == '1')
                        {
                            gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON
                                (widgets->schedule_check_button[i + 2]), TRUE);
                        }
                        else
                        {
                            gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON
                                (widgets->schedule_check_button[i + 2]), FALSE);
                        }
                    }
                }
            }
            /* Schedule time (hour, minute) */
            if(strstr(line, "schedule_time"))
            {
                /* Contains hour or minute (12:30) */
                timebuf[0] = '\0';
                x = 1;          /* Default value */

                /* Get and insert the hour */
                for(i = 0; i < 5 && opt[i] != ':' && opt[i] != '\0'; i++)
                {
                    timebuf[i] = opt[i];
                }
                if(timebuf[strlen(timebuf) - 1] == '\n')
                    timebuf[strlen(timebuf) - 1] = '\0';

                x = atoi(timebuf);
                gtk_spin_button_set_value(GTK_SPIN_BUTTON
                    (widgets->schedule_spin_button[1]), x);

                /* Skip colon */
                i++;

                /* Clear the buffer */
                memset(timebuf, '\0', sizeof(*timebuf));

                /* Get and insert the minute */
                x = 0;          /* Dont change the '0' */
                for(i = i; i < 5 && opt[i] != '\0'; i++)
                {
                    timebuf[x] = opt[i];
                    x++;
                }
                if(timebuf[strlen(timebuf) - 1] == '\n')
                    timebuf[strlen(timebuf) - 1] = '\0';

                x = atoi(timebuf);
                gtk_spin_button_set_value(GTK_SPIN_BUTTON
                    (widgets->schedule_spin_button[2]), x);
            }

            /* Schedule every hour is enabled */
            if(strstr(line, "schedule_every_hour"))
            {
                gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON
                    (widgets->schedule_check_button[9]), TRUE);
            }
        }
    fclose(fp);
    free(line);
    free(opt);
    free(timebuf);
    free(new_buffer);
    g_free(conf_file);
}

