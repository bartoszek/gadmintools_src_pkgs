/* GADMIN-NFS-SERVER - An easy to use GTK+ frontend for the NFS server.
 * Copyright (C) 2014 - 2014 Magnus Loef <magnus-swe@telia.com> 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
*/



#include <gtk/gtk.h>
#include <stdio.h>
#include <string.h>
#include "widgets.h"
#include "gettext.h"


void clear_ptr_array(struct w *widgets)
{
    g_ptr_array_free(widgets->ranges_hbox_array, TRUE);
    g_ptr_array_free(widgets->ranges_from_entry_array, TRUE);
    g_ptr_array_free(widgets->ranges_to_entry_array, TRUE);
    g_ptr_array_free(widgets->ranges_del_button_array, TRUE);

    widgets->ranges_hbox_array = g_ptr_array_new();
    widgets->ranges_from_entry_array = g_ptr_array_new();
    widgets->ranges_to_entry_array = g_ptr_array_new();
    widgets->ranges_del_button_array = g_ptr_array_new();
}
