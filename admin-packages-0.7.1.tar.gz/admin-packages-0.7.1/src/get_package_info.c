/*
 * Admin-Packages - A Package manager for sources.
 * Copyright (C) 2009 - 2011 Magnus Loef <magnus-swe@telia.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307, USA.
 *
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <dirent.h>
#include "allocate.h"
#include "globals.h"
#include "commented.h"
#include "get_package_info.h"

extern char pkgconf_temp[MAX_TEMP_PATH];
extern char package_queue[MAX_TEMP_PATH];
extern int global_resolve_deps;


/* Gets the entire configuration section for this package.
   From: <PackageName> to </PackageName> 
   From: The downloaded temporary packages.conf   if where is "1"
   From: /SYSCONFDIR/admin-packages/packages.conf if where is "2" */
char * get_conf_from_package(int where, char *package)
{
    FILE *fp;
    char *line, *begin_package, *end_package, *conf;
    int found=0;
    long file_size=0;

    if( where == 1 )
    {
        if((fp=fopen(pkgconf_temp, "r"))==NULL)
        {
            perror("fopen");
            printf("Fatal error opening file [%s]\n", pkgconf_temp);
            return 0;
        }
    }
    else
    if( where == 2 )
    {
        if((fp=fopen(PACKAGES_CONF, "r"))==NULL)
        {
            perror("fopen");
            printf("Fatal error opening file [%s]\n", PACKAGES_CONF);
            return 0;
        }
    }
    else
    {
        printf("Get_conf_from_package() requires a correct where parameter.\n");
        return 0;
    }

    fseek(fp, 0, SEEK_END);
    file_size = ftell(fp);
    rewind(fp);

    line = allocate(file_size);
    conf = allocate(file_size);

    begin_package = allocate(MAX_PKG_LEN+4);
    end_package   = allocate(MAX_PKG_LEN+4);

    sprintf(begin_package, "<%s>\n", package);
    sprintf(end_package, "</%s>\n", package);

    if( file_size > 1 )
    while(fgets(line, file_size, fp)!=NULL)
    {
        /* Is this an exact package name match */
        if( strcmp(line, begin_package) == 0 && ! commented(line) )
        {
            sprintf(conf, "%s", line);

            if( file_size > 1 )
            while(fgets(line, file_size, fp)!=NULL)
            {
                strcat(conf, line);

                if( strcmp(line, end_package) == 0 && ! commented(line) )
                {
                    found = 1;
                    break;
                }
            }
        }

        if( found )
          break;
    }
    fclose(fp);
    free(line);
    free(begin_package);
    free(end_package);

    return conf;
}


char ** get_depending_packages(char *package)
{
    FILE *fp;
    char **reqpackages;
    char *tmp_package, *some_package, *end_package, *line;
    int numdeps = 1; /* Always keep 1 slot for the closing NULL */
    int i = 0;
    long file_size = 0;


    if((fp=fopen(PACKAGES_CONF, "r"))==NULL)
    {
        perror("fopen");
        printf("Fatal error opening file [%s]\n", PACKAGES_CONF);
        reqpackages = NULL;
        return reqpackages;
    }
    fseek(fp, 0, SEEK_END);
    file_size = ftell(fp);
    rewind(fp);

    line = allocate(file_size+1);

    tmp_package = allocate(MAX_PKG_LEN+10);
    some_package = allocate(MAX_PKG_LEN+10);
    end_package = allocate(MAX_PKG_LEN+10);

    // FIX.. parser code doesnt handle broken confs (seek pkg_end.. seek pkg_begin line[0]=="<")

    /* Record the number of packages that we should handle */
    /* If a package requires the "package" then numdeps++ */
    if( file_size > 1 )
    while(fgets(line, file_size, fp)!=NULL)
    {
        if( commented(line) )
            continue;

        if( strstr(line, "<") && strstr(line, ">") && ! strstr(line, "/")
        && strlen(line) > 3 && strlen(line) < MAX_PKG_LEN -1
        && ! strstr(line, "pre-install") && ! strstr(line, "installation")
        && ! strstr(line, "post-install") && ! strstr(line, "description")
        && ! strstr(line, "requires") )
        {
            snprintf(some_package, MAX_PKG_LEN-1, "%s", &line[1]);
            some_package[strlen(some_package)-2]='\0';

            sprintf(end_package, "</%s>\n", some_package);

            /* If this package requires "package" then numdeps++ */
            if( file_size > 1 )
            while(fgets(line, file_size, fp)!=NULL)
            {
                if( commented(line) )
                    continue;

                if( strstr(line, "<requires>") )
                {
                    if( file_size > 1 )
                    while(fgets(line, file_size, fp)!=NULL)
                    {
                        if( commented(line) )
                            continue;

                        if( strlen(line) > 3 && strlen(line) < MAX_PKG_LEN-1 )
                        {
                            sscanf(line, "%s", tmp_package);
                            /* Does this package have a requirement for "package" */
                            if( strcmp(package, tmp_package) == 0 )
                                numdeps++;
                        }
                        /* Package end or end of the requires section found */
                        if( strcmp(line, end_package) == 0 || strstr(line, "</requires>") )
                            break;
                    }
                }
                /* Package end found */
                if( strcmp(line, end_package) == 0 )
                    break;
            }
        }
    }

    rewind(fp);

    /* numdeps is numdeps+1 for the closing NULL */
    reqpackages = malloc(numdeps*sizeof(char *));

    /* Record each package name */
    /* If a package requires the "package" then add it to the list */
    if( file_size > 1 )
    while(fgets(line, file_size, fp)!=NULL)
    {
        if( commented(line) )
            continue;

        if( strstr(line, "<") && strstr(line, ">") && ! strstr(line, "/")
        && strlen(line) > 3 && strlen(line) < MAX_PKG_LEN -1 
        && ! strstr(line, "pre-install") && ! strstr(line, "installation")
        && ! strstr(line, "post-install") && ! strstr(line, "description")
        && ! strstr(line, "requires") )
        {
            snprintf(some_package, MAX_PKG_LEN, "%s", &line[1]);
            some_package[strlen(some_package)-2]='\0';

            sprintf(end_package, "</%s>\n", some_package);

            /* If this package requires "package" then numdeps++ */
            if( file_size > 1 )
            while(fgets(line, file_size, fp)!=NULL)
            {
                if( commented(line) )
                    continue;

                if( strstr(line, "<requires>") )
                {
                    if( file_size > 1 )
                    while(fgets(line, file_size, fp)!=NULL)
                    {
                        if( commented(line) )
                            continue;

                        if( strlen(line) > 3 && strlen(line) < MAX_PKG_LEN -1 )
                        {
                            sscanf(line, "%s", tmp_package);
                            /* Does this package have a requirement for "package" */
                            if( strcmp(package, tmp_package) == 0 )
                            {
                                reqpackages[i] = malloc(strlen(line)+1);
                                sscanf(some_package, "%s", reqpackages[i]); /* We only want the package name */
                                i++;
                            }
                        }
                        /* Package end or end of the requires section found */
                        if( strcmp(line, end_package) == 0 || strstr(line, "</requires>") )
                            break;
                    }
                }
                /* Package end found */
                if( strcmp(line, end_package) == 0 )
                    break;
            }
        }
    }

    reqpackages[i] = NULL; /* End with a NULL */

    fclose(fp);
    free(line);
    free(tmp_package);
    free(some_package);
    free(end_package);

    return reqpackages;
}


/* Returns the number of packages in the package queue */
long get_install_list_num()
{
    FILE *fp;
    long file_size=0, i=0, num=0;
    char *line, *pkg_name, *pkg_end;

    /* Read the package queue */
    if((fp=fopen(package_queue, "r"))==NULL)
    {
        printf("Could not read: %s\n", package_queue);
        perror("fopen");
        return 0;
    }
    fseek(fp, 0, SEEK_END);
    file_size = ftell(fp);
    rewind(fp);

    line = allocate(file_size+1);

    pkg_name = allocate(MAX_PKG_LEN+6);
    pkg_end  = allocate(MAX_PKG_LEN+6);

    if( file_size > 1 )
    while(fgets(line, file_size, fp)!=NULL)
    {
        if( commented(line) )
            continue;

        if( strlen(line) > MAX_PKG_LEN-1 )
            continue;

        /* The first entry in a package profile is <package-name> */
        if( strstr(line, "<") && strstr(line, ">") )
        {
            for(i=0; i < MAX_PKG_LEN-1 && i < strlen(line)-1; i++)
            {
                if( line[i]=='<' && strlen(line) < MAX_PKG_LEN-1 )
                {
                    snprintf(pkg_name, MAX_PKG_LEN-1, "%s", &line[i+1]);
                    pkg_name[strlen(line)-3]='\0';
                    snprintf(pkg_end, MAX_PKG_LEN-1, "</%s>\n", pkg_name);
                    num++;
                }
            }

            /* Scroll to the end of this profile </package-name> */
            if( file_size > 1 )
            while(fgets(line, file_size, fp)!=NULL)
            {
                if( commented(line) )
                    continue;

                if( strcmp(line, pkg_end) == 0 )
                    break;
            }
        }
    }
    fclose(fp);
    free(line);
    free(pkg_name);
    free(pkg_end);

    return num;
}


char * get_install_package_from_install_nr(long i)
{
    FILE *fp;
    long file_size=0, z=0, num=0;
    char *line, *pkg_name, *pkg_end;

    /* Read install.tmp */
    if((fp=fopen(package_queue, "r"))==NULL)
    {
        printf("Could not write to: %s\n", package_queue);
        perror("fopen");
        return 0;
    }
    fseek(fp, 0, SEEK_END);
    file_size=ftell(fp);
    rewind(fp);

    line = allocate(file_size+1);

    pkg_name = allocate(MAX_PKG_LEN+3);
    pkg_end  = allocate(MAX_PKG_LEN+6);

    if( file_size > 1 )
    while(fgets(line, file_size, fp)!=NULL)
    {
        if( commented(line) )
            continue;

        if( strlen(line) > MAX_PKG_LEN-1 )
            continue;

        /* The first entry in a package profile is <package-name> */
        if( strstr(line, "<") && strstr(line, ">") )
        {
            for(z=0; z < MAX_PKG_LEN-1; z++)
            {
                if( line[z]=='<' )
                {
                    sprintf(pkg_name, "%s", &line[z+1]);
                    pkg_name[strlen(line)-3]='\0';
                    snprintf(pkg_end, MAX_PKG_LEN-1, "</%s>\n", pkg_name);

                    num++;
                    break;
                }
            }

            /* This is the package at location: i */
            if( num == i )
                break;

            /* Scroll to the end of this profile </package-name> */
            if( file_size > 1 )
            while(fgets(line, file_size, fp)!=NULL)
            {
                if( commented(line) )
                    continue;

                if( strcmp(line, pkg_end) == 0 )
                    break;
            }
        }
    }
    fclose(fp);
    free(line);
    free(pkg_end);

    return pkg_name;
}


long get_num_files_from_package(char *package)
{
    FILE *fp;
    char *line, *begin_package, *end_package;
    long file_size = 0, num_files = 0;
    int found = 0;

    if((fp=fopen(pkgconf_temp, "r"))==NULL)
    {
        perror("fopen");
        printf("Fatal error opening file [%s]\n", pkgconf_temp);
        return 0;
    }
    fseek(fp, 0, SEEK_END);
    file_size = ftell(fp);
    rewind(fp);

    line = allocate(file_size+1);

    begin_package = allocate(MAX_PKG_LEN+4);
    sprintf(begin_package, "<%s>\n", package);

    end_package = allocate(MAX_PKG_LEN+4);
    sprintf(end_package, "</%s>\n", package);

    /* Locate the beginning of the patch section for this package */
    if( file_size > 1 )
    while(fgets(line, file_size, fp)!=NULL)
    {
        if( commented(line) )
            continue;

        if( strcmp(line, begin_package) == 0 )
        {
            if( file_size > 1 )
            while(fgets(line, file_size, fp)!=NULL)
            {
                if( commented(line) )
                    continue;

                if( strcmp(line, end_package) == 0 )
                    break;

                if( ! strstr(line, "<patches>") )
                    continue;
                else
                {
                    found = 1;
                    break;
                }
            }
        }
        if( found )
            break;
    }

    /* Record how many patches this package has */
    if( found )
    {
        if( file_size > 1 )
        while(fgets(line, file_size, fp)!=NULL)
        {
            if( strcmp(line, end_package) == 0 )
                break;

            if( strstr(line, "</patches>") )
                break;

            if( num_files < MAX_NUM_OF_PACKAGES )
                num_files++;
        }
    }
    fclose(fp);
    free(line);
    free(begin_package);
    free(end_package);

    return num_files;
}


long get_num_requires_from_package(char *package)
{
    FILE *fp;
    char *line, *begin_package, *end_package;
    long file_size = 0, req_num = 0;
    int found = 0;

    if((fp=fopen(pkgconf_temp, "r"))==NULL)
    {
        perror("fopen");
        printf("Fatal error opening file [%s]\n", pkgconf_temp);
        return 0;
    }
    fseek(fp, 0, SEEK_END);
    file_size = ftell(fp);
    rewind(fp);

    line = allocate(file_size+1);

    begin_package = allocate(MAX_PKG_LEN+4);
    sprintf(begin_package, "<%s>\n", package);

    end_package = allocate(MAX_PKG_LEN+4);
    sprintf(end_package, "</%s>\n", package);

    /* Locate the beginning of the requires section for this package */
    if( file_size > 1 )
    while(fgets(line, file_size, fp)!=NULL)
    {
        if( commented(line) )
            continue;

        if( strcmp(line, begin_package) == 0 )
        {
            if( file_size > 1 )
            while(fgets(line, file_size, fp)!=NULL)
            {
                if( commented(line) )
                    continue;

                if( strcmp(line, end_package) == 0 )
                    break;

                if( ! strstr(line, "<requires>") )
                    continue;
                else
                {
                    found = 1;
                    break;
                }
            }
        }
        if( found )
            break;
    }

    /* Record how many required packages this package has */
    if( found )
    {
        if( file_size > 1 )
        while(fgets(line, file_size, fp)!=NULL)
        {
            if( strcmp(line, end_package) == 0 )
                break;

            if( strstr(line, "</requires>") )
                break;

            if( req_num < MAX_NUM_OF_PACKAGES )
                req_num++;
            else
                printf("MAX_NUM_OF_PACKAGES reached, required package nr: %d skipped.\n", MAX_NUM_OF_PACKAGES);
        }
    }
    fclose(fp);
    free(line);
    free(begin_package);
    free(end_package);

    return req_num;
}


/* Get version for a package from temp or sysconfdir packages.conf file.
   If where is "1" then use the temporary packages.conf.
   If where is "2" then use SYSCONFDIR/admin-packages/packages.conf */
char * get_version_from_package(int where, char *package)
{
    FILE *fp;
    char *conf_version, *line, *tmp_package;
    int i=0, begin=0, pkg_found=0, version_set=0;
    long file_size=0;

    if( where == 1 )
    {
        if((fp=fopen(pkgconf_temp, "r"))==NULL)
        {
            printf("Error getting package version from file: [%s]\n", pkgconf_temp);
            return 0;
        }
    }
    else
    if( where == 2 )
    {
        if((fp=fopen(PACKAGES_CONF, "r"))==NULL)
        {
            printf("Error getting package version from file: [%s]\n", PACKAGES_CONF);
            return 0;
        }
    }
    else
    {
        printf("Error: get_version_from_packages() must have a valid where parameter.\n");
        return 0;
    }
    fseek(fp, 0, SEEK_END);
    file_size = ftell(fp);
    rewind(fp);

    line = allocate(file_size+1);
    conf_version = allocate(MAX_LINE_LEN+1);

    tmp_package = allocate(MAX_PKG_LEN+1);
    sprintf(tmp_package, "<%s>\n", package);

    if( file_size > 1 )
    while(fgets(line, file_size, fp)!=NULL)
    {
        if( commented(line) )
            continue;

        if( strlen(line) > MAX_LINE_LEN-1 )
            continue;

        /* Is this an exact package name match */
        if( strcmp(line, tmp_package) == 0 )
        {
            pkg_found = 1;

            if( file_size > 1 )
            while(fgets(line, file_size, fp)!=NULL)
            {
                if( commented(line) )
                    continue;

                if( strlen(line) > MAX_LINE_LEN-1 )
                    continue;

                if( strstr(line, "<") )
                    break;

                if( ! strstr(line, "version=") )
                    continue;

                /* Isolate the version (this must be the line) */
                for(i=0; i < strlen(line); i++)
                {
                    if( i > 1 && line[i-1]=='"' )
                    {
                        begin=i;
                        break;
                    }
                }

                for(i=begin; i < strlen(line); i++)
                {
                    if( i > 1 && line[i]=='"' && i > begin )
                    {
                        if( strlen(line) < MAX_VER_LEN-1 )
                        {
                            strncpy(conf_version, &line[begin], i-begin);
                            version_set = 1;
                        }
                        else
                        {
                            printf("The remote conf has a bad version length.\n");
                            printf("It exceeds %i chars\n", MAX_VER_LEN-1);
                        }

                        break;
                    }

                    if( version_set )
                        break;
                }
            }
        }

        if( pkg_found )
            break;
    }
    fclose(fp);
    free(tmp_package);
    free(line);

    return conf_version;
}


/* Get remote directory name: directory="..." */
char *get_directory_from_package(char *package)
{
    FILE *fp;
    char *dir, *line, *tmp_package;
    int i=0, begin=0, pkg_found=0, dir_set=0;
    long file_size=0;

    if((fp=fopen(pkgconf_temp, "r"))==NULL)
    {
        perror("fopen");
        printf("Fatal error opening file [%s]\n", pkgconf_temp);
        return 0;
    }
    fseek(fp, 0, SEEK_END);
    file_size=ftell(fp);
    rewind(fp);

    line = allocate(file_size+1);
    dir = allocate(MAX_SECTION_LEN+1);

    tmp_package = allocate(MAX_PKG_LEN+4);
    sprintf(tmp_package, "<%s>\n", package);

    if( file_size > 1 )
    while(fgets(line, file_size, fp)!=NULL)
    {
        if( commented(line) )
            continue;

        /* Is this an exact package match */
        if( strcmp(line, tmp_package) == 0 )
        {
            pkg_found = 1;

            if( file_size > 1 )
            while(fgets(line, file_size, fp)!=NULL)
            {
                if( commented(line) )
                    continue;

                if( strstr(line, "<") )
                    break;

                if( ! strstr(line, "directory=") )
                    continue;

                /* Isolate the version (this must be the line) */
                for(i=0; i < MAX_SECTION_LEN-1; i++)
                {
                    if( i > 1 && line[i-1]=='"' )
                    {
                        begin = i;
                        break;
                    }
                }

                for(i=begin; i < MAX_SECTION_LEN-1; i++)
                {
                    if( i > 1 && line[i]=='"' && i > begin )
                    {
                        strncpy(dir, &line[begin], i-begin);
                        if( strlen(dir) < MAX_SECTION_LEN )
                        {
                            dir_set = 1;
                        }
                        else
                        {
                            printf("The local conf has a bad type length.\n");
                            printf("It exceeds %i chars\n", MAX_SECTION_LEN-1);
                        }

                        break;
                    }

                    if( dir_set )
                        break;
                }
            }
        }

        if( pkg_found )
            break;
    }
    fclose(fp);
    free(tmp_package);
    free(line);

    return dir;
}


/* Get unpacked name from the package conf */
char *get_unpacked_name_from_package(char *package)
{
    FILE *fp;
    char *conf_section, *line, *tmp_package;
    int i=0, begin=0, pkg_found=0, section_set=0;
    long file_size=0;

    if((fp=fopen(pkgconf_temp, "r"))==NULL)
    {
        perror("fopen");
        printf("Fatal error opening file [%s]\n", pkgconf_temp);
        return 0;
    }
    fseek(fp, 0, SEEK_END);
    file_size = ftell(fp);
    rewind(fp);

    line = allocate(file_size+1);
    conf_section = allocate(MAX_SECTION_LEN+1);

    tmp_package = allocate(MAX_PKG_LEN+4);
    sprintf(tmp_package, "<%s>\n", package);

    if( file_size > 1 )
    while(fgets(line, file_size, fp)!=NULL)
    {
        if( commented(line) )
            continue;

        /* Is this an exact package match */
        if( strcmp(line, tmp_package) == 0 )
        {
            pkg_found = 1;

            if( file_size > 1 )
            while(fgets(line, file_size, fp)!=NULL)
            {
                if( commented(line) )
                    continue;

                if( strstr(line, "<") )
                    break;

                if( ! strstr(line, "unpacked-name=") )
                    continue;

                /* Isolate the version (this must be the line) */
                for(i=0; i < MAX_SECTION_LEN-1; i++)
                {
                    if( i > 1 && line[i-1]=='"' )
                    {
                        begin=i;
                        break;
                    }
                }

                for(i=begin; i < MAX_SECTION_LEN-1; i++)
                {
                    if( i > 1 && line[i]=='"' && i > begin )
                    {
                        strncpy(conf_section, &line[begin], i-begin);
                        if( strlen(conf_section) < MAX_SECTION_LEN )
                        {
                            section_set = 1;
                        }
                        else
                        {
                            printf("The local conf has a bad type length.\n");
                            printf("It exceeds %i chars\n", MAX_SECTION_LEN-1);
                        }

                        break;
                    }

                    if( section_set )
                        break;
                }
            }
        }

        if( pkg_found )
            break;
    }
    fclose(fp);
    free(tmp_package);
    free(line);

    return conf_section;
}



char * get_pre_install_from_package(char *package)
{
    FILE *fp;
    char *conf_section, *line, *begin_package, *end_package;
    long file_size = 0;
    int found = 0;

    if((fp=fopen(pkgconf_temp, "r"))==NULL)
    {
        perror("fopen");
        printf("Fatal error opening file [%s]\n", pkgconf_temp);
        return 0;
    }
    fseek(fp, 0, SEEK_END);
    file_size = ftell(fp);
    rewind(fp);

    line = allocate(file_size+1);
    conf_section = allocate(file_size+1);

    begin_package = allocate(MAX_PKG_LEN+4);
    sprintf(begin_package, "<%s>\n", package);

    end_package = allocate(MAX_PKG_LEN+4);
    sprintf(end_package, "</%s>\n", package);

    /* Locate the beginning of the pre-install section for this package */
    if( file_size > 1 )
    while(fgets(line, file_size, fp)!=NULL)
    {
        if( commented(line) )
            continue;

        if( strcmp(line, begin_package) == 0 )
        {
            if( file_size > 1 )
            while(fgets(line, file_size, fp)!=NULL)
            {
                if( commented(line) )
                    continue;

                if( strcmp(line, end_package) == 0 )
                    break;

                if( ! strstr(line, "<pre-install>") )
                    continue;
                else
                {
                    found = 1;
                    break;
                }
            }
        }
        if( found )
            break;
    }

    /* Save the section */
    if( found )
    {
        if( file_size > 1 )
        while(fgets(line, file_size, fp)!=NULL)
        {
            if( strcmp(line, end_package) == 0 )
                break;

            if( strstr(line, "</pre-install>") )
                break;

            strcat(conf_section, line);
        }
    }

    fclose(fp);
    free(line);
    free(begin_package);
    free(end_package);

    return conf_section;
}


char * get_install_from_package(char *package)
{
    FILE *fp;
    char *conf_section, *line, *begin_package, *end_package;
    long file_size = 0;
    int found = 0;

    if((fp=fopen(pkgconf_temp, "r"))==NULL)
    {
        perror("fopen");
        printf("Fatal error opening file [%s]\n", pkgconf_temp);
        return 0;
    }
    fseek(fp, 0, SEEK_END);
    file_size = ftell(fp);
    rewind(fp);

    line = allocate(file_size+1);
    conf_section = allocate(file_size+1);

    begin_package = allocate(MAX_PKG_LEN+4);
    sprintf(begin_package, "<%s>\n", package);

    end_package = allocate(MAX_PKG_LEN+4);
    sprintf(end_package, "</%s>\n", package);

    /* Locate the beginning of the install section for this package */
    if( file_size > 1 )
    while(fgets(line, file_size, fp)!=NULL)
    {
        if( commented(line) )
            continue;

        if( strcmp(line, begin_package) == 0 )
        {
            if( file_size > 1 )
            while(fgets(line, file_size, fp)!=NULL)
            {
                if( commented(line) )
                    continue;

                if( strcmp(line, end_package) == 0 )
                    break;

                if( ! strstr(line, "<installation>") )
                    continue;
                else
                {
                    found = 1;
                    break;
                }
            }
        }
        if( found )
            break;
    }

    /* Save the section */
    if( found )
    {
        if( file_size > 1 )
        while(fgets(line, file_size, fp)!=NULL)
        {
            if( strcmp(line, end_package) == 0 )
                break;

            if( strstr(line, "</installation>") )
                break;

            strcat(conf_section, line);
        }
    }

    fclose(fp);
    free(line);
    free(begin_package);
    free(end_package);

    return conf_section;
}


char * get_post_install_from_package(char *package)
{
    FILE *fp;
    char *conf_section, *line, *begin_package, *end_package;
    long file_size = 0;
    int found = 0;

    if((fp=fopen(pkgconf_temp, "r"))==NULL)
    {
        perror("fopen");
        printf("Fatal error opening file [%s]\n", pkgconf_temp);
        return 0;
    }
    fseek(fp, 0, SEEK_END);
    file_size = ftell(fp);
    rewind(fp);

    line = allocate(file_size+1);
    conf_section = allocate(file_size+1);

    begin_package = allocate(MAX_PKG_LEN+4);
    sprintf(begin_package, "<%s>\n", package);

    end_package = allocate(MAX_PKG_LEN+4);
    sprintf(end_package, "</%s>\n", package);

    /* Locate the beginning of the post-install section for this package */
    if( file_size > 1 )
    while(fgets(line, file_size, fp)!=NULL)
    {
        if( commented(line) )
            continue;

        if( strcmp(line, begin_package) == 0 )
        {
            if( file_size > 1 )
            while(fgets(line, file_size, fp)!=NULL)
            {
                if( commented(line) )
                    continue;

                if( strcmp(line, end_package) == 0 )
                    break;

                if( ! strstr(line, "<post-install>") )
                    continue;
                else
                {
                    found = 1;
                    break;
                }
            }
        }
        if( found )
            break;
    }

    /* Save the section */
    if( found )
    {
        if( file_size > 1 )
        while(fgets(line, file_size, fp)!=NULL)
        {
            if( strcmp(line, end_package) == 0 )
                break;

            if( strstr(line, "</post-install>") )
                break;

            strcat(conf_section, line);
        }
    }

    fclose(fp);
    free(line);
    free(begin_package);
    free(end_package);

    return conf_section;
}


char * get_description_from_package(char *package)
{
    FILE *fp;
    char *conf_section, *line, *begin_package, *end_package;
    long file_size = 0;
    int found = 0;

    if((fp=fopen(PACKAGES_CONF, "r"))==NULL)
    {
        perror("fopen");
        printf("Fatal error opening file [%s]\n", PACKAGES_CONF);
        return 0;
    }
    fseek(fp, 0, SEEK_END);
    file_size = ftell(fp);
    rewind(fp);

    line = allocate(file_size+1);
    conf_section = allocate(file_size+1);

    begin_package = allocate(MAX_PKG_LEN+4);
    sprintf(begin_package, "<%s>\n", package);

    end_package = allocate(MAX_PKG_LEN+4);
    sprintf(end_package, "</%s>\n", package);

    /* Locate the beginning of the description for this package */
    if( file_size > 1 )
    while(fgets(line, file_size, fp)!=NULL)
    {
        if( commented(line) )
            continue;

        if( strcmp(line, begin_package) == 0 )
        {
            if( file_size > 1 )
            while(fgets(line, file_size, fp)!=NULL)
            {
                if( commented(line) )
                    continue;

                if( strcmp(line, end_package) == 0 )
                    break;

                if( ! strstr(line, "<description>") )
                    continue;
                else
                {
                    found = 1;
                    break;
                }
            }
        }
        if( found )
            break;
    }

    /* Save the section */
    if( found )
    {
        if( file_size > 1 )
        while(fgets(line, file_size, fp)!=NULL)
        {
            if( strcmp(line, end_package) == 0 )
                break;

            if( strstr(line, "</description>") )
                break;

            strcat(conf_section, line);
        }
    }

    fclose(fp);
    free(line);
    free(begin_package);
    free(end_package);

    return conf_section;
}


char ** get_required_packages(char *package)
{
    FILE *fp;
    char **reqpackages;
    char *begin_package, *end_package, *line;
    int numdeps = 1; /* Always keep 1 slot for the closing NULL */
    int i=0, found = 0;
    long file_size = 0;
    long requires_section = 0;

    if((fp=fopen(pkgconf_temp, "r"))==NULL)
    {
        perror("fopen");
        printf("Fatal error opening file [%s]\n", pkgconf_temp);
        reqpackages = NULL;
        return reqpackages;
    }
    fseek(fp, 0, SEEK_END);
    file_size = ftell(fp);
    rewind(fp);

    line = allocate(file_size+1);

    begin_package = allocate(MAX_PKG_LEN+10);
    sprintf(begin_package, "<%s>\n", package);

    end_package = allocate(MAX_PKG_LEN+10);
    sprintf(end_package, "</%s>\n", package);


    /* Scroll to the beginning of the package */
    if( file_size > 1 )
    while(fgets(line, file_size, fp)!=NULL)
    {
        if( commented(line) )
            continue;

        if( strcmp(line, begin_package) == 0 )
        {
            found = 1;
            break;
        }
    }

    if( found )
    {
        /* Scroll to the <requires> section of this package */
        found = 0;
        if( file_size > 1 )
        while(fgets(line, file_size, fp)!=NULL)
        {
            if( commented(line) )
                continue;

            if( strstr(line, "<requires>") )
            {
                found = 1;
                requires_section = ftell(fp); /* Store position */
                break;
            }
            /* Package require section not found */	
            if( strcmp(line, end_package) == 0 )
                break;
        }
    }

    /* While its not the end of the requires or package section, count required packages */
    if( found )
    {
        if( file_size > 1 )
        while(fgets(line, file_size, fp)!=NULL && ! strstr(line,"</requires>"))
            if( ! commented(line) && strlen(line) < MAX_PKG_LEN-1 )
                numdeps++;
    }

    /* numdeps is numdeps+1 for the closing NULL */
    reqpackages = malloc(numdeps*sizeof(char *));

    /* While its not the end of the requires or package section, add required packages */
    if( found )
    {
        fseek(fp, requires_section, SEEK_SET);
        if( file_size > 1 )
        while(fgets(line, file_size, fp)!=NULL && ! strstr(line,"</requires>"))
            if( ! commented(line) && strlen(line) < MAX_PKG_LEN-1 )
            {
                reqpackages[i] = malloc(strlen(line)+1);
                sscanf(line, "%s", reqpackages[i]); /* We only want the package name */
                i++;
            }
    }

    reqpackages[i] = NULL; /* End with a NULL */

    fclose(fp);
    free(line);
    free(begin_package);
    free(end_package);

    return reqpackages;
}


/* Get settings from settings.conf */
char * get_from_settings(char *setting)
{
    FILE *fp;
    char *line, *retval;
    int i=0;
    long file_size=0;

    if((fp=fopen(SETTINGS_CONF, "r"))==NULL)
    {
        perror("fopen");
        printf("Fatal error opening file [%s]\n", SETTINGS_CONF);
        return NULL;
    }
    fseek(fp, 0, SEEK_END);
    file_size = ftell(fp);
    rewind(fp);

    line = allocate(file_size);
    retval = allocate(1024+1);

    if( file_size > 1 )
    while(fgets(line, file_size, fp)!=NULL)
    {
        if( commented(line) || strlen(line) < 3 )
            continue;

        if( strstr(line, setting) )
        {
            for(i=0; i<1000; i++)
                if( line[i]=='=' )
                    break;

            snprintf(retval, 1024, "%s", &line[i+2]);
            retval[strlen(retval)-2]='\0';
            break;
        }
    }
    fclose(fp);
    free(line);

    return retval;
}


/* Shows what package(s) installed a file */
void package_installed_file(char *inputpath)
{
    FILE *fp;
    long x = 0, num = 0, file_size = 0;
    char *line, *filepath;
    struct dirent **namelist;
    int found = 0;

    num = scandir(INSTALLED_PATH, &namelist, 0, alphasort);
    if( num < 0 )
    {
        perror("scandir");
        return;
    }
    else
    {
        filepath = allocate(17000);

        /* List all file in INSTALLED_PATH */
        for(x=0; x<num; x++)
        {
            snprintf(filepath, 16384, "%s/%s", INSTALLED_PATH, namelist[x]->d_name);

            if((fp=fopen(filepath, "r"))==NULL)
            {
                free(namelist[x]);
                continue;
            }
            fseek(fp, 0, SEEK_END);
            file_size = ftell(fp) +1;
            rewind(fp);

            line = allocate(file_size+1);

            if( file_size > 1 )
            while(fgets(line, file_size, fp)!=NULL)
            {
                if( line[strlen(line)-1]=='\n' )
                    line[strlen(line)-1]='\0';

                if( strcmp(line, inputpath) == 0 )
                {
                    printf("Package: [%s] installed: [%s]\n", namelist[x]->d_name, inputpath);
                    found = 1;
                }
            }
            fclose(fp);
            free(line);
            free(namelist[x]);
        }
        free(filepath);
    }
    free(namelist);

    if( ! found )
        printf("No package seems to have installed file: [%s]\n", inputpath);
}
