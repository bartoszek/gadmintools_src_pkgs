/*
 * Admin-Packages - A Package manager for sources.
 * Copyright (C) 2009 - 2011 Magnus Loef <magnus-swe@telia.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307, USA.
 *
 */


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "globals.h"
#include "allocate.h"
#include "get_package_info.h"
#include "queue_package.h"
#include "handle_dependencies.h"
#include "have_equal_or_higher_version.h"
#include "package_in_conf.h"

/* A record of already handeled dependencies.
   Freed after handle_install_dependencies();
   in make_install_list_from_package.c */
extern char *rec_saver[MAX_NUM_OF_PACKAGES];


void handle_install_dependencies(char *package)
{
    int i;
    char *version;
    char **deps, **loopdeps;

    for(i=0; rec_saver[i]; i++)
    {
        /* Exit if the package limit is reached */
        if( i >= MAX_NUM_OF_PACKAGES-1 )
        {
            printf("Maximum number of dependencies reached: [%d]\nInstallation failed.\n", i-1);
            free(package);

            /* Free the records */
            for(i=0; rec_saver[i]; i++)
            {
                free(rec_saver[i]);
                rec_saver[i] = NULL;
            }
            exit(EXIT_FAILURE);
        }

        if( strcmp(rec_saver[i], package) == 0 )
            return; /* Already handling it */
    }

    if( ! package_in_tmp_conf(package) )
    {
        printf("\nError: Non existent dependency found: [%s]\n", package);
        exit(EXIT_FAILURE);
    }

    /* Add this package as a handled dependency */
    rec_saver[i] = malloc(strlen(package)+1);
    strcpy(rec_saver[i], package);

    deps = get_required_packages(package);

    /* Calls itself with the dependencies */
    for(loopdeps=deps; *loopdeps; loopdeps++) 
    {
        handle_install_dependencies(*loopdeps);
        free(*loopdeps);
    }
    free(deps);

    /* Queue the package for install if we dont have it or
       the version to be installed is higher then we have installed.
       If option reinstall is selected itll also queue the package. */

    /* Get from downloaded temporary packages.conf */
    version = get_version_from_package(1, package);
    if( ! have_equal_or_higher_version(package, version) )
    {
        free(version);
        /* We want a progress meter.
           End with "\n" in the calling function */
        printf(". ");
        queue_package_for_install(package);
    }
    else
      free(version);
}


void handle_uninstall_dependencies(char *package)
{
    int i;
    char **deps, **loopdeps;

    for(i=0; rec_saver[i]; i++)
    {
        /* Exit if the package limit is reached */
        if( i >= MAX_NUM_OF_PACKAGES-1 )
        {
            printf("Maximum number of dependencies reached: [%d]\nUninstall failed.\n", i-1);
            free(package);

            /* Free the records */
            for(i=0; rec_saver[i]; i++)
            {
                free(rec_saver[i]);
                rec_saver[i] = NULL;
            }
            exit(EXIT_FAILURE);
        }

        if( strcmp(rec_saver[i], package) == 0 )
            return; /* already handling it */
    }

    /* Add this package as a handled dependency */
    rec_saver[i] = malloc(strlen(package)+1);
    strcpy(rec_saver[i], package);

    deps = get_depending_packages(package);

    /* Calls itself with the dependencies */
    for(loopdeps=deps; *loopdeps; loopdeps++) 
    {
        handle_uninstall_dependencies(*loopdeps);
        free(*loopdeps);
    }
    free(deps);

    /* We want a progress meter.
       End with "\n" in the calling function */
    printf(". ");
    queue_package_for_uninstall(package);
}
