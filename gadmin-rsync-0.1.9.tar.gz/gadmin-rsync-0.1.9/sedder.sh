

for i in `ls src/`
do
    sed -e 's/2007-2011/2007 - 2014/g' src/$i > src/$i.new;
    mv src/$i.new src/$i;
done
