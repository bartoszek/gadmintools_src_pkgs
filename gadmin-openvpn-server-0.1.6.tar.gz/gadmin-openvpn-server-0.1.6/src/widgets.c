/* GAdmin-OpenVPN - An easy to use GTK+ frontend for the openvpn server.
 * Copyright (C) 2008 - 2011 Magnus Loef <magnus-swe@telia.com> 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
*/



#include <gtk/gtk.h>

/* Make sure we have enough of these or itll borrow from the next widget-type and fail */
#define NUM_SERVERTAB_ENTRIES 25
#define NUM_SERVERTAB_SPINBUTTONS 13
#define NUM_SERVERTAB_COMBOS 16


#define NUM_USERTAB_ENTRIES 7
#define NUM_USERTAB_SPINBUTTONS 1
#define NUM_USERTAB_CHECKBUTTONS 3
#define NUM_USERTAB_COMBOS 1


typedef struct w
{
  GtkWidget *main_window;
  GtkWidget *main_vbox;

  GtkWidget *notebook_vbox1;
  GtkWidget *notebook_vbox2;
  GtkWidget *notebook_vbox3;
  GtkWidget *notebook_vbox4;
  GtkWidget *notebook_vbox5;
  GtkWidget *notebook_vbox6;
  GtkWidget *notebook_vbox7;
  GtkWidget *notebook_vbox8;

  GtkWidget *status_label;
  GtkWidget *version_label;

  /* The server tab's widgets */
  GtkWidget *server_treeview;
  GtkListStore *server_store;
  GtkWidget *server_settings_vbox;
  GtkWidget *server_settings_scrolled_window;

  GtkWidget *server_set_entry[NUM_SERVERTAB_ENTRIES];
  GtkWidget *server_set_spinbutton[NUM_SERVERTAB_SPINBUTTONS];
  GtkWidget *server_set_combo[NUM_SERVERTAB_COMBOS];
  GtkWidget *srv_set_table;

  /* The export windows widgets */
  GtkWidget *export_window;
  GtkWidget *export_dir_entry;
  GtkWidget *export_user_entry;
  GtkWidget *export_to_windows_checkbutton;

  /* The user tab's widgets */
  GtkWidget *user_treeview;
  GtkListStore *user_store;
  GtkWidget *user_settings_vbox;
  GtkWidget *user_settings_scrolled_window;
  GtkWidget *user_set_entry[NUM_USERTAB_ENTRIES];
  GtkWidget *user_set_spinbutton[NUM_USERTAB_SPINBUTTONS];
  GtkWidget *user_set_checkbutton[NUM_USERTAB_CHECKBUTTONS];
  GtkWidget *user_set_combo[NUM_USERTAB_COMBOS];
  GtkWidget *gen_cert_progressbar;
  GtkWidget *usr_set_table;
  GtkWidget *ccd_textview;

  /* The delete system user question window */
  GtkWidget *del_system_user_question_window;

  /* The add default configuration question window */
  GtkWidget *default_conf_question_window;

  /* The disc tabs widgets */
  GtkWidget *disc_treeview;
  GtkListStore *disc_store;

  /* The connection tabs widgets */
  GtkWidget *conn_treeview;
  GtkListStore *conn_store;

  /* The log tabs widgets */
  GtkWidget *log_treeview;
  GtkListStore *log_store;

  /* The conf tabs textview */
  GtkWidget *conf_textview;

}wid;
