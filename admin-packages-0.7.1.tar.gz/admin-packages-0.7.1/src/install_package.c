/*
 * Admin-Packages - A Package manager for sources.
 * Copyright (C) 2009 - 2011 Magnus Loef <magnus-swe@telia.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307, USA.
 *
 */


#include "../config.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "allocate.h"
#include "globals.h"
#include "file_exists.h"
#include "install_package.h"
#include "get_package_info.h"
#include "transform.h"
#include "run_command.h"
#include "question_yes.h"

extern char build_directory[MAX_TEMP_PATH];
extern char install_log[MAX_TEMP_PATH];
extern int  global_ask_questions;
extern int  global_show_commands;
extern int  global_verbose;


/* Does the file path exist in the temporary install log file */
int path_exists_in_install_log(char *filepath)
{
    FILE *fp;
    long file_size = 0;
    char *line;
    int ret = 0;

    if((fp=fopen(install_log, "r"))==NULL)
    {
        /* Dont notify */
        return 0;
    }
    fseek(fp, 0, SEEK_END);
    file_size = ftell(fp);
    rewind(fp);

    line = allocate(file_size+1);

    if( file_size > 1 )
    while(fgets(line, file_size, fp)!=NULL)
    {
        if( strlen(line) < 3 )
            continue;

        if( line[strlen(line)-1]=='\n' )
            line[strlen(line)-1]='\0';

        if( strcmp(filepath, line) == 0 )
        {
            ret = 1;
            break;
        }
    }
    fclose(fp);
    free(line);

    return ret;
}


/* Copy all file paths that reference /etc/... from
   INSTALLED_PATH/packageName to the tmp file list
   if the files does not exist there.
   The tmp file should then be moved to the installed path */
void rebuild_file_list(char *package)
{
    FILE *fp;
    long file_size = 0;
    char *line, *newbuf, *installed_file;

    installed_file = allocate(strlen(INSTALLED_PATH)+strlen(package)+2);
    sprintf(installed_file, "%s/%s", INSTALLED_PATH, package);

    if((fp=fopen(installed_file, "r"))==NULL)
    {
        /* Dont notify */
        free(installed_file);
        return;
    }
    fseek(fp, 0, SEEK_END);
    file_size = ftell(fp);
    rewind(fp);

    line   = allocate(file_size+1);
    newbuf = allocate(file_size+1);

    if( file_size > 1 )
    while(fgets(line, file_size, fp)!=NULL)
    {
        if( strlen(line) < 3 )
            continue;

        if( line[strlen(line)-1]=='\n' )
            line[strlen(line)-1]='\0';

        if( ! path_exists_in_install_log(line) )
        {
            strcat(newbuf, line);
            strcat(newbuf, "\n");
        }
    }
    fclose(fp);
    free(line);
    free(installed_file);

    /* Write the missing file paths to the temporary install log file */
    if((fp=fopen(install_log, "a+"))==NULL)
    {
        printf("Error adding to the temporary install log: %s\n", install_log);
        free(newbuf);
        return;
    }
    fputs(newbuf, fp);
    fclose(fp);
    free(newbuf);
}


/* Removes non existent system file paths from the installed files list.
   Adds 2 configuration files if the package name is "admin-packages" and DESTDIR isnt used. */
void clean_file_list(char *package)
{
    FILE *fp;
    long file_size = 0;
    char *line, *newbuf, *installed_file;
    int have_servers = 0, have_settings = 0;
    char *envpath;

    /* Get DESTDIR environment variable if set */
    envpath = getenv("DESTDIR");

    installed_file = allocate(strlen(INSTALLED_PATH)+strlen(package)+2);
    sprintf(installed_file, "%s/%s", INSTALLED_PATH, package);

    if((fp=fopen(installed_file, "r"))==NULL)
    {
        /* Dont notify */
        free(installed_file);
        return;
    }
    fseek(fp, 0, SEEK_END);
    file_size = ftell(fp);
    rewind(fp);

    line   = allocate(file_size+1);
    newbuf = allocate(file_size+1024);

    if( file_size > 1 )
    while(fgets(line, file_size, fp)!=NULL)
    {
        if( strlen(line) < 3 )
            continue;

        if( line[strlen(line)-1]=='\n' )
            line[strlen(line)-1]='\0';

        if( file_exists(line) )
        {
            strcat(newbuf, line);
            strcat(newbuf, "\n");
        }
        else
        if( global_verbose )
            printf("Removing non existent file path from installed file:\n[%s]\n", line);

        /* Add unloggable package manager config files */
        if( strcmp(package, "admin-packages") == 0 )
        {
            if( strstr(line, "/etc/admin-packages/servers.conf") )
                have_servers  = 1;
            if( strcmp(line, "/etc/admin-packages/settings.conf") )
                have_settings = 1;
        }
    }
    fclose(fp);
    free(line);

    /* Add unloggable package manager config files */
    if( ! have_servers && strcmp(package, "admin-packages") == 0 && envpath == NULL )
        strcat(newbuf, "/etc/admin-packages/servers.conf\n");
    else
    if( ! have_servers && strcmp(package, "admin-packages") == 0 )
    {
        strcat(newbuf, envpath);
        strcat(newbuf, "/etc/admin-packages/servers.conf\n");
    }

    if( ! have_settings && strcmp(package, "admin-packages") == 0 && envpath == NULL )
        strcat(newbuf, "/etc/admin-packages/settings.conf\n");
    else
    if( ! have_servers && strcmp(package, "admin-packages") == 0 )
    {
        strcat(newbuf, envpath);
        strcat(newbuf, "/etc/admin-packages/settings.conf\n");
    }


    /* Write the new installed file contents */
    if((fp=fopen(installed_file, "w+"))==NULL)
    {
        printf("Error writing a new installed file: %s\n", installed_file);
        free(installed_file);
        free(newbuf);
        return;
    }
    fputs(newbuf, fp);
    fclose(fp);
    free(installed_file);
    free(newbuf);
}


/* This installs the packages, "install_mode 1" logs installed files and
   directories from the <installation> sections commands. */
int install_ok(char *package, char *install_cmds, int install_mode)
{
    FILE *fp;
    char *cmd, *install_file, *transformed_install;
    int ret = 0;

    /* A package can have empty pre-install and install sections */
    if( install_cmds == NULL || strlen(install_cmds) < 4 )
    {
        printf("Information: package [%s]\nhas an empty install section, continuing.\n", package);
        return 1;
    }

    /* Put an install file in the package directory and run it */
    install_file = allocate(strlen(build_directory)+100);
    sprintf(install_file, "%s/%s", build_directory, INSTALL_SCRIPT_NAME);

    if((fp=fopen(install_file, "w+"))==NULL)
    {
       printf("Error writing install file: %s\n", install_file);
       free(install_file);
       return 0;
    }
    fputs(install_cmds, fp);
    fclose(fp);

    /* Transforms the installfile's variables */
    transformed_install = transform_install_variables(install_file);
    if( transformed_install == NULL )
    {
        printf("Transforming install variables failed.\n");
        free(install_file);
        return 0;
    }
    free(install_file);

    /* Show the installation commands if requested. */
    if( global_show_commands )
    {
        printf("\n------------ Installation commands -------------------\n%s\n", transformed_install);
        printf("------------------------------------------------------\n");
    }
    free(transformed_install);

    /* Ask if the user wants to proceed if requested. */
    if( global_ask_questions )
    {
        if( global_show_commands )
            printf("Do you wish to run the above commands to install this package [y/n]: ");
        else
            printf("Do you wish to install this package [y/n]: ");

        if( question_yes() )
            printf("Proceeding with installation\n");
        else
        {
            printf("Installation aborted by user\n");
            return 2; /* Dont continue */
        }
    }

    if( global_verbose )
    {
        if( install_mode )
            printf("Logging installation...\n");
        else
            printf("Configuring and making, not running or logging installation...\n");
    }

    /* Run the install file with the install logger preloaded */
    cmd = allocate(strlen(build_directory)+strlen(INSTALL_LOG_LIB)+strlen(INSTALL_SCRIPT_NAME)+100);

    if( install_mode )
    {
        sprintf(cmd, "cd %s && chmod 755 %s && LD_PRELOAD=%s ./%s",
        build_directory, INSTALL_SCRIPT_NAME, INSTALL_LOG_LIB, INSTALL_SCRIPT_NAME);
    }
    else
    {
        sprintf(cmd, "cd %s && chmod 755 %s && ./%s",
        build_directory, INSTALL_SCRIPT_NAME, INSTALL_SCRIPT_NAME);
    }

    /* Set build directory as an environment variable for log.c */
    setenv("ADMIN_PACKAGES_BUILD", build_directory, 1);

    /* Run the install phase */
    if( ! run_command(cmd) )
        ret = 0;
    else
        ret = 1;

    free(cmd);

    unsetenv("ADMIN_PACKAGES_BUILD");

    /* Save the install log for the package */
    if( install_mode && file_exists(install_log) )
    {
        /* Rebuild file list. Add /etc/... paths that
           are not logged/installed because they existed */
        rebuild_file_list(package);

        /* Copy /var/admin-packages/tmp/build_directory/admin-packages.log
           to /var/admin-packages/installed/PackageName */
        cmd = allocate(strlen(install_log)+strlen(INSTALLED_PATH)+strlen(package)+10);
        sprintf(cmd, "mv %s %s/%s", install_log, INSTALLED_PATH, package);

        if( ! run_command(cmd) )
        {
            printf("\nError moving the install information\n\n");
            ret = 0;
        }
        else
        {
            if( global_verbose )
            {
                printf("\nPackage uninstall information was stored here:\n%s/%s\n",
                                                            INSTALLED_PATH, package);
            }
            ret = 1;

            /* Remove file paths that does not exist on the system */
            clean_file_list(package);
        }

        free(cmd);
    }
    else
    if( install_mode )
    {
        printf("Uninstall information could not be retrieved for package: %s\n", package);
        printf("From installation log: %s\n\n", install_log);
        ret = 0;
    }

    return ret;
}


int install_package(char *package)
{
    char *install;
    int ret = 0;

    /* Get the <pre-install> section if any and install it, but dont log = 0 */
    install = get_pre_install_from_package(package);
    if( install != NULL && strlen(install) > 1 )
    {
        ret = install_ok(package, install, 0);
    }
    else
      ret = 1; /* Its ok if pre-install is empty */

    if( install != NULL )
        free(install);

    /* Fail on errors or if the user want to quit */
    if( ret == 0 || ret == 2 )
    {
        printf("Package pre-install phase was not successful.\n");
        return 0;
    }
    if( global_verbose )
    {
        if( ret == 1 )
          printf("Package pre-install phase was successful.\n");
    }

    /* Get the <installation> section and install it, enable logging = 1 */
    install = get_install_from_package(package);
    ret = install_ok(package, install, 1);
    if( install != NULL )
        free(install);

    /* Fail on errors or if the user want to quit */
    if( ret == 0 || ret == 2 )
    {
        printf("Package install phase was not successful.\n");
        return 0;
    }
    if( global_verbose )
    {
        if( ret == 1 )
            printf("Package install phase was successful.\n");
    }

    /* Get the <post-install> section and run it, but dont log = 0 */
    install = get_post_install_from_package(package);
    if( install != NULL && strlen(install) > 1 )
    {
        ret = install_ok(package, install, 0);
    }

    if( install != NULL )
        free(install);

    /* Fail on errors or if the user want to quit */
    if( ret == 0 || ret == 2 )
    {
        printf("Package post-install phase was not successful.\n");
        return 0;
    }
    if( global_verbose )
    {
        if( ret == 1 )
            printf("Package post-install phase was successful.\n");
    }

    return ret;
}
