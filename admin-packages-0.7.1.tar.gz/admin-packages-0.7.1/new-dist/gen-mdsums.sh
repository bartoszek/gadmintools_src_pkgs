# This script is a part of Admin-Packages, a packagemanager for sources.
# Admin-Packages (C) 2005-2010 Magnus-swe under GNU GPL version 3 or later.
# For copying and see COPYING in package Admin-Packages.

# Test if pwd exists.
pwd 2>&1 > /dev/null || exit 1

# Setup current directory and chmod for files and directories.
DISTFILES_DIR=`pwd`
DIR_CHMOD="755"
FILE_CHMOD="0644"
MDSUM_PROGRAM="md5sum"

# Remove old mdsums.tmp file if any
if [ -f $DISTFILES_DIR/mdsums.tmp ]; then
   rm -f $DISTFILES_DIR/mdsums.tmp;
fi

# Chmod the toplevel directories and files but not gen-mdsums.sh
for i in $DISTFILES_DIR
{
   if [ -f $i ] && [ ! -f $i == "$DISTFILES_DIR/gen-mdsums.sh" ]; then
      echo -e "Chmodding: $i with $FILE_CHMOD\n";
      chmod $FILE_CHMOD $i;
   fi

   if [ -d $i ]; then
      echo -e "Chmodding: $i with $DIR_CHMOD\n";
      chmod $DIR_CHMOD $i;
   fi
}

# Add mdsums for packages.conf
$MDSUM_PROGRAM $DISTFILES_DIR/packages.conf >> $DISTFILES_DIR/mdsums.tmp

# Chmod the files in the subdirs and create mdsums from them
for i in $DISTFILES_DIR/*
{
   if [ -d $i ]; then
      for z in $i/*
      {
         echo -e "Get mdsum and chmod file with: $FILE_CHMOD\n$z\n";
         chmod $FILE_CHMOD $z && $MDSUM_PROGRAM $z >> $DISTFILES_DIR/mdsums.tmp;
      }
   fi
}

# Move the temp file as the real file and chmod it
mv $DISTFILES_DIR/mdsums.tmp $DISTFILES_DIR/mdsums.list;
chmod $FILE_CHMOD $DISTFILES_DIR/mdsums.list;

echo -e "Done chmodding and md5summing the repository.\n"
