/*
 * Admin-Packages - A Package manager for sources.
 * Copyright (C) 2009 - 2011 Magnus Loef <magnus-swe@telia.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307, USA.
 *
 */


#include "../config.h"
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include "globals.h"
#include "allocate.h"
#include "file_exists.h"
#include "show_help.h"
#include "run_command.h"
#include "set_proxy.h"
#include "update_package.h"
#include "remove_package.h"
#include "list_installed_packages.h"
#include "list_package.h"
#include "get_package_info.h"
#include "dir_handling.h"

/* For recording dependencies */
char *rec_saver[MAX_NUM_OF_PACKAGES]={};
/* The url to get the most recent package from */
char global_newest_url[MAX_URL_LEN]="";
/* Should mdsum checking be used. */
int global_mdsum_check = 1;
/* Should gpg checking be used. */
int global_gpgsum_check = 0;
/* Should a new dist be built from scratch. */
/* Gets files and package.conf from the "new-dist" directory. */
int global_new_dist = 0;
/* Should any questions be asked. */
int global_ask_questions = 1;
/* The local version is always 0 if reinstall is selected. */
int global_reinstall = 0;
/* No deps are handled if 0 */
int global_resolve_deps = 1;
/* For testing everything but installations */
int global_testing = 0;
/* Show descriptions for packages */
int global_describe = 0;
/* Show installation commands */
int global_show_commands = 0;
/* Show verbose output */
int global_verbose = 0;
/* Create binary packages */
int global_create_binary = 0;
/* Install binary packages */
int global_install_binary = 0;

char build_directory[MAX_TEMP_PATH]="";
char build_dir_next[MAX_TEMP_PATH]="";
char pkgconf_temp[MAX_TEMP_PATH]="";
char package_queue[MAX_TEMP_PATH]="";
char mdsum_temp[MAX_TEMP_PATH]="";
char mdsum_pkg[MAX_TEMP_PATH]="";
char install_log[MAX_TEMP_PATH]="";



int main(int argc, char *argv[])
{
    int i = 0;
    int set_new_dist_once = 0;
    char *descr, *cmd;

    if( ! getuid() == 0 )
    {
        printf("\nYou must be root to run %s\n", PACKAGE);
        return 0;
    }
    if( argc < 2 )
    {
        show_help();
        return 0;
    }
    /* Check some defines */
    if( strlen(WGET_PATH) > 100 )
    {
        printf("Error: Program define for wget path exceeds its limits\n");
        return 0;
    }
    if( ! file_exists(WGET_PATH) )
    {
        printf("Error: The wget program was not found here: %s\n", WGET_PATH);
        printf("Please install wget manually\n");
        return 0;
    }
    if( global_mdsum_check )
    {
        if( strlen(MDSUM_PATH) > 100 )
        {
            printf("Program define for md5sum path exceeds its limits\n");
            return 0;
        }
        if( ! file_exists(MDSUM_PATH) )
        {
            printf("Error: The md5/md5sum program was not found here: %s\n", MDSUM_PATH);
            printf("Please install md5/md5sum manually\n");
            return 0;
        }
    }
    if( strlen(INSTALL_LOG_LIB) > 1000 )
    {
        printf("Error: Program define for INSTALL_LOG_LIB path exceeds its limits\n");
        return 0;
    }
    if( ! file_exists(INSTALL_LOG_LIB) )
    {
        printf("Error: Missing install log library: %s\n", INSTALL_LOG_LIB);
        return 0;
    }

    /* Make sure we have a safe temporary build directory */
    if( ! strstr(TEMP_PATH, "/tmp") )
    {
        printf("Error: build_directory must contain \"/tmp\"");
        return 0;
    }


    /* Create the LOCALSTATEDIR/admin-packages/installed directory */
    if( ! file_exists(INSTALLED_PATH) )
    {
        cmd = allocate(strlen(INSTALLED_PATH)+1024);
        sprintf(cmd, "mkdir -p %s", INSTALLED_PATH);
        if( ! run_command(cmd) )
            printf("Error creating install directory:\n[%s]\n", INSTALLED_PATH);
        free(cmd);
    }

    /* Create an initial build directory */
    create_build_directory(build_directory);

    if( global_verbose )
        printf("Using initial build directory:\n[%s]\n", build_directory);

    /* Setup global file paths */
    setup_global_paths();

    /* Only one option is given */
    if( argc < 3 )
    {
        if( strcmp(argv[1], "--list-installed") == 0 )
        {
            printf("\nInstalled packages:\n");
            list_installed_packages();

            clean_build_dirs();
            return 0;
        }

        if( strcmp(argv[1], "help")   == 0
        ||  strcmp(argv[1], "-help")  == 0
        ||  strcmp(argv[1], "--help") == 0 )
        {
            show_help();
            clean_build_dirs();
            return 0;
        }

        if( strcmp(argv[1], "version")   == 0
        ||  strcmp(argv[1], "--version") == 0 )
        {
            printf("%s version: %s\n", PACKAGE, VERSION);

            clean_build_dirs();
            return 0;
        }
    }

    /* List this package's files */
    if( argc > 2 && strcmp(argv[1], "--list-files") == 0 )
    {
        for(i=2; i < argc; i++)
        {
            if( argv[i] == NULL )
                continue;

            printf("\nPackage [%s] installed the following files:\n\n", argv[i]);
            list_package(argv[i]);
        }

        clean_build_dirs();
        return 0;
    }

    /* Show package descriptions */
    if( argc > 2 && strcmp(argv[1], "--describe") == 0 )
    {
        for(i=2; i < argc; i++)
        {
            if( argv[i] == NULL )
                continue;

            /* Should make show_description(); */
            printf("\nPackage [%s] has the following description:\n", argv[i]);
            descr = get_description_from_package(argv[i]);
            printf("--------------------------------------------------------\n");
            if( strlen(descr) > 4 )
                printf("%s", descr); /* Has newline */
            else
                printf("No description available\n");
            printf("--------------------------------------------------------\n");
            free(descr);
        }

        clean_build_dirs();
        return 0;
    }

    /* Proxy configuration */
    if( argv[1]!=NULL && strstr(argv[1], "--set-proxy") )
    {
        if( argv[2]!=NULL && strlen(argv[2]) > 3 )
        {
            set_proxy(argv[2]);
        }
        else
        {
            printf("\nError changing proxy settings.\n");
            printf("Enable  with: --set-proxy http://PROXY:PORT\n");
            printf("Disable with: --set-proxy none\n\n");
        }
        /* For all proxy changes the program ends */
        clean_build_dirs();
        return 0;
    }

    /* Set some more options */
    for(i=1; i < argc; i++)
    {
        if( argv[i] == NULL )
            continue;

        if( strlen(argv[i]) > MAX_PKG_LEN )
        {
            printf("The package length cannot exceed %i chars\n", MAX_PKG_LEN);

            clean_build_dirs();
            return 0;
        }
        if( strcmp(argv[i], "--disable-integrity") == 0 )
        {
            printf("Integrity checking is disabled.\n");
            global_mdsum_check = 0;
            sprintf(argv[i], "%s", "");
        }
        if( strstr(argv[i], "newdist") && ! set_new_dist_once )
        {
            /* Otherwise it will run this for each newdist-pass{1,2,3} */
            set_new_dist_once = 1;
            printf("New dist selected, building a new distribution.\n");
            printf("Using packages from section new-dist.\n");
            global_new_dist = 1;
        }
        if( strcmp(argv[i], "--yes") == 0 )
        {
            printf("Answering yes to all questions.\n");
            global_ask_questions = 0;
            sprintf(argv[i], "%s", "");
        }
        if( strcmp(argv[i], "--testing") == 0 )
        {
            printf("\n\nTest mode selected.\n\n");
            global_testing = 1;
            sprintf(argv[i], "%s", "");
        }
        if( strcmp(argv[i], "--nodeps") == 0 )
        {
            printf("Nodeps selected, not handling dependencies.\n");
            global_resolve_deps = 0;
            sprintf(argv[i], "%s", "");
        }
        if( strcmp(argv[i], "--verbose") == 0 )
        {
            printf("Verbose selected, showing full output.\n");
            global_verbose = 1;
            global_show_commands = 1;
            sprintf(argv[i], "%s", "");
        }
        if( strcmp(argv[i], "--show-commands") == 0 )
        {
            printf("Showing installation commands.\n");
            global_show_commands = 1;
            sprintf(argv[i], "%s", "");
        }
        if( strcmp(argv[i], "--show-descriptions") == 0 )
        {
            /* When listing packages and installing but not removing... */
            printf("Showing descriptions.\n");
            global_describe = 1;
            sprintf(argv[i], "%s", "");
        }
        if( strcmp(argv[i], "--binary") == 0 )
        {
            printf("Installing from the binary repository.\n");
            global_install_binary = 1;
            sprintf(argv[i], "%s", "");
        }
        if( strcmp(argv[i], "--create-binary") == 0 )
        {
            printf("Creating binary packages of installed sources.\n");
            global_create_binary = 1;
            sprintf(argv[i], "%s", "");
        }
        if( strcmp(argv[i], "--") == 0 || strcmp(argv[i], "-") == 0 )
        {
            printf("Unrecognized option: %s\n", argv[i]);
            show_help();

            clean_build_dirs();
            return 0;
        }
    }

    /* Show what package(s) installed a file */
    if( argc > 2 && strcmp(argv[1], "--file-belongs") == 0 )
    {
        printf("\n");
        for(i=2; i < argc; i++)
        {
            if( argv[i] == NULL )
                continue;

            if( argv[i][0]!='/' )
            {
                printf("Error: Not a valid file path: [%s]\n", argv[i]);
                continue;
            }
            package_installed_file(argv[i]);
        }
        clean_build_dirs();
        return 0;
    }

    /* Update all installed packages */
    if( strcmp(argv[1], "--update") == 0 )
    {
        printf("Updating all currently installed packages...\n");

        if( ! update_all_packages() )
        {
            printf("Updating all installed packages failed.\n");
            clean_build_dirs();
            return 0;
        }
        clean_build_dirs();
        return 0;
    }

    /* Remove packages */
    if( strcmp(argv[1], "--remove") == 0 )
    {
        sprintf(argv[1], "%s", "");

        if( argc < 3 )
        {
            printf("Option --remove requires a package name.\n");

            clean_build_dirs();
            return 0;
        }

        for(i=1; i < argc; i++)
        {
            /* Package name lengths must be >= 2 */
            if( strlen(argv[i]) < 2 )
                continue;

            if( ! remove_package(argv[i]) )
            {
                printf("Error: Could not remove package: %s\n", argv[i]);

                clean_build_dirs();
                return 0;
            }
            else
                printf("\nRemoved package: %s\n\n", argv[i]);

            clean_build_dirs();
        }
    }

    /* Install packages */
    if( strcmp(argv[1], "--install") == 0 )
    {
        if( argc < 3 )
        {
            printf("Option --install requires a package name.\n");

            clean_build_dirs();
            return 0;
        }

        sprintf(argv[1], "%s", "");

        for(i=1; i < argc; i++)
        {
            /* Package names must be >= 2 */
            if( strlen(argv[i]) < 2 )
                continue;

            if( ! update_package(argv[i]) )
            {
                printf("Install failed for package: %s\n", argv[i]);

                clean_build_dirs();
                return 0;
            }
        }
    }

    /* ReInstall packages */
    if( strcmp(argv[1], "--reinstall") == 0 )
    {
        if( argc < 3 )
        {
            printf("Option --reinstall requires a package name.\n");

            clean_build_dirs();
            return 0;
        }

        global_reinstall = 1;
        sprintf(argv[1], "%s", "");

        for(i=1; i < argc; i++)
        {
            /* Package names must be >= 2 */
            if( strlen(argv[i]) < 2 )
                continue;

            if( ! update_package(argv[i]) )
            {
                printf("Reinstallation failed for package: %s\n", argv[i]);

                clean_build_dirs();
                return 0;
            }
        }
    }

    /* Clean the temporary build directory root if this is the only admin-packages process.
       Otherwise only remove the randomized temporary sub build directory */
    clean_build_dirs();

    return 0;
}
