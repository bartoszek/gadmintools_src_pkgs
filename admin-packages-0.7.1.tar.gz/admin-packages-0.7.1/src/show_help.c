/*
 * Admin-Packages - A Package manager for sources.
 * Copyright (C) 2009 - 2011 Magnus Loef <magnus-swe@telia.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307, USA.
 *
 */


#include "../config.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "show_help.h"


void show_help()
{
   printf("\nUsage for %s-%s:\n\n", PACKAGE, VERSION);

   printf("%s --install   package(s) [options] (Install packages)\n", PACKAGE);
   printf("%s --reinstall package(s) [options] (Reinstall packages)\n", PACKAGE);
   printf("%s --update               [options] (Updates installed packages)\n", PACKAGE);
   printf("%s --remove    package(s) [options] (Uninstall packages)\n", PACKAGE);

   printf("%s --list-files package(s)    (List installed files for packages)\n", PACKAGE);
   printf("%s --describe   package(s)    (Shows package descriptions)\n", PACKAGE);
   printf("%s --list-installed           (List all installed packages)\n", PACKAGE);
   printf("%s --file-belongs FilePath(s) (Shows what package(s) the file belongs to)\n", PACKAGE);
   printf("%s --show-updates             (Fix: compare lists)\n", PACKAGE);
   printf("%s --set-proxy                (Selects proxy)\n\n", PACKAGE);

   printf("Options:\n");
   printf("\t--yes                 (Answer yes to all questions)\n");
   printf("\t--nodeps              (Dont handle any depending packages)\n");
   printf("\t--verbose             (Show verbose output)\n");
   printf("\t--show-commands       (Show installation commands)\n");
   printf("\t--disable-integrity   (Skips md5 checks, Fixme add gpg)\n");
   printf("\t--show-descriptions   (Show package descriptions)\n");
   printf("\t--testing             (Do everything but installations)\n");
   printf("\t--create-binary       (Create binary packages after source installs)\n");
   printf("\t--binary              (Install binary packages)\n");

   printf("\n--- Creating a new distribution from scratch: ---\n");
   printf("Change settings as required in %s/settings.conf and servers.conf\n\n", SYSCONFDIR);

   printf("Read and download the required packages to the selected repository:\n");
   printf("IE: %s/stable/new-dist/base/required_packages.txt\n\n", LOCAL_REPOSITORY_PATH);

   printf("Run the gen-mdsums.sh script to generate md5sums for the new files.\n");
   printf("Use the following commands to build the new distribution:\n");
   printf("%s --reinstall --nodeps newdist-pass1\n", PACKAGE);
   printf("%s --reinstall --nodeps newdist-pass2\n", PACKAGE);
   printf("/var/enter_chroot_after_pass2.sh\n");
   printf("%s --reinstall --nodeps newdist-pass3\n", PACKAGE);
   printf("/var/enter_chroot_after_pass3.sh\n\n");
}
