/* GADMIN-NFS-SERVER - An easy to use GTK+ frontend for the NFS server.
 * Copyright (C) 2014 - 2014 Magnus Loef <magnus-swe@telia.com> 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
*/



#include <gtk/gtk.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "allocate.h"
#include "widgets.h"
#include "gettext.h"
#include "show_info.h"
#include "list_dirs.h"
#include "reread_conf.h"


void add_directory(struct w *widgets)
{
    GtkTreeIter iter;
    gchar *utf8=NULL;
    G_CONST_RETURN gchar *dir;
    gchar *info;

    dir = gtk_entry_get_text(GTK_ENTRY(widgets->add_directory_entry));
    if( strlen(dir) == 0 )
    {
        info = g_strdup_printf(_("The directory path is too short, the directory was not added.\n"));
        show_info(info);
        g_free(info);
        return;
    }

    gtk_list_store_append(GTK_LIST_STORE(widgets->scope_store), &iter);

    utf8 = g_locale_to_utf8(dir, strlen(dir), NULL, NULL, NULL);
    gtk_list_store_set(GTK_LIST_STORE(widgets->scope_store), &iter, 0, utf8, -1);
}
