/* GADMIN-NFS-SERVER - An easy to use GTK+ frontend for the NFS server.
 * Copyright (C) 2014 - 2014 Magnus Loef <magnus-swe@telia.com> 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
*/


#include <gtk/gtk.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "widgets.h"
#include "gettext.h"
#include "allocate.h"
#include "show_info.h"
#include "delete_dir.h"
#include "populate_dir_treeview.h"
#include "select_first_dir.h"
#include "set_num_clients.h"
#include "populate_clients.h"
#include "reread_conf.h"

extern char global_nic[1024];


void apply_directory_settings(struct w *widgets)
{
    FILE *fp;
    int i = 0;
    gchar *dir;
    gchar *info;

    dir = g_strdup_printf("%s", global_nic);
    if( strlen(dir) == 0 )
    {
        info = g_strdup_printf(_("The directory path is too short, the directory was not changed.\n"));
        show_info(info);
        g_free(info);
        return;
    }

    /* Delete the current dir */
    delete_dir(widgets);

    /* Append the changed dir */
    if((fp=fopen(NFSD_CONF, "a"))==NULL)
    {
        printf("Could not open exports file here: %s\n", NFSD_CONF);
        g_free(dir);
        return;
    }

    /* Add the directory */
    fputs(dir, fp);
    /* Add clients and options */
    for(i = 0; i < widgets->ranges_from_entry_array->len; i++)
    {
        const gchar *client = gtk_entry_get_text(GTK_ENTRY(g_ptr_array_index(widgets->ranges_from_entry_array, i)));
        const gchar *client_opt = gtk_entry_get_text(GTK_ENTRY(g_ptr_array_index(widgets->ranges_to_entry_array, i)));

        fputs(" ", fp);
        fputs(client, fp);
        fputs("(", fp);
        fputs(client_opt, fp);
        fputs(")", fp);
    }
    fputs("\n", fp);
    fclose(fp);

    set_num_clients();
    populate_clients(widgets, global_nic, " ", " ");

    reread_conf();
}
