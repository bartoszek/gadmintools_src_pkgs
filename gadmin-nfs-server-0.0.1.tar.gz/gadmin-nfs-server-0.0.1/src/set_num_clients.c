/* GADMIN-NFS-SERVER - An easy to use GTK+ frontend for the NFS server.
 * Copyright (C) 2014 - 2014 Magnus Loef <magnus-swe@telia.com> 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
*/

#include <gtk/gtk.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "widgets.h"
#include "gettext.h"
#include "allocate.h"
#include "commented.h"
#include "set_num_clients.h"

extern char global_nic[1024];

extern int num_ranges;


/* Set before populate_clients() is called to allocate a number of widgets */
void set_num_clients()
{
    FILE *fp;
    long conf_size = 0;
    int found_dir = 0;
    char *line, *tmp;

    /* Set global num_clients */
    num_ranges = 0;

    gchar *dir = g_strdup_printf("%s ", global_nic);

    if((fp=fopen(NFSD_CONF, "r"))==NULL)
    {
        g_free(dir);
        return;
    }
    fseek(fp, 0, SEEK_END);
    conf_size = ftell(fp);
    rewind(fp);

    line = allocate(conf_size+1);

    if( conf_size > 1 )
    while(fgets(line, conf_size, fp)!=NULL)
    {
        if( strstr(line, dir) ) // fix commented
        {
            found_dir = 1;
            break;
        }
    }

    if( found_dir )
    {
        tmp = strtok(line, " ");
        while(tmp != NULL)
        {
            /* Skip directories */
            if( strlen(tmp) > 1 && ! strstr(tmp, "/") )
            {

                num_ranges++;

            }
            /* We pass NULL to strtok to get the next token in the string, the next ip(opt) */
            tmp = strtok(NULL, " ");
        }
    }
    fclose(fp);
    free(line);
    g_free(dir);
}
