/*
 * Admin-Packages - A Package manager for sources.
 * Copyright (C) 2009 - 2011 Magnus Loef <magnus-swe@telia.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307, USA.
 *
 */


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "globals.h"
#include "allocate.h"
#include "commented.h"

/* Strip all newlines between directives then 
   add a newline after each </PackageName> */
void fix_conf_newlines()
{
    FILE *fp;
    char *line, *some_pkg, *end_pkg, *new_buffer;
    long file_size, allocate_extra=0;

    /* First remove any newlines first on all lines in the config */
    /* And see how many new chars we will be adding */
    if((fp=fopen(PACKAGES_CONF, "r"))==NULL)
    {
        printf("Error reading: [%s] cant fix newlines.\n", PACKAGES_CONF);
        return;
    }
    fseek(fp, 0, SEEK_END);
    file_size = ftell(fp);
    rewind(fp);

    line = allocate(file_size+1);
    some_pkg = allocate(MAX_PKG_LEN+10);
    end_pkg  = allocate(MAX_PKG_LEN+10);

    /* See how many packges we have thatll need
       an extra newline at the end */
    if( file_size > 1 )
    while(fgets(line, file_size, fp)!=NULL)
    {
        if( ! commented(line) && strstr(line, "<") 
        && strstr(line, ">")  && strlen(line) > 3 )
        {
            snprintf(some_pkg, MAX_PKG_LEN-1, "%s", &line[1]);
            some_pkg[strlen(some_pkg)-2]='\0';
            snprintf(end_pkg, MAX_PKG_LEN-1, "</%s>\n", some_pkg);

            if( file_size > 1 )
            while(fgets(line, file_size, fp)!=NULL)
            {
                if( strcmp(end_pkg, line) == 0 )
                {
                    allocate_extra++;
                    break;
                }
            }
        }
    }

    rewind(fp);

    /* Allocate a buffer to hold the conf plus added newlines */
    new_buffer = allocate(file_size+allocate_extra+1024);

    /* Copy this conf to new_buffer but strip all newlines and 
       add a newline at each package end  */
    if( file_size > 1 )
    while(fgets(line, file_size, fp)!=NULL)
    {
        if( line[0]!='\r' && line[0]!='\n' )
            strcat(new_buffer, line);

        if( ! commented(line) && strstr(line, "<") 
        && strstr(line, ">")  && strlen(line) > 3 )
        {
            snprintf(some_pkg, MAX_PKG_LEN-1, "%s", &line[1]);
            some_pkg[strlen(some_pkg)-2]='\0';
            snprintf(end_pkg, MAX_PKG_LEN-1, "</%s>\n", some_pkg);

            if( file_size > 1 )
            while(fgets(line, file_size, fp)!=NULL)
            {
                strcat(new_buffer, line);

                if( strcmp(end_pkg, line) == 0 )
                {
                    strcat(new_buffer, "\n");
                    break;
                }
            }
        }
    }
    fclose(fp);
    free(line);
    free(some_pkg);
    free(end_pkg);

    /* Write the new conf */
    if((fp=fopen(PACKAGES_CONF, "w+"))==NULL)
    {
        printf("Error writing: [%s] cant fix newlines\n", PACKAGES_CONF);
        free(new_buffer);
        return;
    }
    fputs(new_buffer, fp);

    fclose(fp);
    free(new_buffer);
}
