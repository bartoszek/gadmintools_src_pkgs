/*
 * REDIGERA INTE DENNA FIL - den är genererad av Glade.
 */

GtkWidget* create_main_window (void);
GtkWidget* create_help_window (void);
GtkWidget* create_right_actions_window (void);
GtkWidget* create_left_actions_window (void);
GtkWidget* create_status_window (void);
GtkWidget* create_settings_window (void);
GtkWidget* create_archive_window (void);
GtkWidget* create_run_info_window (void);
