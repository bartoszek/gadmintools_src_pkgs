
#ifndef SHOW_UNINSTALL_LIST_H
#define SHOW_UNINSTALL_LIST_H

void show_uninstall_list();

#endif
