
#ifndef RUN_COMMAND_H
#define RUN_COMMAND_H

int run_command(char *command);

#endif
