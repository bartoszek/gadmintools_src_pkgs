/* GADMIN-NFS-SERVER - An easy to use GTK+ frontend for the NFS server.
 * Copyright (C) 2014 - 2014 Magnus Loef <magnus-swe@telia.com> 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
*/

#include <gtk/gtk.h>
#include <stdio.h>
#include <string.h>
#include "widgets.h"
#include "gettext.h"
#include "show_info.h"


void show_help(struct w *widgets)
{
    gchar *help;
    help = g_strconcat(
    _("\n\n1. Adding NFS shares:\n\n"),

    _("	Type a directory path to share and press add.\n"),
    _("	Click on the newly added directory and add a client to\n"),
    _("	the it by typing the IP or DNS hostname in the client entry.\n"),
    _("	Also add share options in the share options entry.\n"),
    _("	Press add to allow the client to access this shared directory.\n\n"),

    _("	Tooltips are available where anything can be added so\n"),
    _("	reading those before clicking add can be a good help.\n\n"),

    _("	Start the server when done by clicking the activate button.\n"),
    _("	The deactivated state should now change to active.\n\n"),
    _("	\n"),
    "\n", NULL);

    show_info(help);
    g_free(help);
}
