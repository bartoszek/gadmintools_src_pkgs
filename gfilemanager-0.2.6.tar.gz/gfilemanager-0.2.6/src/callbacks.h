#include <gtk/gtk.h>


void
on_scan_button_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_connect_button_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_disconnect_button_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_help_button_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_settings_button_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_left_treeview_map                   (GtkWidget       *widget,
                                        gpointer         user_data);

gboolean
on_left_treeview_button_press_event    (GtkWidget       *widget,
                                        GdkEventButton  *event,
                                        gpointer         user_data);

gboolean
on_right_treeview_button_press_event   (GtkWidget       *widget,
                                        GdkEventButton  *event,
                                        gpointer         user_data);

void
on_right_rename_button_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_right_mkdir_button_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_right_delete_button_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_right_cancel_button_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_right_download_button_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_left_rename_button_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_left_mkdir_button_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_left_delete_button_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_left_cancel_button_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_left_upload_button_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_status_window_map                   (GtkWidget       *widget,
                                        gpointer         user_data);

void
on_settings_window_map                 (GtkWidget       *widget,
                                        gpointer         user_data);

void
on_settings_cancel_button_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_settings_ok_button_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_hidden_checkbutton_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_scanrange_spinbutton_value_changed  (GtkSpinButton   *spinbutton,
                                        gpointer         user_data);

void
on_addfile_button_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_left_addfile_button_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_right_addfile_button_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_settings_button_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_scantimeout_spinbutton_value_changed
                                        (GtkSpinButton   *spinbutton,
                                        gpointer         user_data);

void
on_cancel_scan_button_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_rpm_install_button_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_rpm_uninstall_button_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_rpm_cancel_button_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_rpm_install_button_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_rpm_uninstall_button_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_rpm_cancel_button_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_rpm_textview_map                    (GtkWidget       *widget,
                                        gpointer         user_data);

void
on_rpm_upgrade_button_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_rpm_uninstall_button_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_rpm_cancel_button_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_update_both_button_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_run_info_button_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_run_info_window_map                 (GtkWidget       *widget,
                                        gpointer         user_data);

void
on_run_command_button_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_cancel_run_command_button_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_close_run_info_button_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_archive_install_button_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_archive_window_map                  (GtkWidget       *widget,
                                        gpointer         user_data);

void
on_archive_textview_map                (GtkWidget       *widget,
                                        gpointer         user_data);

void
on_archive_close_button_clicked        (GtkButton       *button,
                                        gpointer         user_data);
