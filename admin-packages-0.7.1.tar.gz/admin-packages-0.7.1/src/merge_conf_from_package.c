/*
 * Admin-Packages - A Package manager for sources.
 * Copyright (C) 2009 - 2011 Magnus Loef <magnus-swe@telia.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307, USA.
 *
 */


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "globals.h"
#include "allocate.h"
#include "merge_conf_from_package.h"
#include "get_package_info.h"
#include "package_in_install_list.h"
#include "package_in_conf.h"

extern int global_verbose;


/* Adds or updates the local packages.conf definitions */
int merge_conf_from_package(char *package)
{
    FILE *fp;
    long file_size = 0;
    int success=0, found_begin=0, found_end=0;
    char *pkg_conf;
    char *conf, *edited_conf, *line;
    char *begin_package, *end_package;

    if( ! package_in_install_list(package) || strlen(package) < 2 )
    {
       printf("Package did not exist, didnt merge its conf\n");
       return 0;
    }

    if( package_in_local_conf(package) && strlen(package) > 1 )
    {
        if( global_verbose )
            printf("This package was previously installed, merging description\n");

        /* Change the old package descr to the new */
        if((fp=fopen(PACKAGES_CONF, "r"))==NULL)
        {
            printf("Could not read: %s\n", PACKAGES_CONF);
            perror("fopen");
            return 0;
        }
        fseek(fp, 0, SEEK_END);
        file_size = ftell(fp);
        rewind(fp);

        line = allocate(file_size);
        conf = allocate(file_size);

        begin_package = allocate(MAX_PKG_LEN+10);
        end_package = allocate(MAX_PKG_LEN+10);

        sprintf(begin_package, "<%s>\n", package);
        sprintf(end_package, "</%s>\n", package); 

        if( file_size > 1 )
        while(fgets(line, file_size, fp)!=NULL)
        {
            /* Skip this package */
            if( strcmp(line, begin_package) == 0 )
            {
                found_begin = 1;

                if( file_size > 1 )
                while(fgets(line, file_size, fp)!=NULL)
                {
                    if( strcmp(line, end_package) == 0 )
                    {
                        found_end = 1;
                        break;
                    }
                }
            }

            /* Gathering all other packages conf sections */
            if( strlen(line) < MAX_LINE_LEN-1 && strcmp(line, end_package) )
                strcat(conf, line);
        }

        fclose(fp);
        free(line);
        free(begin_package);
        free(end_package);

        if( ! found_begin || ! found_end )
        {
            printf("Couldnt merge the package confs, missing <end/begin> description.\n");
            free(conf);
            return 0;
        }

        /* Downloaded temporary packages.conf */
        pkg_conf = get_conf_from_package(1, package);

        edited_conf = allocate(strlen(conf)+strlen(pkg_conf)+3);

        sprintf(edited_conf, "%s", conf);
        strcat(edited_conf, "\n");
        strcat(edited_conf, pkg_conf);

        free(conf);
        free(pkg_conf);

        if((fp=fopen(PACKAGES_CONF, "w+"))==NULL)
        {
            printf("Couldnt write the merged conf here: %s\n", PACKAGES_CONF);
            perror("fopen");
            return 0;
        }
        fputs(edited_conf, fp);
        fclose(fp);
        free(edited_conf);

        success = 1;
    }
    else
    {
        if( global_verbose )
            printf("This package was not previously installed, merging description\n");

        /* Write this new package descr. last in the real packages.conf */
        if((fp=fopen(PACKAGES_CONF, "a"))==NULL)
        {
            printf("Could not write to: %s\n", PACKAGES_CONF);
            perror("fopen");
            return 0;
        }

        pkg_conf = get_conf_from_package(1, package);

        /* Show the merged conf */
        if( global_verbose )
            printf("%s\n", pkg_conf);

        fputs("\n", fp);
        fputs(pkg_conf, fp);
        fclose(fp);

        free(pkg_conf);

        success = 1;
    }

    return success;
}
