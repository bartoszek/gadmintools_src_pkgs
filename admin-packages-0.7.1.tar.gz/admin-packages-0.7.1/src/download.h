
#ifndef DOWNLOAD_H
#define DOWNLOAD_H

int download_file(char *url, char *srv_path, char *dl_path, char *file);

int download_files(char *package);

int url_download_remote_conf_from_package(char *package);

#endif

