/*
 * Admin-Packages - A Package manager for sources.
 * Copyright (C) 2009 - 2011 Magnus Loef <magnus-swe@telia.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307, USA.
 *
 */


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "globals.h"
#include "allocate.h"
#include "package_in_install_list.h"

extern int global_resolve_deps;

char package_queue[MAX_TEMP_PATH];


int package_in_install_list(char *package)
{
    FILE *fp;
    char *line, *tmp_package;
    int found = 0;
    long file_size = 0;

    if((fp=fopen(package_queue, "r"))==NULL)
    {
        /* Theres no package queue when using the nodeps option */
        if( global_resolve_deps )
        {
            perror("fopen");
            printf("Error opening file [%s]\n", package_queue);
        }
        return 0;
    }
    fseek(fp, 0, SEEK_END);
    file_size = ftell(fp);
    rewind(fp);

    line = allocate(file_size+1);

    tmp_package = allocate(MAX_REQUIRE_LEN+1);

    sprintf(tmp_package, "<%s>\n", package);

    if( file_size > 1 )
    while(fgets(line, file_size, fp)!=NULL)
    {
        /* Is this an exact package name match */
        if( strcmp(line, tmp_package) == 0 )
        {
            found = 1;
            break;
        }
    }
    fclose(fp);

    free(line);
    free(tmp_package);

    return found;
}
