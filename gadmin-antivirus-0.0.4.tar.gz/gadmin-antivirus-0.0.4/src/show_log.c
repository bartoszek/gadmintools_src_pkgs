/* GAdmin-Antivirus - An easy to use GTK+ frontend for clamav antivirus.
 * Copyright (C) 2010 - 2014 Magnus Loef <magnus-swe@telia.com> 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
*/


#include <gtk/gtk.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "widgets.h"
#include "gettext.h"
#include "show_log.h"
#include "show_info.h"
#include "functions.h"
#include "cron_functions.h"

#define EXPAND_LOG 1

extern gchar *global_scan_name;


/* Set individual colors for the cell renderers rows */
void
log_cell_data_func(GtkTreeViewColumn *col,
                   GtkCellRenderer   *renderer,
                   GtkTreeModel      *model,
                   GtkTreeIter       *iter,
                   gpointer           user_data)
{
    gchar *log_item;
    gtk_tree_model_get(model, iter, 0, &log_item, -1);
 
    if( strstr(log_item, " FOUND")
    &&  strstr(log_item, ": ") )
    {
        /* Make the foreground red */
        /* g_object_set(renderer, "foreground", "Red", "foreground-set",
                                                              TRUE, NULL); */

        /* Make the background red */
        g_object_set(renderer, "background", "Red", "background-set",
                                                           TRUE, NULL);
    }
    else
    {
        /* Show normal foreground color */
        /* g_object_set(renderer, "foreground-set", FALSE, NULL); */

        /* Show normal background color */
        g_object_set(renderer, "background-set", FALSE, NULL);
    }

    if( log_item != NULL )
        g_free(log_item);
}


void
delete_log(struct w *widgets)
{
    /* Clear the log files for the selected scan */
    FILE *fp;
    gchar *log_path;

    log_path = mk_log_path(global_scan_name);
    if(log_path == NULL || strlen(log_path) < 10)
    {
        printf("clear_log: log path too short\n");
        if(log_path != NULL)
            g_free(log_path);
        return;
    }
    if((fp = fopen(log_path, "w+")) == NULL)
    {
        if(log_path != NULL)
            g_free(log_path);
        return;
    }
    fclose(fp);

    if(log_path != NULL)
        g_free(log_path);

    populate_log(widgets);
}


void
populate_log(struct w *widgets)
{
    FILE *fp;
    long file_size = 0;
    int virus_found = 0;
    char *line, *val;
    GtkTreeIter iter;
    gchar *log_path, *info, *utf8;
    GdkRGBA color;

    /* Create a log path for the selected scan */
    log_path = mk_log_path(global_scan_name);
    if(log_path == NULL || strlen(log_path) < 10)
    {
        info = g_strdup_printf
            ("Can not read the selected scans logfile. Filename too short.\n");
        show_info(info);
        g_free(info);

        if(log_path != NULL)
            g_free(log_path);

        /* Destroy the scan log window and return */
        gtk_widget_destroy(widgets->log_window);
        return;
    }

    /* Clear the log treeview */
    gtk_list_store_clear(GTK_LIST_STORE(widgets->log_store));

    /* Show the selected scan log in the treeview */
    if((fp = fopen(log_path, "r")) == NULL)
    {
        info = g_strconcat(_("Can not read the selected scans logfile.\n"),
            _("The scan needs to run first so a log is created.\n"), NULL);
        show_info(info);
        g_free(info);

        if(log_path != NULL)
            g_free(log_path);

        /* Destroy the scan log window and return */
        gtk_widget_destroy(widgets->log_window);
        return;
    }
    fseek(fp, 0, SEEK_END);
    file_size = ftell(fp);
    rewind(fp);

    line = allocate(file_size + 1);
    val = allocate(file_size + 1);

    if(file_size > 1)
        while(fgets(line, file_size, fp) != NULL)
        {
            if(strlen(line) < 10)
                continue;

            gtk_list_store_append(GTK_LIST_STORE(widgets->log_store), &iter);
            utf8 = g_locale_to_utf8(line, strlen(line), NULL, NULL, NULL);
            if(utf8 != NULL)
            {
                utf8[strlen(utf8) - 1] = '\0';
                gtk_list_store_set(widgets->log_store, &iter, 0, utf8, -1);
                g_free(utf8);

                /* See if we have any infected files to alert about */
                if( strstr(line, "Infected files:") &&
                  ! strstr(line, "Infected files: 0\n") )
                {
                    virus_found = 1;
                }
            }
        }
    fclose(fp);

    if(log_path != NULL)
        g_free(log_path);

    free(line);
    free(val);

    /* Alert if a virus has been found */
    if( virus_found )
    {
        gtk_label_set_text(GTK_LABEL(widgets->log_label),
                             _("Viruses have been found."));
        /* Set red status color */
        gdk_rgba_parse(&color, "red");
        gtk_widget_override_color(widgets->log_label, GTK_STATE_FLAG_NORMAL, &color);
    }
    else
    {
        /* Text has been set in show_log_window(). Set green status color */
        gdk_rgba_parse(&color, "dark green");
        gtk_widget_override_color(widgets->log_label, GTK_STATE_FLAG_NORMAL, &color);
    }
}


/* Create and show the log window */
void
show_log_window(struct w *widgets)
{
    GtkWidget *vbox;
    GtkWidget *scrolled_window;
    GtkCellRenderer *cell;
    GtkTreeViewColumn *col;
    GtkWidget *hbuttonbox;
    gchar *info;

    /* Create the log window */
    widgets->log_window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_widget_set_size_request(widgets->log_window, 630, 350);
    gtk_window_set_position(GTK_WINDOW(widgets->log_window),
                                          GTK_WIN_POS_CENTER);

    /* Set window information */
    info = g_strdup_printf(
            _("GAdmin-Antivirus %s \t %s"), VERSION, global_scan_name);
    gtk_window_set_title(GTK_WINDOW(widgets->log_window), info);
    g_free(info);

    /* Create the scrolled window */
    vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
    gtk_container_add(GTK_CONTAINER(widgets->log_window), vbox);

    scrolled_window = gtk_scrolled_window_new(NULL, NULL);
    gtk_box_pack_start(GTK_BOX(vbox), scrolled_window, TRUE, TRUE, 0);

    gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scrolled_window),
        GTK_POLICY_AUTOMATIC, GTK_POLICY_ALWAYS);
    /* Must set a larger size or it wont scroll */
    gtk_widget_set_size_request(scrolled_window, -1, 100);

    /* 1 column */
    widgets->log_store = gtk_list_store_new(1, G_TYPE_STRING);

    widgets->log_treeview = gtk_tree_view_new();
    gtk_tree_view_set_model(GTK_TREE_VIEW(widgets->log_treeview),
                               GTK_TREE_MODEL(widgets->log_store));

    gtk_container_add(GTK_CONTAINER(scrolled_window), widgets->log_treeview);
    gtk_tree_view_set_rules_hint(GTK_TREE_VIEW(widgets->log_treeview), TRUE);

    cell = gtk_cell_renderer_text_new();
    col = gtk_tree_view_column_new_with_attributes(_("Virus scan log"),
                                                  cell, "text", 0, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(widgets->log_treeview),
                                           GTK_TREE_VIEW_COLUMN(col));

    /* Show a label with virus found info */
    widgets->log_label = gtk_label_new_with_mnemonic(_("No viruses have been found."));
    gtk_box_pack_start(GTK_BOX(vbox), widgets->log_label, FALSE, FALSE, 0);

    /* Create a hbutton box to hold the buttons */
    hbuttonbox = gtk_button_box_new(GTK_ORIENTATION_HORIZONTAL);
    gtk_box_pack_start(GTK_BOX(vbox), hbuttonbox, FALSE, FALSE, 0);
    gtk_button_box_set_layout(GTK_BUTTON_BOX(hbuttonbox),GTK_BUTTONBOX_SPREAD);

    /* Delete log button */
    GtkWidget *delete_log_button = gtk_button_new();
    gtk_widget_set_tooltip_text(delete_log_button,
                      _("Delete the selected log."));
    GtkWidget *alignment1 = gtk_alignment_new(0.5, 0.5, 0, 0);
    gtk_container_add(GTK_CONTAINER(delete_log_button), alignment1);
    GtkWidget *hbox1 = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
    gtk_container_add(GTK_CONTAINER(alignment1), hbox1);
    GtkWidget *image1 = gtk_image_new_from_icon_name("gtk-delete",
                                         GTK_ICON_SIZE_BUTTON);
    gtk_box_pack_start(GTK_BOX(hbox1), image1, FALSE, FALSE, 0);
    GtkWidget *label1 = gtk_label_new_with_mnemonic(_("Delete scan log"));
    gtk_box_pack_start(GTK_BOX(hbox1), label1, FALSE, FALSE, 0);
    gtk_label_set_justify(GTK_LABEL(label1), GTK_JUSTIFY_LEFT);
    gtk_box_pack_start(GTK_BOX(hbuttonbox), delete_log_button, FALSE, FALSE, 0);
    /* The delete log button signal */
    g_signal_connect_swapped(delete_log_button, "clicked",
        G_CALLBACK(delete_log), widgets);

    /* Delete file button */
    GtkWidget *delete_file_button = gtk_button_new();
    gtk_widget_set_tooltip_text(delete_file_button,
                      _("Delete the selected file."));
    GtkWidget *alignment2 = gtk_alignment_new(0.5, 0.5, 0, 0);
    gtk_container_add(GTK_CONTAINER(delete_file_button), alignment2);
    GtkWidget *hbox2 = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
    gtk_container_add(GTK_CONTAINER(alignment2), hbox2);
    GtkWidget *image2 = gtk_image_new_from_icon_name("gtk-delete",
                                         GTK_ICON_SIZE_BUTTON);
    gtk_box_pack_start(GTK_BOX(hbox2), image2, FALSE, FALSE, 0);
    GtkWidget *label2 = gtk_label_new_with_mnemonic(
                                    _("Delete selected virus file"));
    gtk_box_pack_start(GTK_BOX(hbox2), label2, FALSE, FALSE, 0);
    gtk_label_set_justify(GTK_LABEL(label2), GTK_JUSTIFY_LEFT);
    gtk_box_pack_start(GTK_BOX(hbuttonbox), delete_file_button, FALSE, FALSE, 0);
    /* The delete file button signal */
    g_signal_connect_swapped(delete_file_button, "clicked",
                 G_CALLBACK(delete_file_from_system), widgets->log_treeview);

    /* Close log window button */
    GtkWidget *close_log_button = gtk_button_new_from_icon_name("gtk-close", GTK_ICON_SIZE_BUTTON);
    gtk_box_pack_start(GTK_BOX(hbuttonbox), close_log_button, FALSE, TRUE, 0);

    /* The window close button signal */
    g_signal_connect_swapped((gpointer) close_log_button, "clicked",
        G_CALLBACK(gtk_widget_destroy), G_OBJECT(widgets->log_window));

    /* Connect a cell data function and color rows individually */
    gtk_tree_view_column_set_cell_data_func(col, cell,
                                  log_cell_data_func, NULL, NULL);

    /* X close window signal */
    g_signal_connect(GTK_WINDOW(widgets->log_window), "delete_event",
        G_CALLBACK(gtk_widget_destroy), NULL);

    gtk_widget_show_all(widgets->log_window);

    /* Populate the textview */
    populate_log(widgets);
}

