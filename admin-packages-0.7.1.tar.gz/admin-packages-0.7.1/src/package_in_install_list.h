
#ifndef PACKAGE_IN_INSTALL_LIST_H
#define PACKAGE_IN_INSTALL_LIST_H

int package_in_install_list(char *package);

#endif
