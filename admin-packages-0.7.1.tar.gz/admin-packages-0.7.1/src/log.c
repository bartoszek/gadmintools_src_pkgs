/*
 * Admin-Packages - A Package manager for sources.
 * Copyright (C) 2009 - 2011 Magnus Loef <magnus-swe@telia.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307, USA.
 *
 */

#include "../config.h"
#include "globals.h"
#include <sys/param.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <dlfcn.h>

char logpath[MAX_TEMP_PATH*2]="";
const char *pathname;

void log_system_file_change(const char *pathname, int result); 
int path_in_install_log(const char *pathname, char *logfile); 

// ny
static int(*true_open)(const char *, int, ...);

static int(*true_open64)(const char *, int, ...);
static int(*true_rename)(const char *, const char *);
static int(*true_symlink)(const char *, const char *);


/* Setup a log path and the glibc hooks we are interrested in.
   Do not use printf's here unless its for an error. */
void _init(void)
{
    void *libc_handle;
    const char *variablename="ADMIN_PACKAGES_BUILD";
    char *envpath;

    /* Get env build directory path */
    envpath = getenv(variablename);
    if( envpath == NULL )
    {
        printf("No such env variable\n");
        return;
    }
    snprintf(logpath, MAX_TEMP_PATH, "%s/%s", envpath, INSTALL_LOG_NAME);

    /* Setup libc hooks */
    libc_handle = dlopen(LIBC_NAME, RTLD_LAZY);
    if( ! libc_handle ) 
    {
        fprintf(stderr, "%s\n", dlerror());
        exit(1);
    }

// NY
    true_open = dlsym(libc_handle, "open");
    if( true_open == NULL )
    {
        printf("Error opening dlsym: open\n");
        exit(1);
    }

    true_open64 = dlsym(libc_handle, "open64");
    if( true_open64 == NULL )
    {
        printf("Error opening dlsym: open64\n");
        exit(1);
    }

    true_rename = dlsym(libc_handle, "rename");
    if( true_rename == NULL )
    {
        printf("Error opening dlsym: rename\n");
        exit(1);
    }

    true_symlink = dlsym(libc_handle, "symlink");
    if( true_symlink == NULL )
    {
        printf("Error opening dlsym: symlink\n");
        exit(1);
    }
}


int path_in_install_log(const char *path, char *logfile)
{
    FILE *fp;
    char *line;
    long file_size = 0;
    int ret = 0;

    if( path == NULL || strlen(path) < 3 )
      return 0;

    if((fp=fopen(logfile, "r"))==NULL)
    {
        /* Dont print anything. */
        return 0;
    }
    fseek(fp, 0, SEEK_END);
    file_size = ftell(fp);
    rewind(fp);

    line = malloc(file_size+1);
    memset(line, 0, file_size+1);

    if( file_size > 1 )
    while(fgets(line, file_size, fp)!=NULL)
    {
        if( strlen(line) < 3 )
            continue;

        if( line[strlen(line)-1]=='\n' )
            line[strlen(line)-1]='\0';

        if( strcmp(line, path) == 0 )
        {
            ret = 1;
            break;
        }
    }
    fclose(fp);
    free(line);

    return ret;
}


/* A file is symlinked */
int symlink(const char *pathname1, const char *pathname2)
{
    char newpath[MAX_TEMP_PATH]="";
    char *curpath = NULL;
    int result;

    result = true_symlink(pathname1, pathname2);

    curpath = getcwd(newpath, MAX_TEMP_PATH - 2);
    if( ! curpath )
        return 0;

    strcat(newpath, "/");
    strcat(newpath, pathname2);

    if( newpath[strlen(newpath)-1]=='\n' )
        newpath[strlen(newpath)-1]='\0';

    log_system_file_change(newpath, result);

    return result;
}


/* A file is moved or renamed */
int rename(const char *pathname1, const char *pathname2)
{
    int result;

    result = true_rename(pathname1, pathname2);

    log_system_file_change(pathname2, result);

    return result;
}

/* A 32 bit file is opened */
int open(const char *pathname, int flags, ...)
{
    va_list ap;
    int mode = 0;
    int result;

    va_start(ap, flags);
    mode = va_arg(ap, int);
    va_end(ap);

    result = true_open(pathname, flags, mode);

    log_system_file_change(pathname, result);

    return result;
}


/* A 64 bit file is opened */
int open64(const char *pathname, int flags, ...)
{
    va_list ap;
    int mode = 0;
    int result;

    va_start(ap, flags);
    mode = va_arg(ap, int);
    va_end(ap);

    result = true_open64(pathname, flags, mode);

    log_system_file_change(pathname, result);

    return result;
}


/* A system file has been added or changed */
void log_system_file_change(const char *pathname, int result)
{
    FILE *fp;
    char *envpath;

    /* Get DESTDIR environment variable if any */
    envpath = getenv("DESTDIR");

    if( pathname == NULL || strlen(pathname) < 3 )
      return;

    /* It must be an absolute path */
    if( pathname[0] != '/' )
      return;

    /* We dont want log files that end up in /tmp */
    if( strlen(pathname) > 3 )
    {
        if( pathname[0]=='/' && pathname[1]=='t'
        &&  pathname[2]=='m' && pathname[3]=='p' )
            return;
    }

    /* We dont want to log files that end up in /dev */
    if( strlen(pathname) > 3 )
    {
        if( pathname[0]=='/' && pathname[1]=='d'
        &&  pathname[2]=='e' && pathname[3]=='v' )
            return;
    }

    /* We dont want to log files that end up in /proc */
    if( strlen(pathname) > 5 )
    {
        if( pathname[0]=='/' && pathname[1]=='p'
        &&  pathname[2]=='r' && pathname[3]=='o'
        &&  pathname[4]=='c' )
            return;
    }

    /* Dont log files that end up in tmp:
       /var/admin-packages/tmp/... */
    if( strstr(pathname, TEMP_PATH) )
        return;

    /* Dont log duplicate entries */
    if( path_in_install_log(pathname, logpath) )
        return;

    /* Error */
    if( result == -1 )
        return;

    /* DESTDIR used but file not in the DESTDIR path */
    if( envpath != NULL && ! strstr(pathname, envpath) )
        return;

    printf("\nResult: [%d]. Logging file: [%s]\n", result, pathname);

    /* A file has been installed, log it */
    if( ! strstr(logpath, "/var/admin-packages/tmp/") )
    {
        printf("\nlog.c: Bad log path: [%s] File not logged: [%s]\n", logpath, pathname);
        return;
    }

    if((fp=fopen(logpath, "a+"))==NULL)
    {
        printf("Error writing logfile: %s\n", logpath);
        return;
    }
    fputs(pathname, fp);
    fputs("\n", fp);
    fclose(fp);
}
