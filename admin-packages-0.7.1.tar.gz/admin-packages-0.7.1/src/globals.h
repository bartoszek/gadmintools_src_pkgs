
#ifndef HAVE_GLOBALS_H
#define HAVE_GLOBALS_H

#include "../config.h"

#define REMOTE_ROOT "distfiles"
#define REMOTE_NEW_DIST_ROOT "new-dist"

#define PACKAGES_CONF SYSCONFDIR"/packages.conf"
#define SERVERS_CONF  SYSCONFDIR"/servers.conf"
#define SETTINGS_CONF SYSCONFDIR"/settings.conf"

#define TEMP_PATH      LOCALSTATEDIR"/admin-packages/tmp"
#define INSTALLED_PATH LOCALSTATEDIR"/admin-packages/installed"

#define PKGCONF_NAME        "packages.conf"
#define PACKAGE_QUEUE_NAME  "package.queue"
#define MDSUM_NAME          "mdsums.list"
#define MDSUM_PKG_NAME      "mdsum.pkg"
#define INSTALL_LOG_NAME    "admin-packages-install.log"
#define INSTALL_SCRIPT_NAME "admin-packages-install.sh"
#define BINARY_SCRIPT_NAME  "binary_script.sh"

/* The log library's max path length when logging installed files */
#define LOG_MAX_PATH_LEN 16384
/* Max packages it will handle when resolving deps for a package */
#define MAX_NUM_OF_PACKAGES 10000
/* Max chars in the build_directory path */
#define MAX_TEMP_PATH 1024
/* Max chars used as the randomized build directory name */
#define MAX_RAND_DIR  20
/* Path to the proc filesystem */
#define PROC_PATH "/proc"

/* Defines for max length of the conf lines to read */
#define MAX_LINE_LEN      1024
#define MAX_PKG_LEN       1024
#define MAX_VER_LEN       100
#define MAX_COMPR_LEN     100
#define MAX_SECTION_LEN   100
#define MAX_REQUIRE_LEN   1024
#define MAX_URL_LEN       8192
#define MAX_MDSUM_LINE    1024
#define MAX_READ_POPEN    16384

#endif
