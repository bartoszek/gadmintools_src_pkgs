
#ifndef LIST_INSTALLED_PACKAGES_H
#define LIST_INSTALLED_PACKAGES_H

void list_installed_packages();

#endif
