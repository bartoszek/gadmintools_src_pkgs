/* GADMIN-NFS-SERVER - An easy to use GTK+ frontend for the NFS server.
 * Copyright (C) 2014 - 2014 Magnus Loef <magnus-swe@telia.com> 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
*/


#include <gtk/gtk.h>

/* Number of widgets used in the settings window */
#define NUM_SETTINGS_ENTRIES 3
#define NUM_SETTINGS_COMBOS  10

/* Number of widgets used in the loadbalancing window */
#define NUM_LOADBALANCE_ENTRIES 10
#define NUM_LOADBALANCE_COMBOS  5

#define NUM_LOADBALANCE_UPLOAD_ENTRIES 6

/* Number of entries used in the scope and host settings */
#define NUM_SCOPE_SETTINGS 19
#define NUM_HOST_SETTINGS  19


typedef struct w
{
  GtkWidget *main_window;
  GtkWidget *main_vbox;
  GtkWidget *notebook_vbox1;
  GtkWidget *notebook_vbox2;
  GtkWidget *notebook_vbox3;
  GtkWidget *notebook_vbox4;
  GtkWidget *onoff_label;
  GtkWidget *nfs_version_label;
  GtkWidget *scope_treeview;
  GtkListStore *scope_store;
  GtkTreePath *scope_treepath;

  /* Add directory entry */
  GtkWidget *add_directory_entry;

  /* Directory settings */
  GtkWidget *scope_set_vbox;
  GtkWidget *scope_set_viewport;
  GtkWidget *scope_set_scrolled_vbox;
  GtkWidget *scope_set_entry[NUM_SCOPE_SETTINGS];

  /* Clients and client access options */
  GtkWidget *range_vbox;
  GtkWidget *range_viewport;
  GtkWidget *range_scrolled_vbox;
  GtkWidget *range_from;
  GtkWidget *range_to;
  GPtrArray *ranges_hbox_array;
  GPtrArray *ranges_from_entry_array;
  GPtrArray *ranges_to_entry_array;
  GPtrArray *ranges_del_button_array;
  GtkWidget *ranges_add_vbox;
  GtkWidget *ranges_add_button;
  GtkWidget *ranges_add_from_entry;
  GtkWidget *ranges_add_to_entry; 

  GtkWidget *credits_window;

}wid;
