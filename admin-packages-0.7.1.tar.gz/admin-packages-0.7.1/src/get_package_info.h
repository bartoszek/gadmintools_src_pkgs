
#ifndef GET_PACKAGE_INFO_H
#define GET_PACKAGE_INFO_H

char * get_conf_from_package(int where, char *package);

char * get_version_from_package(int where, char *package);

char * get_unpacked_name_from_package(char *package);

char * get_directory_from_package(char *package);

/* Combine these as get_install_section() */
char * get_pre_install_from_package(char *package);
char * get_install_from_package(char *package);
char * get_post_install_from_package(char *package);
char * get_description_from_package(char *package);

char ** get_depending_packages(char *package);
char ** get_required_packages(char *package);

long get_install_list_num();

char * get_install_package_from_install_nr(long i);

long get_num_files_from_package(char *package);

long get_num_requires_from_package(char *package);

char * get_from_settings(char *setting);

void package_installed_file(char *inputpath);

#endif
