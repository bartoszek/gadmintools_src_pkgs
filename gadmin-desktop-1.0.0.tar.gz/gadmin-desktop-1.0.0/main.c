/*
    GAdmin-Desktop-Settings.
    Author: Magnus Loef
    gcc `pkg-config --cflags --libs gtk+-2.0` main.c -o program
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
#include "main.h"

/* Calculates and shows the result from the libraries */
void activate_settings();

/* Creates the main window */
void create_main_window();


/* Shows an about window */
void show_about()
{
    GtkTextBuffer *textbuffer;
    GtkWidget *window, *vbox, *textview;
    GtkWidget *viewport, *scrolled_window, *close_button;
    gchar *utf8 = NULL;
    gchar *text;

    /* Create a window */
    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_widget_set_size_request(window, 500, 500);
    gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);

    /* Create a vbox and add it to the window */
    vbox = gtk_vbox_new(FALSE, 0);
    gtk_container_add(GTK_CONTAINER(window), vbox);

    /* Add a scrolled window in the vbox */
    scrolled_window = gtk_scrolled_window_new(NULL, NULL);
    gtk_box_pack_start(GTK_BOX(vbox), scrolled_window, TRUE, TRUE, 0);
    gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scrolled_window),
                                       GTK_POLICY_AUTOMATIC, GTK_POLICY_ALWAYS);
    /* Create a viewport */
    viewport = gtk_viewport_new(NULL, NULL);
    gtk_container_add(GTK_CONTAINER(scrolled_window), viewport);
    /* Create a textview */
    textview = gtk_text_view_new();
    /* Add the textview to the viewport */
    gtk_container_add(GTK_CONTAINER(viewport), textview);
    /* Set textmode to wrap on words */
    gtk_text_view_set_wrap_mode(GTK_TEXT_VIEW(textview), GTK_WRAP_WORD);
    /* Add a window close button */
    close_button = gtk_button_new_from_stock(GTK_STOCK_CLOSE);
    gtk_box_pack_start(GTK_BOX(vbox), close_button, FALSE, TRUE, 0);
    /* Close window button */
    g_signal_connect_swapped(G_OBJECT(close_button), "clicked",
                         G_CALLBACK(gtk_widget_destroy), window);

    /* Text for the about window */
    text = g_strconcat("\n\t\t\tAbout GAdmin-Desktop-Settings:\n\n",
                       "\tAuthor: Magnus Loef.\n",
    NULL);
    /* Add the text to the about window */
    textbuffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(textview));
    utf8 = g_locale_to_utf8(text, strlen(text), NULL, NULL, NULL);
    if( utf8!=NULL )
    {
        gtk_text_buffer_set_text(textbuffer, utf8, strlen(utf8));
        g_free(utf8);
    }
    /* Show the about window and all the widgets */
    gtk_widget_show_all(window);
}

/* The programs main function */
int main(int argc, char *argv[])
{
    wid *widgets = g_malloc(sizeof(wid));

    gtk_set_locale();
    gtk_init(&argc, &argv);

    create_main_window(widgets);

    gtk_main();

    g_free(widgets);

    return 0;
}

/* Creates the main window */
void create_main_window(struct w *widgets)
{
    /* Various widgets for the main window */
    GtkWidget *vbox;
    GtkWidget *frame1;
    GtkWidget *frame2;
    GtkWidget *table;
    GtkWidget *scrolled_window;
/*    gchar *text; */
    GtkWidget *toolbar_hbox;
    GtkWidget *toolbar;
    GtkWidget *activate_settings_icon;
    GtkWidget *activate_settings_button;
    GtkWidget *about_icon;
    GtkWidget *about_button;
    GtkWidget *quit_icon;
    GtkWidget *quit_button;

    /* Create the programs main window */
    widgets->main_window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(widgets->main_window), "GAdmin-Desktop-Settings");
    gtk_widget_set_size_request(widgets->main_window, 400, 300);
    gtk_window_set_position(GTK_WINDOW(widgets->main_window), GTK_WIN_POS_CENTER);
    gtk_container_set_border_width(GTK_CONTAINER(widgets->main_window), 10);
    /* Window close button clicked signal */
    g_signal_connect(GTK_WINDOW(widgets->main_window),
                     "delete_event", G_CALLBACK(gtk_main_quit), NULL);

    /* Create a frame, vbox and table */
    frame1 = gtk_frame_new("Settings:");
    vbox   = gtk_vbox_new(FALSE, 5);
    table  = gtk_table_new(4,2, FALSE);
    /* Add the vbox to the table */
    gtk_container_add(GTK_CONTAINER(widgets->main_window), vbox);

    /* Add a hbox to the vbox */
    toolbar_hbox = gtk_hbox_new(FALSE, 0);
    gtk_box_pack_start(GTK_BOX(vbox), toolbar_hbox, FALSE, FALSE, 0);
    /* Create a toolbar and add it to the hbox */
    toolbar = gtk_toolbar_new();
    gtk_box_pack_start(GTK_BOX(toolbar_hbox), toolbar, TRUE, TRUE, 0);
    gtk_toolbar_set_style(GTK_TOOLBAR(toolbar), GTK_TOOLBAR_BOTH);

    /* Add a activate_settings button to the toolbar */
    activate_settings_icon = gtk_image_new_from_stock("gtk-refresh",
                         gtk_toolbar_get_icon_size(GTK_TOOLBAR(toolbar)));
    activate_settings_button = gtk_toolbar_append_element(GTK_TOOLBAR(toolbar),
                            GTK_TOOLBAR_CHILD_BUTTON, NULL, "Activate",
                            NULL, NULL, activate_settings_icon, NULL, NULL);
    /* activate_settings button signal */
    g_signal_connect_swapped(G_OBJECT(activate_settings_button), "clicked",
                      G_CALLBACK(activate_settings), widgets);

    /* About button */
    about_icon = gtk_image_new_from_stock("gtk-about",
                     gtk_toolbar_get_icon_size(GTK_TOOLBAR(toolbar)));
    about_button = gtk_toolbar_append_element(GTK_TOOLBAR(toolbar),
                           GTK_TOOLBAR_CHILD_BUTTON, NULL, "About",
                                 NULL, NULL, about_icon, NULL, NULL);
    /* About button signal */
    g_signal_connect_swapped(G_OBJECT(about_button),
          "clicked", G_CALLBACK(show_about), NULL);

    /* Quit button */
    quit_icon = gtk_image_new_from_stock("gtk-quit",
                   gtk_toolbar_get_icon_size(GTK_TOOLBAR(toolbar)));
    quit_button = gtk_toolbar_append_element(GTK_TOOLBAR(toolbar),
                                            GTK_TOOLBAR_CHILD_BUTTON,
                                            NULL, "Quit", NULL, NULL,
                                            quit_icon, NULL, NULL);
    /* Quit button signal */
    g_signal_connect(G_OBJECT(quit_button), "clicked", G_CALLBACK(gtk_main_quit), NULL);


    /* Add the frame to the vbox and table to the frame */
    gtk_box_pack_start(GTK_BOX(vbox), frame1, FALSE, FALSE, 0);
    gtk_container_add(GTK_CONTAINER(frame1), table);

    /* Add spinbuttons to the table with precision set to 2 digits */
    widgets->spinbutton[0] = make_spinbutton_with_label(GTK_TABLE(table),
                                    "Monitor brightness :",0,1,0,1,10,2);
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(widgets->spinbutton[0]), 0.50);

    /* Add a combo to the table */
/*
    widgets->combo = make_combo_with_label(GTK_TABLE(table),
                        "Välj vilken kopplingstyp :", 0,1,5,6);
*/
    /* Add choices to the combo */
/*
    text = g_strdup_printf("Seriell");
    gtk_combo_box_append_text(GTK_COMBO_BOX(widgets->combo), text);
    if( text!=NULL )
        g_free(text);
    text = g_strdup_printf("Parallell");
    gtk_combo_box_append_text(GTK_COMBO_BOX(widgets->combo), text);
    if( text!=NULL )
        g_free(text);
*/
    /* Set selected combo index to the first choice "Seriell" */
/*    gtk_combo_box_set_active(GTK_COMBO_BOX(widgets->combo), 0); */

    /* Create frame2 and add it to the vbox */
    frame2 = gtk_frame_new("Program output:");
    gtk_box_pack_start(GTK_BOX(vbox), frame2, TRUE, TRUE, 0);

    /* Create a scrolled window and add it to frame2 */
    scrolled_window = gtk_scrolled_window_new(NULL, NULL);
    gtk_container_add(GTK_CONTAINER(frame2), scrolled_window);

    /* Add a textview to frame2 */
    widgets->textview = gtk_text_view_new();
    gtk_container_add(GTK_CONTAINER(scrolled_window), widgets->textview);

    /* Show the window and all its widgets */
    gtk_widget_show_all(widgets->main_window);

    return;
}

/* Append text to the textview */
void append_text(GtkTextBuffer *textbuffer, gchar *text)
{
    /* A gtk text iter */
    GtkTextIter iter;

    /* Get text end iter from textbuffer to iter */
    gtk_text_buffer_get_end_iter(textbuffer, &iter);
    /* Append text at the end iter */
    gtk_text_buffer_insert(textbuffer, &iter, text, -1);
    /* free the text */
    if( text!=NULL )
        g_free(text);
}

/* activate_settings things */
void activate_settings(struct w *widgets)
{
    /* Combo index */
/*  gint index = 0; */
    /* Text for the textbuffer */
/*    gchar *text; */
    /* Textbuffer for the textview */
    GtkTextBuffer *textbuffer;
    /* Variables used in calculations */
//    float light_percent = 0.0;
    double light_percent = 0.10;

    /* Get the selected volt and current */
    light_percent = gtk_spin_button_get_value_as_float(GTK_SPIN_BUTTON(widgets->spinbutton[0]));

    /* Get textbuffer for the textview */
    textbuffer = gtk_text_view_get_buffer(GTK_TEXT_VIEW(widgets->textview));

    /* Clear the textbuffer */
    gtk_text_buffer_set_text(GTK_TEXT_BUFFER(textbuffer), "", 0);


    gchar *cmd;

    /* Change comma to a dot */
    gchar *value = g_strdup_printf("%.2f", light_percent);
    value[1]='.';


    cmd = g_strdup_printf("xrandr --output `xrandr -q | grep ' connected' \
    | cut -f1 -d' '` --brightness %s", value);
//    printf("CMD: %s\n", cmd);


    // EXEC
    system(cmd);

    append_text(textbuffer, cmd);

    return;
}

/* Makes a spinbutton and adds it to the table in the main window */
GtkWidget * make_spinbutton_with_label(GtkTable * table,
                                  const gchar * label_text, gint left_attach,
                                  gint right_attach, gint top_attach,
                                  gint bottom_attach, gint spinbutton_length, gint precision)
{
    GtkWidget *spinbutton;
    gdouble min = 0.1;     /* minimum value */
    gdouble max = 1.0;     /* max value */
    gdouble step = 0.05;   /* Steps per click */

    GtkWidget *label;
    label = gtk_label_new(label_text);

    spinbutton = gtk_spin_button_new_with_range(min, max, step);

    /* Set precision */
    gtk_spin_button_set_digits(GTK_SPIN_BUTTON(spinbutton), precision);

    gtk_table_attach(table, label, left_attach, right_attach, top_attach, bottom_attach, GTK_FILL, GTK_EXPAND, 2, 2);
    gtk_table_attach(table, spinbutton, left_attach + 2, right_attach + 2, top_attach, bottom_attach,
                                                  GTK_FILL | GTK_EXPAND, GTK_FILL | GTK_EXPAND, 20, 2);

    gtk_misc_set_alignment(GTK_MISC(label), 0, 0.5);
    gtk_misc_set_padding(GTK_MISC(label), 2, 2);
    gtk_widget_set_size_request(spinbutton, spinbutton_length, -1);

    gtk_widget_show(spinbutton);
    gtk_widget_show(label);

    /* Make the spinbutton non-editable, only spinnable */
    gtk_editable_set_editable(GTK_EDITABLE(spinbutton), FALSE);

    return spinbutton;
}

/* Makes a combo and adds it to the table in the main window */
GtkWidget * make_combo_with_label(GtkTable * table,
                              const gchar * label_text, gint left_attach,
                              gint right_attach, gint top_attach,
                              gint bottom_attach)
{
    GtkWidget *combo;
    GtkWidget *label;
    label = gtk_label_new(label_text);
    combo = gtk_combo_box_new_text();

    gtk_table_attach(table, label, left_attach, right_attach, top_attach, bottom_attach, GTK_FILL, GTK_EXPAND, 2, 2);
    gtk_table_attach(table, combo, left_attach + 2, right_attach + 2, top_attach, bottom_attach,
                                             GTK_FILL | GTK_EXPAND, GTK_FILL | GTK_EXPAND, 20, 2);

    gtk_misc_set_alignment(GTK_MISC(label), 1, 0.5);
    gtk_misc_set_padding(GTK_MISC(label), 2, 2);

    gtk_widget_show(combo);
    gtk_widget_show(label);

    return combo;
}
