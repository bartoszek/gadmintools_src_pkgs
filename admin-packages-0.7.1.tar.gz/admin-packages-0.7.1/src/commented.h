
#ifndef COMMENTED_H
#define COMMENTED_H

int commented(char *line);

#endif
