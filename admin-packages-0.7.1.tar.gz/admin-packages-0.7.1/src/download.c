/*
 * Admin-Packages - A Package manager for sources.
 * Copyright (C) 2009 - 2011 Magnus Loef <magnus-swe@telia.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307, USA.
 *
 */

#include "../config.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include "allocate.h"
#include "globals.h"
#include "file_exists.h"
#include "run_command.h"
#include "commented.h"
#include "download.h"
#include "mdsums_match.h"
#include "get_package_info.h"
#include "unpack_package.h"
#include "have_equal_or_higher_version.h"


extern char build_directory[MAX_TEMP_PATH];
extern char pkgconf_temp[MAX_TEMP_PATH];
extern char global_newest_url[MAX_URL_LEN];

extern int global_mdsum_check;
extern int global_verbose;
extern int global_new_dist;


void trim_line(char *line)
{
    long i = 0;

    for(i=0; i<strlen(line); i++)
    if( line[i]=='\r' || line[i]=='\n' || line[i]=='\t' )
    {
        line[i]='\0';
        break;
    }
}


/* Download a file */
int download_file(char *url, char *srv_path, char *dl_path, char *file)
{
    int ret = 0;
    char *cmd, *file_path;

    trim_line(url);
    trim_line(srv_path);
    trim_line(dl_path);
    trim_line(file);

    cmd = allocate(strlen(url)+strlen(srv_path)+strlen(dl_path)+strlen(file)+1024);

    file_path = allocate(strlen(dl_path)+strlen(file)+6);
    sprintf(file_path, "%s/%s", dl_path, file);

    if( strstr(url, "ftp://") )
    {
        if( global_verbose )
           sprintf(cmd, "%s --directory-prefix=%s --passive-ftp %s/%s/%s", WGET_PATH, dl_path, url, srv_path, file);
        else
           sprintf(cmd, "%s --quiet --directory-prefix=%s --passive-ftp %s/%s/%s", WGET_PATH, dl_path, url, srv_path, file);
    }
    else
    if( strstr(url, "http://") || strstr(url, "https://") )
    {
        if( global_verbose )
            sprintf(cmd, "%s --directory-prefix=%s %s/%s/%s", WGET_PATH, dl_path, url, srv_path, file);
        else
            sprintf(cmd, "%s --quiet --directory-prefix=%s %s/%s/%s", WGET_PATH, dl_path, url, srv_path, file);
    }
    else
    if( strstr(url, "/") || ! strstr(url, "file://") )
    {
        /* Local repository */
        if( global_verbose )
            sprintf(cmd, "cp -v %s/%s/%s %s", url, srv_path, file, dl_path);
        else
            sprintf(cmd, "cp %s/%s/%s %s", url, srv_path, file, dl_path);
    }
    else
    {
        printf("Error in servers.conf:\n[%s] is not a valid url.\n", url);
        return 0;
    }

    printf("Downloading file from: [%s/%s/%s]\n", url, srv_path, file);
    printf("Downloading file to  : [%s]\n", file_path);

    ret = run_command(cmd);

    free(cmd);
    free(file_path);

    return ret;
}


/* Download all files for a package,
   unpack any archives and check mdsums */
int download_files(char *package)
{
    FILE *fp;
    char *line, *tmp_package, *dir, *srv_path;
    long file_size = 0;

    if((fp=fopen(pkgconf_temp, "r"))==NULL)
    {
        perror("fopen");
        printf("Error opening file: [%s]\n", pkgconf_temp);
        return 0;
    }
    fseek(fp, 0, SEEK_END);
    file_size = ftell(fp);
    rewind(fp);

    line = allocate(file_size);

    tmp_package = allocate(MAX_PKG_LEN+3);

    if( global_new_dist )
        srv_path = allocate(MAX_PKG_LEN+strlen(REMOTE_NEW_DIST_ROOT)+1024);
    else
        srv_path = allocate(MAX_PKG_LEN+strlen(REMOTE_ROOT)+1024);

    sprintf(tmp_package, "<%s>\n", package);

    dir = get_directory_from_package(package);
    if( global_new_dist )
        sprintf(srv_path, "%s/%s", REMOTE_NEW_DIST_ROOT, dir);
    else
        sprintf(srv_path, "%s/%s", REMOTE_ROOT, dir);

    free(dir);

    if( file_size > 1 )
    while(fgets(line, file_size, fp)!=NULL)
    {
        if( commented(line) )
            continue;

        /* Is this an exact <package name> match */
        if( strcmp(line, tmp_package) == 0 )
            break;
    }

    if( file_size > 1 )
    while(fgets(line, file_size, fp)!=NULL)
    {
        if( commented(line) )
            continue;

        if( strstr(line, "<files>") )
            break;
    }

    if( file_size > 1 )
    while(fgets(line, file_size, fp)!=NULL)
    {
        if( commented(line) )
            continue;

        if( strlen(line) < 3 )
            continue;

        if( strstr(line, "</files>") )
            break;
                                                        /* dl_path / file */
        if( ! download_file(global_newest_url, srv_path, build_directory, line) )
        {
            fclose(fp);
            free(line);
            free(tmp_package);
            free(srv_path);
            return 0;
        }

        if( ! mdsums_match(line) )
        {
            printf("Error: File md5sum do not match the list md5sum.\n");
            fclose(fp);
            free(line);
            free(tmp_package);
            free(srv_path);
            return 0;
        }

        if( global_mdsum_check )
            printf("Md5sums match, proceeding.\n");

        /* Unpack files if they are compressed archives */
        unpack_package(line);
    }
    fclose(fp);
    free(line);
    free(tmp_package);
    free(srv_path);

    return 1;
}


/* Find the url with the highest version of a given package */
int url_download_remote_conf_from_package(char *package)
{
   FILE *url_fp, *pkg_fp;
   char *url, *tmp_url, *tmp_package, *version, *line;
   int i=0, begin=0, package_matches=0, new_ver_found=0;
   int  found_url = 0;
   long file_size = 0;
   long line_size = 0;

   if((url_fp=fopen(SERVERS_CONF, "r"))==NULL)
   {
       perror("fopen");
       printf("You need to have atleast one repository URL in:\n%s\n", SERVERS_CONF);
       return 0;
   }
   fseek(url_fp, 0, SEEK_END);
   /* If a file consists of a single line of text at the top that has no newline at
      the end in Fedora11 the last char will not be read unless "+1" is added to
      the file size recieved from ftell().

      "echo 'Some TextX' > testfile".
      The last 'X' will be read on the second fgets() pass.
    */
   file_size = ftell(url_fp) +1;
   rewind(url_fp);

   url = allocate(file_size+1);

   tmp_package = allocate(MAX_PKG_LEN+3);
   sprintf(tmp_package, "<%s>\n", package);

   /* Reading local servers.conf */
   if( file_size > 1 )
   while(fgets(url, file_size, url_fp)!=NULL)
   {
      if( commented(url) )
        continue;

      trim_line(url);

      if( strstr(url, "http://") || strstr(url, "https://")
      ||  strstr(url, "ftp://")  || strstr(url, "ftps://")  )
      {
          printf("\nDownloading from configured URL:\n[%s]\n", url);
          found_url = 1;
      }
      else
      if( strstr(url, "local:/") )
      {
          if( strstr(url, "local://") )
          {
             printf("Error: There should only be one slash in local repository paths\n");
             continue;
          }
          tmp_url = allocate(file_size+1);
          snprintf(tmp_url, file_size, "%s", &url[6]);
          snprintf(url, file_size, "%s", tmp_url);
          free(tmp_url);

          printf("\nCopying from configured local path:\n[%s]\n", url);
          found_url = 1;
      }
      else
        continue;


      /* Download packages.conf for a new dist */
      if( global_new_dist )
      {
          if( ! download_file(url, REMOTE_NEW_DIST_ROOT, build_directory, PKGCONF_NAME) )
          {
              printf("There was an error downloading the package list: [%s]\n", PKGCONF_NAME);
              printf("From: [%s]\n", url);
              continue;
          }
      }
      else
      {
          if( ! download_file(url, REMOTE_ROOT, build_directory, PKGCONF_NAME) )
          {
              printf("There was an error downloading the package list: [%s]\n", PKGCONF_NAME);
              printf("From: [%s]\n", url);
              continue;
          }
      }

      /* Compare versions. Record the highest version and its url */
      if((pkg_fp=fopen(pkgconf_temp, "r"))==NULL)
      {
         perror("fopen");
         printf("Fatal error opening downloaded file [%s]\n", pkgconf_temp);
         fclose(url_fp);
         free(url);
         free(tmp_package);
         return 0;
      }
      fseek(pkg_fp, 0, SEEK_END);
      line_size = ftell(pkg_fp);
      rewind(pkg_fp);

      line = allocate(line_size+1);
      version = allocate(MAX_VER_LEN+1);

      if( line_size > 1 )
      while(fgets(line, line_size, pkg_fp)!=NULL)
      {
         /* Package match */
         if( strcmp(tmp_package, line) == 0 )
         {
             package_matches = 1;
             break;
         }
      }

      if( package_matches && line_size > 1 )
      while(fgets(line, line_size, pkg_fp)!=NULL)
      {
         if( strstr(line, "<") )
             break;

         if( strstr(line, "#") )
             continue;

         if( ! strstr(line, "version") )
             continue;

         /* Isolate the version */
         for(i=0; i<MAX_VER_LEN; i++)
         {
             if( i > 1 && line[i-1]=='"' )
             {
                 begin = i;
                 break;
             }
         }
         for(i=begin+1; i < MAX_VER_LEN-1; i++)
         {
             if( i > 1 && line[i]=='"' )
             {
                 strncpy(version, &line[begin], i-begin);
                 break;
             }
         }

         /* Check if this version is higher then what we have installed and 
          * higher then the other remote confs versions we have downloaded so far */
         if( ! have_equal_or_higher_version(package, version) )
         {
             if( strlen(version) < MAX_VER_LEN-1 && strlen(url) < MAX_URL_LEN-1 )
             {
                 new_ver_found = 1;
                 sprintf(global_newest_url, "%s", url);

                 printf("Found a new version: [%s-%s]\n", package, version);
                 break;

                 /* Dont scan this package list any more, get the
                  * new url and package list if any and scan again */
             }
             else
                 printf("New package/url length override attempt\n");
          }
      }
      fclose(pkg_fp);
      free(version);
      free(line);
   }  /* Scanning different urls and packages.conf */

   free(tmp_package);
   fclose(url_fp);
   free(url);

   if( ! found_url )
   {
       printf("Error: No valid url found in servers.conf\n");
   }

   return new_ver_found;
}
