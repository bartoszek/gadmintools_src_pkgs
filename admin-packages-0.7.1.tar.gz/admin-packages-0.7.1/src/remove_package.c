/*
 * Admin-Packages - A Package manager for sources.
 * Copyright (C) 2009 - 2011 Magnus Loef <magnus-swe@telia.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307, USA.
 *
 */


#include "../config.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include "globals.h"
#include "allocate.h"
#include "file_exists.h"
#include "run_command.h"
#include "question_yes.h"
#include "remove_package.h"
#include "show_uninstall_list.h"
#include "make_lists.h"
#include "list_package.h"
#include "package_in_conf.h"
#include "fix_conf_newlines.h"
#include "commented.h"

extern char pkgconf_temp[MAX_TEMP_PATH];
extern char package_queue[MAX_TEMP_PATH];
extern char mdsum_temp[MAX_TEMP_PATH];
extern char mdsum_pkg[MAX_TEMP_PATH];

extern int global_ask_questions;
extern int global_resolve_deps;


/* Packages that are parts of the base and shouldnt be removed */
/* Uses exact strcmp() matching */
char *non_removable_packages[]={
"linux"             , "linux-config",
"glibc"             , "ncurses",
"glibc-linuxthreads", "coreutils",
"make"              , "grep",
"autoconf"          , "automake",
"sed"               , "gawk",
"gettext"           , "patch",
"tar"               , "bash",
"util-linux"        , "perl",
"binutils"          , "m4",
"libtool"           , "kbd",
"e2fsprogs"         , "grub",
"module-init-tools" , "shadow",
"sysvinit"          , "gzip",
"bzip2"             , "wget",
"zlib"              , "gcc-core", 
"file"              , "gcc-g++", 
"binutils"          , "gcc-testsuite",
"openssl-engine"    , "openssl",
"hal"               , "dbus",
NULL};


/* Directories where it has no reason to remove files from */
/* Uses relaxed strstr() matching */
char *non_removable_files[]={
"/boot"    ,"/mnt",
"/dev"     ,"/proc",
"/home"    ,"/root",
"/initrd"  ,"/selinux",
"/media"   ,"/sys",
"/misc"    ,"/tmp",
NULL};


int do_remove(char *package)
{
    FILE *fp;
    long file_size=0;
    char *line, *conf, *filepath, *command, *begin_package, *end_package;
    int i=0, found_begin=0, found_end=0, ret=0;
    int once_per_iter=0, skipped_files=0;

    /* Some packages arent removable */
    if( package == NULL )
    {
        printf("Error, package is zero length\n");
        return 0;
    }
    if( strlen(package) < 2 )
    {
        printf("Error, package length is less then 2\n");
        return 0;
    }

    filepath = allocate(strlen(INSTALLED_PATH)+MAX_PKG_LEN+1024);
    sprintf(filepath, "%s/%s", INSTALLED_PATH, package);

    if((fp=fopen(filepath, "r"))==NULL)
    {
        printf("The package has no removal information here: %s\n", filepath);
        printf("Proceeding with removing the package description in %s\n", PACKAGES_CONF);
    }
    else
    {
        fseek(fp, 0, SEEK_END);
        file_size = ftell(fp);
        rewind(fp);

        line = allocate(file_size+3);

        if( file_size > 1 )
        while(fgets(line, file_size, fp)!=NULL)
        {
            if( line[strlen(line)-1]=='\n')
                line[strlen(line)-1]='\0';

            /* Atleast 7 /tmp/ab in length and not '*' or '..' */
            if( file_exists(line) && strlen(line) > 6 
            && ! strstr(line, "*") && ! strstr(line, "..") )
            {
                /* Remove the files that arent in non_removable_files */
                i = 0;
                once_per_iter = 0;
                while( non_removable_files[i] != NULL )
                {
                    if( strstr(non_removable_files[i], line) )
                    {
                        printf("\nRefusing to remove this file: %s\n\n", non_removable_files[i]);
                        skipped_files = 1;
                    }
                    else
                    {
                        if( ! once_per_iter )
                        {
                            printf("Removed: [%s]\n", line);

                            command = allocate(strlen(line)+10);
                            sprintf(command, "rm -f %s", line);
                            if( ! run_command(command) )
                                printf("Error removing file:\n%s\n", line);

                            free(command);
                            once_per_iter = 1;
                        }
                    }
                    i++;
                }
            }
            else
            {
                printf("Skipped a nonexistent or illegal(*) file: [%s]\n", line);
                skipped_files = 1;
            }
        }
        free(line);
    }
    fclose(fp);

    /* Remove the package install log /var/admin-packages/installed/..package.. */
    command = allocate(strlen(filepath)+10);
    sprintf(command, "rm -f %s", filepath);
    if( ! run_command(command) )
    {
        printf("Error deleting the removal information:\n%s\n", filepath);

        free(command);
    }

    free(filepath);

    /* Remove the package description in /etc/admin-packages/packages.conf */
    if((fp=fopen(PACKAGES_CONF, "r"))==NULL)
    {
        perror("fopen");
        printf("Fatal error opening file [%s]\n", PACKAGES_CONF);
        return 0;
    }
    fseek(fp, 0, SEEK_END);
    file_size = ftell(fp);
    rewind(fp);

    line = allocate(file_size+3);
    conf = allocate(file_size+3);
    begin_package = allocate(MAX_PKG_LEN+5);
    end_package = allocate(MAX_PKG_LEN+5);

    sprintf(begin_package, "<%s>\n", package);
    sprintf(end_package, "</%s>\n", package);

    if( file_size > 1 )
    while(fgets(line, file_size, fp)!=NULL)
    {
        if( commented(line) )
            continue;

        /* Is this an exact package match */
        if( strcmp(line, begin_package) == 0 )
        {
            ret = 1; found_begin = 1;

            if( file_size >  1 )
            while(fgets(line, file_size, fp)!=NULL)
            {
                if( strcmp(line, end_package) == 0 )
                {
                    found_end = 1;
                    break;
                }
            }
        }

        if( strcmp(line, end_package) == 0 )
            continue;

        strcat(conf, line);
    }
    fclose(fp);
    free(line);
    free(begin_package);
    free(end_package);

    if( ! found_begin )
    {
        printf("Error begin description for package: %s not found.\n", package);
        free(conf);
        return 0;
    }

    if( ! found_end )
    {
        printf("Error end description for package: %s not found.\n", package);
        free(conf);
        return 0;
    }

    /* Write the new conf without the removed package description */
    if((fp=fopen(PACKAGES_CONF, "w+"))==NULL)
    {
        perror("fopen");
        printf("Fatal error opening file [%s]\n", PACKAGES_CONF);
        free(conf);
        return 0;
    }

    if( ! skipped_files )
        printf("The package was removed successfully.\n");
    else
        printf("The package was removed but some files where skipped.\n");

    fputs(conf, fp);
    fclose(fp);
    free(conf);

    return ret;
}


int remove_package(char *package)
{
    FILE *fp;
    long file_size=0;
    char *line;
    char *some_package, *end_package;
    int i=0, ret=0;

    /* Some packages arent removable */
    if( package == NULL )
    {
        printf("Error, package is zero length\n");
        return 0;
    }
    if( strlen(package) < 2 )
    {
        printf("Error, package length is less then 2\n");
        return 0;
    }

    unlink(pkgconf_temp);
    unlink(mdsum_temp);
    unlink(mdsum_pkg);
    unlink(package_queue);

    if( ! package_in_local_conf(package) )
    {
        printf("This package doesnt seem to be installed on the system.\n");
        return 0;
    }


    /* If --nodeps is selected then only remove this package */
    if( ! global_resolve_deps )
    {
        if( global_ask_questions )
        {
            printf("Do you wish to proceed with removing package: %s [y/n]: ", package);
            if( ! question_yes() )
                return 0;
        }

        i = 0;
        while( non_removable_packages[i] != NULL )
        {
            if( strcmp(non_removable_packages[i], package) == 0 )
            {
                printf("\nRefusing to remove this base system package: %s\n\n", non_removable_packages[i]);
                return 0;
            }
            i++;
        }

        if( global_ask_questions )
        {
            /* Show the files installed by this package 
               and ask if they should be deleted */
            list_package(package);

            printf("\nPackage [%s] contains the files listed above.\n\n", package);
            printf("Do you wish to proceed with removing these files [y/n]: ");

            if( question_yes() )
                ret = do_remove(package);
            else
            {
                printf("Package not removed (No selected).\n");
                return 0;
            }
        }
        else
            ret = do_remove(package);

        fix_conf_newlines();

        return ret;
    }

    /* --nodeps is not selected... remove dependencies if any... */

    printf("Resolving dependencies and scheduling packages for removal.\n");
    make_uninstall_list_from_package(package);
    show_uninstall_list();

    if( global_ask_questions )
    {
        printf("Do you wish to proceed with removing these packages [y/n]: ");
        if( ! question_yes() )
            return 0;
    }

    /* List the files installed by this package */
    if((fp=fopen(package_queue, "r"))==NULL)
    {
        printf("Package queue could not be found here: %s\n", package_queue);
        return 0;
    }
    fseek(fp, 0, SEEK_END);
    file_size = ftell(fp);
    rewind(fp);

    line = allocate(file_size+3);
    some_package = allocate(MAX_PKG_LEN+10);
    end_package = allocate(MAX_PKG_LEN+10);

    if( file_size > 1 )
    while(fgets(line, file_size, fp)!=NULL)
    {
        if( commented(line) )
            continue;

        if( strlen(line) < 4 )
            continue;

        /* This is the first package in the queue */
        if( strstr(line, "<") && strstr(line, ">") )
        {
            snprintf(some_package, MAX_PKG_LEN-1, "%s", &line[1]);
            some_package[strlen(some_package)-2]='\0';

            if( strlen(some_package) < 2 )
                continue;

            snprintf(end_package, MAX_PKG_LEN-1, "</%s>\n", some_package);

            /* Scroll to the end of this packge */
            if( file_size > 1 )
            while(fgets(line, file_size, fp)!=NULL)
            {
                if( commented(line) )
                    continue;

                if( strcmp(line, end_package) == 0 )
                {
                    i = 0;
                    while( non_removable_packages[i] != NULL )
                    {
                        if( strcmp(non_removable_packages[i], some_package) == 0 )
                        {
                            printf("\nRefusing to remove this base system package: %s\n\n", non_removable_packages[i]);
                            fclose(fp);
                            free(line);
                            free(some_package);
                            free(end_package);
                            return 0;
                        }
                        i++;
                    }

                    if( global_ask_questions )
                    {
                        /* Show the files installed by this package 
                           and ask if they should be deleted */
                        list_package(some_package);

                        printf("\nPackage [%s] contains the files listed above.\n\n", some_package);
                        printf("Do you wish to proceed with removing these files [y/n]: ");

                        if( question_yes() )
                            ret = do_remove(some_package);
                        else
                        {
                            printf("Package not removed (No selected).\n");
                            fclose(fp);
                            free(line);
                            free(some_package);
                            free(end_package);
                            return 0;
                        }
                    }
                    else
                        ret = do_remove(some_package);

                    if( ret == 0 )
                    {
                        printf("Error: Failed to remove package: [%s]\n", some_package);
                        fclose(fp);
                        free(line);
                        free(some_package);
                        free(end_package);
                        return ret;
                    }

                    break;
                }
            }
        }
    }
    fclose(fp);
    free(line);
    free(some_package);
    free(end_package);

    fix_conf_newlines();

    unlink(pkgconf_temp);
    unlink(mdsum_temp);
    unlink(mdsum_pkg);
    unlink(package_queue);

    return ret;
}
