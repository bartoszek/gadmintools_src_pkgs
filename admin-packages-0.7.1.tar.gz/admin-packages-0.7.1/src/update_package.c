/*
 * Admin-Packages - A Package manager for sources.
 * Copyright (C) 2009 - 2011 Magnus Loef <magnus-swe@telia.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307, USA.
 *
 */


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include "globals.h"
#include "allocate.h"
#include "question_yes.h"
#include "download.h"
#include "queue_package.h"
#include "update_package.h"
#include "make_lists.h"
#include "commented.h"
#include "show_install_list.h"
#include "get_package_info.h"
#include "mdsums_match.h"
#include "unpack_package.h"
#include "install_package.h"
#include "merge_conf_from_package.h"
#include "dir_handling.h"
#include "run_command.h"
#include "fix_conf_newlines.h"
#include "binary_packages.h"

extern char global_newest_url[MAX_URL_LEN];
extern char build_directory[MAX_TEMP_PATH];
extern char build_dir_next[MAX_TEMP_PATH];
extern char pkgconf_temp[MAX_TEMP_PATH];
extern char package_queue[MAX_TEMP_PATH];
extern char mdsum_temp[MAX_TEMP_PATH];
extern char mdsum_pkg[MAX_TEMP_PATH];

extern int global_mdsum_check;
extern int global_ask_questions;
extern int global_resolve_deps;
extern int global_testing;
extern int global_verbose;
extern int global_reinstall;
extern int global_new_dist;
extern int global_create_binary;
extern int global_install_binary;


/* Get the site with the latest version of the package.
   Download mdsums.list and packages.conf from this site.
   Compare mdsums for the downloaded packages.conf.

   Resolve dependencies and make an ordered install list.

   Download all files from section <files> for each package.
   Compare all downloaded filed against the mdsums.list.
   Unpack compressed archives and remove the original packages.

   Configure, make and install packages according to
   packages.conf and the ordered install list.

   Creates or installs binary packages if specified. */

int update_package(char *package)
{
    char *version;
    char *list_package;
    char *cmd;
    long i = 0, number = 0;

    /* Create 2 randomized temporary build directories */
    create_build_directory(build_directory);
    create_build_directory(build_dir_next);
    setup_global_paths();

    if( global_verbose )
    {
        printf("Build directory: %s\n", build_directory);
        printf("Build dir next : %s\n", build_dir_next);
    }

    /* Download the remote packages.conf file.
       This also sets global_newest_url and version */
    if( ! url_download_remote_conf_from_package(package) )
    {
        printf("No updates could be found for package: %s\n", package);
        return 0;
    }

    /* Download remote mdsums.list file if mdsum checking is enabled */
    if( global_mdsum_check )
    {
        /* Get mdsums.list from the new-dist directory if specified */
        if( global_new_dist )
        {
            if( ! download_file(global_newest_url, REMOTE_NEW_DIST_ROOT, build_directory, MDSUM_NAME) )
            {
                printf("\nmdsums.list download failed.\n");
                return 0;
            }
        }
        else
        {   /* Get mdsums.list file from the distfiles directory */
            if( ! download_file(global_newest_url, REMOTE_ROOT, build_directory, MDSUM_NAME) )
            {
                printf("\nmdsums.list download failed.\n");
                return 0;
            }
        }
        /* Compare mdsums for packages.conf against the mdsums.list if checking is enabled */
        printf("Comparing mdsums for [%s]\n", PKGCONF_NAME);
        if( ! mdsums_match(PKGCONF_NAME) )
        {
            printf("Md5sum check failed for [%s]\n", PKGCONF_NAME);
            return 0;
        }
        else
            printf("Mdsums for [%s] are correct\n", PKGCONF_NAME);
    }

    /* Make an install list queue for this package and all required packages */
    if( global_resolve_deps )
    {
        printf("Resolving dependencies and scheduling packages for installation.\n");

        make_install_list_from_package(package);
    }
    else /* Only queue this package for install */
    {
        printf("Nodeps selected, only one package scheduled for installation.\n");

        queue_package_for_install(package);
    }

    /* Show what will be installed */
    show_install_list();

    /* Get how many packages have been queued in the install list */
    number = get_install_list_num();

    /* Question */
    if( global_ask_questions )
    {
        printf("Do you wish to install these [%li] packages [y/n]: ", number);

        if( question_yes() )
            printf("Proceeding with installation...\n");
        else
        {
            printf("Installation aborted by user.\n");
            return 0;
        }
    }

    /* Count down while installing all packages */
    for(i=1; i <= number; i++)
    {
        /* Get packages from the install list queue */
        list_package = get_install_package_from_install_nr(i);

        /* Get version from downloaded temporary packages.conf */
        version = get_version_from_package(1, list_package);
        if( global_reinstall )
            printf("Reinstalling: %s-%s\n", list_package, version);
        else
            printf("Installing: %s-%s\n", list_package, version);
        free(version);

        if( ! global_install_binary )
        {
            /* Download all required files for this source package to the build_directory */
            printf("Downloading all files for package: [%s]\n", list_package);
            if( ! download_files(list_package) )
            {
                printf("\nDownloading all files for package [%s] failed.\n", list_package);
                free(list_package);
                return 0;
            }
        }

        if( ! global_testing )
        {
            /* Install_package() also adds a list of what files where
               installed at: Build_Directory/installed/PackageName */
            if( ! global_install_binary )
            {
                if( ! install_package(list_package) )
                {
                    if( global_reinstall )
                        printf("Reinstalling package: [%s] failed.\n", list_package);
                    else
                        printf("Installing package: [%s] failed.\n", list_package);

                    free(list_package);
                    return 0;
                }
            }
            if( global_install_binary )
            {
                if( ! install_binary_package(list_package) )
                {
                    if( global_reinstall )
                        printf("Reinstalling binary package: [%s] failed.\n", list_package);
                    else
                       printf("Installing binary package: [%s] failed.\n", list_package);

                    free(list_package);
                    return 0;
                }
            }

            /* Merge this package description to the list of installed packages */
            if( ! merge_conf_from_package(list_package) )
            {
                printf("Merging the package conf failed, aborting\n");
                free(list_package);
                return 0;
            }
            else
            if( global_verbose )
                printf("Merged the package description\n");

            /* Binary package creation selected */
            if( global_create_binary )
            {
                if( ! create_binary_package(list_package) )
                {
                    printf("Failed to create binary package: [%s]\n", list_package);
                    free(list_package);
                    return 0;
                }
                printf("Binary package created: [%s]\n", list_package);
            }

            /* Get from the temporary downloaded packages.conf */
            version = get_version_from_package(2, list_package);
            if( global_reinstall )
                printf("\nReinstalled package: %s-%s\n\n", list_package, version);
            else
                printf("\nInstalled package: %s-%s\n\n", list_package, version);
            free(version);

            /* If this package is "newdist-pass2" and a local repo is used,
               then copy the local new-dist repo to tooldir/repo */
            if( global_new_dist && strstr(list_package, "newdist-pass2")
            &&  global_newest_url[0]=='/' )
            {
                /* "local:" has been snipped from the global_newest_url previously
                   so now we have the local repository path */

                /* Create a repository directory in the tooldir */
                cmd = allocate(4096);
                sprintf(cmd, "mkdir -p /tools%s", global_newest_url);
                if( ! run_command(cmd) )
                {
                    printf("Error creating tooldir repository after newdist-pass2.\n");
                    free(cmd);
                    exit(1);
                }
                free(cmd);
                /* Copy the local new-dist directory to the tooldir repository */	    
                cmd = allocate(4096);
                sprintf(cmd, "cp -R %s/new-dist /tools%s", global_newest_url, global_newest_url);
                if( ! run_command(cmd) )
                {
                    printf("Error copying the repository after newdist-pass2.\n");
                    free(cmd);
                    exit(1);
                }
                free(cmd);
            }
        }
        else
            printf("\nTesting selected, skipping installation for package: [%s]\n\n", list_package);

        free(list_package);

        /* Move: packages.conf, package.queue and mdsums.list to the next build dir */
        cmd = allocate((MAX_TEMP_PATH*2)+1024);
        snprintf(cmd, (MAX_TEMP_PATH*2)+1024,
        "mv %s/%s %s", build_directory, PKGCONF_NAME, build_dir_next);
        if( ! run_command(cmd) )
        {
            printf("Error moving packages.conf to a new\nrandomized build directory after installation.\n");
            free(cmd);
            exit(1);
        }
        free(cmd);

        cmd = allocate((MAX_TEMP_PATH*2)+1024);
        snprintf(cmd, (MAX_TEMP_PATH*2)+1024,
        "mv %s/%s %s", build_directory, PACKAGE_QUEUE_NAME, build_dir_next);
        if( ! run_command(cmd) )
        {
            printf("Error moving packages.queue to the new randomized build directory after installation.\n");
            free(cmd);
            exit(1);
        }
        free(cmd);

        if( global_mdsum_check )
        {
            cmd = allocate((MAX_TEMP_PATH*2)+1024);
            snprintf(cmd, (MAX_TEMP_PATH*2)+1024,
            "mv %s/%s %s", build_directory, MDSUM_NAME, build_dir_next);
            if( ! run_command(cmd) )
            {
                printf("Error moving mdsums.list to the new randomized build directory after installation.\n");
                free(cmd);
                exit(1);

            }
            free(cmd);
        }

        /* Clean the randomized build directory */
        clean_build_directory_temp();

        /* Make the next build directory current */
        strcpy(build_directory, build_dir_next);
        /* Setup global build directory paths */
        setup_global_paths();

        /* Create a new directory for the next package */
        create_build_directory(build_dir_next);
    }

    if( global_verbose )
    {
        if( number < 1 )
            printf("No new packages where installed.\n");
        else
        if( number == 1 )
            printf("One new package was installed: [%s]\n", package);
        else
            printf("Number of new packages installed: [%li]\n", number);
    }

    fix_conf_newlines();

    return 1;
}


/* Update all installed packages */
int update_all_packages()
{
    FILE *fp;
    char *line, *pkg_name, *pkg_end, *version;
    long i = 0, file_size = 0;
    int retval = 0;

    if((fp=fopen(PACKAGES_CONF, "r"))==NULL)
    {
        printf("Error opening: [%s]\n", PACKAGES_CONF);
        printf("Install a package first\n");
        return 0;
    }
    fseek(fp, 0, SEEK_END);
    file_size = ftell(fp);
    rewind(fp);

    line = allocate(file_size+1);
    pkg_name = allocate(MAX_PKG_LEN+3);
    pkg_end  = allocate(MAX_PKG_LEN+6);

    if( file_size > 1 )
    while(fgets(line, file_size, fp)!=NULL)
    {
        if( commented(line) )
            continue;

        if( strlen(line) > MAX_PKG_LEN-1 )
            continue;

        /* The first entry in a package profile is <PackageName> */
        if( strstr(line, "<") && strstr(line, ">") )
        {
            for(i=0; i< MAX_PKG_LEN-1; i++)
            {
                if( line[i]=='<' && strlen(line) < MAX_PKG_LEN-1 )
                {
                    sprintf(pkg_name, "%s", &line[i+1]);
                    pkg_name[strlen(line)-3]='\0';

                    snprintf(pkg_end, MAX_PKG_LEN-1, "</%s>\n", pkg_name);

                    /* Get version from SYSCONFDIR/admin-packages/packages.conf */
                    version = get_version_from_package(2, pkg_name);


                    /* Update the package if theres a new version */

                    /* This will download new packages.conf files etc for each package */

                    printf("\nTrying to update package: %s-%s\n", pkg_name, version);
                    free(version);

                    if( ! update_package(pkg_name) )
                    {
                        // printf("Update failed for package: [%s]\n", pkg_name);

                        retval = 0;
                    }

                    retval = 1;
                }
            }

            /* Scroll to the end of this profile </package-name> */
            if( file_size > 1 )
            while(fgets(line, file_size, fp)!=NULL)
            {
                if( commented(line) )
                    continue;

                if( strcmp(line, pkg_end) == 0 )
                    break;
            }
        }
    }
    fclose(fp);
    free(line);
    free(pkg_name);
    free(pkg_end);

    return retval;
}
