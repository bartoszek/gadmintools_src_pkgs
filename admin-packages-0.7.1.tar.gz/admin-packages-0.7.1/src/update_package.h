
#ifndef UPDATE_PACKAGE_H
#define UPDATE_PACKAGE_H

int update_package(char *package);

int update_all_packages();

#endif
