/* GAdmin-Antivirus - An easy to use GTK+ frontend for clamav antivirus.
 * Copyright (C) 2010 - 2014 Magnus Loef <magnus-swe@telia.com> 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
*/


#include "../config.h"
#include <gtk/gtk.h>
#include "support.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "widgets.h"
#include "functions.h"
#include "show_info.h"
/* for wexitstatus */
#include <sys/wait.h>

#ifndef _XOPEN_SOURCE
#define _XOPEN_SOURCE
#endif

extern int MAX_READ_POPEN;


int
commented(char *line)
{
    int i = 0, ret = 0;

    if( strlen(line) > 4000)
    {
        printf("Commented: A line longer then 4000 chars is bad input.\n");
        return 1;
    }

    if(line != NULL && strlen(line) > 0)
    {
        for(i = 0; line[i] != '\0'; i++)
        {
            /* Skip whitespace and tabs */
            if(line[i] == ' ' || line[i] == '\t')
                continue;

            /* If the first char thats not whitespace is '#' or ';'
               then the line is commented out */
            if(line[i] == '#' || line[i] == ';')
                ret = 1;
            else
                ret = 0;

            break;
        }
    }

    return ret;
}

void
run_command_show_err(gchar * command)
{
    FILE *fp;
    char *line, *info;

    if((fp = popen(command, "r")) == NULL)
    {
        perror("popen");
        return;
    }
    else
    {
        line = allocate(MAX_READ_POPEN + 2);
        info = allocate(MAX_READ_POPEN + 2);
        while(fgets(line, MAX_READ_POPEN, fp) != NULL)
            strcat(info, line);

        pclose(fp);
        show_info(info);
        free(info);
        free(line);
    }
}

int
run_command(gchar * command)
{
    FILE *fp;
    int status = 0, exit_status = 0;

    if((fp = popen(command, "w")) == NULL)
    {
        perror("popen");
        return 0;
    }
    status = pclose(fp);

    exit_status = WEXITSTATUS(status);

    if(exit_status > 0)
        exit_status = 0;
    else
        exit_status = 1;

    return exit_status;
}

int
file_exists(char *infile)
{
    FILE *fp;
    if((fp = fopen(infile, "r")) == NULL)
        return 0;

    fclose(fp);

    return 1;
}

int
get_option_pos(char *line, int optnum)
{
    int z = 0;
    int num = 1;
    long i = 0;

    if(optnum == 0)
    {
        for(i = 0; line[i] != '\0'; i++)
            if(line[i] != ' ' && line[i] != '\t')
                break;

        return i;
    }

    if(optnum == 1)
    {
        for(i = 0; line[i] != '\0'; i++)
            if(line[i] != ' ' && line[i] != '\t')
                break;

        for(i = i; line[i] != '\0'; i++)
            if((line[i] == ' ' || line[i] == '\t')
            && line[i + 1] != ' ' && line[i + 1] != '\t')
                break;

        i++;

        return i;
    }

    /* Scroll past the first option declaration
       to the first option value */
    if(line != NULL && strlen(line) > 0)
    {
        for(i = 0; line[i] != '\0'; i++)
        {
            if(line[i] != ' ')
                break;
        }
        for(i = i; line[i] != '\0'; i++)
        {
            if((line[i - 1] == ' ' || line[i - 1] == '\t')
            && line[i] != ' ' && line[i] != '\t')
                break;
        }
    }

    /* One small step for man, one giant leap for mankind :) */
    i++;

    for(z = 0; z <= optnum; z++)
    {
        if(num == optnum)
            break;

        /* Scroll to the beginning of the option value */
        if(line != NULL && strlen(line) > 0)
        {
            for(i = i; line[i] != '\0'; i++)
            {
                if(line[i - 1] == ' ' && line[i] != ' ')
                {
                    num++;
                    break;
                }
            }
        }
    }

    return i;
}

char *
allocate(long allocate_size)
{
    char *ret;
    ret = malloc(allocate_size);
    if(ret == NULL)
    {
        printf("Cant allocate enough ram, exiting\n");
        exit(1);
    }
    memset(ret, 0, allocate_size);

    return ret;
}

void
move_file_to_quarantine(struct w *widgets)
{
    gchar *info;

    info = g_strconcat("",
        _("\t\t\tNothing has been done.\n\n"),
        _("Moving files does not seem wise as the quarantine directory\n"),
        _("can give false positives or hide other viruses.\n\n"),
        _("Remove the file using the delete virus button or\n"),
        _("reinstall the operating system if it is a critical\n"),
        _("operating system file that can not be replaced.\n"),
        NULL);

    show_info(info);
    g_free(info);
}

/* Set to FALSE to disallow system file deletions */
#define DELETE_SYSTEM_FILES TRUE

int
delete_file_from_system(GtkTreeView *treeview)
{
    int i = 0;
    gchar *cmd, *info, *file_path = NULL;
    GtkTreeModel *model;
    GtkTreePath *tree_path;
    GtkTreeIter iter;

    /* Wether to remove the system file or not */
    if( ! DELETE_SYSTEM_FILES )
    {
        info = g_strdup_printf(_("File deletion is disabled:\n%s\n"),
                                                            file_path);
        show_info(info);
        if(info != NULL)
            g_free(info);
        return 0;
    }

    /* Get the current tree path */
    gtk_tree_view_get_cursor(GTK_TREE_VIEW(treeview), &tree_path, 0);
    if(tree_path == NULL)
    {
        info = g_strdup_printf(_("Select a file to remove first.\n"));
        show_info(info);
        if(info != NULL)
            g_free(info);
        return 0;
    }

    /* Get the tree model */
    model = gtk_tree_view_get_model(GTK_TREE_VIEW(treeview));

    /* Get the current iter */
    gtk_tree_model_get_iter(model, &iter, tree_path);

    if( tree_path != NULL )
        gtk_tree_path_free(tree_path);

    /* Get the value in column 0 */
    gtk_tree_model_get(model, &iter, 0, &file_path, -1);

    /* Check file path length */
    if( strlen(file_path) > 999999 )
    {
        info = g_strdup_printf(_("Error: File path too long:\n%s\n"),
                                                            file_path);
        show_info(info);
        if(info != NULL)
            g_free(info);

        g_free(file_path);
        return 0;
    }

    /* Sanitize the file path recieved from the log treeview */
    for(i=strlen(file_path); i>0; i--)
    {
        /* Remove the first colon delimiter last in the path */
        if( file_path[i]==':' )
        {
            file_path[i]='\0';
            break;
        }
    }

    if(file_path == NULL || ! file_exists(file_path)
    || strcmp(file_path, "/") == 0
    || strstr(file_path, "?")
    || strstr(file_path, "*")
    || file_path[0]!='/' )
    {
        info = g_strdup_printf(
             _("Error: Unable to remove virus file. Bad path:\n%s\n"),
                                                             file_path);
        show_info(info);
        if(info != NULL)
            g_free(info);
        g_free(file_path);
        return 0;
    }

    /* Everything looks fine, remove the file */
    cmd = g_strdup_printf("rm -f -- \"%s\"", file_path);
    if(!run_command(cmd))
    {
        info = g_strdup_printf(_("Error: Unable to remove virus file:\n%s\n"),
                                                                     file_path);
        show_info(info);
        if(info != NULL)
            g_free(info);
        g_free(file_path);
        g_free(cmd);
        return 0;
    }
    g_free(cmd);
    g_free(file_path);

    /* Remove the treeview row and set path to the first row */
    gtk_list_store_remove(GTK_LIST_STORE(model), &iter);
    set_treeview_path_first(GTK_TREE_VIEW(treeview));

    return 1;
}

void
set_treeview_path_first(GtkTreeView *treeview)
{
    GtkTreePath *tree_path;
    gboolean edit = 0;

    tree_path = gtk_tree_path_new_first();
    if(tree_path)
    {
        gtk_tree_view_set_cursor(GTK_TREE_VIEW(treeview),
                                    tree_path, NULL, edit);
        gtk_tree_path_free(tree_path);
    }
}

void
enable_clamav_file(gchar *path)
{
    FILE *fp;
    long file_size = 0;
    char *line, *new_buffer;

    if(path != NULL && strlen(path) < 10)
    {
        printf("Error: Enable freshclam: Path too short.\n");
        return;
    }
    if((fp = fopen(path, "r")) == NULL)
    {
        /* Dont expect to find a configuration */
        return;
    }
    fseek(fp, 0, SEEK_END);
    file_size = ftell(fp);
    rewind(fp);

    line = allocate(file_size + 1);
    new_buffer = allocate(file_size + 1);

    if(file_size > 1)
    {
        while(fgets(line, file_size, fp) != NULL)
        {
            if(commented(line))
            {
                continue;
                strcat(new_buffer, line);
            }
            /* Remove freshclam disable lines */
            if(strstr(line, "FRESHCLAM_DELAY"))
                continue;
            if(strstr(line, "EXAMPLE"))
                continue;
            if(strstr(line, "Example"))
                continue;

            strcat(new_buffer, line);
        }
    }
    fclose(fp);
    free(line);

    /* Write the new conf */
    if((fp = fopen(path, "w+")) == NULL)
    {
        printf("Could not write the Clamav configuration file here: %s\n",
                                                                      path);
        free(new_buffer);
        return;
    }
    fputs(new_buffer, fp);
    fclose(fp);
    free(new_buffer);
}

void
enable_clamav()
{
    /* Remove lines in configuration files that
       prevent clamscan and freshclam from running
       on the various distributions */
    enable_clamav_file(FRESHCLAM_CONF);
    enable_clamav_file("/etc/sysconfig/freshclam");
    enable_clamav_file("/etc/clamav.conf");
}

