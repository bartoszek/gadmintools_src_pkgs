/* GAdmin-Antivirus - An easy to use GTK+ frontend for clamav antivirus.
 * Copyright (C) 2010 - 2014 Magnus Loef <magnus-swe@telia.com> 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
*/



#include <gtk/gtk.h>
#include "make_settings_spinbuttons.h"

/* For time scheduling */
GtkWidget *
make_shortleft_spinbutton_with_label(GtkGrid *grid,
                             const gchar * label_text,
                             gint left_attach, gint top_attach,
                             gint width_attach, gint height_attach,
                             gint spinbutton_length, gdouble min,
                                                      gdouble max)
{
    GtkWidget *spinbutton;
    GtkWidget *label;
    GtkWidget *hbox;
    /* Steps per click */
    gdouble step = 1;

    label = gtk_label_new(label_text);
    spinbutton = gtk_spin_button_new_with_range(min, max, step);

    hbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 10);
    gtk_box_pack_start(GTK_BOX(hbox), label, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(hbox), spinbutton, FALSE, TRUE, 0);

    gtk_grid_attach(grid, hbox, left_attach, top_attach, width_attach, height_attach);

    gtk_misc_set_alignment(GTK_MISC(label), 0, 0.5);
    gtk_misc_set_padding(GTK_MISC(label), 2, 2);

    gtk_widget_show(spinbutton);
    gtk_widget_show(label);

    return spinbutton;
}

