/* GADMIN-NFS-SERVER - An easy to use GTK+ frontend for the NFS server.
 * Copyright (C) 2014 - 2014 Magnus Loef <magnus-swe@telia.com> 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
*/



#include <gtk/gtk.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "widgets.h"
#include "gettext.h"
#include "reread_conf.h"
#include "allocate.h"
#include "show_info.h"
#include "clear_ptr_array.h"
#include "set_num_clients.h"
#include "populate_clients.h"
#include "commented.h"

extern char global_netmask[1024];
extern char global_subnet[1024];
extern char global_nic[1024];


void add_client(struct w *widgets)
{
    FILE *fp;
    long file_size = 0;
    int dir_found = 0;
    int client_added = 0;
    char *line, *new_conf, *opt;
    gchar *info;
    G_CONST_RETURN gchar *range_from;
    G_CONST_RETURN gchar *range_to;

    /* get client data from the entries */
    range_from = gtk_entry_get_text(GTK_ENTRY(widgets->ranges_add_from_entry));
    range_to = gtk_entry_get_text(GTK_ENTRY(widgets->ranges_add_to_entry));

    if( strlen(range_from) < 3 ) // ::1
    {
       info = g_strdup_printf(_("The client host is too short, the client was not added.\n"));
       show_info(info);
       g_free(info);
       return;
    }

    if( strlen(range_to) < 2 ) // rw
    {
       info = g_strdup_printf(_("The client options is too short, the client was not added.\n"));
       show_info(info);
       g_free(info);
       return;
    }


    if((fp=fopen(NFSD_CONF, "r"))==NULL)
    {
        printf("Couldnt open exports file here: %s\n", NFSD_CONF);
        return;
    }
    fseek(fp, 0, SEEK_END);
    file_size = ftell(fp);
    rewind(fp);

    line = allocate(file_size+1);
    opt = allocate(file_size+1);

    gchar *dir = g_strdup_printf("%s", global_nic);

    /* If this dir already exists, dont add it */
    if( file_size > 1 )
    while(fgets(line, file_size, fp)!=NULL)
    {
        sscanf(line, "%s", opt);

        if( strcmp(dir, opt) == 0 && ! commented(line) )
        {
            dir_found = 1;
        }
    }
    fclose(fp);
    free(line);
    free(opt);

    /* Add directory if not found */
    if( ! dir_found )
    {
        if((fp=fopen(NFSD_CONF, "a"))==NULL)
        {
            printf("Couldnt open exports file here: %s\n", NFSD_CONF);
            return;
        }
        fputs(dir, fp);
        fclose(fp);
        dir_found = 1;
    }

    /* Add client and options */
    if((fp=fopen(NFSD_CONF, "r"))==NULL)
    {
        printf("Could not open exports file here: %s\n", NFSD_CONF);
        return;
    }
    fseek(fp, 0, SEEK_END);
    file_size = ftell(fp);
    rewind(fp);

    line = allocate(file_size+1);
    new_conf = allocate(file_size+1024);

    if( file_size > 1 )
    while(fgets(line, file_size, fp)!=NULL)
    {
	if( strstr(line, dir) ) //&& ! commented(line) )
	{
	    strcat(new_conf, line);

            if( new_conf[strlen(new_conf)-1]=='\n'  )
                new_conf[strlen(new_conf)-1]='\0';

	    strcat(new_conf, " ");
	    strcat(new_conf, range_from); // ip
	    strcat(new_conf, "(");
	    strcat(new_conf, range_to);   // (opts)
	    strcat(new_conf, ")");
	    strcat(new_conf, "\n");
	    client_added = 1;
	}
	else
	  strcat(new_conf, line);
    }
    fclose(fp);
    free(line);

    if( client_added )
    {
	if((fp=fopen(NFSD_CONF, "w+"))==NULL)
	{
    	    printf("Could not write exports file here: %s\n", NFSD_CONF);
	    free(new_conf);
    	    return;
	}
        fputs(new_conf, fp);
	fclose(fp);
    }
    free(new_conf);

    if( client_added )
    {
	clear_ptr_array(widgets);
	set_num_clients();
	populate_clients(widgets, global_nic, global_subnet, global_netmask);
	reread_conf();
    }
    else
    {
        info = g_strdup_printf(_("The client was not added.\n"));
        show_info(info);
        g_free(info);
    }
}
