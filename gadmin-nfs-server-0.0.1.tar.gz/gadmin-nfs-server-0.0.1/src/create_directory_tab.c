/* GADMIN-NFS-SERVER - An easy to use GTK+ frontend for the NFS server.
 * Copyright (C) 2014 - 2014 Magnus Loef <magnus-swe@telia.com> 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
*/



#include <gtk/gtk.h>
#include <stdio.h>
#include <string.h>
#include "widgets.h"
#include "gettext.h"

/* Wether or not to let the directory section expand */
#define EXPAND_SCOPE_SECTION TRUE

/* Wether or not to let the client section expand */
#define EXPAND_RANGE_SECTION TRUE

#include "dir_treeview_row_clicked.h"
#include "add_directory.h"
#include "delete_dir_from_btn.h"
#include "apply_directory_settings.h"


void create_directory_tab(struct w *widgets)
{
    GtkCellRenderer *scope_cell_renderer;
    GtkWidget *treeview_vbox;
    GtkWidget *scrolled_window;

    /* Create the scopes treeview in a scrolled window */
    treeview_vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);

    /* Add the scope treeview to the first stretchable vpaned widget */
    GtkWidget *vpaned = gtk_paned_new(GTK_ORIENTATION_VERTICAL);
    gtk_paned_pack1(GTK_PANED(vpaned), treeview_vbox, 1, 1);
    gtk_box_pack_start(GTK_BOX(widgets->notebook_vbox1), vpaned, EXPAND_SCOPE_SECTION, TRUE, 0);

    scrolled_window = gtk_scrolled_window_new(NULL, NULL);
    gtk_box_pack_start(GTK_BOX(treeview_vbox), scrolled_window, TRUE, TRUE, 0);
    gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scrolled_window),
                                                   GTK_POLICY_AUTOMATIC,
                                                       GTK_POLICY_ALWAYS);
    /* Set scrolled window size */

    //GtkRequisition directory_req;
    //gtk_widget_get_preferred_size(scrolled_window, &directory_req, &directory_req);
    //gtk_widget_set_size_request(GTK_WIDGET(scrolled_window), directory_req.width, directory_req.height);
    gtk_widget_set_size_request(GTK_WIDGET(scrolled_window), -1, 10);


    widgets->scope_store = gtk_list_store_new(4, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

    widgets->scope_treeview = gtk_tree_view_new();
    gtk_tree_view_set_model(GTK_TREE_VIEW(widgets->scope_treeview), GTK_TREE_MODEL(widgets->scope_store));

    gtk_container_add(GTK_CONTAINER(scrolled_window), widgets->scope_treeview);
    gtk_tree_view_set_rules_hint(GTK_TREE_VIEW(widgets->scope_treeview), TRUE);

    /* Set the column labels in the treeview */
    scope_cell_renderer = gtk_cell_renderer_text_new();

    GtkTreeViewColumn *eth_col = gtk_tree_view_column_new_with_attributes(_("Directory"), scope_cell_renderer, "text", 0, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(widgets->scope_treeview), GTK_TREE_VIEW_COLUMN(eth_col));

    /* Make the treeview sortable */
    gtk_tree_view_column_set_sort_column_id(GTK_TREE_VIEW_COLUMN(eth_col), 0);

    g_signal_connect((gpointer)widgets->scope_treeview, "button_press_event",
                                G_CALLBACK(dir_treeview_row_clicked), widgets);

    g_signal_connect(GTK_WINDOW(widgets->main_window), "delete_event",
                                       G_CALLBACK(gtk_main_quit), NULL);

    /* The add directory entries and: add, delete and apply buttons */
    GtkWidget *add_del_hbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
    gtk_box_pack_start(GTK_BOX(treeview_vbox), add_del_hbox, FALSE, FALSE, 0);

    /* Directory entry */
    widgets->add_directory_entry = gtk_entry_new();
    gtk_box_pack_start(GTK_BOX(add_del_hbox), widgets->add_directory_entry, TRUE, TRUE, 0);
    gtk_widget_set_size_request(widgets->add_directory_entry, -1, -1);
    gtk_widget_set_tooltip_text(GTK_WIDGET(widgets->add_directory_entry), "/var/www/html");

    /* A hbutton box for the add and delete directory buttons */
    GtkWidget *dir_hbuttonbox = gtk_button_box_new(GTK_ORIENTATION_HORIZONTAL);
    gtk_box_pack_start(GTK_BOX(add_del_hbox), dir_hbuttonbox, FALSE, FALSE, 0);
    gtk_button_box_set_layout(GTK_BUTTON_BOX(dir_hbuttonbox), GTK_BUTTONBOX_SPREAD);

    /* The add directory button */
    GtkWidget *add_dir_button = gtk_button_new_from_icon_name("list-add", GTK_ICON_SIZE_BUTTON);
    g_signal_connect_swapped(G_OBJECT(add_dir_button), "clicked",
                             G_CALLBACK(add_directory), widgets);
    gtk_widget_set_tooltip_text(GTK_WIDGET(widgets->add_directory_entry), _("Add a new directory"));
    gtk_container_add(GTK_CONTAINER(dir_hbuttonbox), add_dir_button);

    /* The delete directory button */
    GtkWidget *del_dir_button = gtk_button_new_from_icon_name("list-remove", GTK_ICON_SIZE_BUTTON);
    g_signal_connect_swapped(G_OBJECT(del_dir_button), "clicked",
                             G_CALLBACK(delete_dir_from_btn), widgets);
    gtk_widget_set_tooltip_text(GTK_WIDGET(widgets->add_directory_entry), _("Delete the selected directory"));
    gtk_container_add(GTK_CONTAINER(dir_hbuttonbox), del_dir_button);

    /* Apply button */
    GtkWidget *apply_dir_button = gtk_button_new_from_icon_name("list-apply", GTK_ICON_SIZE_BUTTON);
    gtk_container_add(GTK_CONTAINER(dir_hbuttonbox), apply_dir_button);
    g_signal_connect_swapped(G_OBJECT(apply_dir_button), "clicked",
                                     G_CALLBACK(apply_directory_settings), widgets);

    /* A spacer at the end */
    GtkWidget *scope_spacer_label_del2 = gtk_label_new("");
    gtk_box_pack_start(GTK_BOX(add_del_hbox), scope_spacer_label_del2, FALSE, FALSE, 9);

    /* Client settings */
    widgets->range_vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);


    /* Add the client settings to the second stretchable vpaned widget */
    gtk_paned_pack2(GTK_PANED(vpaned), widgets->range_vbox, 1, 1);

    GtkWidget *scrolled_range_window = gtk_scrolled_window_new(NULL, NULL);
    gtk_box_pack_start(GTK_BOX(widgets->range_vbox), scrolled_range_window, TRUE, TRUE, 0);

    gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scrolled_range_window), GTK_POLICY_NEVER, GTK_POLICY_ALWAYS);

    widgets->range_viewport = gtk_viewport_new(NULL, NULL);
    gtk_container_add(GTK_CONTAINER(scrolled_range_window), widgets->range_viewport);

    /* Set clients scrolled window vertical size */
    gtk_widget_set_size_request(GTK_WIDGET(scrolled_range_window), -1, 90);

    /* So it can be destroyed initially */
    widgets->range_scrolled_vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
}
