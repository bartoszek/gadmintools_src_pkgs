/*
 * Admin-Packages - A Package manager for sources.
 * Copyright (C) 2009 - 2011 Magnus Loef <magnus-swe@telia.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307, USA.
 *
 */


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "allocate.h"
#include "package_in_conf.h"
#include "globals.h"

extern char pkgconf_temp[MAX_TEMP_PATH];


int package_in_local_conf(char *package)
{
    FILE *fp;
    char *line, *tmp_package;
    int found=0;
    long file_size=0;

    if((fp=fopen(PACKAGES_CONF, "r"))==NULL)
    {
        /* No packages has been installed yet */
        return 0;
    }
    fseek(fp, 0, SEEK_END);
    file_size=ftell(fp);
    rewind(fp);

    line = allocate(file_size);

    tmp_package = allocate(MAX_REQUIRE_LEN);

    sprintf(tmp_package, "<%s>\n", package);

    if( file_size > 1 )
    while(fgets(line, file_size, fp)!=NULL)
    {
        /* Is this an exact package name match */
        if( strcmp(line, tmp_package) == 0 )
            found = 1;

        if( found )
            break;
    }
    fclose(fp);
    free(line);
    free(tmp_package);

    return found;
}

int package_in_tmp_conf(char *package)
{
    FILE *fp;
    char *line, *tmp_package;
    int found=0;
    long file_size=0;

    if((fp=fopen(pkgconf_temp, "r"))==NULL)
    {
        /* No packages has been installed yet */
        return 0;
    }
    fseek(fp, 0, SEEK_END);
    file_size=ftell(fp);
    rewind(fp);

    line = allocate(file_size);

    tmp_package = allocate(MAX_REQUIRE_LEN);

    sprintf(tmp_package, "<%s>\n", package);

    if( file_size > 1 )
    while(fgets(line, file_size, fp)!=NULL)
    {
        /* Is this an exact package name match */
        if( strcmp(line, tmp_package) == 0 )
            found = 1;

        if( found )
            break;
    }
    fclose(fp);
    free(line);
    free(tmp_package);

    return found;
}
