

#ifndef QUEUE_PACKAGE_H
#define QUEUE_PACKAGE_H

int queue_package_for_install(char *package);

int queue_package_for_uninstall(char *package);

#endif

