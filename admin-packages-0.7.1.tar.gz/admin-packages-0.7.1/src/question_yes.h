
#ifndef QUESTION_YES_H
#define QUESTION_YES_H

int question_yes();

#endif
