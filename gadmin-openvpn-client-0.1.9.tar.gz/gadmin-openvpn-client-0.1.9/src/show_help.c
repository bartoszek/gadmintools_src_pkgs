/* GAdmin-OpenVPN - An easy to use GTK+ frontend for the openvpn client.
 * Copyright (C) 2008 - 2012 Magnus Loef <magnus-swe@telia.com> 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
*/


#include <gtk/gtk.h>
#include "../config.h"
#include "support.h"
#include "gettext.h"
#include "widgets.h"



void show_help()
{
  gchar *help_text; 
  GtkWidget *help_window, *vbox15, *scrolledwindow16;
  GtkWidget *help_textview, *close_help_button;
  GtkWidget *alignment19, *hbox52, *image19, *label109;

  help_window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_widget_set_name(help_window, "help_window");
  gtk_widget_set_size_request(help_window, 650, 350);
  gtk_window_set_title(GTK_WINDOW (help_window), _("GADMIN-OpenVPN help"));
  gtk_window_set_position(GTK_WINDOW (help_window), GTK_WIN_POS_CENTER);

  vbox15 = gtk_vbox_new(FALSE, 0);
  gtk_widget_set_name(vbox15, "vbox15");
  gtk_widget_show(vbox15);
  gtk_container_add(GTK_CONTAINER(help_window), vbox15);

  scrolledwindow16 = gtk_scrolled_window_new(NULL, NULL);
  gtk_widget_set_name(scrolledwindow16, "scrolledwindow16");
  gtk_widget_show(scrolledwindow16);
  gtk_box_pack_start(GTK_BOX(vbox15), scrolledwindow16, TRUE, TRUE, 0);
  gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scrolledwindow16), GTK_POLICY_AUTOMATIC, GTK_POLICY_ALWAYS);

  help_textview = gtk_text_view_new();
  gtk_widget_set_name(help_textview, "help_textview");
  gtk_widget_show(help_textview);
  gtk_container_add(GTK_CONTAINER(scrolledwindow16), help_textview);
  gtk_text_view_set_editable(GTK_TEXT_VIEW(help_textview), FALSE);
  gtk_text_view_set_cursor_visible(GTK_TEXT_VIEW(help_textview), FALSE);
  gtk_text_view_set_left_margin(GTK_TEXT_VIEW(help_textview), 30);
  gtk_text_view_set_right_margin(GTK_TEXT_VIEW(help_textview), 10);

  help_text = g_strconcat(

  _("\n\nGAdmin-OpenVPN-Client Setup:\n\n"),


  _("\nImporting a VPN connection package:\n\n"),
  _("Click the import button and then the import package button\n"),
  _("to import a setup package that was previously exported from\n"),
  _("gadmin-openvpn-server. These packages includes everything\n"),
  _("required to automatically setup a VPN-connection.\n\n"),
  
  _("\nImporting a VPN configuration file:\n\n"),
  _("Click the import button and then the import configuration file\n"),
  _("button to import a connection configuration file and then\n"),
  _("add certificates and keys with the certificate and key\n"),
  _("selection buttons in the connections tab.\n\n"),

  _("If user authentication is required by the server you write\n"),
  _("a username and password and then press the apply button.\n\n"),

  _("After pressing the apply button you are ready to connect\n"),
  _("to the remote VPN network with the activate button.\n\n"),


  _("\nCertificates and authentication:\n\n"),

  _("You can increase security by supplying a different path for\n"),
  _("the location of the password file if you use authentication.\n"),
  _("You can set this path in the passfile entry. This path can also\n"),
  _("be set to an external media, such as an usb stick.\n\n"),

  _("This VPN-client can also be set to connect when the computer starts.\n\n"),

  _("For more detailed information about OpenVPN and its configuration visit:\n"),
  _("http://www.openvpn.net\n"), NULL);
  gtk_text_buffer_set_text(gtk_text_view_get_buffer(GTK_TEXT_VIEW(help_textview)), help_text, -1);

  if( help_text!=NULL )
    g_free(help_text);

  close_help_button = gtk_button_new();
  gtk_widget_set_name(close_help_button, "close_help_button");
  gtk_widget_show(close_help_button);
  gtk_box_pack_start(GTK_BOX(vbox15), close_help_button, FALSE, FALSE, 0);

  alignment19 = gtk_alignment_new(0.5, 0.5, 0, 0);
  gtk_widget_set_name(alignment19, "alignment19");
  gtk_widget_show(alignment19);
  gtk_container_add(GTK_CONTAINER(close_help_button), alignment19);

  hbox52 = gtk_hbox_new(FALSE, 2);
  gtk_widget_set_name(hbox52, "hbox52");
  gtk_widget_show(hbox52);
  gtk_container_add(GTK_CONTAINER(alignment19), hbox52);

  image19 = gtk_image_new_from_stock("gtk-close", GTK_ICON_SIZE_BUTTON);
  gtk_widget_set_name(image19, "image19");
  gtk_widget_show(image19);
  gtk_box_pack_start(GTK_BOX(hbox52), image19, FALSE, FALSE, 0);

  label109 = gtk_label_new_with_mnemonic(_("Close"));
  gtk_widget_set_name(label109, "label109");
  gtk_widget_show(label109);
  gtk_box_pack_start(GTK_BOX (hbox52), label109, FALSE, FALSE, 0);
  gtk_label_set_justify(GTK_LABEL(label109), GTK_JUSTIFY_LEFT);

  g_signal_connect_swapped(close_help_button, "clicked",
                           G_CALLBACK(gtk_widget_destroy),
                           GTK_OBJECT(help_window));

  gtk_widget_show_all(help_window);
}
