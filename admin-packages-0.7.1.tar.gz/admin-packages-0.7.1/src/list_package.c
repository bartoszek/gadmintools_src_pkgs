/*
 * Admin-Packages - A Package manager for sources.
 * Copyright (C) 2009 - 2011 Magnus Loef <magnus-swe@telia.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307, USA.
 *
 */


#include "../config.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "globals.h"
#include "allocate.h"


/* List all files installed by a package */
void list_package(char *package)
{
    FILE *fp;
    long file_size=0;
    char *line, *filepath;

    if( package == NULL )
    {
        printf("Error, package is zero in length\n");
        return;
    }
    if( strlen(package) < 2 )
    {
        printf("Error, package length is less then 2\n");
        return;
    }

    filepath = allocate(strlen(INSTALLED_PATH)+MAX_PKG_LEN+1024);
    sprintf(filepath, "%s/%s", INSTALLED_PATH, package);
    if((fp=fopen(filepath, "r"))==NULL)
    {
        printf("The package has no install profile here: %s\n", filepath);
        free(filepath);
        return;
    }
    else
    {
        fseek(fp, 0, SEEK_END);
        file_size = ftell(fp);
        rewind(fp);

        line = allocate(file_size+3);

        if( file_size > 1 )
        while(fgets(line, file_size, fp)!=NULL)
        {
            if( line[strlen(line)-1]=='\n')
                line[strlen(line)-1]='\0';

            printf("%s\n", line);
        }
        fclose(fp);
        free(line);
    }
    free(filepath);
}
