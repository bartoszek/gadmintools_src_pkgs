/* GAdmin-Antivirus - An easy to use GTK+ frontend for clamav antivirus.
 * Copyright (C) 2010 - 2014 Magnus Loef <magnus-swe@telia.com> 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
*/


#include <gtk/gtk.h>
#include <stdio.h>
#include <string.h>
#include "widgets.h"
#include "gettext.h"
#include "functions.h"


void
create_progress_tab(struct w *widgets)
{
    /* Create the progress textview in a scrolled window */
    GtkWidget *progress_hbox[1], *progress_scrolled_window[1];
    GtkTreeViewColumn *virpath_col;
    GtkTreeViewColumn *virtype_col;
    GtkCellRenderer *path_cell_renderer, *virus_cell_renderer;

    progress_hbox[0] = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
    gtk_box_pack_start(GTK_BOX(widgets->notebook_vbox2),
                         progress_hbox[0], TRUE, TRUE, 0);

    progress_scrolled_window[0] = gtk_scrolled_window_new(NULL, NULL);
    gtk_box_pack_start(GTK_BOX(progress_hbox[0]),
       progress_scrolled_window[0], TRUE, TRUE, 0);
    gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(progress_scrolled_window
                                [0]), GTK_POLICY_AUTOMATIC, GTK_POLICY_ALWAYS);
    /* Must set a larger size or it wont scroll */
    gtk_widget_set_size_request(progress_scrolled_window[0], -1, -1);

    widgets->progress_textview = gtk_text_view_new();
    gtk_container_add(GTK_CONTAINER(progress_scrolled_window[0]),
        widgets->progress_textview);

    /* The virus found treeview */
    progress_hbox[1] = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
    gtk_box_pack_start(GTK_BOX(widgets->notebook_vbox2),
                         progress_hbox[1], TRUE, TRUE, 0);

    progress_scrolled_window[1] = gtk_scrolled_window_new(NULL, NULL);
    gtk_box_pack_start(GTK_BOX(progress_hbox[1]), progress_scrolled_window[1],
        TRUE, TRUE, 0);
    gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(progress_scrolled_window
            [1]), GTK_POLICY_AUTOMATIC, GTK_POLICY_ALWAYS);
    gtk_widget_set_size_request(progress_scrolled_window[1], -1, -1);


    widgets->virus_treeview = gtk_tree_view_new();
    gtk_container_add(GTK_CONTAINER(progress_scrolled_window[1]),
        widgets->virus_treeview);

    widgets->virus_store = gtk_list_store_new(2, G_TYPE_STRING, G_TYPE_STRING);
    gtk_tree_view_set_model(GTK_TREE_VIEW(widgets->virus_treeview),
        GTK_TREE_MODEL(widgets->virus_store));

    path_cell_renderer = gtk_cell_renderer_text_new();
    virpath_col =
        gtk_tree_view_column_new_with_attributes(_("Detected viruses"),
        path_cell_renderer, "text", 0, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(widgets->virus_treeview),
        GTK_TREE_VIEW_COLUMN(virpath_col));

    virus_cell_renderer = gtk_cell_renderer_text_new();
    virtype_col =
        gtk_tree_view_column_new_with_attributes(_("Virus type"),
        virus_cell_renderer, "text", 1, NULL);
    gtk_tree_view_append_column(GTK_TREE_VIEW(widgets->virus_treeview),
        GTK_TREE_VIEW_COLUMN(virtype_col));

    /* Buttonbox and buttons for Quarantine and Delete */
    GtkWidget *hbuttonbox;
    hbuttonbox = gtk_button_box_new(GTK_ORIENTATION_HORIZONTAL);
    gtk_button_box_set_layout(GTK_BUTTON_BOX(hbuttonbox),GTK_BUTTONBOX_SPREAD);
    gtk_box_pack_start(GTK_BOX(widgets->notebook_vbox2), hbuttonbox, FALSE,
                                                                   FALSE, 0);

    /* Quarantine button */
    GtkWidget *quarantine_button = gtk_button_new();
    gtk_widget_set_tooltip_text(quarantine_button,
        _("Move this file to the quarantine."));
    GtkWidget *alignment = gtk_alignment_new(0.5, 0.5, 0, 0);
    gtk_container_add(GTK_CONTAINER(quarantine_button), alignment);
    GtkWidget *hbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
    gtk_container_add(GTK_CONTAINER(alignment), hbox);
    GtkWidget *image = gtk_image_new_from_icon_name("gtk-refresh",
                                          GTK_ICON_SIZE_BUTTON);
    gtk_box_pack_start(GTK_BOX(hbox), image, FALSE, FALSE, 0);

    GtkWidget *label = gtk_label_new_with_mnemonic(_("Move to quarantine"));
    gtk_box_pack_start(GTK_BOX(hbox), label, FALSE, FALSE, 0);
    gtk_label_set_justify(GTK_LABEL(label), GTK_JUSTIFY_LEFT);
    gtk_box_pack_start(GTK_BOX(hbuttonbox), quarantine_button, FALSE, FALSE, 0);
    /* Move to quarantine button signal hookup */
    g_signal_connect_swapped(quarantine_button, "clicked",
        G_CALLBACK(move_file_to_quarantine), widgets);

    /* Delete from system button */
    GtkWidget *delete_button = gtk_button_new();
    gtk_widget_set_tooltip_text(delete_button,
        _("Delete the selected virus file from the filesystem."));

    GtkWidget *alignment1 = gtk_alignment_new(0.5, 0.5, 0, 0);
    gtk_container_add(GTK_CONTAINER(delete_button), alignment1);
    GtkWidget *hbox1 = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
    gtk_container_add(GTK_CONTAINER(alignment1), hbox1);
    GtkWidget *image1 = gtk_image_new_from_icon_name("gtk-delete",
                                          GTK_ICON_SIZE_BUTTON);
    gtk_box_pack_start(GTK_BOX(hbox1), image1, FALSE, FALSE, 0);

    GtkWidget *label1 =
        gtk_label_new_with_mnemonic(_("Delete virus file from filesystem"));
    gtk_box_pack_start(GTK_BOX(hbox1), label1, FALSE, FALSE, 0);
    gtk_label_set_justify(GTK_LABEL(label1), GTK_JUSTIFY_LEFT);
    gtk_box_pack_start(GTK_BOX(hbuttonbox), delete_button, FALSE, FALSE, 0);
    /* Delete file from filesystem button signal hookup */
    g_signal_connect_swapped(delete_button, "clicked",
        G_CALLBACK(delete_file_from_system), widgets->virus_treeview);

    gtk_widget_show_all(widgets->main_window);
}
