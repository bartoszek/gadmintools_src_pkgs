/* GADMIN-CONTROL-PANEL - a GTK+ control panel for GAdmintools.
 * Copyright (C) 2010 - 2014 Magnus Loef <magnus-swe@telia.com> 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
*/


#include "../config.h"
#include <gtk/gtk.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include "interface.h"
#include "credits_window.h"
#include "show_info.h"
#include "support.h"

#define MAX_APPS 20


int file_exists(gchar *infile)
{
    FILE *fp;

    if((fp=fopen(infile, "r"))==NULL)
      return 0;

    fclose(fp);
    return 1;
}


int run_command(gchar *cmd)
{
    FILE *fp;
    int success = 0;

    if((fp=popen(cmd, "w"))==NULL)
    {
        perror("Command");
    }
    else
      {
         success = 1;
         pclose(fp);
      }

    return success;
}


void start_program(gchar *progname)
{
    gchar *cmd, *info;

    if( strcmp(progname, "proftpd") == 0  )
      cmd = g_strdup_printf("%s/gadmin-proftpd &", SBINDIR);
    else
    if( strcmp(progname, "dhcpd") == 0  )
      cmd = g_strdup_printf("%s/gadmin-dhcpd &", SBINDIR);
    else
    if( strcmp(progname, "bind") == 0  )
      cmd = g_strdup_printf("%s/gadmin-bind &", SBINDIR);
    else
    if( strcmp(progname, "squid") == 0  )
      cmd = g_strdup_printf("%s/gadmin-squid &", SBINDIR);
    else
    if( strcmp(progname, "samba") == 0  )
      cmd = g_strdup_printf("%s/gadmin-samba &", SBINDIR);
    else
    if( strcmp(progname, "httpd") == 0  )
      cmd = g_strdup_printf("%s/gadmin-httpd &", SBINDIR);
    else
    if( strcmp(progname, "rsync") == 0  )
      cmd = g_strdup_printf("%s/gadmin-rsync &", SBINDIR);
    else
    if( strcmp(progname, "openvpn-client") == 0  )
      cmd = g_strdup_printf("%s/gadmin-openvpn-client &", SBINDIR);
    else
    if( strcmp(progname, "openvpn-server") == 0  )
      cmd = g_strdup_printf("%s/gadmin-openvpn-server &", SBINDIR);
    else
    if( strcmp(progname, "sshd") == 0  )
      cmd = g_strdup_printf("%s/gadmin-sshd &", SBINDIR);
    else
    if( strcmp(progname, "antivirus") == 0  )
      cmd = g_strdup_printf("%s/gadmin-antivirus &", SBINDIR);
    else
    if( strcmp(progname, "torque-cluster") == 0  )
      cmd = g_strdup_printf("%s/gadmin-torque-cluster &", SBINDIR);
    else
    if( strcmp(progname, "sendmail") == 0  )
      cmd = g_strdup_printf("%s/gadmin-sendmail &", SBINDIR);
    else
    if( strcmp(progname, "nfs-server") == 0  )
      cmd = g_strdup_printf("%s/gadmin-nfs-server &", SBINDIR);
    else
      cmd = g_strdup_printf("Nothing_selected");

    if( ! run_command(cmd) )
    {
        info = g_strdup_printf(_("Failed to start the program with:\n%s\n"), cmd);
        show_info(info);
        g_free(info);
    }
    g_free(cmd);
}


GtkWidget * make_scaled_image(int width, int height, gboolean keep_ratio,
                                          gchar *dirpath, gchar *filename)
{
    GtkWidget *image;
    GdkPixbuf *pbuf;
    gchar *filepath;
    GError *error = NULL;

    /* Support png and xpm files */
    filepath = g_strdup_printf("%s/%s.png", dirpath, filename);

    if( ! file_exists(filepath) )
    {
        if( filepath!=NULL )
            g_free(filepath);
        filepath = g_strdup_printf("%s/%s.xpm", dirpath, filename);
    }

    pbuf = gdk_pixbuf_new_from_file_at_scale(filepath,
    width, height, keep_ratio, &error);

    if( !pbuf )
      printf("File loading error: [%s] not found.\n", filepath);


    image = gtk_image_new_from_pixbuf(pbuf);

    return image;
}


GtkWidget * append_button_with_scaled_image(GtkWidget *buttonA, GtkWidget *button_hboxA,
                         GtkWidget *alignmentA, GtkWidget *hboxA,
                         GtkWidget *labelA, GtkWidget *imageA,
                         gchar *imagefile, gchar *label_text)
{
    buttonA = gtk_button_new();
    gtk_box_pack_start(GTK_BOX(button_hboxA), buttonA, FALSE, FALSE, 0);

    alignmentA = gtk_alignment_new(0.0, 0.0, 0, 0);
    gtk_container_add(GTK_CONTAINER(buttonA), alignmentA);

    hboxA = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
    gtk_container_add(GTK_CONTAINER(alignmentA), hboxA);

    imageA = make_scaled_image(60, 60, TRUE, PIXMAPS_DIRECTORY, imagefile);
    gtk_box_pack_start(GTK_BOX(hboxA), imageA, FALSE, FALSE, 0);

    labelA = gtk_label_new_with_mnemonic(label_text);
    gtk_box_pack_start(GTK_BOX(hboxA), labelA, FALSE, FALSE, 0);

    return buttonA;
}


GtkWidget *create_main_window(void)
{
    GtkWidget *main_window, *main_vbox;
    GtkWidget *main_hbox, *main_image;
    GtkWidget *spacer_label, *hbuttonbox1;
    GtkWidget *about_button, *quit_button;
    GtkWidget *button_hbox[MAX_APPS];
    GtkWidget *alignment[MAX_APPS];
    GtkWidget *hbox[MAX_APPS];
    GtkWidget *image[MAX_APPS];
    GtkWidget *label[MAX_APPS];
    GtkWidget *button[MAX_APPS];
    int i=0, x=0, row_number=0;
    gchar *path;
    GtkRequisition min_size, natural_size;
    GtkRequisition max_size;
    min_size.width = 0;
    max_size.width = 0;

    /* Initialize the widget arrays */
    for(x=0; x<MAX_APPS; x++)
    {
        button_hbox[x]=NULL;
        alignment[x]=NULL;
        hbox[x]=NULL;
        image[x]=NULL;
        label[x]=NULL;
        button[x]=NULL;
    }

    /* The main window */
    main_window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(main_window), _("GAdmin-Control-Panel"));
    gtk_window_set_destroy_with_parent(GTK_WINDOW(main_window), TRUE);
    gtk_window_set_position(GTK_WINDOW(main_window), GTK_WIN_POS_CENTER);

    /* Main vbox */
    main_vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);
    gtk_container_add(GTK_CONTAINER(main_window), main_vbox);

    /* Main hbox for the gadmintools image */
    main_hbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
    gtk_box_pack_start(GTK_BOX(main_vbox), main_hbox, FALSE, TRUE, 0);

    /* Append buttons with scaled images for installed programs */
    for(i=0; i<MAX_APPS; i++)
    {
        /* Add an initial button row */
        if( i == 0 )
        {
            button_hbox[row_number] = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
            gtk_box_pack_start(GTK_BOX(main_vbox), button_hbox[row_number], FALSE, FALSE, 0);
        }

        /* Add new button rows when they are full */
        if( i == 4 || i == 8 || i == 12 )
        {
            row_number++;
            button_hbox[row_number] = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
            gtk_box_pack_start(GTK_BOX(main_vbox), button_hbox[row_number], FALSE, FALSE, 0);
        }

        /* gadmin-proftpd.png -> gadmin-proftpd.
           .png or .xpm is added based on what icons exist. .png is preferred */
        path = g_strdup_printf("%s/gadmin-proftpd", SBINDIR);
        if( i == 0 && file_exists(path) )
        {
            button[i] = append_button_with_scaled_image(button[i], button_hbox[row_number],
                        alignment[i], hbox[i], label[i], image[i],
                        "gadmin-proftpd", _("FTP Server"));
            g_signal_connect_swapped(G_OBJECT(button[i]), "clicked",
                                G_CALLBACK(start_program), "proftpd");
            continue;
        }

        path = g_strdup_printf("%s/gadmin-dhcpd", SBINDIR);
        if( i == 1 && file_exists(path) )
        {
            button[i] = append_button_with_scaled_image(button[i], button_hbox[row_number],
                        alignment[i], hbox[i], label[i], image[i],
                        "gadmin-dhcpd", _("DHCP Server"));
            g_signal_connect_swapped(G_OBJECT(button[i]), "clicked",
                                  G_CALLBACK(start_program), "dhcpd");
            continue;
        }

        path = g_strdup_printf("%s/gadmin-bind", SBINDIR);
        if( i == 2 && file_exists(path) )
        {
            button[i] = append_button_with_scaled_image(button[i], button_hbox[row_number],
            alignment[i], hbox[i], label[i], image[i],
            "gadmin-bind", _("DNS Server"));
            g_signal_connect_swapped(G_OBJECT(button[i]), "clicked",
                                    G_CALLBACK(start_program), "bind");
            continue;
        }

        path = g_strdup_printf("%s/gadmin-squid", SBINDIR);
        if( i == 3 && file_exists(path) )
        {
            button[i] = append_button_with_scaled_image(button[i], button_hbox[row_number],
            alignment[i], hbox[i], label[i], image[i],
            "gadmin-squid", _("Proxy Server"));
            g_signal_connect_swapped(G_OBJECT(button[i]), "clicked",
                                    G_CALLBACK(start_program), "squid");
            continue;
        }

        path = g_strdup_printf("%s/gadmin-samba", SBINDIR);
        if( i == 4 && file_exists(path) )
        {
            button[i] = append_button_with_scaled_image(button[i], button_hbox[row_number],
                        alignment[i], hbox[i], label[i], image[i],
                        "gadmin-samba", _("Samba Server"));
            g_signal_connect_swapped(G_OBJECT(button[i]), "clicked",
                                  G_CALLBACK(start_program), "samba");
            continue;
        }

        path = g_strdup_printf("%s/gadmin-httpd", SBINDIR);
        if( i == 5 && file_exists(path) )
        {
            button[i] = append_button_with_scaled_image(button[i], button_hbox[row_number],
                        alignment[i], hbox[i], label[i], image[i],
                        "gadmin-httpd", _("Web Server"));
            g_signal_connect_swapped(G_OBJECT(button[i]), "clicked",
                                  G_CALLBACK(start_program), "httpd");
            continue;
        }

        path = g_strdup_printf("%s/gadmin-rsync", SBINDIR);
        if( i == 6 && file_exists(path) )
        {
            button[i] = append_button_with_scaled_image(button[i], button_hbox[row_number],
            alignment[i], hbox[i], label[i], image[i],
            "gadmin-rsync", _("Backups"));
            g_signal_connect_swapped(G_OBJECT(button[i]), "clicked",
                                  G_CALLBACK(start_program), "rsync");
            continue;
        }

        path = g_strdup_printf("%s/gadmin-openvpn-client", SBINDIR);
        if( i == 7 && file_exists(path) )
        {
            button[i] = append_button_with_scaled_image(button[i], button_hbox[row_number],
                        alignment[i], hbox[i], label[i], image[i],
                        "gadmin-openvpn-client", _("VPN Client"));
            g_signal_connect_swapped(G_OBJECT(button[i]), "clicked",
                         G_CALLBACK(start_program), "openvpn-client");
            continue;
        }

        path = g_strdup_printf("%s/gadmin-openvpn-server", SBINDIR);
        if( i == 8 && file_exists(path) )
        {
            button[i] = append_button_with_scaled_image(button[i], button_hbox[row_number],
                        alignment[i], hbox[i], label[i], image[i],
                        "gadmin-openvpn-server", _("VPN Server"));
            g_signal_connect_swapped(G_OBJECT(button[i]), "clicked",
                         G_CALLBACK(start_program), "openvpn-server");
            continue;
        }

        path = g_strdup_printf("%s/gadmin-sshd", SBINDIR);
        if( i == 9 && file_exists(path) )
        {
            button[i] = append_button_with_scaled_image(button[i], button_hbox[row_number],
                        alignment[i], hbox[i], label[i], image[i],
                        "gadmin-sshd", _("SSH Server"));
            g_signal_connect_swapped(G_OBJECT(button[i]), "clicked",
                                    G_CALLBACK(start_program), "sshd");
            continue;
        }

        path = g_strdup_printf("%s/gadmin-antivirus", SBINDIR);
        if( i == 10 && file_exists(path) )
        {
            button[i] = append_button_with_scaled_image(button[i], button_hbox[row_number],
                    alignment[i], hbox[i], label[i], image[i],
                    "gadmin-antivirus", _("Antivirus"));
            g_signal_connect_swapped(G_OBJECT(button[i]), "clicked",
                              G_CALLBACK(start_program), "antivirus");
            continue;
        }

        path = g_strdup_printf("%s/gadmin-torque-cluster", SBINDIR);
        if( i == 11 && file_exists(path) )
        {
            button[i] = append_button_with_scaled_image(button[i], button_hbox[row_number],
                        alignment[i], hbox[i], label[i], image[i],
                        "gadmin-torque-cluster", _("Torque Cluster"));
            g_signal_connect_swapped(G_OBJECT(button[i]), "clicked",
                              G_CALLBACK(start_program), "torque-cluster");
            continue;
        }

        path = g_strdup_printf("%s/gadmin-sendmail", SBINDIR);
        if( i == 12 && file_exists(path) )
        {
            button[i] = append_button_with_scaled_image(button[i], button_hbox[row_number],
                        alignment[i], hbox[i], label[i], image[i],
                        "gadmin-sendmail", _("Sendmail Server"));
            g_signal_connect_swapped(G_OBJECT(button[i]), "clicked",
                              G_CALLBACK(start_program), "sendmail");
            continue;
        }

        path = g_strdup_printf("%s/gadmin-nfs-server", SBINDIR);
        if( i == 13 && file_exists(path) )
        {
            button[i] = append_button_with_scaled_image(button[i], button_hbox[row_number],
                          alignment[i], hbox[i], label[i], image[i],
                          "gadmin-nfs-server", _("NFS Server"));
            g_signal_connect_swapped(G_OBJECT(button[i]), "clicked",
                              G_CALLBACK(start_program), "nfs-server");
            continue;
        }
    }
    g_free(path);


    /* A spacer label above the quit button */
    spacer_label = gtk_label_new("");
    gtk_box_pack_start(GTK_BOX(main_vbox), spacer_label, TRUE, TRUE, 0);
    gtk_misc_set_padding(GTK_MISC(spacer_label), 0, 5);

    hbuttonbox1 = gtk_button_box_new(GTK_ORIENTATION_HORIZONTAL);
    gtk_button_box_set_layout(GTK_BUTTON_BOX(hbuttonbox1), GTK_BUTTONBOX_SPREAD);
    gtk_box_pack_start(GTK_BOX(main_vbox), hbuttonbox1, FALSE, FALSE, 0);

    /* The about button and signal */
    about_button = gtk_button_new_from_icon_name("gtk-about", GTK_ICON_SIZE_BUTTON);
    gtk_container_add(GTK_CONTAINER(hbuttonbox1), about_button);
    g_signal_connect(G_OBJECT(about_button), "clicked",
                       G_CALLBACK(show_credits), NULL);

    /* The quit button and signal */
    quit_button = gtk_button_new_from_icon_name("gtk-quit", GTK_ICON_SIZE_BUTTON);
    gtk_container_add(GTK_CONTAINER(hbuttonbox1), quit_button);
    g_signal_connect(G_OBJECT(quit_button), "clicked",
                       G_CALLBACK(gtk_main_quit), NULL);

    gtk_widget_show_all(main_window);

    /* Make the buttons equally wide.
       They must be initialized and shown first or they wont expand */
    for(x=0; x<MAX_APPS; x++)
    {
        if( ! GTK_IS_BUTTON(button[x]) )
            continue;

        /* Get the largest button width */
        gtk_widget_get_preferred_size(GTK_WIDGET(button[x]), &min_size, &natural_size);

        if( min_size.width > max_size.width )
        {
            max_size.width = min_size.width;
        }
    }
    /* Make all buttons use the new max width */
    for(x=0; x<MAX_APPS; x++)
    {
        if( ! GTK_IS_BUTTON(button[x]) )
            continue;

        gtk_widget_set_size_request(GTK_WIDGET(button[x]), max_size.width, -1);
    }

    /* Adjust for when no application images are found. */
    if( max_size.width == 0 )
      max_size.width = 100;

    /* Add and make the main image as wide as 4 of the buttons in a row */
    main_image = make_scaled_image(max_size.width*4, -1, TRUE,
                PIXMAPS_DIRECTORY, "gadmin-control-panel");
    gtk_box_pack_start(GTK_BOX(main_hbox), main_image, FALSE, FALSE, 0);

    gtk_widget_show(main_image);

    return main_window;
}
