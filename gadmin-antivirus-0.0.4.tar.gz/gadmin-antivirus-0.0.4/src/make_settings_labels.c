/* GAdmin-Antivirus - An easy to use GTK+ frontend for clamav antivirus.
 * Copyright (C) 2010 - 2014 Magnus Loef <magnus-swe@telia.com> 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
*/


#include <gtk/gtk.h>
#include "make_settings_labels.h"


void
make_3columns_label(GtkGrid *grid,
    const gchar * label_text,
    gint left_attach, gint top_attach, gint width_attach, gint height_attach)
{
    GtkWidget *label;

    label = gtk_label_new(label_text);

    gtk_grid_attach(grid, label, left_attach, top_attach, width_attach, height_attach);
    gtk_widget_show(label);
}


GtkWidget *
make_3columns_label_spin(GtkGrid *grid,
    const gchar * label_text,
    gint left_attach, gint top_attach, gint width_attach, gint height_attach)
{
    GtkWidget *hbox, *label, *padlabel;
    label = gtk_label_new(label_text);
    padlabel = gtk_label_new("\t");
    GtkWidget *checkbutton = gtk_check_button_new();

    hbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
    gtk_box_pack_start(GTK_BOX(hbox), label, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(hbox), checkbutton, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(hbox), padlabel, TRUE, TRUE, 0);

    gtk_grid_attach(grid, hbox, left_attach, top_attach, width_attach+1, height_attach);

//    gtk_grid_attach_next_to(grid, checkbutton, label, GTK_POS_RIGHT, 1, 1);
//    Checkbutton can be clicked outside its visible region, cant shrink it...

    gtk_widget_show(label);
    gtk_widget_show(padlabel);
    gtk_widget_show(checkbutton);

    return checkbutton;
}
