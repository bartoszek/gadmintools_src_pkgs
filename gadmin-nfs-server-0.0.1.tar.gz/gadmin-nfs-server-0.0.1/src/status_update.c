/* GADMIN-NFS-SERVER - An easy to use GTK+ frontend for the NFS server.
 * Copyright (C) 2014 - 2014 Magnus Loef <magnus-swe@telia.com> 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
*/



#include <gtk/gtk.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include "widgets.h"
#include "gettext.h"
#include "allocate.h"

extern int MAX_READ_POPEN;
extern int activated;


int status_update(struct w *widgets)
{
    FILE *fp;
    char *line;
    int found = 0;
    gchar *command;
    gchar *utf8=NULL;
    gchar *text;
    GdkRGBA color;

    command = g_strdup_printf("pidof nfsd >/dev/null; echo $?");
    if((fp=popen(command, "r"))==NULL)
    {
        text = g_strdup_printf(_("Status: Deactivated"));
        utf8 = g_locale_to_utf8(text, strlen(text), NULL, NULL, NULL);
        gtk_label_set_text(GTK_LABEL(widgets->onoff_label), utf8);
        g_free(utf8);
        g_free(text);
        activated = 0;

        /* Set status color */
        gdk_rgba_parse(&color, "red");
        gtk_widget_override_color(widgets->onoff_label, GTK_STATE_FLAG_NORMAL, &color);

        g_free(command);
        return FALSE;
    }
    g_free(command);

    line = allocate(MAX_READ_POPEN);
    while(fgets(line, MAX_READ_POPEN, fp)!=NULL)
    {
       if( strlen(line) < 30 && strstr(line, "0") ) // pidof result 0 = running
       {
          found = 1;
          break;
       }
    }
    pclose(fp);
    free(line);

    if( ! found )
    {
        text = g_strdup_printf(_("Status: Deactivated"));
        utf8 = g_locale_to_utf8(text, strlen(text), NULL, NULL, NULL);
        gtk_label_set_text(GTK_LABEL(widgets->onoff_label), utf8);
        g_free(utf8);
	g_free(text);
	activated = 0;

        /* Set status color */
        gdk_rgba_parse(&color, "red");
        gtk_widget_override_color(widgets->onoff_label, GTK_STATE_FLAG_NORMAL, &color);
    }
    else
    {
	text = g_strdup_printf(_("Status: Activated"));
	utf8 = g_locale_to_utf8(text, strlen(text), NULL, NULL, NULL);
	gtk_label_set_text(GTK_LABEL(widgets->onoff_label), utf8);
	g_free(utf8);
        g_free(text);
	activated = 1;

        /* Set status color */
        gdk_rgba_parse(&color, "green");
        gtk_widget_override_color(widgets->onoff_label, GTK_STATE_FLAG_NORMAL, &color);
    }

    return TRUE;
}
