/*
 * Admin-Packages - A Package manager for sources.
 * Copyright (C) 2009 - 2011 Magnus Loef <magnus-swe@telia.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307, USA.
 *
 */


#include "../config.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "allocate.h"
#include "globals.h"
#include "file_exists.h"
#include "get_package_info.h"
#include "run_command.h"

extern char build_directory[MAX_TEMP_PATH];
extern char global_newest_url[MAX_URL_LEN];
extern int  global_verbose;


/* Dont extract files that are called the same as or end with
   the following chars if they already exist on the system */
char *non_extractable_files[]={
".config"        ,".conf",
".cfg"           ,".cnf",
".allow"         ,".deny",
".types"         ,".users",
".bak"           ,".backup",
".rc"            ,".db",
"profile"        ,"passwd",
"group"          ,"shadow",
"gshadow"        ,"inittab",
"fstab"          ,"mtab",
"crontab"        ,"quotatab",
"quotagrpadmins" ,"ftpusers",
"printcap"       ,"shells",
"hosts"          ,"adjtime",
"services"       ,"sudoers",
"protocols"      ,"localtime",
"master.passwd"  ,".master",
"charset.alias",
NULL};

// NY charset.alias


int create_binary_package(char *package)
{
    FILE *fp1, *fp2;
    long file_size = 0;
    char *cmd, *binpath, *version, *arch;
    char *line, *script_file, *installed_file;
    int ret = 0;

    printf("Creating binary package: [%s]\n", package);

    /* Write a new "create binary script" with this content:
       tar --no-recursion -cjvpPf Archive_NAME.tar.gz (Space) */
    script_file = allocate(4096);
    sprintf(script_file, "%s/%s", build_directory, BINARY_SCRIPT_NAME);
    if((fp1=fopen(script_file, "w+"))==NULL)
    {
         printf("Error writing archive script file: %s\n", script_file);
         free(script_file);
         return ret;
    }
    /* 2 means get version from installed package. 1 means get it from the tmp packages.conf */
    version = get_version_from_package(2, package);
    cmd = allocate(strlen(package)+1024); /* There must be a space at the end below */
    if( global_verbose )
        sprintf(cmd, "tar --no-recursion -cjvpPf %s-%s.tar.bz2 ", package, version);
    else
        sprintf(cmd, "tar --no-recursion -cjpPf %s-%s.tar.bz2 ", package, version);
    fputs(cmd, fp1);
    free(cmd);
    free(version);

    /* Read the the install file in: INSTALLED_PATH/PACKAGE */
    installed_file = allocate(strlen(INSTALLED_PATH)+strlen(package)+2);
    sprintf(installed_file, "%s/%s", INSTALLED_PATH, package);

    /* Append install paths to the new create_binary script:
       /tmp/file1 /tmp/file2 /tmp/file3 /tmp/some_dir */
    if((fp2=fopen(installed_file, "r"))==NULL)
    {
        printf("Error reading: [%s]\nCan not create binary package.\n", installed_file);
        free(script_file);
        free(installed_file);
        return ret;
    }
    fseek(fp2, 0, SEEK_END);
    file_size = ftell(fp2);
    rewind(fp2);
    line = allocate(file_size+1);

    if( file_size > 1 )
    while(fgets(line, file_size, fp2)!=NULL)
    {
        if( line[strlen(line)-1]=='\n' )
            line[strlen(line)-1]='\0';

        fputs(line, fp1);
        fputs(" ", fp1);
    }
    fclose(fp1);
    fclose(fp2);
    free(installed_file);
    free(line);

    /* Run the create binary script */
    cmd = allocate(strlen(build_directory)+(strlen(BINARY_SCRIPT_NAME)*2)+100);
    if( global_verbose )
    {
        sprintf(cmd, "cd %s && chmod 755 %s && ./%s",
            build_directory, BINARY_SCRIPT_NAME, BINARY_SCRIPT_NAME);
    }
    else
    {
        sprintf(cmd, "cd %s && chmod 755 %s && ./%s",
            build_directory, BINARY_SCRIPT_NAME, BINARY_SCRIPT_NAME);
    }

    if( ! run_command(cmd) )
        ret = 0;
    else
        ret = 1;

    free(cmd);
    free(script_file);

    /* Copy the resulting package to:
       REPO/stable/binary/ARCH/Package */
    arch = get_from_settings(":TMACRO-ARCH:");
    binpath = allocate(4096);

    /* A local repo is used from servers.conf */
    if( global_newest_url[0]=='/' )
        sprintf(binpath, "%s/binary/%s", global_newest_url, arch);
    else
        sprintf(binpath, "%s/stable/binary/%s", LOCAL_REPOSITORY_PATH, arch);

    free(arch);

    cmd = allocate(strlen(binpath)+10);
    sprintf(cmd, "mkdir -p %s", binpath);
    if( ! run_command(cmd) )
        ret = 0;
    else
        ret = 1;

    free(cmd);

    version = get_version_from_package(2, package);
    cmd = allocate(4096);
    sprintf(cmd, "mv %s/%s-%s.tar.bz2 %s", build_directory, package, version, binpath);
    free(version);

    if( ! run_command(cmd) )
        ret = 0;
    else
        ret = 1;

    if( ret == 1 )
        printf("The binary package was added here:\n[%s]\n", binpath);

    free(cmd);
    free(binpath);

    return ret;
}


int install_binary_package(char *package)
{
    FILE *fp;
    long x = 0, file_size = 0;
    char *line, *tmp_line, *cmd, *version;
    char *binpath, *file_path, *arch, *extract_list;
    int i = 0, dont_extract = 0, ret = 0;

    arch = get_from_settings(":TMACRO-ARCH:");
    binpath = allocate(2048);

    /* A local repo is used from servers.conf */
    if( global_newest_url[0]=='/' )
        sprintf(binpath, "%s/binary/%s", global_newest_url, arch);
    else
        sprintf(binpath, "%s/stable/binary/%s", LOCAL_REPOSITORY_PATH, arch);

    free(arch);

    printf("Installing binary package: [%s]\n", package);

    version = get_version_from_package(2, package);

    /* Get a list of files in the archive and put the list as:
       /var/admin-packages/installed/PackageName */
    cmd = allocate(4096);
    sprintf(cmd, "tar --list --file %s/%s-%s.tar.bz2 > %s/%s", binpath, package, version, INSTALLED_PATH, package);
    if( ! run_command(cmd) )
    {
        printf("Error: Unable to get archive file listing.\n");
        free(binpath);
        free(version);
        free(cmd);
        return 0;
    }
    else
        ret = 1;

    free(cmd);

    /* Extract all files that dont match the non_extractable_files list:
       tar -zxf packagename-0.1.2.tar.gz '/path/.conf' '/path/.cfg' etc.
    */
    file_path = allocate(4096);
    sprintf(file_path, "%s/%s", INSTALLED_PATH, package);

    if((fp=fopen(file_path, "r"))==NULL)
    {
        printf("Error reading: [%s]\nCan not create binary package.\n", file_path);
        free(binpath);
        free(version);
        free(file_path);
        return 0;
    }
    fseek(fp, 0, SEEK_END);
    file_size = ftell(fp);
    rewind(fp);
    line = allocate(file_size+1);
    tmp_line = allocate(file_size+1);
    extract_list = allocate(file_size*2); /* calloc this instead to save some bytes */

    if( file_size > 1 )
    while(fgets(line, file_size, fp)!=NULL)
    {
        /* Get the last path element ".conf" etc */
        for(x=strlen(line)-1; line[x]!='\0'; x--)
        {
            if( line[x]=='/' || line[x]=='.' )
            {
                if( line[x]=='/' )
                    sprintf(tmp_line, "%s", &line[x+1]);
                else
                    sprintf(tmp_line, "%s", &line[x]);

                break;
            }
        }

        if( line[strlen(line)-1]=='\n' )
            line[strlen(line)-1]='\0';

        if( tmp_line[strlen(tmp_line)-1]=='\n' )
            tmp_line[strlen(tmp_line)-1]='\0';

        i = 0;
        while( non_extractable_files[i] != NULL )
        {
            dont_extract = 0;

            /* This file should not be extracted if it already exists on the system */
            if( strcmp(tmp_line, non_extractable_files[i]) == 0 )
            {
                if( file_exists(line) )
                {
                    dont_extract = 1;
                    break;
                }
            }
            i++;
        }

        if( dont_extract )
        {
            printf("\nNot extracting existing configuration file:\n[%s]\n", line);
            continue;
        }

        /* Make an extract_list */
        strcat(extract_list, " '");
        strcat(extract_list, line);
        strcat(extract_list, "' ");
    }
    fclose(fp);
    free(file_path);
    free(line);
    free(tmp_line);

    /* Run the extraction command. -U means unlink links first. */
    cmd = allocate(4096+strlen(extract_list));
    if( global_verbose )
        sprintf(cmd, "tar xfjpPUv %s/%s-%s.tar.bz2 %s", binpath, package, version, extract_list);
    else
        sprintf(cmd, "tar xfjpPUv %s/%s-%s.tar.bz2 %s", binpath, package, version, extract_list);

    printf("\nExracting binary archive...\n");
    if( ! run_command(cmd) )
        ret = 0;
    else
        ret = 1;

    free(cmd);
    free(extract_list);
    free(version);
    free(binpath);

    return ret;
}
