/*
 * Admin-Packages - A Package manager for sources.
 * Copyright (C) 2009 - 2011 Magnus Loef <magnus-swe@telia.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307, USA.
 *
 */


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include "allocate.h"
#include "globals.h"
#include "file_exists.h"
#include "run_command.h"
#include "make_lists.h"
#include "handle_dependencies.h"

extern char *rec_saver[MAX_NUM_OF_PACKAGES];
extern char package_queue[MAX_TEMP_PATH];


void make_install_list_from_package(char *package)
{
    int i=0;
    char *cmd;

    if( strlen(package) > MAX_PKG_LEN-1 )
    {
        printf("Error: package length > %d\n", MAX_PKG_LEN-1);
        return;
    }

    /* If the resolver fails there wont be an install.tmp */
    cmd = allocate(1024);
    snprintf(cmd, 1000, "touch %s", package_queue);
    if( ! run_command(cmd) )
        printf("Make install list: cant create install.temp\n");
    free(cmd);

    /* read_dependencies_recursively and put those 
       we need in a file in installation order */
    handle_install_dependencies(package);

    /* EOF after the progress meter started in handle_install_dependencies.c */
    printf("\n");

    /* Free the recorded packages in handle_install_dependencies(); */
    for(i=0; rec_saver[i]; i++)
    {
        free(rec_saver[i]);
        rec_saver[i] = NULL;
    }
}


void make_uninstall_list_from_package(char *package)
{
    int i=0;
    char *cmd;

    if( strlen(package) > MAX_PKG_LEN-1 )
    {
        printf("Error: package length > %d\n", MAX_PKG_LEN-1);
        return;
    }

    /* If the resolver fails there wont be an install.tmp */
    cmd = allocate(1024);
    snprintf(cmd, 1000, "touch %s", package_queue);
    if( ! run_command(cmd) )
        printf("Make uninstall list, cant create: %s\n", package_queue);
    free(cmd);

    /* read_dependencies_recursively and put those 
       we need in a file in installation order */
    handle_uninstall_dependencies(package);

    /* EOF after the progress meter started in handle_uninstall_dependencies.c */
    printf("\n");

    /* Free the recorded packages in handle_uninstall_dependencies(); */
    for(i=0; rec_saver[i]; i++)
    {
        free(rec_saver[i]);
        rec_saver[i] = NULL;
    }
}
