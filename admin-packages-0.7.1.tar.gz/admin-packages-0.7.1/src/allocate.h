
#ifndef ALLOCATE_H
#define ALLOCATE_H

char * allocate(long allocate_size);

#endif
