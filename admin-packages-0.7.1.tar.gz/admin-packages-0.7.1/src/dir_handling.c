/* Admin-Packages - A package manager for sources.
 * Copyright (C) 2009 - 2011 Magnus Loef <magnus-swe@telia.com> 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/wait.h>
#include <time.h>
#include "allocate.h"
#include "dir_handling.h"
#include "run_command.h"
#include "globals.h"

extern char build_directory[MAX_TEMP_PATH];
extern char build_dir_next[MAX_TEMP_PATH];
extern char pkgconf_temp[MAX_TEMP_PATH];
extern char package_queue[MAX_TEMP_PATH];
extern char mdsum_temp[MAX_TEMP_PATH];
extern char mdsum_pkg[MAX_TEMP_PATH];
extern char install_log[MAX_TEMP_PATH];
extern int global_verbose;


/* Gets the number of running instances of this program */
int num_processes_running(char *process)
{
    FILE *fp;
    long num, max_file_size = 4000;
    char *line, *sub_proc_path;
    int x = 0, num_processes = 0;
    struct dirent **namelist;
    char buf[2];
    int num_bytes = 0;

    sub_proc_path = allocate(1024);

    num = scandir(PROC_PATH, &namelist, 0, alphasort);
    if( num < 0 )
    {
        perror("scandir");
        free(sub_proc_path);
        return 0;
    }
    else
    {
        /* List all directories in PROC_PATH */
        for(x=0; x<num; x++)
        {
            /* Now list PROC_PATH/24207/cmdline */
            snprintf(sub_proc_path, 1000, "%s/%s/cmdline", PROC_PATH, namelist[x]->d_name);

            if((fp=fopen(sub_proc_path, "r"))==NULL)
            {
                free(namelist[x]);
                continue;
            }
            line = allocate(max_file_size+1);

            num_bytes = 0;
            while( fread(buf, 1, 1, fp) > 0)
            {
                /* Assemble command and its arguments */
                num_bytes++;
                buf[1]='\0';

                /* The arguments can be null terminated, use spaces instead */
                if( buf[0]=='\0' )
                    buf[0]=' ';

                if( num_bytes < max_file_size )
                    strcat(line, buf);
            }

            if( num_bytes > 10 && num_bytes < max_file_size )
            {
                /* Check if this is our process */
                if( strstr(line, process) )
                {
                    num_processes++;
                }
            }
            fclose(fp);
            free(line);
            free(namelist[x]);
        }
    }
    free(namelist);
    free(sub_proc_path);

    if( global_verbose )
        printf("Number of running processes: %d\n", num_processes-1);

    /* 2 processes means its one process for some reason */
    num_processes = num_processes -1;

    return num_processes;
}

/* Setup global file paths */
void setup_global_paths()
{
    snprintf(pkgconf_temp, MAX_TEMP_PATH, "%s/%s", build_directory, PKGCONF_NAME);
    snprintf(package_queue, MAX_TEMP_PATH, "%s/%s", build_directory, PACKAGE_QUEUE_NAME);
    snprintf(mdsum_temp, MAX_TEMP_PATH, "%s/%s", build_directory, MDSUM_NAME);
    snprintf(mdsum_pkg, MAX_TEMP_PATH, "%s/%s", build_directory, MDSUM_PKG_NAME);
    snprintf(install_log, MAX_TEMP_PATH, "%s/%s", build_directory, INSTALL_LOG_NAME);
}

/* Create a randomized temporary build directory */
void create_build_directory(char *dirpath)
{
    char rand_char;
    char rand_string[]="abcdefghijklmnopqrstuvwxyz1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    int i=0, z=0, x=0;
    char *cmd;

    /* Sleep some between directory creations */
    sleep(1);

    /* Create a randomized temporary build directory path */
    snprintf(dirpath, 1024, "%s/", TEMP_PATH);
    z = strlen(dirpath);

    /* Seed rand */
    srand((unsigned)time(NULL));

    /* Add random chars and digits to build_directory */
    for(i=0; i < strlen(rand_string); i++)
    {
        x = rand() % strlen(rand_string);
        rand_char = rand_string[x];

        /* Add random chars to the end of /var/admin-packages/tmp/... */
        dirpath[i+z] = rand_char;

        if( i >= MAX_RAND_DIR )
            break;
    }

    if( dirpath==NULL || ! strstr(dirpath, "/tmp") )
    {
        printf("Error: Creating a randomized temporary build directory failed.\n");
        exit(1);
    }

    cmd = allocate(strlen(dirpath)+42);
    sprintf(cmd, "mkdir -p %s", dirpath);
    if( ! run_command(cmd) )
        printf("Error creating temporary build directory:\n[%s]\n", dirpath);
    free(cmd);
}

/* Clean build dirs that can be cleaned */
void clean_build_dirs()
{
    /* Clean the temporary build directory root if this is the only admin-packages process.
       Otherwise remove the randomized temporary build directory */
    if( num_processes_running("admin-packages") < 2 )
        clean_build_directory_root();
    else
        /* Clean the randomized build directory temp */
        clean_build_directory_temp();
}


/* Clean the build directory root */
void clean_build_directory_root()
{
    char *cmd;

    if( global_verbose )
        printf("Cleaning the build directory root: %s\n", TEMP_PATH);

    cmd = allocate(strlen(TEMP_PATH)+20);
    sprintf(cmd, "rm -rf %s/*", TEMP_PATH);

    if( ! strstr(cmd, "/tmp") )
    {
        printf("Error cleaning the build directory root\n");
        return;
    }
    if( ! run_command(cmd) )
        printf("Error cleaning the build directory root: %s\n", TEMP_PATH);
    free(cmd);
}


/* Clean the randomized temporary build directory */
void clean_build_directory_temp()
{
    char *cmd;

    if( global_verbose )
        printf("Cleaning temporary build directory: %s\n", build_directory);

    cmd = allocate(strlen(build_directory)+20);
    sprintf(cmd, "rm -rf %s", build_directory);
    if( ! strstr(cmd, "/tmp") )
    {
        printf("Error cleaning the build directory\n");
        return;
    }
    if( ! run_command(cmd) )
        printf("Error cleaning the build directory: %s\n", build_directory);
    free(cmd);
}
