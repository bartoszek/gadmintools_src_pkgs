/* GADMIN-NFS-SERVER - An easy to use GTK+ frontend for the NFS server.
 * Copyright (C) 2014 - 2014 Magnus Loef <magnus-swe@telia.com> 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
*/


#include <gtk/gtk.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "widgets.h"
#include "gettext.h"
#include "allocate.h"
#include "show_info.h"
#include "clear_ptr_array.h"
#include "add_client.h"
#include "delete_client.h"
#include "set_del_row_num.h"
#include "commented.h"

extern int num_ranges;


void populate_clients(struct w *widgets,
                             gchar *nic,
                          gchar *subnet,
                          gchar *netmask)
{
    FILE *fp;
    long file_size = 0;
    int found_dir = 0;
    gint i = 0;
    int z = 0;
    char *line, *opt, *tmp;
    char *client_addr;
    char *client_opt;
    gchar *utf8=NULL, *info;

    GtkWidget *hbox[num_ranges];
    GtkWidget *from_label[num_ranges];
    GtkWidget *to_label[num_ranges];
    GtkWidget *from_entry[num_ranges];
    GtkWidget *to_entry[num_ranges];
    GtkWidget *del_range_button[num_ranges];
    GtkWidget *spacer_label_del[num_ranges];
    GtkWidget *add_range_hbox;
    GtkWidget *from_label_add, *to_label_add;
    GtkWidget *spacer_label_add;

    if( nic == NULL )
    {
       info = g_strdup_printf(_("Populate clients recieved a NULL value, clients not populated\n"));
       show_info(info);
       g_free(info);
       return;
    }

    /* Destroy all range widgets and clear range pointers */
    clear_ptr_array(widgets);

    gtk_widget_destroy(widgets->range_scrolled_vbox);

    widgets->range_scrolled_vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 0);

    gtk_container_add(GTK_CONTAINER(widgets->range_viewport), widgets->range_scrolled_vbox);

    if((fp=fopen(NFSD_CONF, "r"))==NULL)
    {
        return;
    }
    fseek(fp, 0, SEEK_END);
    file_size = ftell(fp);
    rewind(fp);

    line = allocate(file_size+1);
    opt  = allocate(file_size+1);

    if( file_size > 1 )
    while(fgets(line, file_size, fp)!=NULL)
    {
        sscanf(line, "%s", opt);

        if( strstr(opt, nic) && ! commented(line) )
        {
            found_dir = 1;
            break;
        }
    }
    fclose(fp);
    free(opt);

    /* Add a header label above the ranges */
    GtkWidget *range_spacer_hbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
    gtk_box_pack_start(GTK_BOX(widgets->range_scrolled_vbox), range_spacer_hbox, FALSE, FALSE, 0);
    GtkWidget *range_spacer_label = gtk_label_new(_("The selected directory is shared to:"));
    gtk_box_pack_start(GTK_BOX(range_spacer_hbox), range_spacer_label, TRUE, TRUE, 0);

    /* "Add range" hbox, label, entry and button */
    add_range_hbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
    gtk_box_pack_start(GTK_BOX(widgets->range_scrolled_vbox), add_range_hbox, FALSE, FALSE, 0);

    from_label_add = gtk_label_new(_(" Client: "));
    gtk_box_pack_start(GTK_BOX(add_range_hbox), from_label_add, FALSE, FALSE, 0);

    widgets->ranges_add_from_entry = gtk_entry_new();
    gtk_box_pack_start(GTK_BOX(add_range_hbox), widgets->ranges_add_from_entry, TRUE, TRUE, 0);
    gtk_widget_set_tooltip_text(GTK_WIDGET(widgets->add_directory_entry),
       "192.168.0.10 , 192.168.0.0/24 , host.example.org or *example.org");

    // Options Combo, but hard to cover all preconfigured servers variations
    to_label_add = gtk_label_new(_(" Options: "));
    gtk_box_pack_start(GTK_BOX(add_range_hbox), to_label_add, FALSE, FALSE, 0);

    widgets->ranges_add_to_entry = gtk_entry_new();
    gtk_box_pack_start(GTK_BOX(add_range_hbox), widgets->ranges_add_to_entry, TRUE, TRUE, 0);
    gtk_widget_set_tooltip_text(GTK_WIDGET(widgets->add_directory_entry),
       _("A comma delimited set of options: ro, rw, sync, async, subtree_check, no_subtree_check, root_squash, no_root_squash, all_squash etc"));


    widgets->ranges_add_button = gtk_button_new_from_icon_name("list-add", GTK_ICON_SIZE_BUTTON);
    gtk_box_pack_start(GTK_BOX(add_range_hbox), widgets->ranges_add_button, FALSE, TRUE, 0);
    g_signal_connect_swapped(G_OBJECT(widgets->ranges_add_button), "clicked",
                             G_CALLBACK(add_client), widgets);

    /* Give some room between the scroller and the button */
    spacer_label_add = gtk_label_new("");
    gtk_box_pack_start(GTK_BOX(add_range_hbox), spacer_label_add, FALSE, FALSE, 5);

    /* Get the actual size of the add range button so we can compare it to the
       delete range buttons and use the same width for all */
    GtkRequisition add_button_req;
    gtk_widget_get_preferred_size(GTK_WIDGET(widgets->ranges_add_button), &add_button_req, &add_button_req);
/// Bad on last req ???

    if( ! found_dir )
    {
        free(line);
        gtk_widget_show_all(widgets->main_window);
        return;
    }

    client_addr = allocate(file_size+1);
    client_opt  = allocate(file_size+1);

    i = 0;
    tmp = strtok(line, " ");
    while(tmp != NULL)
    {
        /* Skip directories */
        if( strlen(tmp) > 1 && ! strstr(tmp, "/") )
        {
            snprintf(client_addr, file_size, "%s", tmp);

            for(z = 0; z < strlen(tmp)-1; z++)
            if( tmp[z]=='(' )
            {
                snprintf(client_opt, file_size, "%s", &tmp[z+1]);

                /* Cut end option ")" and newline */

                if( client_opt[strlen(client_opt)-1]=='\n')
                    client_opt[strlen(client_opt)-1]='\0';
                client_opt[strlen(client_opt)-1]='\0';
                break;
            }
            /* Cut after ip */
            client_addr[z]='\0';


            hbox[i] = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 0);
            gtk_box_pack_start(GTK_BOX(widgets->range_scrolled_vbox), hbox[i], FALSE, FALSE, 0);
            g_ptr_array_add(widgets->ranges_hbox_array, (gpointer) hbox[i]);

            from_label[i] = gtk_label_new(_(" Client: "));
            gtk_box_pack_start(GTK_BOX(hbox[i]), from_label[i], FALSE, FALSE, 0);

            from_entry[i] = gtk_entry_new();
            gtk_box_pack_start(GTK_BOX(hbox[i]), from_entry[i], TRUE, TRUE, 0);
            g_ptr_array_add(widgets->ranges_from_entry_array, (gpointer) from_entry[i]);
            utf8 = g_locale_to_utf8(client_addr, strlen(client_addr), NULL, NULL, NULL);
            gtk_entry_set_text(GTK_ENTRY(from_entry[i]), utf8);
            if( utf8 != NULL )
                g_free(utf8);

            to_label[i] = gtk_label_new(_(" Options: "));
            gtk_box_pack_start(GTK_BOX(hbox[i]), to_label[i], FALSE, FALSE, 0);

            to_entry[i] = gtk_entry_new();
            gtk_box_pack_start(GTK_BOX(hbox[i]), to_entry[i], TRUE, TRUE, 0);
            g_ptr_array_add(widgets->ranges_to_entry_array, (gpointer) to_entry[i]);
            utf8 = g_locale_to_utf8(client_opt, strlen(client_opt), NULL, NULL, NULL);
            gtk_entry_set_text(GTK_ENTRY(to_entry[i]), utf8);
            if( utf8 != NULL )
                g_free(utf8);

            del_range_button[i] = gtk_button_new_from_icon_name("list-remove", GTK_ICON_SIZE_BUTTON);
            gtk_box_pack_start(GTK_BOX(hbox[i]), del_range_button[i], FALSE, TRUE, 0);
            g_ptr_array_add(widgets->ranges_del_button_array, (gpointer) del_range_button[i]);


            g_signal_connect_swapped(G_OBJECT(del_range_button[i]), "clicked",
                                  G_CALLBACK(set_del_row_num), GINT_TO_POINTER(i));
            g_signal_connect_swapped(G_OBJECT(del_range_button[i]), "clicked",
                                            G_CALLBACK(delete_client), widgets);

            /* Give some room between the scroller and the button */
            spacer_label_del[i] = gtk_label_new("");
            gtk_box_pack_start(GTK_BOX(hbox[i]), spacer_label_del[i], FALSE, FALSE, 5);

            /* Make the add and delete buttons the same width. */
            GtkRequisition del_button_req;
            gtk_widget_get_preferred_size(GTK_WIDGET(del_range_button[i]), &del_button_req, &del_button_req);
// Bad size req ???

            if( add_button_req.width > del_button_req.width )
                gtk_widget_set_size_request(GTK_WIDGET(del_range_button[i]), add_button_req.width, -1);

            if( del_button_req.width > add_button_req.width )
                gtk_widget_set_size_request(GTK_WIDGET(widgets->ranges_add_button), del_button_req.width, -1);

            i++;
        }
        /* We pass NULL to strtok to get the next token in the string */
        tmp = strtok(NULL, " ");
    }
    free(client_addr);
    free(client_opt);
    free(line);

    gtk_widget_show_all(widgets->main_window);
}
