/*
 * Admin-Packages - A Package manager for sources.
 * Copyright (C) 2009 - 2011 Magnus Loef <magnus-swe@telia.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307, USA.
 *
 */


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "allocate.h"
#include "globals.h"
#include "have_equal_or_higher_version.h"
#include "get_package_info.h"
#include "transform.h"
#include "commented.h"
#include "file_exists.h"

char package_queue[MAX_TEMP_PATH];

/* If set to 1 local package version is always 0 */
extern int global_reinstall;

extern int global_resolve_deps;
extern int global_verbose;


/*  Compares the installed and install.list versions to this version. */
int have_equal_or_higher_version(char *package, char *required_version)
{
    FILE *fp;
    char *conf_version, *line, *tmp_package;
    int i=0, begin=0, pkg_found=0, version_set=0;
    int local_ver=0, remote_ver=0;
    long file_size=0;
    char *tmp_ver;

    if( global_reinstall )
    {
        if( global_verbose )
            printf("Reinstalling, installed package versions are always zero.\n"); 
        return 0;
    }

    /* Get version from SYSCONFDIR/admin-packages/packages.conf */
    tmp_ver = get_version_from_package(2, package);

    conf_version = transform_version(tmp_ver);
    sscanf(conf_version, "%i", &local_ver);

    free(conf_version);
    free(tmp_ver);

    conf_version = transform_version(required_version);

    sscanf(conf_version, "%i", &remote_ver);

    free(conf_version);

    if( global_verbose )
    {
        printf("Comparing installed version: %i\n", local_ver);
        printf("To the remote version      : %i\n", remote_ver);
    }

    /* If package in packges.conf >= the to be installed package */
    if( local_ver >= remote_ver )
    {
       if( global_verbose )
         printf("The installed version of this package is\nequal to or higher then the remote package\n\n");
       return 1;
    }

    /* There is no package.queue when using the nodeps option */
    if( ! global_resolve_deps )
      return 0;

    if((fp=fopen(package_queue, "r"))==NULL)
    {
        perror("fopen");
        printf("Fatal error opening file: [%s]\n", package_queue);
        return 0;
    }

    fseek(fp, 0, SEEK_END);
    file_size=ftell(fp);
    rewind(fp);

    line = allocate(file_size+1);
    conf_version = allocate(MAX_VER_LEN+1);

    tmp_package = allocate(MAX_PKG_LEN+4);
    sprintf(tmp_package, "<%s>\n", package);

    if( file_size > 1 )
    while(fgets(line, file_size, fp)!=NULL)
    {
        if( commented(line) )
            continue;

        /* Is this an exact package match */
        if( strcmp(line, tmp_package) == 0 )
        {
            pkg_found = 1;

            if( file_size > 1 )
            while(fgets(line, file_size, fp)!=NULL)
            {
                if( commented(line) )
                    continue;

                if( strstr(line, "<") )
                    break;

                if( ! strstr(line, "version=") )
                    continue;

                /* Isolate the version (this must be the line) */
                for(i=0; i < MAX_VER_LEN-1; i++)
                {
                    if( i > 1 && line[i-1]=='"' )
                    {
                        begin = i;
                        break;
                    }
                }

                for(i=begin; i < MAX_VER_LEN-1; i++)
                {
                    if( i > 1 && line[i]=='"' && i > begin )
                    {
                        strncpy(conf_version, &line[begin], i-begin);
                        version_set = 1;
                        break;
                    }
                }

                if( version_set )
                    break;
            }
        }

        if( pkg_found )
            break;
    }
    fclose(fp);
    free(tmp_package);
    free(line);

    tmp_ver = allocate(MAX_VER_LEN+3);

    local_ver = 0; /* incase it cant convert for this second comparison */

    tmp_ver = transform_version(conf_version);

    sscanf(tmp_ver, "%i", &local_ver);

    free(tmp_ver);
    free(conf_version);

    if( local_ver >= remote_ver )
    {
       if( global_verbose )
         printf("This package version already scheduled for install\nis higher or equal to the remote version\n");
       return 1;
    }

    return 0;
}
