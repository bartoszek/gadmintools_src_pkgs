/*
 * Admin-Packages - A Package manager for sources.
 * Copyright (C) 2009 - 2011 Magnus Loef <magnus-swe@telia.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307, USA.
 *
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "allocate.h"
#include "globals.h"
#include "show_uninstall_list.h"
#include "commented.h"

extern char package_queue[MAX_TEMP_PATH];

#define NUM_PACKAGES_PER_LINE 4


/* Reads the package queue and outputs a list of packages to be installed */
/* It also lists a defined number of packages per line */

void show_uninstall_list()
{
    FILE *fp;
    long file_size=0, i=0;
    char *line, *package_begin, *package_end;

    if((fp=fopen(package_queue, "r"))==NULL)
    {
        printf("Cant open the uninstall list here: %s\n", package_queue);
        perror("fopen");
        return;
    }

    fseek(fp, 0, SEEK_END);
    file_size = ftell(fp);
    rewind(fp);

    line = allocate(file_size+1);
    package_begin = allocate(MAX_LINE_LEN+3);
    package_end = allocate(MAX_LINE_LEN+3);

    printf("\nPackages scheduled for removal:\n");

    if( file_size > 1 )
    while(fgets(line, file_size, fp)!=NULL)
    {
        if( commented(line) )
            continue;

        if( strstr(line, "<") && ! strstr(line, "#")
        && strlen(line) > 3 && strlen(line) < MAX_LINE_LEN-1 )
        {
            /* Cut the beginning/ending '<' */
            sprintf(package_begin, "%s", &line[1]);
            package_begin[strlen(package_begin)-2]='\0';

            sprintf(package_end, "</%s>\n", package_begin);

            /* No newline */
            printf("<%s> ", package_begin);

            /* Number of packages to list on one line */
            i++;
            if( i == NUM_PACKAGES_PER_LINE )
            {
                i = 0;
                printf("\n");
            }

            /* Scroll to the end of this package */
            if( file_size > 1 )
            while(fgets(line, file_size, fp)!=NULL)
            {
                if( commented(line) )
                    continue;

                if( strcmp(line, package_end) == 0 )
                    break;
            }
        }
    }
    fclose(fp);
    free(line);
    free(package_begin);
    free(package_end);

    /* Beautification */
    printf("\n\n");
}
