/*
 * Gfilemanager - GTK+2 filemanager with samba support.
 * Copyright (C) 2002, 2003 Magnus-swe <magnus-swe@telia.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307, USA.
 *
 */


#ifdef HAVE_CONFIG_H
#include <config.h>
#endif


/* Dont generate sigpipe */
#ifdef SIGPIPE
 signal(SIGPIPE, SIG_IGN);
#endif

/* Connection timed out .. probably a slow net/sambaserver */
#ifndef ETIMEDOUT
#define ETIMEDOUT 110
#endif

#ifndef ECONNREFUSED
#define ECONNREFUSED 111
#endif

#ifndef EINPROGRESS
#define EINPROGRESS 115
#endif

#include <sys/time.h>
#include <errno.h>
#include <gtk/gtk.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include <unistd.h>    
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* If we dont have bcopy .. use memcpy functions. */
#if HAVE_MEMEORY_H
#include <memory.h>
#endif

#ifndef HAVE_BCOPY
#define bcopy(s,d,n) memcpy((d),(s),(n))
#define bzero(d,n) memset((d),0,(n))
#endif

/* Used for both setting icons and different actions on different files */
void mimetypes( GtkWidget *widget, gpointer user_data, char *filez, char *path );

/* For the smb server scanner */
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <fcntl.h> /* non/blocking */

struct sockaddr_in pin;
struct hostent *server_host_name;
struct timeval tv;

char right_path[20000]="/";   /* Remote/local right path */
char left_path[20000]="/";    /* Left path */
char remember_path[20000]=""; /* Remember the right local path before connect */
char homedirectory[1024]="";  /* Homedirectory path */
char settings[1024]="";       /* Settings path */
char tempfile[1024]="";       /* temp name of file for use with popup windows */
char temppath[1024]="";       /* temporary path for use with popup windows */

char filetype[1024]="";       /* Which icon to set in filelist (from mimetypes) */
int listing_files=0;          /* Filetype/icon (dont run an action on list) */

char left_mount[1024]="";     /* Keep track of which treeview mounted what device */
char right_mount[1024]="";

/* Default settings, safety incase load settings fails */
char music_act[1024]="xmms -e";
char video_act[1024]="mplayer -vo sdl -framedrop";
char graphics_act[1024]="gqview";
char text_act[1024]="gedit";
char document_act[1024]="oowriter";
char spread_act[1024]="oocalc";
char sourcecode_act[1024]="gnome-terminal -e \"mcedit";
char webcode_act[1024]="gnome-terminal -e \"mcedit";
char action[8192];
int show_hidden=0;      /* Hidden files/directories */
int subnets=0;          /* If a selection is made to browse more subnets */
int scan_timeout=10000; /* 100000 is the worst i have seen, that network was really bad and the nic too */

int connected=0;        /* So we know if we should add more columns (maybe ill add them at startup instead) */
int updating=0;         /* Dont allow doing anything while a treeview updates */
int action_window=0;    /* Dont let the user open 2 action windows (X-close pressed hmm ?) */
int app_started=0;      /* Add files/dirs to remote treeview once (so we dont have to do ls twice */
int toggle=0;           /* Otherwise itll toggle when the settingswindow maps */
int scan=0;             /* So we can stop the samba scanner */

/* Fixme */
int actions_showing=0;  /* Dont let the user have more then one action_window open at the same time */


GtkWidget *main_window;
GtkWidget *help_window;
GtkWidget *settings_window;
GtkWidget *ip_entry;
GtkWidget *share_entry;
GtkWidget *user_entry;
GtkWidget *password_entry;
GtkWidget *right_status_entry;
GtkWidget *left_treeview;
GtkWidget *right_treeview;
GtkWidget *left_path_entry;
GtkWidget *right_path_entry;
GtkWidget *left_status_entry;
GtkWidget *right_actions_window;
GtkWidget *right_rename_entry;
GtkWidget *right_mkdir_entry;
GtkWidget *right_addfile_entry;
GtkWidget *left_actions_window;
GtkWidget *left_rename_entry;
GtkWidget *left_mkdir_entry;
GtkWidget *left_addfile_entry;
GtkWidget *status_window;
GtkWidget *scan_progress;
GtkWidget *scan_entry;

GtkWidget *music_entry;
GtkWidget *video_entry;
GtkWidget *graphics_entry;
GtkWidget *text_entry;
GtkWidget *document_entry;
GtkWidget *spreadsheet_entry;
GtkWidget *html_entry;
GtkWidget *sourcecode_entry;
GtkWidget *hidden_checkbutton;
GtkWidget *scanrange_spinbutton;
GtkWidget *scantimeout_spinbutton;
GtkWidget *archive_window;
GtkWidget *archive_textview;

GtkWidget *run_info_window;
GtkWidget *run_command_textview;
GtkWidget *disc_treeview;
GtkWidget *label60;
GtkWidget *run_command_entry;

/* The combo computer listing */
GtkWidget *combo1; 
GList *items = NULL;

/* For the file/directory icons  */
/* Setup in on_left_treeview_map */
GdkPixbuf *main_window_pixbuf;
GdkPixbuf *cdrom_pixbuf;
GdkPixbuf *floppy_pixbuf;
GdkPixbuf *dir_pixbuf;
GdkPixbuf *text_pixbuf;
GdkPixbuf *movie_pixbuf;
GdkPixbuf *sound_pixbuf;
GdkPixbuf *image_pixbuf;
GdkPixbuf *office_pixbuf;
GdkPixbuf *compressed_pixbuf;
GdkPixbuf *rpm_pixbuf;
GdkPixbuf *code_pixbuf;
GdkPixbuf *elf_pixbuf;
GdkPixbuf *exe_pixbuf;

GtkCellRenderer *pixmap_cell;


void
on_status_window_map                   (GtkWidget       *widget,
                                        gpointer         user_data)
{
   /* Look it up before we use its widgets from another window */
   scan_progress = lookup_widget(GTK_WIDGET (widget), "scan_progress");
   scan_entry = lookup_widget(GTK_WIDGET (widget), "scan_entry");
}


void
on_scan_button_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
   /* Resolving hostnames using nmblookup and adding the resolved names to the computer combo */
   FILE *fp;
   int sd, retval;
   gdouble progress_val = 0;
   extern int errno;
   char *ser1, *ser3, *ser4, *remote_host;
   char pbuffy[1024]="", systemz[1024]="", buffy[8192]="", netbios_name[1024]="", statbuf[1024]="";
   gchar *utf8=NULL;   
   int x, count=0, end=0, serint4=0;
   int found_lookup=0;
   int sub=subnets;
   int port=139;
   
   /* Clear the list */   
   items=NULL;
   left_status_entry = lookup_widget(GTK_WIDGET (button), "left_status_entry");
   right_status_entry = lookup_widget(GTK_WIDGET (button), "right_status_entry");
   scan=1;
   /* Check for nmblookup */
   fp=popen("nmblookup", "r");
   while(fgets(pbuffy, 1024, fp))
   {
      if( strstr(pbuffy, "Usage") )
      {
	 found_lookup=1;
         break;
      }
   }
   pclose(fp);

   if( ! found_lookup )
   {
      gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("The command: nmblookup was not found, refusing to scan."));
      return;	   
   }

   remote_host=(char *)malloc(1024);
   bzero(remote_host, 1024);
   ser1=(char *)malloc(1024);
   bzero(ser1, 1024);
   ser3=(char *)malloc(1024);
   bzero(ser3, 1024);
   ser4=(char *)malloc(1024);
   bzero(ser4, 1024);
   
   /* Hostname -i to get the scan values right */
   fp=popen("hostname -i", "r");
   while(fgets(pbuffy, 1024, fp))
   {
      if(strstr(pbuffy, ".") && strlen(pbuffy)>=7)
      {
         pbuffy[strlen(pbuffy)-2]='\0';
         printf("\nUsing scan-sequence from this ip:[%s]\n", pbuffy);

         if( strstr(pbuffy, "127.0.0.1") )
	 {
            gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("/etc/hosts: \"192.168.x.x computername.domain nickname\""));
            gtk_entry_set_text(GTK_ENTRY(right_status_entry), _("then type hostname \"nickname\""));
            free(remote_host);
            free(ser1);
            free(ser3);
            free(ser4);
            return;
	 }

         if( subnets )
         {          
            /* Get everything but the last 2 ipbits */
            for(x=0; pbuffy[x]; x++)
            {
               if(pbuffy[x]=='.')
               {
                  count++;
                  if(count==2) /* second dot */
                  {
	             count=40;
                     end=strlen(pbuffy)-x; 
                     pbuffy[strlen(pbuffy)-end]='\0';
                     strcpy(ser1, pbuffy);
                     break;
	          }
	       }      
	    }   
         }
         else
            {
               /* Get everything but the last ipbit */
               for(x=0; pbuffy[x]; x++)
               {
	          if(pbuffy[x]=='.')
	          {
	             count++;
	             if(count==3) /* third dot */
	             {
	                count=40;
                        end=strlen(pbuffy)-x; 
                        pbuffy[strlen(pbuffy)-end]='\0';
                        strcpy(ser1, pbuffy);
                        break;
	             }
	          }      
	       }   
            }        
      }
   }
   pclose(fp);

   status_window = create_status_window ();
   gtk_widget_show(status_window);
   while(gtk_events_pending ())
   gtk_main_iteration ();
  
   ip_entry = lookup_widget(GTK_WIDGET (button), "ip_entry");
   combo1 = lookup_widget(GTK_WIDGET (button), "combo1");
   printf("Using first bits:[%s]\n", ser1);

   if( strlen(ser1)==0 )
   {
      gtk_widget_destroy(status_window);
      gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("/etc/hosts: \"192.168.x.x computername.domain nickname\""));
      gtk_entry_set_text(GTK_ENTRY(right_status_entry), _("then type hostname \"nickname\""));
      free(remote_host);
      free(ser1);
      free(ser3);
      free(ser4);
      return;
   }

   /* Scan loop */
   while(serint4<255)
   {
      /* Break the loop when everything has been scanned */
      if( (! sub && serint4==254) || ! scan )
      break;

      /* Switch subnet */
      if( sub && serint4 == 254 )
      {
          serint4=0;
          sub--;
      }
      serint4++;
      strcpy(remote_host, ser1);
      strcat(remote_host, ".");
      sprintf(ser3, "%d", sub);
      sprintf(ser4, "%d", serint4);

      if( subnets )
      {
         strcat(remote_host, ser3);
         strcat(remote_host, ".");
         strcat(remote_host, ser4);
      }
      else
         strcat(remote_host, ser4);

      /* Set progress in the progress bar */
      if( progress_val <= 1.00 && progress_val >= 0.00 )
      {
         if( subnets )
         progress_val = progress_val + 0.00196 / subnets;
         if( ! subnets )
         progress_val = progress_val + 0.0118 / 3;
         gtk_progress_bar_set_fraction (GTK_PROGRESS_BAR (scan_progress), progress_val);
      }
      while(gtk_events_pending ())
      gtk_main_iteration ();

      /* Setup the socket  */   
      server_host_name=gethostbyname(remote_host);
      bzero(&pin, sizeof(pin));
      pin.sin_family=AF_INET; 
      pin.sin_addr.s_addr=((struct in_addr *)
      (server_host_name->h_addr))->s_addr;
      pin.sin_port=htons(port);

      /* USING TCP/IP */
      if((sd=socket(AF_INET, SOCK_STREAM, 0))==-1)
      {
         perror("socket");
      }

      /* TTL FOR send / connect */
      tv.tv_sec  = 0;
      tv.tv_usec = scan_timeout;
      retval = setsockopt(sd, SOL_SOCKET, SO_SNDTIMEO, (char*)&tv, sizeof(tv));

      if( retval == -1 )
      {
         perror("setsockopt");
      }

      /* I hope it wont be too slow on slow networks */
      if( connect(sd, (void *)&pin, sizeof(pin)) ==-1 )
      {
//         perror("connect");
         if( errno == ETIMEDOUT )
         {
            /* Find a ECONNECT so i can use only one nmblookup code snipplet */
            printf("connection timed out while connecting to:[%s], probing deeper.\n", inet_ntoa(pin.sin_addr));
            while(gtk_events_pending ())
            gtk_main_iteration ();
            strcpy(systemz, "nmblookup -A ");
            strcat(systemz, inet_ntoa(pin.sin_addr));
            fp=popen(systemz, "r");
            while(gtk_events_pending ())
            gtk_main_iteration ();
            while(fgets(buffy, 8192, fp))
            {
               netbios_name[0]='\0';
     	       if( strstr(buffy, "<00>") )
	       {
   	          sscanf(buffy, "%s", netbios_name);
                  printf("Found samba host (Using extended scan) at IP:[%s] with name:[%s]\n", inet_ntoa(pin.sin_addr), netbios_name);
  	          strcpy(statbuf, "Samba server [");
	          strcat(statbuf, netbios_name);
	          strcat(statbuf, "] was found by using an extended scan.");
                  gtk_entry_set_text(GTK_ENTRY(scan_entry), statbuf);
                  utf8=g_locale_to_utf8(netbios_name, strlen(netbios_name), NULL, NULL, NULL);
                  items = g_list_append (items, utf8);
                  break;
               }
            }       
            pclose(fp);
         }

         if( errno == ECONNREFUSED )
         printf("Connection to port 139 on:[%s] REFUSED (not a sambaserver)\n", inet_ntoa(pin.sin_addr));
         //printf("error number: [%d] .. host:[%s]\n", errno, inet_ntoa(pin.sin_addr) );
      }
      else
         {
            while(gtk_events_pending ())
            gtk_main_iteration ();
            strcpy(systemz, "nmblookup -A ");
            strcat(systemz, inet_ntoa(pin.sin_addr));
            fp=popen(systemz, "r");
            while(gtk_events_pending ())
            gtk_main_iteration ();
            while(fgets(buffy, 8192, fp))
            {
               netbios_name[0]='\0';
   	       if( strstr(buffy, "<00>") )
	       {
	          sscanf(buffy, "%s", netbios_name);
                  printf("Found samba host at IP:[%s] with name:[%s]\n", inet_ntoa(pin.sin_addr), netbios_name);
	          strcpy(statbuf, "Samba server [");
	          strcat(statbuf, netbios_name);
	          strcat(statbuf, "] found.");
                  gtk_entry_set_text(GTK_ENTRY(scan_entry), statbuf);
                  utf8=g_locale_to_utf8(netbios_name, strlen(netbios_name), NULL, NULL, NULL);
                  items = g_list_append (items, utf8);
	          break;
 	       }
            }       
            pclose(fp);
         }
         close(sd);
         //printf("PROGRESS: [%g]\n", progress_val);
         //printf("Scanning host:[%s]\n", remote_host);
   }
   /* Add servers to combobox if there was any */

   /* Dont show 100% when user pressed the cancel scan button */
   if ( scan )
   gtk_progress_bar_set_fraction (GTK_PROGRESS_BAR (scan_progress), 1.0);
   while(gtk_events_pending ())
   gtk_main_iteration ();
   if( scan )
   usleep(500000);
   if(items !=NULL)
   gtk_combo_set_popdown_strings(GTK_COMBO(combo1), items);
   if(utf8 !=NULL)
   g_free(utf8);
   gtk_widget_destroy(status_window);
   free(ser1); free(ser3); free(ser4); free(remote_host);
}


/* Cut_path */
int retPos(char *s, char tkn) 
{
   int len = strlen(s);
   int pos;
   len = len -2;
   for(pos=len;s[pos] != '/';pos--) 
   {
   /* printf("%c",s[pos]); */
   }
   return pos;
} 


/* Cut_path */
void StrCut( char *s, short pos1, short pos2, char *Result )
{
   short Length;
   short i;
   Length = strlen( s );
   for( i=pos1;i<pos2;i++ )
   {
      Result[i-pos1] = s[i];
   }
   Result[ pos2-pos1 ] = 0;
}


void read_settings()
{
   FILE *fp;
   int x;
   long siz;
   char *old_buffer, *temp;
   char hidden_act[1024]="";
   char subnet_act[1024]="";
   char scantimeout_act[1024]="";
   
   if( (fp=fopen(settings, "r"))==NULL)
   {
      printf(_("Cant open the settings file in your homedirectory.\n"));
      printf(_("This is normal when you run it for the first time.\n"));
      printf(_("writing and using default values.\n"));
      system(_("mkdir $HOME/.gfilemanager"));
   }
   else
      {
         fseek(fp, 0, SEEK_END);
         siz=ftell(fp);
         rewind(fp);
         old_buffer=(char *)malloc(siz);
         bzero(old_buffer, siz);
         temp=(char *)malloc(1024);
         bzero(temp, 1024);
         printf(_("\nReading the configuration settings please wait...\n"));
         while((fgets(old_buffer, siz, fp)!=NULL))
         {
            strcpy(temp, old_buffer);
            temp[strlen(temp)-1]='\0';
            if( strstr(temp, "Music") )
            {
               for(x=strlen(temp)-1; temp[x]; x--)
	       {
	          if(temp[x]==':')
	          {
	 	     x=x+2;
                     snprintf(music_act, x-strlen(temp)-1, "%s", temp+x);
//                     printf("Music setting:[%s]\n", music_act);
		     break;
	          }
	       }      
	    }
	    if( strstr(temp, "Video") )
            {
               for(x=strlen(temp)-1; temp[x]; x--)
	       {
	          if(temp[x]==':')
		  {
	 	     x=x+2;
                     snprintf(video_act, x-strlen(temp)-1, "%s", temp+x);
//                     printf("Video setting:[%s]\n", video_act);
		     break;
	          }
	       }      
	    }
	    if( strstr(temp, "Graphics") )
            {
               for(x=strlen(temp)-1; temp[x]; x--)
 	       {
	          if(temp[x]==':')
		  {
	 	     x=x+2;
                     snprintf(graphics_act, x-strlen(temp)-1, "%s", temp+x);
//                     printf("Graphics setting:[%s]\n", graphics_act);
		     break;
	          }
	       }      
	    }
	    if( strstr(temp, "Text") )
            {
               for(x=strlen(temp)-1; temp[x]; x--)
	       {
	          if(temp[x]==':')
	          {
	 	     x=x+2;
                     snprintf(text_act, x-strlen(temp)-1, "%s", temp+x);
//                     printf("Text setting:[%s]\n", text_act);
		     break;
	          }
	       }      
	    }
	    if( strstr(temp, "Document") )
            {
               for(x=strlen(temp)-1; temp[x]; x--)
	       {
	          if(temp[x]==':')
		  {
	 	     x=x+2;
                     snprintf(document_act, x-strlen(temp)-1, "%s", temp+x);
//                     printf("Document:[%s]\n", document_act);
		     break;
	          }
	       }      
	    }
	    if( strstr(temp, "Spreadsheet") )
            {
               for(x=strlen(temp)-1; temp[x]; x--)
	       {
	          if(temp[x]==':')
	          {
	 	     x=x+2;
                     snprintf(spread_act, x-strlen(temp)-1, "%s", temp+x );
//                     printf("Spread setting:[%s]\n", spread_act);
		     break;
	          }
	       }      
	    }
	    if( strstr(temp, "Websource") )
            {
               for(x=strlen(temp)-1; temp[x]; x--)
	       {
	          if(temp[x]==':')
	          {
	 	     x=x+2;
                     snprintf(webcode_act, x-strlen(temp)-1, "%s", temp+x );
//                     printf("Webcode setting:[%s]\n", webcode_act);
		     break;
	          }
	       }      
	    }
	    if( strstr(temp, "Sourcecode") )
            {
               for(x=strlen(temp)-1; temp[x]; x--)
	       {
	          if(temp[x]==':')
	          {
	 	     x=x+2;
                     snprintf(sourcecode_act, x-strlen(temp)-1, "%s", temp+x );
//                     printf("Sourcecode setting:[%s]\n", sourcecode_act);
		     break;
	          }
	       }      
	    }
            if( strstr(temp, "showhidden") )
	    { 
	       for(x=strlen(temp)-1; temp[x]; x--)
	       {
	          if(temp[x]==':')
		  {
		     x=x+2;
		     snprintf(hidden_act, x-strlen(temp)-1, "%s", temp+x);
//		     printf("Hidden setting:[%s]\n", hidden_act);
		     show_hidden=atoi(hidden_act);
		     break;
		  }
	       }
	    }
            if( strstr(temp, "subnets") )
	    { 
	       for(x=strlen(temp)-1; temp[x]; x--)
	       {
	          if(temp[x]==':')
		  {
		     x=x+2;
		     snprintf(subnet_act, x-strlen(temp)-1, "%s", temp+x);
//		     printf("Subnet setting:[%s]\n", subnet_act);
		     subnets=atoi(subnet_act);
		     break;
		  }
	       }
	    }
            if( strstr(temp, "scantimeout") )
	    { 
	       for(x=strlen(temp)-1; temp[x]; x--)
	       {
	          if(temp[x]==':')
		  {
		     x=x+2;
		     snprintf(scantimeout_act, x-strlen(temp)-1, "%s", temp+x);
//		     printf("Scantimeout setting:[%s]\n", scantimeout_act);
		     scan_timeout=atoi(scantimeout_act);
		     break;
		  }
	       }
	    }
         }
         printf(_("Loaded the program settings.\n\n"));         
         fclose(fp);
	 free(old_buffer); free(temp);
	 return;
      }      

      /* If we failed the first time we add a default configuration */   
      if( (fp=fopen(settings, "w+"))==NULL)
      {
         printf(_("Cant open the settings file in your homedirectory, quitting!!! (HOME path not set ?).\n"));
         printf(_("Using default settings.\n"));
         return;
      }
      else
         {
//	    printf("Wrote default settings.\n");
            fputs("#These are the settings for Gfilemanager, DO NOT EDIT.\n", fp);
            fputs("Music: xmms -e\n", fp);
            fputs("Video: mplayer -vo sdl -framedrop\n", fp);
            fputs("Graphics: gqview\n", fp);
            fputs("Text: gedit\n", fp);
            fputs("Document: oowriter\n", fp);
            fputs("Spreadsheet: oocalc\n", fp);
            fputs("Webcode: gnome-terminal -e \"mcedit\n", fp);
            fputs("Sourcecode: gnome-terminal -e \"mcedit\n", fp);
            fputs("show hidden: 0\n", fp);
            fputs("subnets: 0\n", fp);
            fputs("scantimeout: 10000\n", fp);
            /* Add a newline at the end (refusing to use append mode) */
	    fputs("\n", fp);
            fclose(fp);
	 }
}


void clear_right(GtkWidget *widget, gpointer user_data)
{
   GtkListStore *right_model;
   right_treeview = lookup_widget (GTK_WIDGET (widget), "right_treeview");
   right_model = gtk_list_store_new(4, GDK_TYPE_PIXBUF, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
   gtk_tree_view_set_model(GTK_TREE_VIEW(right_treeview), GTK_TREE_MODEL (right_model));
}


void clear_left(GtkWidget *widget, gpointer user_data)
{
   GtkListStore *left_model;
   left_treeview = lookup_widget (GTK_WIDGET (widget), "left_treeview");
   left_model = gtk_list_store_new(4, GDK_TYPE_PIXBUF, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
   gtk_tree_view_set_model(GTK_TREE_VIEW(left_treeview), GTK_TREE_MODEL (left_model));
}


void 
list_left(GtkWidget *widget, gpointer user_data)
{
   /* List files and directories in the left treeview (and right at startup) */
   FILE *fp;
   char *old_buffer, *systemz, *filez, *sizez, *attribz, *files_buffer, *sizez_buffer;
   GtkTreeIter iter;
   GtkTreeModel *left_model, *right_model;
   GtkTreePath *path;
   gboolean edit=0;
   long siz;
   gchar *utf8=NULL;
   int i=0, begin=0, begin_sizez=0, z=0, y=0; //, one_time=0; 
   char mounts[8192]="", mount_buffy[8192]="";
  
   if( updating )
   return;
  
   updating=1;

   listing_files=1; /* dont perform an action while listing mimetypes/icons */

   /* add files and directories for both treeviews at startup (speed increase) */
   if( ! app_started )
   {
      clear_right(right_treeview, NULL);
   }
   right_model = gtk_tree_view_get_model(GTK_TREE_VIEW(right_treeview));

   clear_left(left_treeview, NULL);
   left_model = gtk_tree_view_get_model(GTK_TREE_VIEW(left_treeview));

   /* Insert mountable devices first in the list */
   if((fp = popen("ls -l /mnt", "r"))==NULL)
   {
      printf("\nError opening on mount\n");
      return;
   }
   while((fgets(mount_buffy, 8192, fp)!=NULL))
   { 
      sscanf(mount_buffy, "%*s %*s %*s %*s %*s %*s %*s %*s %s", mounts);
      if( strstr(mounts, "cd") )
      {
         gtk_list_store_append(GTK_LIST_STORE(left_model), &iter);
         gtk_list_store_set(GTK_LIST_STORE(left_model), &iter, 0, cdrom_pixbuf, -1);
         utf8 = g_locale_to_utf8(mounts, strlen(mounts), NULL, NULL, NULL); 
         gtk_list_store_set(GTK_LIST_STORE(left_model), &iter, 1, utf8, -1);
         utf8 = g_locale_to_utf8("4096", 4, NULL, NULL, NULL);
         gtk_list_store_set(GTK_LIST_STORE(left_model), &iter, 2, utf8, -1);
         utf8 = g_locale_to_utf8("M", 1, NULL, NULL, NULL);
         gtk_list_store_set(GTK_LIST_STORE(left_model), &iter, 3, utf8, -1);
         if( ! app_started )
         {
            gtk_list_store_append(GTK_LIST_STORE(right_model), &iter);
            gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 0, cdrom_pixbuf, -1);
            utf8 = g_locale_to_utf8(mounts, strlen(mounts), NULL, NULL, NULL);
            gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 1, utf8, -1);
            utf8 = g_locale_to_utf8("4096", 4, NULL, NULL, NULL);
            gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 2, utf8, -1);
            utf8 = g_locale_to_utf8("M", 1, NULL, NULL, NULL);
            gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 3, utf8, -1);
         }
      }
      if( strstr(mounts, "floppy") )
      {
         gtk_list_store_append(GTK_LIST_STORE(left_model), &iter);
         gtk_list_store_set(GTK_LIST_STORE(left_model), &iter, 0, floppy_pixbuf, -1);
         utf8 = g_locale_to_utf8(mounts, strlen(mounts), NULL, NULL, NULL);
         gtk_list_store_set(GTK_LIST_STORE(left_model), &iter, 1, utf8, -1);
         utf8 = g_locale_to_utf8("4096", 4, NULL, NULL, NULL);
         gtk_list_store_set(GTK_LIST_STORE(left_model), &iter, 2, utf8, -1);
         utf8 = g_locale_to_utf8("M", 1, NULL, NULL, NULL);
         gtk_list_store_set(GTK_LIST_STORE(left_model), &iter, 3, utf8, -1);
         if( ! app_started )
         {
            gtk_list_store_append(GTK_LIST_STORE(right_model), &iter);
            gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 0, floppy_pixbuf, -1);
            utf8 = g_locale_to_utf8(mounts, strlen(mounts), NULL, NULL, NULL);
            gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 1, utf8, -1);
            utf8 = g_locale_to_utf8("4096", 4, NULL, NULL, NULL);
            gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 2, utf8, -1);
            utf8 = g_locale_to_utf8("M", 1, NULL, NULL, NULL);
            gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 3, utf8, -1);
         }
      }
   }
   pclose(fp);
    
   filez=(char *)malloc(8192);
   bzero(filez, 8192);
   sizez=(char *)malloc(8192);
   bzero(sizez, 8192);
   attribz=(char *)malloc(8192);
   bzero(attribz, 8192);
   systemz=(char *)malloc(8192);
   bzero(systemz, 8192);
   strcpy(systemz, "ls -laQ \"");
   strcat(systemz, left_path);
   strcat(systemz, "\" > ");
   strcat(systemz, tempfile);
   system(systemz);

   if((fp = fopen(tempfile, "r"))==NULL)
   {
      printf("\nError opening file\n");
      return;
   }
   fseek(fp, 0, SEEK_END);
   siz=ftell(fp);
   rewind(fp);
   old_buffer=(char *)malloc(siz);
   bzero(old_buffer, siz);
   files_buffer=(char *)malloc(siz);
   bzero(files_buffer, siz);
   sizez_buffer=(char *)malloc(siz);
   bzero(sizez_buffer, siz);

   /* dont show ".." when at root level */
   if( strlen(left_path)==1 )
   i=i-1;

   /* List directories in the left treeview with attrib "D" */
   while((fgets(old_buffer, siz, fp)!=NULL))
   {
      i++;
      if(i>=3) /* begin at ".." */
      {
         /* Check for attribute "d" */
         sscanf(old_buffer, "%s %*s %*s %*s %s", attribz, sizez);
	 if( strstr(attribz, "d") )
 	 {
            /* Append directory names to the left treeview */
            for(y=0; old_buffer[y]; y++)
	    {
	       if( old_buffer[y]=='"' )
               {
	          y=y+1;
                  begin=y;
		  for(y=y; old_buffer[y]; y++)
		  {
		     if( old_buffer[y]=='"' )
		     {
                        snprintf(filez, y-begin+1, "%s", old_buffer+begin);   
                        /* A selection to show or not to show hidden files/directories */
                        if( old_buffer[begin]=='.' && old_buffer[begin+1]!='.' && ! show_hidden)
			break;

//                        printf("DIRECTORY:[%s]\n", filez);
			gtk_list_store_append(GTK_LIST_STORE(left_model), &iter);
                        gtk_list_store_set(GTK_LIST_STORE(left_model), &iter, 0, dir_pixbuf, -1);
                        utf8 = g_locale_to_utf8(filez, strlen(filez), NULL, NULL, NULL);
                        gtk_list_store_set(GTK_LIST_STORE(left_model), &iter, 1, utf8, -1);
                        utf8 = g_locale_to_utf8(sizez, strlen(sizez), NULL, NULL, NULL);
                        gtk_list_store_set(GTK_LIST_STORE(left_model), &iter, 2, utf8, -1);
                        utf8 = g_locale_to_utf8("D", 1, NULL, NULL, NULL);
                        gtk_list_store_set(GTK_LIST_STORE(left_model), &iter, 3, utf8, -1);

                        /* Add Directories to the right treeview at startup (decreases loading time) */
			if( ! app_started )
			{
 			   gtk_list_store_append(GTK_LIST_STORE(right_model), &iter);
                           gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 0, dir_pixbuf, -1);
                           utf8 = g_locale_to_utf8(filez, strlen(filez), NULL, NULL, NULL);
                           gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 1, utf8, -1);
                           utf8 = g_locale_to_utf8(sizez, strlen(sizez), NULL, NULL, NULL);
                           gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 2, utf8, -1);
                           utf8 = g_locale_to_utf8("D", 1, NULL, NULL, NULL);
                           gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 3, utf8, -1);
			}
		        break; 
	             }
		  }
	       }  
	    }
	 }
         else
	    {  
	       /* These are files, put them in a buffer and insert them last */
               for(y=0; old_buffer[y]; y++)
  	       {
	          if( old_buffer[y]=='"' )
                  {
	             y=y+1;
		     begin=y;
		     for(y=y; old_buffer[y]; y++)
		     {
		        if( old_buffer[y]=='"' )
		        {
                           snprintf(filez, y-begin+1, "%s", old_buffer+begin);   

                           /* A selection to or not to show hidden files/directories */
                           if( old_buffer[begin]=='.' && old_buffer[begin+1]!='.' && ! show_hidden)
                           break;
		           strcat(files_buffer, filez);
	                   strcat(files_buffer, "\n");

                           sscanf(old_buffer, "%*s %*s %*s %*s %s", sizez);
	                   strcat(sizez_buffer, sizez);
	                   strcat(sizez_buffer, "\n");
			   
//                           printf("Left Filez:[%s] sizez:[%s]\n", filez, sizez);

		           break; 
	                }
 		     }
	          }  
	       }
	    }
	    attribz[0]='\0';
      }
   }  
   fclose(fp);
   free(systemz);
   free(old_buffer);
   free(attribz);

   y=0;

   /* List files in the left treeview with attrib "A" */
   while(files_buffer[z]!='\0')
   {
      /* Get filesize */
      begin_sizez=y;
      for(y=y; sizez_buffer[y]; y++)
      {
         if(sizez_buffer[y]=='\n')
         {
            snprintf(sizez, y-begin_sizez+1, "%s", sizez_buffer+begin_sizez);   
            break;
         }
      }

      begin=z;
      for(z=z; files_buffer[z]; z++) 
      {
         /* Copy from start to newline and append files */
         if( files_buffer[z]=='\n' )
	 {
            snprintf(filez, z-begin+1, "%s", files_buffer+begin);   

	    if( strstr(filez,"->")==0 && strstr(filez,"/")==0 )
	    {
               gtk_list_store_append(GTK_LIST_STORE(left_model), &iter);

               mimetypes(NULL, NULL, filez, left_path);

               if( filetype !=NULL )
               {
	          if( strstr(filetype, "movie") )
                  gtk_list_store_set(GTK_LIST_STORE(left_model), &iter, 0, movie_pixbuf, -1);
		 
	          if( strstr(filetype, "sound") )
                  gtk_list_store_set(GTK_LIST_STORE(left_model), &iter, 0, sound_pixbuf, -1);

	          if( strstr(filetype, "text") )
                  gtk_list_store_set(GTK_LIST_STORE(left_model), &iter, 0, text_pixbuf, -1);

		  if( strstr(filetype, "office") )
                  gtk_list_store_set(GTK_LIST_STORE(left_model), &iter, 0, office_pixbuf, -1);

		  if( strstr(filetype, "image") )
                  gtk_list_store_set(GTK_LIST_STORE(left_model), &iter, 0, image_pixbuf, -1);

		  if( strstr(filetype, "compressed") )
                  gtk_list_store_set(GTK_LIST_STORE(left_model), &iter, 0, compressed_pixbuf, -1);

		  if( strstr(filetype, "rpm") )
                  gtk_list_store_set(GTK_LIST_STORE(left_model), &iter, 0, rpm_pixbuf, -1);

		  if( strstr(filetype, "code") )
                  gtk_list_store_set(GTK_LIST_STORE(left_model), &iter, 0, code_pixbuf, -1);
		 		 
		  if( strstr(filetype, "data") )
                  gtk_list_store_set(GTK_LIST_STORE(left_model), &iter, 0, code_pixbuf, -1);

		  if( strstr(filetype, "elf") )
                  gtk_list_store_set(GTK_LIST_STORE(left_model), &iter, 0, elf_pixbuf, -1);
	         
		  if( strstr(filetype, "exe") )
                  gtk_list_store_set(GTK_LIST_STORE(left_model), &iter, 0, exe_pixbuf, -1);
               }
               utf8 = g_locale_to_utf8(filez, strlen(filez), NULL, NULL, NULL);
               gtk_list_store_set(GTK_LIST_STORE(left_model), &iter, 1, utf8, -1);
               utf8 = g_locale_to_utf8(sizez, strlen(sizez), NULL, NULL, NULL);
               gtk_list_store_set(GTK_LIST_STORE(left_model), &iter, 2, utf8, -1);
               utf8 = g_locale_to_utf8("A", 1, NULL, NULL, NULL);
               gtk_list_store_set(GTK_LIST_STORE(left_model), &iter, 3, utf8, -1);
            }
	    
            /* When first started, add files to the right treeview (decreases loading time) */
            if( ! app_started && strstr(filez,"->")==0 && strstr(filez,"/")==0 )
	    {
               gtk_list_store_append(GTK_LIST_STORE(right_model), &iter);
               gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 0, text_pixbuf, -1);
               utf8 = g_locale_to_utf8(filez, strlen(filez), NULL, NULL, NULL);
               gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 1, utf8, -1);
               utf8 = g_locale_to_utf8(sizez, strlen(sizez), NULL, NULL, NULL);
               gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 2, utf8, -1);
               utf8 = g_locale_to_utf8("A", 1, NULL, NULL, NULL);
               gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 3, utf8, -1);
            }
            break;
         }
      }
      z++;
      y++;
      if(files_buffer[z]=='\0')
      break;
   }
   
   free(files_buffer);
   free(sizez_buffer);
   strcpy(filez, "rm -f ");
   strcat(filez, tempfile);
   system(filez);
   free(filez);
   free(sizez);
   path = gtk_tree_path_new_first(); /* This might break if permissionchecking fails ! */
   gtk_tree_view_set_cursor(GTK_TREE_VIEW(left_treeview), path, NULL, edit);
   if( ! app_started )
   {
      gtk_tree_view_set_cursor(GTK_TREE_VIEW(right_treeview), path, NULL, edit);
   }
   gtk_tree_path_free(path);
   app_started=1;
   updating=0;
   listing_files=0; /* Icons/mimetypes */
}


void 
list_right(GtkWidget *widget, gpointer user_data)
{
   FILE *fp;
   char *old_buffer, *systemz, *filez, *attribz, *sizez, *files_buffer, *sizez_buffer;
   GtkTreeIter iter;
   GtkTreeModel *right_model;
   GtkTreePath *path;
   gboolean edit=0;
   long siz;
   gchar *utf8=NULL;
   int i=0, begin=0, begin_sizez=0, z=0, y=0;
   char mounts[8192]="", mount_buffy[8192]="";
   
   if( updating )
   return;

   updating=1;

   listing_files=1; /* dont perform an action while listing mimetypes/icons */

   /* clear and update right treeview */
   clear_right(right_treeview, NULL);
   right_model = gtk_tree_view_get_model(GTK_TREE_VIEW(right_treeview));


   /* Insert mountable devices in list */
   if((fp = popen("ls -l /mnt", "r"))==NULL)
   {
      printf("\nError opening file\n");
      return;
   }
   while((fgets(mount_buffy, 8192, fp)!=NULL))
   {
      sscanf(mount_buffy, "%*s %*s %*s %*s %*s %*s %*s %*s %s", mounts);
      if( strstr(mounts, "cd") )
      {
         gtk_list_store_append(GTK_LIST_STORE(right_model), &iter);
         gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 0, cdrom_pixbuf, -1);
         utf8 = g_locale_to_utf8(mounts, strlen(mounts), NULL, NULL, NULL);
         gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 1, utf8, -1);
         utf8 = g_locale_to_utf8("4096", 4, NULL, NULL, NULL);
         gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 2, utf8, -1);
         utf8 = g_locale_to_utf8("M", 1, NULL, NULL, NULL);
         gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 3, utf8, -1);
      }

      if( strstr(mounts, "floppy") )
      {
         gtk_list_store_append(GTK_LIST_STORE(right_model), &iter);
         gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 0, floppy_pixbuf, -1);
         utf8 = g_locale_to_utf8(mounts, strlen(mounts), NULL, NULL, NULL);
         gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 1, utf8, -1);
         utf8 = g_locale_to_utf8("4096", 4, NULL, NULL, NULL);
         gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 2, utf8, -1);
         utf8 = g_locale_to_utf8("M", 1, NULL, NULL, NULL);
         gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 3, utf8, -1);
      }
   }
   pclose(fp);

   filez=(char *)malloc(8192);
   bzero(filez, 8192);
   attribz=(char *)malloc(8192);
   bzero(attribz, 8192);
   sizez=(char *)malloc(8192);
   bzero(sizez, 8192);
   systemz=(char *)malloc(8192);
   bzero(systemz, 8192);

   strcpy(systemz, "ls -laQ \"");
   strcat(systemz, right_path);
   strcat(systemz, "\" > ");
   strcat(systemz, tempfile);
   system(systemz);

   if((fp = fopen(tempfile, "r"))==NULL)
   {
      printf("\nError opening temp file\n");
      return;
   }
   fseek(fp, 0, SEEK_END);
   siz=ftell(fp);
   rewind(fp);
   old_buffer=(char *)malloc(siz);
   bzero(old_buffer, siz);
   files_buffer=(char *)malloc(siz);
   bzero(files_buffer, siz);
   sizez_buffer=(char *)malloc(siz);
   bzero(sizez_buffer, siz);

   /* dont show ".." when at root level */
   if(strlen(right_path)==1)
   i=i-1;

   /* List directories in the left treeview with attrib "D" */
   while((fgets(old_buffer, siz, fp)!=NULL))
   {
      i++;
      if(i>=3)
      {
         sscanf(old_buffer, "%s %*s %*s %*s %s", attribz, sizez);
	 if( strstr(attribz, "d") )
 	 {
            /* Append the whole directory name */
            for(y=0; old_buffer[y]; y++)
	    {
	       if( old_buffer[y]=='"' )
               {
                  y=y+1;
		  begin=y;
		  for(y=y; old_buffer[y]; y++)
		  {
		     if( old_buffer[y]=='"' )
		     {
                        /* A selection to show or not to show hidden files/directories */
                        if( old_buffer[begin]=='.' && old_buffer[begin+1]!='.' && ! show_hidden )
                        break;
			
                        snprintf(filez, y-begin+1, "%s", old_buffer+begin);   
			gtk_list_store_append(GTK_LIST_STORE(right_model), &iter);
                        gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 0, dir_pixbuf, -1);
                        utf8 = g_locale_to_utf8(filez, strlen(filez), NULL, NULL, NULL);
                        gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 1, utf8, -1);

                        utf8 = g_locale_to_utf8(sizez, strlen(sizez), NULL, NULL, NULL);
                        gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 2, utf8, -1);
//printf("Right Directory:[%s] size:[%s]\n", filez, sizez);

                        utf8 = g_locale_to_utf8("D", 1, NULL, NULL, NULL);
                        gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 3, utf8, -1);
		        break; 
	             }
		  }
	       }  
	    }
	 }
         else
	    {  
	       /* These are files, put them in a buffer and insert them last */
               for(y=0; old_buffer[y]; y++)
  	       {
	          if( old_buffer[y]=='"' )
	          {
                     y=y+1;
		     begin=y;
		     for(y=y; old_buffer[y]; y++)
		     {
		        if( old_buffer[y]=='"' )
		        {
                           /* A selection to show or not to show hidden */
                           if( old_buffer[begin]=='.' && old_buffer[begin+1]!='.' && ! show_hidden )
			   break;
                           snprintf(filez, y-begin+1, "%s", old_buffer+begin);   
		           strcat(files_buffer, filez);
	                   strcat(files_buffer, "\n");
			   
                           sscanf(old_buffer, "%*s %*s %*s %*s %s", sizez);
	                   strcat(sizez_buffer, sizez);
	                   strcat(sizez_buffer, "\n");
			   
//                           printf("Right Filez:[%s] sizez:[%s]\n", filez, sizez);
		           break;
	                }
		     }

	          }  
	       }
	    }
	    attribz[0]='\0';
      }
   }  
   fclose(fp);
   free(systemz);
   free(old_buffer);
   free(attribz);
   y=0;

   /* List files in the right treeview with attrib "A" */
   while(files_buffer[z]!='\0' && sizez_buffer[y]!='\0')
   {
      filez[0]='\0';
      sizez[0]='\0';
      /* Get filesize */
      begin_sizez=y;
      for(y=y; sizez_buffer[y]; y++)
      {
         if(sizez_buffer[y]=='\n')
         {
            snprintf(sizez, y-begin_sizez+1, "%s", sizez_buffer+begin_sizez);   
            break;
         }
      }

      begin=z;
      for(z=z; files_buffer[z]; z++) 
      {
         if(files_buffer[z]=='\n')
	 {
            snprintf(filez, z-begin+1, "%s", files_buffer+begin);   
            /* Dont show links */
	    if( strstr(filez,"->")==0 && strstr(filez,"/")==0 )
	    {
               gtk_list_store_append(GTK_LIST_STORE(right_model), &iter);

               mimetypes(NULL, NULL, filez, right_path);
               if( filetype !=NULL )
               {
	          if( strstr(filetype, "movie") )
                  gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 0, movie_pixbuf, -1);
		 
	          if( strstr(filetype, "sound") )
                  gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 0, sound_pixbuf, -1);

	          if( strstr(filetype, "text") )
                  gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 0, text_pixbuf, -1);

		  if( strstr(filetype, "office") )
                  gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 0, office_pixbuf, -1);

		  if( strstr(filetype, "image") )
                  gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 0, image_pixbuf, -1);

		  if( strstr(filetype, "compressed") )
                  gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 0, compressed_pixbuf, -1);

		  if( strstr(filetype, "rpm") )
                  gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 0, rpm_pixbuf, -1);

		  if( strstr(filetype, "code") )
                  gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 0, code_pixbuf, -1);
		 		 
		  if( strstr(filetype, "data") )
                  gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 0, code_pixbuf, -1);

		  if( strstr(filetype, "elf") )
                  gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 0, elf_pixbuf, -1);
	         
		  if( strstr(filetype, "exe") )
                  gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 0, exe_pixbuf, -1);
               }
               utf8 = g_locale_to_utf8(filez, strlen(filez), NULL, NULL, NULL);
               gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 1, utf8, -1);

               utf8 = g_locale_to_utf8(sizez, strlen(sizez), NULL, NULL, NULL);
               gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 2, utf8, -1);

               utf8 = g_locale_to_utf8("A", 1, NULL, NULL, NULL);
               gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 3, utf8, -1);
//               printf("size[%s] .. file:[%s]\n", sizez, filez);
	    }
            break;
         }
      }
      z++;
      y++;
      if(files_buffer[z]=='\0')
      break;
   }
   free(files_buffer);
   free(sizez_buffer);
   strcpy(filez, "rm -f ");
   strcat(filez, tempfile);
   system(filez);   
   free(filez);
   free(sizez);
   path = gtk_tree_path_new_first(); /* This might break if permissionchecking fails ! */
   gtk_tree_view_set_cursor(GTK_TREE_VIEW(right_treeview), path, NULL, edit);
   gtk_tree_path_free(path);
   updating=0;
   listing_files=0;
}


void action_sound( char *mime_filez, char *mime_path )
{
   gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("Opening music please wait..."));
   while(gtk_events_pending ())
   gtk_main_iteration ();
   strcpy(action, music_act);
   strcat(action, " \"");
   strcat(action, mime_path);
   strcat(action, "/");
   strcat(action, mime_filez);
   strcat(action, "\" &");
   system(action);
   strcpy(action, _("Added: "));
   strcat(action, mime_filez);
   strcat(action, _(" (if the music wasnt loaded you can reconfigure the settings)."));
   gtk_entry_set_text(GTK_ENTRY(left_status_entry), action);
}


void action_movie( char *mime_filez, char *mime_path )
{
   gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("Opening movie please wait..."));
   while(gtk_events_pending ())
   gtk_main_iteration ();
   strcpy(action, video_act);
   strcat(action, " \"");
   strcat(action, mime_path);
   strcat(action, "/");
   strcat(action, mime_filez);
   strcat(action, "\" &");
   system(action);
   strcpy(action, _("Played: "));
   strcat(action, mime_filez);
   strcat(action, _(" (if the movie didnt show you can reconfigure the settings)."));
   gtk_entry_set_text(GTK_ENTRY(left_status_entry), action);
}


void action_image( char *mime_filez, char *mime_path )
{
   gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("Opening image please wait..."));
   while(gtk_events_pending ())
   gtk_main_iteration ();
   strcpy(action, graphics_act);
   strcat(action, " \"");
   strcat(action, mime_path);
   strcat(action, "/");
   strcat(action, mime_filez);
   strcat(action, "\" &");
   system(action);
   strcpy(action, _("Showed: "));
   strcat(action, mime_filez);
   strcat(action, _(" (if the image didnt show you can reconfigure the settings)."));
   gtk_entry_set_text(GTK_ENTRY(left_status_entry), action);
}

      
void action_plain_text( char *mime_filez, char *mime_path )
{
   gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("Opening textfile please wait..."));
   while(gtk_events_pending ())
   gtk_main_iteration ();
   strcpy(action, text_act);
   strcat(action, " \"");
   strcat(action, mime_path);
   strcat(action, "/");
   strcat(action, mime_filez);
   strcat(action, "\" &");
   system(action);
   strcpy(action, _("Opened: "));
   strcat(action, mime_filez);
   strcat(action, _(" (if the textfile didnt show you can reconfigure the settings)."));
   gtk_entry_set_text(GTK_ENTRY(left_status_entry), action);
}


void action_document( char *mime_filez, char *mime_path )
{
   gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("Opening document please wait..."));
   while(gtk_events_pending ())
   gtk_main_iteration ();
   strcpy(action, document_act);
   strcat(action, " \"");
   strcat(action, mime_path);
   strcat(action, "/");
   strcat(action, mime_filez);
   strcat(action, "\" &");
   system(action);
   strcpy(action, _("Opened: "));
   strcat(action, mime_filez);
   strcat(action, _(" (if the document didnt show you can reconfigure the settings)."));
   gtk_entry_set_text(GTK_ENTRY(left_status_entry), action);
}

      
void action_spreadsheet( char *mime_filez, char *mime_path )
{
   gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("Opening spreadsheet please wait..."));
   while(gtk_events_pending ())
   gtk_main_iteration ();
   strcpy(action, spread_act);
   strcat(action, " \"");
   strcat(action, mime_path);
   strcat(action, "/");
   strcat(action, mime_filez);
   strcat(action, "\" &");
   system(action);
   strcpy(action, _("Opened: "));
   strcat(action, mime_filez);
   strcat(action, _(" (if the spreadsheet didnt show you can reconfigure the settings)."));
   gtk_entry_set_text(GTK_ENTRY(left_status_entry), action);
}


void action_webcode( char *mime_filez, char *mime_path )
{
   gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("Opening webcode please wait..."));
   while(gtk_events_pending ())
   gtk_main_iteration ();
   strcpy(action, webcode_act);
   strcat(action, " \"");
   strcat(action, mime_path);
   strcat(action, "/");
   strcat(action, mime_filez);
   strcat(action, "\""); 
   /* The last \" is there because of the open -e thing */
   if( strstr(webcode_act,"\"") )
   {
     strcat(action, "\" &");
   }
   else
     strcat(action, " &");
   system(action);
   strcpy(action, _("Opened: "));
   strcat(action, _(" (if the webcode didnt show you can reconfigure the settings)."));
   gtk_entry_set_text(GTK_ENTRY(left_status_entry), action);
}


void action_sourcecode( char *mime_filez, char *mime_path )
{
   gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("Opening sourcecode please wait...") );
   while(gtk_events_pending ())
   gtk_main_iteration ();
   strcpy(action, sourcecode_act);
   strcat(action, " \"");
   strcat(action, mime_path);
   strcat(action, "/");
   strcat(action, mime_filez);
   strcat(action, "\""); 
   /* The last \" is there because of the open -e thing */
   if( strstr(sourcecode_act,"\"") )
   {
     strcat(action, "\" &");
   }
   else
     strcat(action, " &");
   system(action);
   strcpy(action, _("Opened: "));
   strcat(action, mime_filez);
   strcat(action, _(" (if the sourcecode didnt show you can reconfigure the settings)."));
   gtk_entry_set_text(GTK_ENTRY(left_status_entry), action);
}


void action_exe( char *mime_filez, char *mime_path )
{
   gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("Running exe please wait...") );
   while(gtk_events_pending ())
   gtk_main_iteration ();
   // file stat (wine or winex)
   strcpy(action, "wine -winver win98");
   strcat(action, " \"");
   strcat(action, mime_path);
   strcat(action, "/");
   strcat(action, mime_filez);
   strcat(action, "\""); // & ?
   system(action);
   strcpy(action, _("Opened: "));
   strcat(action, mime_filez);
   gtk_entry_set_text(GTK_ENTRY(left_status_entry), action);
}


void action_elf( char *mime_filez, char *mime_path )
{
   gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("Running binary please wait...") );
   while(gtk_events_pending ())
   gtk_main_iteration ();
   strcpy(action, "\"");
   strcat(action, mime_path);
   strcat(action, "/./");
   strcat(action, mime_filez);
   strcat(action, "\" &"); 
   system(action);
   strcpy(action, _("Opened: "));
   strcat(action, mime_filez);
   gtk_entry_set_text(GTK_ENTRY(left_status_entry), action);
}


/* Used to determine filetype icon when listing and the appropriate file action */
void mimetypes( GtkWidget *widget, gpointer user_data, char *filez, char *path )
{
   FILE *fp;
   char mime_buffy[8192]="";
   char mime_combo[8192]="";
   strcpy(mime_combo, "file \"");
   strcat(mime_combo, path);
   strcat(mime_combo, "/");
   strcat(mime_combo, filez);
   strcat(mime_combo, "\"");
   strcpy(filetype, "");

   /* MP3 */      
   if( filez[strlen(filez)-4]=='.' && ( filez[strlen(filez)-3]=='M'   ||  filez[strlen(filez)-3]=='m' )
   &&( filez[strlen(filez)-2]=='P' ||   filez[strlen(filez)-2]=='p' ) &&  filez[strlen(filez)-1]=='3' )
   {
      if( listing_files==0 )
      action_sound( filez, path );
      strcpy(filetype, "sound");
      return;
   }

   /* OGG */
   if( filez[strlen(filez)-4]=='.' && ( filez[strlen(filez)-3]=='O'   ||  filez[strlen(filez)-3]=='o' )
   &&( filez[strlen(filez)-2]=='G' ||   filez[strlen(filez)-2]=='g' ) && (filez[strlen(filez)-1]=='G' || filez[strlen(filez)-1]=='g') )
   {
      if( listing_files==0 )
      action_sound( filez, path );
      strcpy(filetype, "sound");
      return;
   }

   /* WAV */
   if( filez[strlen(filez)-4]=='.' && ( filez[strlen(filez)-3]=='W'   ||  filez[strlen(filez)-3]=='w' )
   &&( filez[strlen(filez)-2]=='A' ||   filez[strlen(filez)-2]=='a' ) && (filez[strlen(filez)-1]=='V' || filez[strlen(filez)-1]=='v') )
   {
      if( listing_files==0 )
      action_sound( filez, path );
      strcpy(filetype, "sound");
      return;
   }

   /* PCM */
   if( filez[strlen(filez)-4]=='.' && ( filez[strlen(filez)-3]=='P'   ||  filez[strlen(filez)-3]=='p' )
   &&( filez[strlen(filez)-2]=='C' ||   filez[strlen(filez)-2]=='c' ) && (filez[strlen(filez)-1]=='M' || filez[strlen(filez)-1]=='m') )
   {
      if( listing_files==0 )
      action_sound( filez, path );
      strcpy(filetype, "sound");
      return;
   }

   /* AVI */
   if( filez[strlen(filez)-4]=='.' && ( filez[strlen(filez)-3]=='A'   ||  filez[strlen(filez)-3]=='a' )
   &&( filez[strlen(filez)-2]=='V' ||   filez[strlen(filez)-2]=='v' ) && (filez[strlen(filez)-1]=='I' || filez[strlen(filez)-1]=='i') )
   {
      if( listing_files==0 )
      action_movie( filez, path );
      strcpy(filetype, "movie");
      return;
   }

   /* MPG */
   if( filez[strlen(filez)-4]=='.' && ( filez[strlen(filez)-3]=='M'   ||  filez[strlen(filez)-3]=='m' )
   &&( filez[strlen(filez)-2]=='P' ||   filez[strlen(filez)-2]=='p' ) && (filez[strlen(filez)-1]=='G' || filez[strlen(filez)-1]=='g') )
   {
      if( listing_files==0 )
      action_movie( filez, path );
      strcpy(filetype, "movie");
      return;
   }

   /* JPG */
   if( filez[strlen(filez)-4]=='.' && ( filez[strlen(filez)-3]=='J'   ||  filez[strlen(filez)-3]=='j' )
   &&( filez[strlen(filez)-2]=='P' ||   filez[strlen(filez)-2]=='p' ) && (filez[strlen(filez)-1]=='G' || filez[strlen(filez)-1]=='g') )
   {
      if( listing_files==0 )
      action_image( filez, path );
      strcpy(filetype, "image");
      return;
   }

   /* PNG */
   if( filez[strlen(filez)-4]=='.' && ( filez[strlen(filez)-3]=='P'   ||  filez[strlen(filez)-3]=='p' )
   &&( filez[strlen(filez)-2]=='N' ||   filez[strlen(filez)-2]=='n' ) && (filez[strlen(filez)-1]=='G' || filez[strlen(filez)-1]=='g') )
   {
      if( listing_files==0 )
      action_image( filez, path );
      strcpy(filetype, "image");
      return;
   }

   /* XPM */
   if( filez[strlen(filez)-4]=='.' && ( filez[strlen(filez)-3]=='X'   ||  filez[strlen(filez)-3]=='x' )
   &&( filez[strlen(filez)-2]=='P' ||   filez[strlen(filez)-2]=='p' ) && (filez[strlen(filez)-1]=='M' || filez[strlen(filez)-1]=='m') )
   {
      if( listing_files==0 )
      action_image( filez, path );
      strcpy(filetype, "image");
      return;
   }
      
   /* GIF */
   if( filez[strlen(filez)-4]=='.' && ( filez[strlen(filez)-3]=='G'   ||  filez[strlen(filez)-3]=='g' )
   &&( filez[strlen(filez)-2]=='I' ||   filez[strlen(filez)-2]=='i' ) && (filez[strlen(filez)-1]=='F' || filez[strlen(filez)-1]=='f') )
   {
      if( ! listing_files )
      action_image( filez, path );
      strcpy(filetype, "image");
      return;
   }

   /* BMP */
   if( filez[strlen(filez)-4]=='.' && ( filez[strlen(filez)-3]=='B'   ||  filez[strlen(filez)-3]=='b' )
   &&( filez[strlen(filez)-2]=='M' ||   filez[strlen(filez)-2]=='m' ) && (filez[strlen(filez)-1]=='P' || filez[strlen(filez)-1]=='p') )
   {
      if( ! listing_files )
      action_image( filez, path );
      strcpy(filetype, "image");
      return;
   }

   /* DOC */
   if( filez[strlen(filez)-4]=='.' && ( filez[strlen(filez)-3]=='D'   ||  filez[strlen(filez)-3]=='d' )
   &&( filez[strlen(filez)-2]=='O' ||   filez[strlen(filez)-2]=='o' ) && (filez[strlen(filez)-1]=='C' || filez[strlen(filez)-1]=='c') )
   {
      if( ! listing_files )
      action_document( filez, path );
      strcpy(filetype, "office");
      return;
   }

   /* SXW */
   if( filez[strlen(filez)-4]=='.' && ( filez[strlen(filez)-3]=='S'   ||  filez[strlen(filez)-3]=='s' )
   &&( filez[strlen(filez)-2]=='X' ||   filez[strlen(filez)-2]=='x' ) && (filez[strlen(filez)-1]=='W' || filez[strlen(filez)-1]=='w') )
   {
      if( ! listing_files )
      action_document( filez, path );
      strcpy(filetype, "office");
      return;
   }

   /* XLS */
   if( filez[strlen(filez)-4]=='.' && ( filez[strlen(filez)-3]=='X'   ||  filez[strlen(filez)-3]=='x' )
   &&( filez[strlen(filez)-2]=='L' ||   filez[strlen(filez)-2]=='l' ) && (filez[strlen(filez)-1]=='S' || filez[strlen(filez)-1]=='s') )
   {
      if( ! listing_files )
      action_spreadsheet( filez, path );
      strcpy(filetype, "office");
      return;
   }

   /* SXC */
   if( filez[strlen(filez)-4]=='.' && ( filez[strlen(filez)-3]=='S'   ||  filez[strlen(filez)-3]=='s' )
   &&( filez[strlen(filez)-2]=='X' ||   filez[strlen(filez)-2]=='x' ) && (filez[strlen(filez)-1]=='C' || filez[strlen(filez)-1]=='c') )
   {
      if( ! listing_files )
      action_spreadsheet( filez, path );
      strcpy(filetype, "office");
      return;
   }


   /* .RPM archive handler popup */
   if( filez[strlen(filez)-4]=='.' && ( filez[strlen(filez)-3]=='R'   ||  filez[strlen(filez)-3]=='r' )
   &&( filez[strlen(filez)-2]=='P' ||   filez[strlen(filez)-2]=='p' ) && (filez[strlen(filez)-1]=='M' || filez[strlen(filez)-1]=='m') )
   {
      strcpy(filetype, "compressed");
      if( ! listing_files )
      {
         strcpy(filetype, "rpm");
         gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("Querying archive please wait..."));
         while( gtk_events_pending() )
         gtk_main_iteration ();
         strcpy(action, "rpm -qpi \"");
         strcat(action, path);
         strcat(action, "/");
         strcat(action, filez);
         strcat(action, "\" > ");
         strcat(action, homedirectory);
         strcat(action, "/");
         strcat(action, ".gfilemanager/");
         strcat(action, "archive_query");
         system(action);
         /* Used with the popup */
         strcpy(temppath, path);
         strcpy(tempfile, filez);
         archive_window=create_archive_window();
         gtk_widget_show(archive_window);
      }
      return;
   }


   /* .DEB archive handler popup */
   if( filez[strlen(filez)-4]=='.' && ( filez[strlen(filez)-3]=='D'   ||  filez[strlen(filez)-3]=='d' )
   &&( filez[strlen(filez)-2]=='E' ||   filez[strlen(filez)-2]=='e' ) && (filez[strlen(filez)-1]=='B' || filez[strlen(filez)-1]=='b') )
   {
      strcpy(filetype, "compressed");
      if( ! listing_files )
      {
         strcpy(filetype, "deb");
         gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("Querying archive please wait..."));
         while( gtk_events_pending() )
         gtk_main_iteration ();
         strcpy(action, "dpkg --contents \"");
         strcat(action, path);
         strcat(action, "/");
         strcat(action, filez);
         strcat(action, "\" > ");
         strcat(action, homedirectory);
         strcat(action, "/");
         strcat(action, ".gfilemanager/");
         strcat(action, "archive_query");
         system(action);
         /* Used with the popup */
         strcpy(temppath, path);
         strcpy(tempfile, filez);
         archive_window=create_archive_window();
         gtk_widget_show(archive_window);
      }
      return;
   }


   /* .TAR.GZ archive handler popup */
   if( filez[strlen(filez)-7]=='.'  && ( filez[strlen(filez)-6]=='T'   ||  filez[strlen(filez)-6]=='t' )
   &&( filez[strlen(filez)-5]=='A'  ||   filez[strlen(filez)-5]=='a' ) && (filez[strlen(filez)-4]=='R' || filez[strlen(filez)-4]=='r' )
   &&  filez[strlen(filez)-3]=='.'  && ( filez[strlen(filez)-2]=='G'   || filez[strlen(filez)-2]=='g' )
   &&( filez[strlen(filez)-1]=='Z'  ||   filez[strlen(filez)-1]=='z' )  )
   {
      strcpy(filetype, "compressed");
      if( ! listing_files )
      {
         strcpy(filetype, ".tar.gz");
         gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("Querying archive please wait..."));
         while( gtk_events_pending() )
         gtk_main_iteration ();
         strcpy(action, "tar -tzvf \"");
         strcat(action, path);
         strcat(action, "/");
         strcat(action, filez);
         strcat(action, "\" | zcat -f > ");
         strcat(action, homedirectory);
         strcat(action, "/");
         strcat(action, ".gfilemanager/");
         strcat(action, "archive_query");
         system(action);
         /* Used with the popup */
         strcpy(temppath, path);
         strcpy(tempfile, filez);
         archive_window=create_archive_window();
         label60 = lookup_widget(GTK_WIDGET (archive_window), "label60");
	 gtk_label_set_label(GTK_LABEL(label60), _("Unpack"));
         gtk_widget_show(archive_window);
      }
      return;
   }


   /* .TAR archive handler popup */
   if( filez[strlen(filez)-4]=='.' 
   &&( filez[strlen(filez)-3]=='T'  ||   filez[strlen(filez)-3]=='t' )
   &&( filez[strlen(filez)-2]=='A'  ||   filez[strlen(filez)-2]=='a' )
   &&( filez[strlen(filez)-1]=='R'  ||   filez[strlen(filez)-1]=='r' ) )
   {
      strcpy(filetype, "compressed");
      if( ! listing_files )
      {
         strcpy(filetype, ".tar");
         gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("Querying archive please wait..."));
         while( gtk_events_pending() )
         gtk_main_iteration ();
         strcpy(action, "tar -tvf \"");
         strcat(action, path);
         strcat(action, "/");
         strcat(action, filez);
         strcat(action, "\" > ");
         strcat(action, homedirectory);
         strcat(action, "/");
         strcat(action, ".gfilemanager/");
         strcat(action, "archive_query 2>&1");
         system(action);
         /* Used with the popup */
         strcpy(temppath, path);
         strcpy(tempfile, filez);
         archive_window=create_archive_window();
         label60 = lookup_widget(GTK_WIDGET (archive_window), "label60");
	 gtk_label_set_label(GTK_LABEL(label60), _("Unpack"));
         gtk_widget_show(archive_window);
      }
      return;
   }


   /* RAR archive handler popup */ 
   if( filez[strlen(filez)-4]=='.' && ( filez[strlen(filez)-3]=='R' || filez[strlen(filez)-3]=='r' ) 
   &&( filez[strlen(filez)-2]=='A' || filez[strlen(filez)-2]=='a' ) && ( filez[strlen(filez)-1]=='R' || filez[strlen(filez)-1]=='r' ) )
   {
      strcpy(filetype, "compressed");
      if( ! listing_files )
      {
         printf("RAR for Linux is not free, it will stop working in 40 days unless you buy it.\n");
         printf("You can download it at www.rarlab.com.\n");
         strcpy(filetype, "rar");
         gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("Querying Nonfree archive please wait..."));
         while( gtk_events_pending() )
         gtk_main_iteration ();
         strcpy(action, "rar v \"");
         strcat(action, path);
         strcat(action, "/");
         strcat(action, filez);
         strcat(action, "\" > ");
         strcat(action, homedirectory);
         strcat(action, "/");
         strcat(action, ".gfilemanager/");
         strcat(action, "archive_query");
         system(action);
         /* Used with the popup */
         strcpy(temppath, path);
         strcpy(tempfile, filez);
         archive_window=create_archive_window();
         label60 = lookup_widget(GTK_WIDGET (archive_window), "label60");
	 gtk_label_set_label(GTK_LABEL(label60), _("Unpack"));
         gtk_widget_show(archive_window);
      }
      return;
   }


   /* ZIP archive handler popup */ 
   if( filez[strlen(filez)-4]=='.' && ( filez[strlen(filez)-3]=='Z' || filez[strlen(filez)-3]=='z' ) 
   &&( filez[strlen(filez)-2]=='I' || filez[strlen(filez)-2]=='i' ) && ( filez[strlen(filez)-1]=='P' || filez[strlen(filez)-1]=='p' ) )
   {
      strcpy(filetype, "compressed");
      if( ! listing_files )
      {
         strcpy(filetype, "zip");
         gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("Querying archive please wait..."));
         while( gtk_events_pending() )
         gtk_main_iteration ();
         strcpy(action, "unzip -l \"");
         strcat(action, path);
         strcat(action, "/");
         strcat(action, filez);
         strcat(action, "\" > ");
         strcat(action, homedirectory);
         strcat(action, "/");
         strcat(action, ".gfilemanager/");
         strcat(action, "archive_query");
         system(action);
         /* Used with the popup */
         strcpy(temppath, path);
         strcpy(tempfile, filez);
         archive_window=create_archive_window();
         label60 = lookup_widget(GTK_WIDGET (archive_window), "label60");
	 gtk_label_set_label(GTK_LABEL(label60), _("Unpack"));
         gtk_widget_show(archive_window);
      }
      return;
   }


   /* .GZ archive handlerpopup */ 
   if( filez[strlen(filez)-3]=='.' && ( filez[strlen(filez)-2]=='G' || filez[strlen(filez)-2]=='g' ) 
   &&( filez[strlen(filez)-1]=='Z' || filez[strlen(filez)-1]=='z' ) )
   {
      strcpy(filetype, "compressed");
      if( ! listing_files )
      {
         strcpy(filetype, ".gz");
         gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("Querying archive please wait..."));
         while( gtk_events_pending() )
         gtk_main_iteration ();
         strcpy(action, "gunzip -cd \"");
         strcat(action, path);
         strcat(action, "/");
         strcat(action, filez);
         strcat(action, "\" | zcat -f > ");
         strcat(action, homedirectory);
         strcat(action, "/");
         strcat(action, ".gfilemanager/");
         strcat(action, "archive_query");
         system(action);
         /* Used with the popup */
         strcpy(temppath, path);
         strcpy(tempfile, filez);
         archive_window=create_archive_window();
         label60 = lookup_widget(GTK_WIDGET (archive_window), "label60");
	 gtk_label_set_label(GTK_LABEL(label60), _("Unpack"));
         gtk_widget_show(archive_window);
      }
      return;
   }


   /* .TAR.BZ2 archive handler popup */ 
   if( filez[strlen(filez)-4]=='.' && ( filez[strlen(filez)-3]=='B' || filez[strlen(filez)-3]=='b' ) 
   &&( filez[strlen(filez)-2]=='Z' || filez[strlen(filez)-2]=='z' ) && filez[strlen(filez)-1]=='2' )
   {
      strcpy(filetype, "compressed");
      if( ! listing_files )
      {
         strcpy(filetype, ".tar.bz2");
         gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("Querying archive please wait..."));
         while( gtk_events_pending() )
         gtk_main_iteration ();
         strcpy(action, "tar -tvf \"");
         strcat(action, path);
         strcat(action, "/");
         strcat(action, filez);
         strcat(action, "\" --use-compress-program bzip2 > ");
         strcat(action, homedirectory);
         strcat(action, "/");
         strcat(action, ".gfilemanager/");
         strcat(action, "archive_query");
         system(action);
         /* Used with the popup */
         strcpy(temppath, path);
         strcpy(tempfile, filez);
         archive_window=create_archive_window();
         label60 = lookup_widget(GTK_WIDGET (archive_window), "label60");
	 gtk_label_set_label(GTK_LABEL(label60), _("Unpack"));
         gtk_widget_show(archive_window);
      }
      return;
   }


   /* .C file */
   if( filez[strlen(filez)-2]=='.' && ( filez[strlen(filez)-1]=='C' || filez[strlen(filez)-1]=='c' ) ) 
   {
      if( listing_files==0 )
      action_sourcecode( filez, path );
      strcpy(filetype, "code");
      return;
   }
   
   /* .H file */
   if( filez[strlen(filez)-2]=='.' && ( filez[strlen(filez)-1]=='H' || filez[strlen(filez)-1]=='h' ) ) 
   {
      if( listing_files==0 )
      action_sourcecode( filez, path );
      strcpy(filetype, "code");
      return;
   }
   
   /* .IN file */
   if( filez[strlen(filez)-3]=='.' && ( filez[strlen(filez)-2]=='I' || filez[strlen(filez)-2]=='i' )
   && ( filez[strlen(filez)-1]=='N' || filez[strlen(filez)-1]=='n' ) ) 
   {
      if( listing_files==0 )
      action_sourcecode( filez, path );
      strcpy(filetype, "code");
      return;
   }
   
   /* .AM file */
   if( filez[strlen(filez)-3]=='.' && ( filez[strlen(filez)-2]=='A' || filez[strlen(filez)-2]=='a' )
   && ( filez[strlen(filez)-1]=='M' || filez[strlen(filez)-1]=='m' ) ) 
   {
      if( listing_files==0 )
      action_sourcecode( filez, path );
      strcpy(filetype, "code");
      return;
   }
   
   /* CC file */
   if( filez[strlen(filez)-3]=='.' && ( filez[strlen(filez)-2]=='C' || filez[strlen(filez)-2]=='c' )
   &&( filez[strlen(filez)-1]=='C' || filez[strlen(filez)-1]=='c' ) ) 
   {
      if( listing_files==0 )
      action_sourcecode( filez, path );
      strcpy(filetype, "code");
      return;
   }

   /* PL file */ 
   if( filez[strlen(filez)-3]=='.' && ( filez[strlen(filez)-2]=='P' || filez[strlen(filez)-2]=='p' ) 
   &&( filez[strlen(filez)-1]=='L' || filez[strlen(filez)-1]=='l' ) )
   {
      if( listing_files==0 )
      action_sourcecode( filez, path );
      strcpy(filetype, "code");
      return;
   }

   /* PHP file */ 
   if( filez[strlen(filez)-4]=='.' && ( filez[strlen(filez)-3]=='P' || filez[strlen(filez)-3]=='p' ) 
   &&( filez[strlen(filez)-2]=='H' || filez[strlen(filez)-2]=='h' ) && ( filez[strlen(filez)-1]=='P' || filez[strlen(filez)-1]=='p' ) )
   {
      if( listing_files==0 )
      action_webcode( filez, path );
      strcpy(filetype, "code");
      return;
   }

   /* HTML file */ 
   if( filez[strlen(filez)-5]=='.' && ( filez[strlen(filez)-4]=='H' || filez[strlen(filez)-4]=='h' ) 
   &&( filez[strlen(filez)-3]=='T' || filez[strlen(filez)-3]=='t' ) 
   &&( filez[strlen(filez)-2]=='M' || filez[strlen(filez)-2]=='m' ) )
   {
      if( listing_files==0 )
      action_webcode( filez, path );
      strcpy(filetype, "code");
      return;
   }

   /* HTM file */ 
   if( filez[strlen(filez)-4]=='.' && ( filez[strlen(filez)-3]=='H' || filez[strlen(filez)-3]=='h' ) 
   &&( filez[strlen(filez)-2]=='T' || filez[strlen(filez)-2]=='t' ) 
   &&( filez[strlen(filez)-1]=='M' || filez[strlen(filez)-1]=='m' ) )
   {
      if( listing_files==0 )
      action_webcode( filez, path );
      strcpy(filetype, "code");
      return;
   }

   /* .exe */ 
   if( filez[strlen(filez)-4]=='.' && ( filez[strlen(filez)-3]=='E' || filez[strlen(filez)-3]=='e' ) 
   &&( filez[strlen(filez)-2]=='X' || filez[strlen(filez)-2]=='x' ) 
   &&( filez[strlen(filez)-1]=='E' || filez[strlen(filez)-1]=='e' ) )
   {
      if( listing_files==0 )
      action_exe( filez, path );
      strcpy(filetype, "exe");
      return;
   }

   /* Extended mimetype check (takes care of all unspecified things) */
   if((fp = popen(mime_combo, "r"))==NULL)
   {
      printf("\nError opening mimefile\n");
      return; 
   }
   while((fgets(mime_buffy, 8192, fp)!=NULL))
   {
      if( strstr(mime_buffy, "text") || strstr(mime_buffy, "empty") 
      ||  strstr(mime_buffy, "script") || strstr(mime_buffy, "instruction") )
      {
         if( listing_files==0 )
         action_plain_text( filez, path );
         strcpy(filetype, "text");
	 break;
      }

      if( strstr(mime_buffy, "ELF") )
      {
         if( listing_files==0 )
         action_elf( filez, path );
         strcpy(filetype, "elf");
	 break;
      }

      if( strstr(mime_buffy, "data") )
      {
         if( listing_files==0 )
         action_sourcecode( filez, path );
         strcpy(filetype, "data");
	 break;
      }
      /* Hmm, insert a link image maybe */
      if( strstr(mime_buffy, "link") )
      {
         if( listing_files==0 )
         action_sourcecode( filez, path );
         strcpy(filetype, "link");
	 break;
      }
   }
   pclose(fp);
}  /* End of mimetypes */


void
on_left_treeview_map                  (GtkWidget       *widget,
                                        gpointer         user_data)
{
   /* Setup both treeview's, append files and directories set pixmaps and paths. */
   GtkListStore *left_model, *right_model;
   GtkCellRenderer *cell;
   GtkTreeViewColumn *file_column, *attrib_column, *size_column, *pixmap_column;

   /* Setup the main window icon */
   pixmap_cell = gtk_cell_renderer_pixbuf_new();
   main_window_pixbuf=gdk_pixbuf_new_from_file("/usr/share/pixmaps/gfilemanager.png", NULL);
   g_object_set(pixmap_cell, "pixbuf", main_window_pixbuf, NULL);
   
   main_window = lookup_widget (GTK_WIDGET (widget), "main_window");
   gtk_window_set_icon (GTK_WINDOW (main_window), main_window_pixbuf);
   gdk_pixbuf_unref (main_window_pixbuf);



   /* Setup the pixmaps for mountables */
   pixmap_cell = gtk_cell_renderer_pixbuf_new();
   cdrom_pixbuf=gdk_pixbuf_new_from_file("/usr/share/pixmaps/gfilemanager/gfilemanager_cdrom.png", NULL);
   g_object_set(pixmap_cell, "pixbuf", cdrom_pixbuf, NULL);
   pixmap_cell = gtk_cell_renderer_pixbuf_new();
   floppy_pixbuf=gdk_pixbuf_new_from_file("/usr/share/pixmaps/gfilemanager/gfilemanager_floppy.png", NULL);
   g_object_set(pixmap_cell, "pixbuf", floppy_pixbuf, NULL);

   /* Setup the pixmaps for directories */
   pixmap_cell = gtk_cell_renderer_pixbuf_new();
   dir_pixbuf=gdk_pixbuf_new_from_file("/usr/share/pixmaps/gfilemanager/gfilemanager_dir.png", NULL);
   g_object_set(pixmap_cell, "pixbuf", dir_pixbuf, NULL);

   /* Setup the pixmaps for files */
   pixmap_cell = gtk_cell_renderer_pixbuf_new();
   text_pixbuf=gdk_pixbuf_new_from_file("/usr/share/pixmaps/gfilemanager/gfilemanager_text.png", NULL);
   g_object_set(pixmap_cell, "pixbuf", text_pixbuf, NULL);

   pixmap_cell = gtk_cell_renderer_pixbuf_new();
   movie_pixbuf=gdk_pixbuf_new_from_file("/usr/share/pixmaps/gfilemanager/gfilemanager_movie.png", NULL);
   g_object_set(pixmap_cell, "pixbuf", movie_pixbuf, NULL);

   pixmap_cell = gtk_cell_renderer_pixbuf_new();
   sound_pixbuf=gdk_pixbuf_new_from_file("/usr/share/pixmaps/gfilemanager/gfilemanager_sound.png", NULL);
   g_object_set(pixmap_cell, "pixbuf", sound_pixbuf, NULL);

   pixmap_cell = gtk_cell_renderer_pixbuf_new();
   image_pixbuf=gdk_pixbuf_new_from_file("/usr/share/pixmaps/gfilemanager/gfilemanager_image.png", NULL);
   g_object_set(pixmap_cell, "pixbuf", image_pixbuf, NULL);

   pixmap_cell = gtk_cell_renderer_pixbuf_new();
   office_pixbuf=gdk_pixbuf_new_from_file("/usr/share/pixmaps/gfilemanager/gfilemanager_office.png", NULL);
   g_object_set(pixmap_cell, "pixbuf", office_pixbuf, NULL);

   pixmap_cell = gtk_cell_renderer_pixbuf_new();
   compressed_pixbuf=gdk_pixbuf_new_from_file("/usr/share/pixmaps/gfilemanager/gfilemanager_compressed.png", NULL);
   g_object_set(pixmap_cell, "pixbuf", compressed_pixbuf, NULL);

   pixmap_cell = gtk_cell_renderer_pixbuf_new();
   rpm_pixbuf=gdk_pixbuf_new_from_file("/usr/share/pixmaps/gfilemanager/gfilemanager_rpm.png", NULL);
   g_object_set(pixmap_cell, "pixbuf", rpm_pixbuf, NULL);

   pixmap_cell = gtk_cell_renderer_pixbuf_new();
   code_pixbuf=gdk_pixbuf_new_from_file("/usr/share/pixmaps/gfilemanager/gfilemanager_code.png", NULL);
   g_object_set(pixmap_cell, "pixbuf", code_pixbuf, NULL);

   pixmap_cell = gtk_cell_renderer_pixbuf_new();
   elf_pixbuf=gdk_pixbuf_new_from_file("/usr/share/pixmaps/gfilemanager/gfilemanager_elf.png", NULL);
   g_object_set(pixmap_cell, "pixbuf", elf_pixbuf, NULL);

   pixmap_cell = gtk_cell_renderer_pixbuf_new();
   exe_pixbuf=gdk_pixbuf_new_from_file("/usr/share/pixmaps/gfilemanager/gfilemanager_exe.png", NULL);
   g_object_set(pixmap_cell, "pixbuf", exe_pixbuf, NULL);




   left_treeview = lookup_widget (GTK_WIDGET (widget), "left_treeview");
   right_treeview = lookup_widget (GTK_WIDGET (widget), "right_treeview");

   left_model = gtk_list_store_new(4, GDK_TYPE_PIXBUF, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
   right_model = gtk_list_store_new(4, GDK_TYPE_PIXBUF, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

   gtk_tree_view_set_model(GTK_TREE_VIEW(left_treeview), GTK_TREE_MODEL (left_model));
   gtk_tree_view_set_model(GTK_TREE_VIEW(right_treeview), GTK_TREE_MODEL (right_model));
   cell = gtk_cell_renderer_text_new();

   /* Setup the left treeview */
   pixmap_column = gtk_tree_view_column_new_with_attributes(" ", pixmap_cell, "pixbuf", 0, NULL);
   file_column = gtk_tree_view_column_new_with_attributes(_("File"), cell, "text", 1, NULL);
   size_column = gtk_tree_view_column_new_with_attributes(_("Size"), cell, "text", 2, NULL);
   attrib_column = gtk_tree_view_column_new_with_attributes(_("Attribute"), cell, "text", 3, NULL);

   gtk_tree_view_append_column(GTK_TREE_VIEW(left_treeview), GTK_TREE_VIEW_COLUMN(pixmap_column));
   gtk_tree_view_append_column(GTK_TREE_VIEW(left_treeview), GTK_TREE_VIEW_COLUMN(file_column));
   gtk_tree_view_append_column(GTK_TREE_VIEW(left_treeview), GTK_TREE_VIEW_COLUMN(size_column));
   gtk_tree_view_append_column(GTK_TREE_VIEW(left_treeview), GTK_TREE_VIEW_COLUMN(attrib_column));

   /* Set up the right treeview */
   pixmap_column = gtk_tree_view_column_new_with_attributes(" ", pixmap_cell, "pixbuf", 0, NULL);
   file_column = gtk_tree_view_column_new_with_attributes(_("File"), cell, "text", 1, NULL);
   size_column = gtk_tree_view_column_new_with_attributes(_("Size"), cell, "text", 2, NULL);
   attrib_column = gtk_tree_view_column_new_with_attributes(_("Attribute"), cell, "text", 3, NULL);

   gtk_tree_view_append_column(GTK_TREE_VIEW(right_treeview), GTK_TREE_VIEW_COLUMN(pixmap_column));
   gtk_tree_view_append_column(GTK_TREE_VIEW(right_treeview), GTK_TREE_VIEW_COLUMN(file_column));
   gtk_tree_view_append_column(GTK_TREE_VIEW(right_treeview), GTK_TREE_VIEW_COLUMN(size_column));
   gtk_tree_view_append_column(GTK_TREE_VIEW(right_treeview), GTK_TREE_VIEW_COLUMN(attrib_column));

   /* Get the users home directory and the specified file action settings */
   strcpy(homedirectory, g_get_home_dir() );
   strcpy(tempfile, homedirectory);
   strcat(tempfile, "/.gfilemanager/tempfile");
   strcpy(settings, homedirectory);
   strcat(settings, "/.gfilemanager/settings");
//   printf("Your \"perform action on left doubleclick settings\" are here:[%s]\n\n", settings);
   read_settings();
   list_left(left_treeview, NULL);
}


void 
list_remote(GtkWidget *widget, gpointer user_data)
{
   FILE *fp;
   char *filez, *attribz, *sizez, *old_buffer, *cut, 
        *connect, *attr_buffy, *noattr_buffy, *attr_files, *noattr_files;
   long siz;
   GtkTreeIter iter;
   GtkTreeModel *right_model;
   GtkTreePath *path;
   gboolean edit=0;
   int directory=0, int_total_space=0, int_free_space=0, int_tot_blocks=0, int_of_size=0, int_blocks_avail=0; // ,one_time=1;
   int i=1, z=0, x, y, a, begin, two_dots=0;
   char tot_blocks[1024]="", of_size[1024]="", blocks_avail[1024]="", total_space[1024]="", free_space[1024]="", statusbuffer[8192]="";
   gchar *utf8=NULL;
   G_CONST_RETURN gchar *gtk_ip;
   G_CONST_RETURN gchar *gtk_share;
   G_CONST_RETURN gchar *gtk_username;
   G_CONST_RETURN gchar *gtk_password;

   right_path_entry  = lookup_widget (GTK_WIDGET (right_treeview), "right_path_entry");
   left_status_entry  = lookup_widget (GTK_WIDGET (right_treeview), "left_status_entry");
   right_status_entry  = lookup_widget (GTK_WIDGET (right_treeview), "right_status_entry");
   gtk_ip = gtk_entry_get_text(GTK_ENTRY(ip_entry));
   gtk_share = gtk_entry_get_text(GTK_ENTRY(share_entry));
   gtk_username = gtk_entry_get_text(GTK_ENTRY(user_entry));
   gtk_password = gtk_entry_get_text(GTK_ENTRY(password_entry));

   filez=(char *)malloc(8192);
   bzero(filez, 8192);
   attribz=(char *)malloc(8192);     
   bzero(attribz, 8192);
   sizez=(char *)malloc(8192);
   bzero(sizez, 8192);
   cut=(char *)malloc(8192);
   bzero(cut, 8192);

   clear_right(right_treeview, NULL);
   right_model = gtk_tree_view_get_model(GTK_TREE_VIEW(right_treeview));

   /* get the new right listing */  
   connect=(char *)malloc(8192);
   bzero(connect, 8192);
   strcpy(connect, "smbclient //");
   strcat(connect, gtk_ip);
   strcat(connect, "/\"");
   strcat(connect, gtk_share);
   strcat(connect, "\" -U ");
   strcat(connect, gtk_username);
   strcat(connect, "%");
   strcat(connect, gtk_password);
   strcat(connect, " -c \"cd \\\"");
   strcat(connect, right_path);
   strcat(connect, "\\\" ; ls\" > ");
   strcat(connect, tempfile);
   fp = popen(connect, "w");
   pclose(fp);
   free(connect);

   if((fp = fopen(tempfile, "r"))==NULL)
   {
      printf("\nError opening file in remote update function\n");
      return; 
   }
   fseek(fp, 0, SEEK_END);
   siz=ftell(fp);
   rewind(fp);
   old_buffer=(char *)malloc(siz);
   bzero(old_buffer, siz);
   attr_files=(char *)malloc(siz);
   bzero(attr_files, siz);
   noattr_files=(char *)malloc(siz);
   bzero(noattr_files, siz);
   attr_buffy=(char *)malloc(siz);
   bzero(attr_buffy, siz);
   noattr_buffy=(char *)malloc(siz);
   bzero(noattr_buffy, siz);

   /* Append directories to remote treeview */
   while((fgets(old_buffer, siz, fp)!=NULL))
   {
      i++;
      filez[0]='\0';
      attribz[0]='\0';
      sizez[0]='\0';
      utf8=NULL;

      sscanf(old_buffer, "%s %s", filez, attribz);

      /* Adjustment for diffrerent systems (win98 <-> samba/win2k etc) */
      /* while there isnt a [..] directory dont insert anything */
      if( filez[0]=='.' && filez[1]=='.' && ! two_dots )
      {
//         printf("Adjusted uplevel dots in list_remote,\nif it echoes and \"..\" shows and no \".\" then its all good\n"); 
	 two_dots=1;
      }

      if( ! two_dots )
      continue;
  
      if(i>=4 && strlen(filez)>0) /* Skip the first smb output */
      {
         sscanf(old_buffer, "%*s %*s %s", sizez);
         for( z=strlen(old_buffer)-1; old_buffer[z]; z-- ) /* Scan backwards and find attribute */
         {
            /* Check if its a Directory then insert it ..  currently covered: ' D ' ' DA ' ' DH ' ' DR ' */
            if( strstr(old_buffer, "STATUS_NO_MEDIA")==0 && strstr(old_buffer, "/")==0  
	    &&  old_buffer[z]==' ' && old_buffer[z+1]=='D' 
	    &&  ( old_buffer[z+2]==' ' || old_buffer[z+2]=='A' || old_buffer[z+2]=='H' || old_buffer[z+2]=='R' ) 
	    &&  ( old_buffer[z+2]==' ' || old_buffer[z+3]==' ' ) )
            directory=1;
            /* ' DAH ' ' DAR ' ( otherwise it had been a pain to figure out :) */
	    if (old_buffer[z]==' ' && old_buffer[z+1]=='D' && old_buffer[z+2]=='A' && ( old_buffer[z+3]=='H' || old_buffer[z+3]=='R' ) && old_buffer[z+4]==' ' )
            directory=1;

            if( directory )
            {
               /* at attribz */
               z=z-3;
	       directory=0;
               snprintf(filez, z+2, "%s", old_buffer+2);
               /* Cut whitespace after directory-name ("directory      /") */
               for(a=strlen(filez)-1; filez[a]; a--)
               {
                  if(filez[a]!=' ') 
                  {
                     a++;
                     snprintf(cut, a+1, "%s", filez);
                     strcpy(filez, cut);
                     gtk_list_store_append(GTK_LIST_STORE(right_model), &iter);
                     gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 0, dir_pixbuf, -1);
                     utf8 = g_locale_to_utf8(filez, strlen(filez), NULL, NULL, NULL);
                     gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 1, utf8, -1);
                     /* This is bogus size */
                     utf8 = g_locale_to_utf8("4096", 4, NULL, NULL, NULL);
                     gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 2, utf8, -1);
                     utf8 = g_locale_to_utf8("D", 1, NULL, NULL, NULL);
                     gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 3, utf8, -1);
                     break;
                  }
               }
               break;
            }
         }

         /* Everything else is files.  Add it to 2 buffers ...
	  * one with the attributed files the other with the rest,
          * Filtering out unwanted stuff like error messages and so on 
	  *
	  * Samba parsing can go wrong when extremely long/special filenames are found 
	  */

         /* ATTRIBBED FILES */
         if(  utf8==NULL && strstr(old_buffer, "[WORKGROUP] OS")==0 
	 && strstr(old_buffer, "main=[")==0 && strstr(old_buffer, "login successful")==0 
	 && strstr(old_buffer, "/")==0 && strstr(old_buffer, "STATUS_NO_MEDIA")==0
	 && strstr(old_buffer, "blocks of size")==0
	 && ( strstr(old_buffer, " A ")    || strstr(old_buffer, " H ") 
	 ||   strstr(old_buffer, " R ")    || strstr(old_buffer, " S ")   
	 ||   strstr(old_buffer, " AH ")   || strstr(old_buffer, " AR ")   
	 ||   strstr(old_buffer, " AS ")   || strstr(old_buffer, " AHR ") 
	 ||   strstr(old_buffer, " ASR ")  || strstr(old_buffer, " AHS ")
	 ||   strstr(old_buffer, " AHSR ")   ) )
         {
            snprintf(attr_files, z-2, "%s", old_buffer+2); /* cut some */
            strcat(attr_buffy, attr_files); /* We append this after the directories down below (all files) */
	    strcat(attr_buffy, "\n"); /* Must add the newline back to the string so it will always be there for the cuttage */
//            printf("ATTRIBBED FILES:%s:\n", attr_files);
         }
	 else
	    {
               /* NOT ATTRIBBED FILES */
	       if( utf8==NULL && strstr(old_buffer, "[WORKGROUP] OS")==0 
	       && strstr(old_buffer, "main=[")==0 && strstr(old_buffer, "login successful")==0 
	       && strstr(old_buffer, "/")==0 && strstr(old_buffer, "STATUS_NO_MEDIA")==0 && 
	       strstr(old_buffer, "blocks of size")==0 )
	       {
                  snprintf(noattr_files, z-2, "%s", old_buffer+2); /* cut some */
                  strcat(noattr_buffy, noattr_files); /* We append this after the directories down below (all files) */
    	          strcat(noattr_buffy, "\n"); /* Must add the newline back to the string so it will always be there for the cuttage */
//                  printf("NOT ATTRIBBED FILES:%s:\n", noattr_files);
               }
               /* Show disk free */
               if( strstr(old_buffer, "blocks of size") )
	       {
		  sscanf(old_buffer, "%s %*s %*s %*s %s %s", tot_blocks, of_size, blocks_avail);

                  /* It has a dot at the end of the value */
		  if( of_size[strlen(of_size)-1]=='.' )
                      of_size[strlen(of_size)-1]='\0';

                  int_tot_blocks = atoi(tot_blocks);
                  int_of_size = atoi(of_size);
                  int_blocks_avail = atoi(blocks_avail);

                  /* Free space  */
                  if( int_blocks_avail > 100000 && int_of_size > 10000 )
		  {
		     int_free_space = int_blocks_avail * ( (int_of_size / 1024 ) / 1024) /1024 ;
	             sprintf(free_space, "%d", int_total_space);
                     strcpy(statusbuffer, _("       Free space: "));
  	  	     strcat(statusbuffer, free_space);
		     strcat(statusbuffer, " GB    ");
		  }
                  if( int_blocks_avail > 1023 && int_blocks_avail < 100000 && int_of_size > 1000 )
		  {
		     int_free_space = int_blocks_avail * (int_of_size / 1024) / 1024;
 	             sprintf(free_space, "%d", int_free_space);
                     strcpy(statusbuffer, _("       Free space: "));
  	  	     strcat(statusbuffer, free_space);
		     strcat(statusbuffer, " MB    ");
		  }
                  if( int_blocks_avail < 1023 )
		  {
		     int_free_space = int_blocks_avail * ( int_of_size / 1024 );
 	             sprintf(free_space, "%d", int_free_space);
                     strcpy(statusbuffer, _("       Free space: "));
  	  	     strcat(statusbuffer, free_space);
		     strcat(statusbuffer, " KB    ");
		  }

                  /* Total space */
                  if( int_tot_blocks > 10000 && int_of_size > 10000 )
		  {
		     int_total_space = int_tot_blocks * ( int_of_size / 1024 ) / (1024 * 1024);
	             sprintf(total_space, "%d", int_total_space);
                     strcat(statusbuffer, _("Total size: "));
		     strcat(statusbuffer, total_space);
		     strcat(statusbuffer, " GB");
		  }
                  if( int_tot_blocks < 10000 && int_of_size > 10000 )
		  {
		     int_total_space = int_tot_blocks * ( int_of_size / 1024 ) / 1024; // / 1024;
	             sprintf(total_space, "%d", int_total_space);
                     strcat(statusbuffer, _("Total size: "));
		     strcat(statusbuffer, total_space);
		     strcat(statusbuffer, " MB");
		  }
                  if( int_tot_blocks > 999 && int_of_size > 1000 && int_of_size < 10000 )
		  {
		     int_total_space = int_tot_blocks * ( int_of_size / 1024 );
 	             sprintf(total_space, "%d", int_total_space);
                     strcat(statusbuffer, _("Total size: "));
		     strcat(statusbuffer, total_space);
		     strcat(statusbuffer, " KB");
		  }
                  gtk_entry_set_text(GTK_ENTRY(right_status_entry), statusbuffer);
	       }

	    }
      }
   }  
   fclose(fp);
   free(old_buffer);



   /* All directories has been insterted .. lets insert the files */

   /* mangez .. append the correct icons (a samba ReCode would be nice) */
   
   a=0; x=0; z=0;  

   while(attr_buffy[z]!='\0')
   {
      begin=z; /* start of line */

      for(z=z; attr_buffy[z]; z++) 
      {
         /* copy from start to newline */
         if(attr_buffy[z]=='\n')
	 {
            snprintf(cut, z-begin+1, "%s", attr_buffy+begin);   
            snprintf(sizez, z-begin+1, "%s", attr_buffy+begin); 

            for(x=strlen(cut)-1; cut[x]; x--)
            {
               if(cut[x]==' ' && cut[x+1]!=' ')
      	       {
	          a++;
                  /* SIZEZ */
	          if(a==5) /* 5 whitespaces from the end */
	          {
		     y=x;
                     if(strlen(sizez)>0) /* Not size line .. for the status-line */
	             {
		        begin=y-1;
			sizez[begin]='\0';
                        
                        for(y=strlen(sizez)-1; sizez[y]; y--) /* cut remaining whitespace before the filname ends */
                        {
                           if(sizez[y]==' ' && sizez[y+1]!=' ')
   	                   {
			      /* Dates etc on the right taken away */
                              y=y+1;
                              if(strlen(sizez)>0) /* dont append additional junk */
			      {
			         snprintf(attribz, y, "%s", sizez+y);
				 strcpy(sizez, attribz);
				 /* UGLY CHANGE TO ATTRIBZ */
                                 gtk_list_store_append(GTK_LIST_STORE(right_model), &iter);
                                 utf8 = g_locale_to_utf8(sizez, strlen(sizez), NULL, NULL, NULL);
                                 gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 2, utf8, -1);
//                                 printf("SIZE ATTR CUT:%s:\n", sizez);
                                 sizez[0]='\0'; /* so it doesnt append additional junk */
				 break;
                              }
                           }
		        }
                     }
	          }

                  /* FILEZ WITH ATTRIBUTES */
	          if(a==7) /* 7 whitespaces from the end */
	          {
                     if(strlen(cut)>0) /* Not size line .. for the status-line */
	             {
                        for(x=x; cut[x]; x--) /* cut remaining whitespace before the filname ends */
                        {
                           if(cut[x]==' ' && cut[x-1]!=' ')
   	                   {
                              cut[x]='\0';
                              if(strlen(cut)>0) /* dont append additional junk */
			      {
                                 utf8 = g_locale_to_utf8(cut, strlen(cut), NULL, NULL, NULL);
                                 gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 0, text_pixbuf, -1);
                                 gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 1, utf8, -1);

                                 utf8 = g_locale_to_utf8("A", 1, NULL, NULL, NULL);
                                 gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 3, utf8, -1);
//                                 printf("FILEZ ATTR CUT:%s:\n", cut);
                                 cut[0]='\0'; /* so it doesnt append additional junk */
                                 break;
                              }
                           }
		        }
                     }
	          }
               }
            }
            z++;
	    a=0;
            break;
	 }
      }
   }

   a=0; x=0; z=0;

   /* FILEZ AND SIZEZ WITH NO ATTRIBUTES */
   while(noattr_buffy[z]!='\0') /* while not end of buffer */
   {
      begin=z; /* start of line */

      for(z=z; noattr_buffy[z]; z++) /* copy from start to newline */
      {
         if(noattr_buffy[z]=='\n')
	 {
            snprintf(cut, z-begin+1, "%s", noattr_buffy+begin);   
            snprintf(sizez, z-begin+1, "%s", noattr_buffy+begin); 

            for(x=strlen(cut)-1; cut[x]; x--)
            {
               if(cut[x]==' ' && cut[x+1]!=' ')
      	       {
                  a++;

                  /* SIZEZ NO ATTRIBUTE */
	          if(a==5) /* 5 whitespaces from the end */
	          {
		     y=x;
                     if(strlen(sizez)>0) /* Not size line .. for the status-line */
	             {
                        
		        begin=y-1;
			sizez[begin]='\0';
                        
                        for(y=strlen(sizez)-1; sizez[y]; y--)
                        {
                           if(sizez[y]==' ' && sizez[y+1]!=' ')
   	                   {
			      /* Dates etc on the right taken away */
                              y=y+1;
                              if(strlen(sizez)>0)
			      {
			         snprintf(attribz, y, "%s", sizez+y);
				 strcpy(sizez, attribz);
				 /* UGLY CHANGE TO ATTRIBZ */
                                 gtk_list_store_append(GTK_LIST_STORE(right_model), &iter);
                                 gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 0, text_pixbuf, -1);
                                 utf8 = g_locale_to_utf8(sizez, strlen(sizez), NULL, NULL, NULL);
                                 gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 2, utf8, -1);
//                                 printf("SIZE NO ATTR CUT:%s:\n", sizez);
                                 sizez[0]='\0'; /* so it doesnt append additional junk */
				 break;
                              }
                           }
		        }
                     }  
	          }  

                  /* FILEZ WITH NO ATTRIBUTE */
	          if(a==6)
                  {
                     for(x=x; cut[x]; x--) /* cut remaining whitespace before the filname ends */
                     {
                        if(cut[x]==' ' && cut[x-1]!=' ')
   	                {
                           cut[x]='\0';
                           if(strlen(cut)>0) /* dont append additional junk */
		 	   {
                              /* FILEZ NO ATTRIB .. Since sizez comes first (a=5) a new line is appended there */
                              gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 0, text_pixbuf, -1);
                              utf8 = g_locale_to_utf8(cut, strlen(cut), NULL, NULL, NULL); // use filez
                              gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 1, utf8, -1);
                              utf8 = g_locale_to_utf8("A", 1, NULL, NULL, NULL);
                              gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 3, utf8, -1);
//                              printf("\nFILEZ NO ATTR CUT:%s:\n", cut);
			      cut[0]='\0'; /* so it doesnt append additional junk */
			      break;
                           }
                        }
		     }
	          }
               }
	    }
            z++;
            a=0;
	    break;
         }
      }
   } 
   free(attribz); free(sizez); free(cut); 
   free(attr_files); free(noattr_files); free(attr_buffy); free(noattr_buffy);
   if(utf8 !=NULL)
   g_free(utf8);
   path = gtk_tree_path_new_first();
   gtk_tree_view_set_cursor(GTK_TREE_VIEW(right_treeview), path, NULL, edit);
   gtk_tree_path_free(path);
   strcpy(filez, "rm -f ");
   strcat(filez, tempfile);
   system(filez);   
   free(filez);
}


void
on_connect_button_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
   FILE *fp;
   long siz;
   int found_lookup=0, valid_share=0;
   char hosts_buf[8192]="";
   char lookitup[8192]="", pbuffy[1024]="";
   GtkTreeModel *right_model;
   GtkTreeIter iter;
   GtkTreePath *path;
   gboolean edit=0;
   gchar *utf8=NULL;
   char *connect; 
   char filez[8192]="", attribz[8192]="", sizez[8192]="", extra[8192]="";
   char *old_buffer;
   G_CONST_RETURN gchar *gtk_ip;
   G_CONST_RETURN gchar *gtk_share;
   G_CONST_RETURN gchar *gtk_username;
   G_CONST_RETURN gchar *gtk_password;

   ip_entry = lookup_widget(GTK_WIDGET (button), "ip_entry");
   share_entry = lookup_widget(GTK_WIDGET (button), "share_entry");
   user_entry = lookup_widget(GTK_WIDGET (button), "user_entry");
   password_entry = lookup_widget(GTK_WIDGET (button), "password_entry");
   right_path_entry  = lookup_widget (GTK_WIDGET (button), "right_path_entry");
   left_status_entry = lookup_widget(GTK_WIDGET (button), "left_status_entry");
   right_status_entry = lookup_widget(GTK_WIDGET (button), "right_status_entry");

   gtk_ip = gtk_entry_get_text(GTK_ENTRY(ip_entry));
   gtk_share = gtk_entry_get_text(GTK_ENTRY(share_entry));
   gtk_username = gtk_entry_get_text(GTK_ENTRY(user_entry));
   gtk_password = gtk_entry_get_text(GTK_ENTRY(password_entry));

   if( connected )
   return;

   if(strlen(gtk_ip)==0)
   {
      gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("Specify a computername to connect to"));
      return;
   }

   /* Check presence of nmblookup (relying on paths instead of stating) */
   fp=popen("nmblookup", "r");
   while(fgets(pbuffy, 1024, fp))
   {
      if( strstr(pbuffy, "Usage") )
      {
	 found_lookup=1;
         break;
      }
   }
   pclose(fp);

   if( ! found_lookup )
   {
      gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("The command: \"nmblookup\" was not found."));
      gtk_entry_set_text(GTK_ENTRY(right_status_entry), _("  Cannot connect to sambaserver."));
      return;	   
   }

   /* NMBlookup server */
   strcpy(lookitup, "nmblookup ");
   strcat(lookitup, gtk_ip);
   strcat(lookitup, " > ");
   strcat(lookitup, tempfile);
   system(lookitup);

   if((fp = fopen(tempfile, "r"))==NULL)
   {
      printf("\nError opening hostfile on connect\n");
      return;
   }
   fseek(fp, 0, SEEK_END);
   siz=ftell(fp);
   rewind(fp);
   old_buffer=(char *)malloc(siz);
   bzero(old_buffer, siz);
   /* resolve hostname so we can connect */
   while(fgets(old_buffer, siz, fp))
   {
      if(strstr(old_buffer, "failed")!=0)
      {
         gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("NMBlookup failed: use server name, not IP-address."));
         gtk_entry_set_text(GTK_ENTRY(right_status_entry), _(" Is your firewall blocking broadcasts ?"));
         connected=0;
         return;
      }
      /* Taking the first line with (computer) <00> */
      if(strstr(old_buffer, "<00>"))
      {
         strcpy(hosts_buf, " ");
         sscanf(old_buffer, "%s", hosts_buf);  /* get ip */
         hosts_buf[strlen(hosts_buf)-4]='\0'; /* Skip last "<00>" */
         gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("NMBLookup: found the server"));
         gtk_entry_set_text(GTK_ENTRY(right_status_entry), "");
         connected=1;
         break;
      }
      if(old_buffer==NULL)
      break;
   }
   fclose(fp);
   free(old_buffer);

   /* List the shares in right_treeview */
   connect=(char *)malloc(8192);
   bzero(connect, 8192);
   strcpy(connect, "smbclient -L //"); 
   strcat(connect, gtk_ip);
   strcat(connect, " -U ");
   strcat(connect, gtk_username);
   strcat(connect, "%");
   strcat(connect, gtk_password);
   strcat(connect, " -d0 -c \" lcd \\\"");
   strcat(connect, left_path);
   strcat(connect, "\\\" ; ls\" > ");
   strcat(connect, tempfile);
   fp = popen(connect, "w");
   pclose(fp);
   free(connect);

   /* Do errorchecking here because the errors are located a few lines down */
   if((fp = fopen(tempfile, "r"))==NULL)
   {
      printf("\nError opening home host file on connect\n");
      return;
   }
   fseek(fp, 0, SEEK_END);
   siz=ftell(fp);
   rewind(fp);
   old_buffer=(char *)malloc(siz);
   bzero(old_buffer, siz);
   while(fgets(old_buffer, siz, fp))
   {

      filez[0]='\0';
      attribz[0]='\0';
      sizez[0]='\0';
      extra[0]='\0';
      sscanf(old_buffer, "%s %s %s %s", filez, attribz, sizez, extra);
      /* win2000 , Linux and win9x smbd's gives different output (get rid of it)*/
      /* Dont list if its got no valid share */
      if( ( 0==strstr(filez, "sharename") && 0==strstr(attribz, "type") ) || ( 0==strstr(filez, "--") && 0==strstr(attribz, "--") ) )
      {
         /* Skipping stuff 2   "printer", "ipc", "$" .. no shit should slip thru (leaving printer$ ? hmm) */
         if( 0==strstr(attribz, "printer") && 0==strstr(attribz, "IPC") && 0==strstr(filez, "$") && strstr(old_buffer,"Disk") )
         {
	    valid_share=1;
         }
      }      
      
      /* Error reporting */
      if( strstr(old_buffer, "ERRbad") )
      {
         gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("Wrong username/password password combination."));
         connected=0;
         return;
      }
      if( strstr(old_buffer, "failed") )
      {
         gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("Wrong username/password password combination."));
         connected=0;
         return;
      }
      if( strstr(old_buffer, "Error returning browse") )
      {
         gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("Bad username/password combination"));
         connected=0;
         return;
      }
      if( strstr(old_buffer, "NT_STATUS_LOGON_FAIL") )
      {
         gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("Bad username/password combination try guest with no password"));
         connected=0;
         return;
      }
      if( strstr(old_buffer, "NT_STATUS_BAD_NETWORK_NAME") )
      {
         gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("Bad username/password combination try guest with no password"));
         connected=0;
         return;
      }
      if( strstr(old_buffer, "NT_STATUS_ACCESS_DENIED") )
      {
         gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("Bad username/password combination try guest with no password"));
         connected=0;
         return;
      }
      if( strstr(old_buffer, "Access denied") )
      {
         gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("Bad username/password combination try guest with no password"));
         connected=0;
         return;
      }
   }
   fclose(fp);

   if( ! valid_share )
   {
      gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("The server has no valid share (may have printer$ or ip*$ but its ignored)."));
      free(old_buffer);
      connected=0;
      return;
   }
   
   /* Remember where we where in the right treeview before connect */
   strcpy(remember_path, right_path);
   
   /* Clear everything */
   gtk_entry_set_text(GTK_ENTRY(right_path_entry), "");
   gtk_entry_set_text(GTK_ENTRY(share_entry), "");
   strcpy(right_path, "");

   right_treeview = lookup_widget (GTK_WIDGET (button), "right_treeview");
   clear_right(right_treeview, NULL);
   right_model = gtk_tree_view_get_model(GTK_TREE_VIEW(right_treeview));

   /* Append to remote treevieew */
   if((fp = fopen(tempfile, "r"))==NULL)
   {
      printf("Error opening file on inserting shares in remote\n");
      return;
   }
   fseek(fp, 0, SEEK_END);
   siz=ftell(fp);
   rewind(fp);
   old_buffer=(char *)malloc(siz);
   bzero(old_buffer, siz);
   while(fgets(old_buffer, siz, fp))
   {
      /* Insert Sharelisting in right_treeview */
      /* Dont append twice so we clear the buffers */            
      filez[0]='\0';
      attribz[0]='\0';
      sizez[0]='\0';
      extra[0]='\0';
      sscanf(old_buffer, "%s %s %s %s", filez, attribz, sizez, extra);
      /* win2000 , Linux and win9x smbd's gives different output (get rid of it)*/
      /* Skipping stuff 1   "--", "sharename type" */
      if( ( 0==strstr(filez, "sharename") && 0==strstr(attribz, "type") ) || ( 0==strstr(filez, "--") && 0==strstr(attribz, "--") ) )
      {
         /* Skipping stuff 2   "printer", "ipc", "$" .. no shit should slip thru (leaving printer$ ? hmm) */
         if( 0==strstr(attribz, "printer") && 0==strstr(attribz, "IPC") && 0==strstr(filez, "$") )
         {
            if( strstr(old_buffer, "Disk") ) /* We have a value with disk in it ipc is new */
            {
               /* Share names can be 3 whitespace separated words */
               if(strstr(attribz,"Disk")==0) /* If attribz doesnt contain "Disk" */
               {
                  strcat(filez, " ");
                  strcat(filez, attribz);
  	          strcpy(attribz, "Disk");
		  if(strstr(sizez,"Disk")==0) /* If sizez doesnt contain "Disk" */
		  {
                     strcat(filez, " ");
		     strcat(filez, sizez);
		     strcpy(sizez, "0");
 		  }
               }
	       utf8 = g_locale_to_utf8(filez, strlen(filez), NULL, NULL, NULL);
               if(strlen(utf8)!=0)
	       {
                  gtk_list_store_append(GTK_LIST_STORE(right_model), &iter);
                  gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 0, dir_pixbuf, -1);
                  /* filez */
                  gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 1, utf8, -1);

                  utf8 = g_locale_to_utf8(attribz, strlen(attribz), NULL, NULL, NULL);
                  gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 3, utf8, -1);
               }
            }
	 }  
      }  
      if(old_buffer==NULL)
      break;
   }
   if(utf8 !=NULL)
   g_free(utf8);
   path = gtk_tree_path_new_first();
   gtk_tree_view_set_cursor(GTK_TREE_VIEW(right_treeview), path, NULL, edit);
   gtk_tree_path_free(path);
   fclose(fp);

   strcpy(old_buffer, "rm -f ");
   strcat(old_buffer, tempfile);
   system(old_buffer);
   free(old_buffer); 
   connected=1;
   return;
}


void
on_disconnect_button_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
   if( ! connected )
   return;

   connected=0;
   /* Resume browsing in the directory the user was before connect */
   strcpy(right_path, remember_path);
   right_path_entry  = lookup_widget (GTK_WIDGET (right_treeview), "right_path_entry");
   share_entry  = lookup_widget (GTK_WIDGET (right_treeview), "share_entry");
   left_status_entry  = lookup_widget (GTK_WIDGET (right_treeview), "left_status_entry");
   right_status_entry  = lookup_widget (GTK_WIDGET (right_treeview), "right_status_entry");
   gtk_entry_set_text(GTK_ENTRY(right_path_entry), right_path);
   gtk_entry_set_text(GTK_ENTRY(share_entry), "");
   gtk_entry_set_text(GTK_ENTRY(left_status_entry), "");
   gtk_entry_set_text(GTK_ENTRY(right_status_entry), "");
   list_right(right_treeview, NULL);
}


gboolean
on_left_treeview_button_press_event   (GtkWidget       *widget,
                                        GdkEventButton  *event,
                                        gpointer         user_data)
{
   FILE *fp;
   char *str, *str1, *str2, *filez, *attribz, *old_buffer;
   char mount[1024]="", umount[1024]="", tempo[8192]="";
   int mounted=0;
   long siz;
   GtkTreeIter iter;
   GtkTreeModel *left_model;
   GtkTreeSelection *selection;
   G_CONST_RETURN gchar *gtk_ip;
   G_CONST_RETURN gchar *gtk_share;
   G_CONST_RETURN gchar *gtk_username;
   G_CONST_RETURN gchar *gtk_password;
   left_path_entry  = lookup_widget (GTK_WIDGET (left_treeview), "left_path_entry");
   ip_entry  = lookup_widget (GTK_WIDGET (left_treeview), "ip_entry");
   share_entry  = lookup_widget (GTK_WIDGET (left_treeview), "share_entry");
   user_entry  = lookup_widget (GTK_WIDGET (left_treeview), "user_entry");
   password_entry  = lookup_widget (GTK_WIDGET (left_treeview), "password_entry");
   gtk_ip = gtk_entry_get_text(GTK_ENTRY(ip_entry));
   gtk_share = gtk_entry_get_text(GTK_ENTRY(share_entry));
   gtk_username = gtk_entry_get_text(GTK_ENTRY(user_entry));
   gtk_password = gtk_entry_get_text(GTK_ENTRY(password_entry));

   
   /* Left treeview actions ( clicked 2 times on button 2 or 3 ) */
   if(event->type == GDK_2BUTTON_PRESS && (event->button == 2 || event->button == 3) ) 
   {
      /* Upload file or directory etc */
      filez=(char *)malloc(1024);
      bzero(filez, 1024);
      attribz=(char *)malloc(1024);
      bzero(attribz, 1024);
      selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(left_treeview));
      gtk_tree_selection_set_mode(selection, GTK_SELECTION_SINGLE);
      gtk_tree_selection_get_selected(selection, &left_model, &iter);
      gtk_tree_model_get(left_model, &iter, 1, &filez, -1);
      gtk_tree_model_get(left_model, &iter, 3, &attribz, -1);
      if( filez==NULL )
      {
         free(filez); free(attribz);
         return FALSE;
      }
      /* Show actions window */
      left_actions_window=create_left_actions_window();
      gtk_widget_show(left_actions_window);
      /* Add whats clicked to the rename box in the actions window */
      left_rename_entry = lookup_widget (GTK_WIDGET (left_actions_window), "left_rename_entry");
      gtk_entry_set_text(GTK_ENTRY(left_rename_entry), filez);
      free(filez); free(attribz);
      return FALSE;
   }


   /* perform actions in left treeview ( clicked 2 times on button 1 ) */
   if(event->type == GDK_2BUTTON_PRESS && event->button == 1) 
   {
      filez=(char *)malloc(1024);
      bzero(filez, 1024);
      attribz=(char *)malloc(1024);
      bzero(attribz, 1024);
      selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(left_treeview));
      gtk_tree_selection_set_mode(selection, GTK_SELECTION_SINGLE);
      gtk_tree_selection_get_selected(selection, &left_model, &iter);
      gtk_tree_model_get(left_model, &iter, 1, &filez, -1);
      gtk_tree_model_get(left_model, &iter, 3, &attribz, -1);
//      printf("filez:[%s] left_path[%s]\n", filez, left_path);


      /* Action on a mountable device(directory) */
      if( strstr(attribz, "M") && strlen(left_mount) < 3 )
      {
         strcpy(left_mount, "/mnt/");
	 strcat(left_mount, filez);
         /* Check if its listed in mtab(mounted), itll output "already mounted" for now */
         if((fp = fopen("/etc/mtab", "r"))==NULL)
         {
            printf("Error opening file /etc/mtab\n");
            return FALSE;
         }
         fseek(fp, 0, SEEK_END);
         siz=ftell(fp);
         rewind(fp);
         old_buffer=(char *)malloc(siz);
         bzero(old_buffer, siz);
         while(fgets(old_buffer, siz, fp))
         {
	    sscanf(old_buffer, "%*s %s", tempo);
            if( strstr(tempo, left_mount) && strlen(tempo) == strlen(left_mount) )
	    {
	       mounted=1;
	    }
         }
         fclose(fp);
	 free(old_buffer);
	 
	 if( ! mounted )
	 {
	    strcpy(mount, "mount ");
	    strcat(mount, left_mount);
	    system(mount);
	    strcpy(mount, _("Mounted the device: "));
	    strcat(mount, left_mount);
	    strcat(mount, _(" CD up to unmount it."));
            left_status_entry = lookup_widget (GTK_WIDGET (left_treeview), "left_status_entry");
            gtk_entry_set_text(GTK_ENTRY(left_status_entry), mount);
            strcpy(left_path, "/mnt/");
	    strcat(left_path, filez);
            gtk_entry_set_text(GTK_ENTRY(left_path_entry), left_path);
	 }
	 else
	   {
              strcpy(left_path, "/mnt/");
	      strcat(left_path, filez);
              left_status_entry = lookup_widget (GTK_WIDGET (left_treeview), "left_status_entry");
              gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("The device is already mounted, browsing it."));
              gtk_entry_set_text(GTK_ENTRY(left_path_entry), left_path);
	   }
           /* update left treeview */
           list_left(left_treeview, NULL);
           free(filez); free(attribz);
           return FALSE;
      }

      /* Perform actions on single files. */
      if(strstr(attribz, "A"))
      mimetypes(NULL, NULL, filez, left_path);

      /* Dont do anything if ".." is clicked or if filez is NULL (bad utf8) */
      if( strlen(filez)==0 || ( strstr(filez, "..") && strlen(left_path)<2 ) )
      {
         free(filez); free(attribz);
         return FALSE;
      }

      left_status_entry = lookup_widget (GTK_WIDGET (widget), "left_status_entry");

      /* Dont let the user go into /dev for various reasons */
      if(strstr(filez, "dev") && strlen(left_path)==1 )
      {
         gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("CD /dev is not allowed"));
         free(filez); free(attribz);
         return FALSE;
      }
      /* Clear the statusbar */
      gtk_entry_set_text(GTK_ENTRY(left_status_entry), "");

      /* CD up or down and update the left treeview */
      str=(char *)malloc(1024);
      str1=(char *)malloc(1024);
      str2=(char *)malloc(1024);
      bzero(str, 1024);
      bzero(str1, 1024);
      bzero(str2, 1024);

      /* CD UP */   
      if( strstr(filez, "..") && 2==strlen(filez) && strstr(attribz, "D") )
      {
         /* Crop the path */
         strcpy(str, left_path);
         StrCut(str, 0, retPos(str,'/'), str1);
         strcpy(left_path, str1); /* copy it back .. but exclude newline char */
         /* So we always have atlest a / path */
         if(strlen(left_path)==0)
         strcpy(left_path, "/");
         gtk_entry_set_text(GTK_ENTRY(left_path_entry), left_path);

         /* If it has a mounted device and the other side isnt in it */
	 if( strlen(left_mount)>0 && strstr(left_path, "/mnt") 
	 &&  strlen(left_path)==4 )
         {
	    if( strstr(right_mount, left_mount) 
	    && strlen(right_mount)==strlen(left_mount) )
	    {
 	       strcpy(left_mount, "");
            }
	    else	          
	      {
	         strcpy(umount, "umount ");
	         strcat(umount, left_mount);
	         system(umount);
	         strcpy(umount, _("Unmounted the device: "));
	         strcat(umount, left_mount);
                 left_status_entry = lookup_widget (GTK_WIDGET (right_treeview), "left_status_entry");
                 gtk_entry_set_text(GTK_ENTRY(left_status_entry), umount);
 	         strcpy(left_mount, "");
	      }
         }
	 
         /* update left treeview */
         list_left(left_treeview, NULL);
         free(str); free(str1); free(str2);
         free(filez); free(attribz);
         return FALSE;
      }

      /* CD down in left treeview */
      if( strstr(filez,"..")==0 && strstr(attribz,"D") )
      {
         if(strlen(left_path)!=1)
         strcat(left_path, "/");
         strcat(left_path, filez);
         gtk_entry_set_text(GTK_ENTRY(left_path_entry), left_path);
         /* update left treeview */
         list_left(left_treeview, NULL);
         free(str); free(str1); free(str2);
         free(filez); free(attribz);
         return FALSE;
      }
   }
   return FALSE;
}


gboolean
on_right_treeview_button_press_event  (GtkWidget       *widget,
                                        GdkEventButton  *event,
                                        gpointer         user_data)
{
   FILE *fp;
   char right_entry[8192]="", mount[1024]="", umount[1024]="", tempo[1024]="";
   int mounted=0;
   GtkTreeIter iter;
   GtkTreeModel *right_model;
   GtkTreeSelection *selection;
   GtkTreePath *path;
   gboolean edit=0;
   gchar *utf8=NULL;
   char *str, *str1, *str2, *cut;
   char *connect, *old_buffer, *filez_shift;
   char *filez, *attribz, *sizez;
   long siz;
   int cdup=0;      /* used to not mix cd ups and downs */
   G_CONST_RETURN gchar *gtk_ip;
   G_CONST_RETURN gchar *gtk_share;
   G_CONST_RETURN gchar *gtk_username;
   G_CONST_RETURN gchar *gtk_password;

   right_path_entry  = lookup_widget (GTK_WIDGET (right_treeview), "right_path_entry");
   left_status_entry  = lookup_widget (GTK_WIDGET (right_treeview), "left_status_entry");
   right_status_entry  = lookup_widget (GTK_WIDGET (right_treeview), "right_status_entry");
   gtk_entry_set_text(GTK_ENTRY(right_status_entry), "");

   /* Updating while beeing updated block and dont do any remote type action while left */
   if( ! updating && connected ) 
   {
      updating=1;
      gtk_ip = gtk_entry_get_text(GTK_ENTRY(ip_entry));
      gtk_share = gtk_entry_get_text(GTK_ENTRY(share_entry));
      gtk_username = gtk_entry_get_text(GTK_ENTRY(user_entry));
      gtk_password = gtk_entry_get_text(GTK_ENTRY(password_entry));

      /* Remote action dialog .. button 2 or 3 clicked twice */ 
      if(event->type == GDK_2BUTTON_PRESS && (event->button == 2 || event->button == 3) ) 
      {
         /* Cant download the entire share */
	 /* Can do this by making a left dirname the same as the share then dl it all recursively (warning popup :) */

         /* If we arent at the sharelevel */
         if(strlen(gtk_share)!=0)
         {
            /* showing the action window (fix it so it doesnt show twice maybe) */
            filez=(char *)malloc(8192);
            bzero(filez, 8192);
            selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(right_treeview));
            gtk_tree_selection_set_mode(selection, GTK_SELECTION_SINGLE);
            gtk_tree_selection_get_selected(selection, &right_model, &iter);
            gtk_tree_model_get(right_model, &iter, 1, &filez, -1);
            /* Show the right actions window */
            right_actions_window=create_right_actions_window();
    	    gtk_widget_show(right_actions_window);
            /* Add whats clicked to the rename box in the actions window */
            right_rename_entry = lookup_widget (GTK_WIDGET (right_actions_window), "right_rename_entry");
            gtk_entry_set_text(GTK_ENTRY(right_rename_entry), filez);
            free(filez);
            updating=0;
	 }
         return FALSE;
      }


      /* Button 1 clicked 2 times .. cd remote */
      if(event->type == GDK_2BUTTON_PRESS && event->button == 1) 
      {
         filez=(char *)malloc(8192);
         bzero(filez, 8192);
         attribz=(char *)malloc(8192);     
         bzero(attribz, 8192);
         sizez=(char *)malloc(8192);
         bzero(sizez, 8192);
         gtk_entry_set_text(GTK_ENTRY(right_status_entry), "");
         selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(right_treeview));
         gtk_tree_selection_set_mode(selection, GTK_SELECTION_SINGLE);
         gtk_tree_selection_get_selected(selection, &right_model, &iter);
         gtk_tree_model_get(right_model, &iter, 1, &filez, -1);
         gtk_tree_model_get(right_model, &iter, 2, &sizez, -1);
         gtk_tree_model_get(right_model, &iter, 3, &attribz, -1);

         /* Fix remote mimetype actions ( if connected ! connected ) */
         if( filez==NULL || ! connected )
         {
            updating=0;
            free(filez); free(attribz); free(sizez);
            return FALSE;
         }
         right_status_entry  = lookup_widget (GTK_WIDGET (right_treeview), "right_status_entry");
         share_entry = lookup_widget(GTK_WIDGET (right_treeview), "share_entry");
         gtk_share = gtk_entry_get_text(GTK_ENTRY(share_entry));

         /* So the user can change the Username and password without reconnecting */
         password_entry = lookup_widget(GTK_WIDGET (right_treeview), "password_entry");
         user_entry = lookup_widget(GTK_WIDGET (right_treeview), "user_entry");
         gtk_password = gtk_entry_get_text(GTK_ENTRY(password_entry));
         gtk_username = gtk_entry_get_text(GTK_ENTRY(user_entry));

         /* Use clicked share set it in the sharebox */
         if(strlen(gtk_share)==0)
         {
            filez_shift=(char *)malloc(8192);
            bzero(filez_shift, 8192);
            strcpy(filez_shift, filez);
            gtk_entry_set_text(GTK_ENTRY(share_entry), filez_shift);
            free(filez_shift);
	    strcpy(filez, "");
         }

         /* CD UP in remote treeview */
         if(strstr(filez, "..") && strstr(attribz, "D"))
         {
            cdup=1; 
            /* SHOW SHARE LISTING (cd up .. and we have no path depth) */
            if(strlen(right_path)<=1) /* if its "" or "/" */ 
            {
               gtk_entry_set_text(GTK_ENTRY(right_status_entry), _("Showing the shared directories"));
               gtk_entry_set_text(GTK_ENTRY(share_entry), "");
               gtk_entry_set_text(GTK_ENTRY(right_path_entry), "");
               connect=(char *)malloc(8192);
               bzero(connect, 8192);
               strcpy(connect, "smbclient -L //");
               strcat(connect, gtk_ip);
               strcat(connect, " -U ");
               strcat(connect, gtk_username);
               strcat(connect, "%");
               strcat(connect, gtk_password);
               strcat(connect, " > ");
               strcat(connect, tempfile);
               strcpy(right_path, "");
               fp = popen(connect, "w");
               pclose(fp);
               free(connect);
 
               clear_right(right_treeview, NULL);
               right_model = gtk_tree_view_get_model(GTK_TREE_VIEW(right_treeview));

               if((fp = fopen(tempfile, "r"))==NULL)
   	       {
	          printf("cant open share on clicked up file\n");
                  updating=0;
	          return FALSE;
	       }
               fseek(fp, 0, SEEK_END);
               siz=ftell(fp);
               rewind(fp);
               filez=(char *)malloc(8192);
               bzero(filez, 8192);
               attribz=(char *)malloc(8192);     
               bzero(attribz, 8192);
               sizez=(char *)malloc(8192);
               bzero(sizez, 8192);
               old_buffer=(char *)malloc(siz);
               bzero(old_buffer, siz);

               /* SHOW SMB SHARES in remote treeview */
               while((fgets(old_buffer, siz, fp)!=NULL))
               {
                  /* Return if errors */
                  if(strstr(old_buffer, "ERRbad")!=0)
                  {
                     gtk_entry_set_text(GTK_ENTRY(right_status_entry), _("Wrong username/password combination."));
                     // did something bad here hmmz
                     return FALSE;
                  }

                  /* Dont append twice so we clear the buffers */            
                  filez[0]='\0';
                  attribz[0]='\0';
                  sizez[0]='\0';
                  sscanf(old_buffer, "%s %s %s", filez, attribz, sizez);
                  /* win2000 , Linux and win9x smbd's seems to give different output (get rid of it) */
                  /* Skipping stuff 1   "--", "sharename type" */
                  if( ( 0==strstr(filez, "sharename") && 0==strstr(attribz, "type") ) || ( 0==strstr(filez, "--") && 0==strstr(attribz, "--") ) )
                  {
                     /* Skipping stuff 2   "printer", "ipc", "$" .. no shit should slip thru (leaving printer$ hmm) */
                     if( 0==strstr(attribz, "printer") && 0==strstr(attribz, "ipc") && 0==strstr(filez, "$") )
                     {
                        if( strstr(old_buffer, "Disk")!=0 ) /* We have a value with disk in it */
                        {
                           /* Share names can be 3 whitespace separated words */
	                   if(strstr(attribz,"Disk")==0) /* If attribz doesnt contain "Disk" */
	                   {
                              strcat(filez, " ");
	                      strcat(filez, attribz);
		              strcpy(attribz, "Disk");
 		              if(strstr(sizez,"Disk")==0)
		              {
                                 strcat(filez, " ");
		                 strcat(filez, sizez);
		                 strcpy(sizez, "0");
 		              }
                           }
		           utf8 = g_locale_to_utf8(filez, strlen(filez), NULL, NULL, NULL);
                           if(strlen(utf8)!=0)
		           {
                              gtk_list_store_append(GTK_LIST_STORE(right_model), &iter);

                              gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 0, dir_pixbuf, -1);

                              /* filez */
                              gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 1, utf8, -1);

		              utf8 = g_locale_to_utf8(sizez, strlen(sizez), NULL, NULL, NULL);
                              gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 2, utf8, -1);


                              utf8 = g_locale_to_utf8(attribz, strlen(attribz), NULL, NULL, NULL);
                              gtk_list_store_set(GTK_LIST_STORE(right_model), &iter, 3, utf8, -1);
                           }
	                }  /* skipping stuff */
	             }  /* skipping stuff 2 */
                  }  /* Skipping stuff 1 */
               }  /* While */
               fclose(fp);
	       if(utf8 !=NULL)
               g_free(utf8);            
               strcpy(filez, "rm -f ");
               strcat(filez, tempfile);
               system(filez);
               free(filez); free(attribz); free(sizez);
               free(old_buffer); 
               path = gtk_tree_path_new_first();
               gtk_tree_view_set_cursor(GTK_TREE_VIEW(right_treeview), path, NULL, edit);
               gtk_tree_path_free(path);
	       updating=0;
               return FALSE; 
            }  /* SHOW SHARE LISTING END */
            else
               {	    
                  /* CD UP in the remote treeview */
                  gtk_entry_set_text(GTK_ENTRY(right_status_entry), "");
                  str=(char *)malloc(8192);
                  bzero(str, 8192);
                  str1=(char *)malloc(8192);
                  bzero(str1, 8192);
                  str2=(char *)malloc(8192);
                  bzero(str2, 8192);
                  cut=(char *)malloc(8192);
                  bzero(cut, 8192);
                  strcpy(str, right_path); 
                  StrCut(str, 0, retPos(str,'/'), str1);
                  strcpy(right_path, str1); /* copy it back after cutpath */
                  free(str); free(str1); free(str2); free(cut);
                  connect=(char *)malloc(8192);
                  bzero(connect, 8192);
                  strcpy(connect, "smbclient //");
                  strcat(connect, gtk_ip);
                  strcat(connect, "/\"");
                  strcat(connect, gtk_share);
                  strcat(connect, "\" -U ");
                  strcat(connect, gtk_username);
                  strcat(connect, "%");
                  strcat(connect, gtk_password);
                  strcat(connect, " -c \"cd \\\"");
                  strcat(connect, right_path);
                  strcat(connect, "\\\" ; lcd \\\"");
                  strcat(connect, left_path);
                  strcat(connect, "\\\" ; ls\" > ");
                  strcat(connect, tempfile);
                  fp = popen(connect, "w");
                  pclose(fp);
                  free(connect);
                  /* show where we are in remote entry */
                  strcpy(right_entry, "/");
                  strcat(right_entry, gtk_share);
                  strcat(right_entry, right_path);
                  gtk_entry_set_text(GTK_ENTRY(right_path_entry), right_entry);
               }
         }     /* CD up in remote treeview end */ 


         /* CD DOWN remote */
         if( strstr(attribz, "D") && ! cdup )
         {
            cdup=1;
            /* if there is no "/" at the end, add one */
            if(right_path[strlen(right_path)-1]!='/')
            {
               strcat(right_path, "/");
               strcat(right_path, filez);
            }
            else
            strcat(right_path, filez);

            connect=(char *)malloc(8192);
            bzero(connect, 8192);
            strcpy(connect, "smbclient //");
            strcat(connect, gtk_ip);
            strcat(connect, "/\"");
            strcat(connect, gtk_share);
            strcat(connect, "\" -U ");
            strcat(connect, gtk_username);
            strcat(connect, "%");
            strcat(connect, gtk_password);
            strcat(connect, " -c \"cd \\\"");
            strcat(connect, right_path);
            strcat(connect, "\\\" ; lcd \\\"");
            strcat(connect, left_path);
            strcat(connect, "\\\" ; ls\" > ");
            strcat(connect, tempfile);
            fp = popen(connect, "w");
            pclose(fp);
//            printf("cd down remote:[%s]\n", connect);            
	    free(connect);
	    
	    /* If there are permission troubles dont cd down in remote treeview just say there are trubles */
            if((fp = fopen(tempfile, "r"))==NULL)
            {
               printf("\nError opening file\n");
               updating=0;
               return FALSE; 
            }
            fseek(fp, 0, SEEK_END);
            siz=ftell(fp);
            rewind(fp);
            old_buffer=(char *)malloc(siz);
            bzero(old_buffer, siz);
            while((fgets(old_buffer, siz, fp)!=NULL))
            {
               /* Return if there are any permission or error problems */
               if(strstr(old_buffer, "ERRbad")!=0)
               {
                  gtk_entry_set_text(GTK_ENTRY(right_status_entry), _("Wrong username/password combination."));
                  updating=0; 
                  gtk_entry_set_text(GTK_ENTRY(share_entry), "");
                  fclose(fp); free(old_buffer);
                  return FALSE;
               }
               if(strstr(old_buffer, "BAD_NETWORK_NAME")!=0)
               {
                  gtk_entry_set_text(GTK_ENTRY(right_status_entry), _("Wrong username/password combination."));
                  gtk_entry_set_text(GTK_ENTRY(share_entry), "");
                  updating=0;
                  fclose(fp); free(old_buffer);
                  return FALSE;
               }
               if(strstr(old_buffer, "ACCESS_DENIED")!=0)
               {
                  gtk_entry_set_text(GTK_ENTRY(right_status_entry), _("Access denied"));
                  gtk_entry_set_text(GTK_ENTRY(share_entry), "");
                  updating=0;
                  fclose(fp); free(old_buffer);
                  return FALSE;
               }
               if(strstr(old_buffer, "Errnosuchshare")!=0)
               {
                  gtk_entry_set_text(GTK_ENTRY(right_status_entry), _("There is no such share"));
                  gtk_entry_set_text(GTK_ENTRY(share_entry), "");
                  updating=0;
                  fclose(fp); free(old_buffer);
                  return FALSE;
               }
	    }
            fclose(fp);
	    free(old_buffer);	    
            /* show where we are in remote entry */
            strcpy(right_entry, "/");
            strcat(right_entry, gtk_share);
            strcat(right_entry, right_path);
            gtk_entry_set_text(GTK_ENTRY(right_path_entry), right_entry);
            updating=0;
         }  /* CD down remote end */ 


         if( cdup )
         {
            clear_right(right_treeview, NULL);
            right_model = gtk_tree_view_get_model(GTK_TREE_VIEW(right_treeview));
            list_remote(right_treeview, NULL);
            updating=0;
            return FALSE;
         }
      }  /* If button 1 doubleclicked */
   }  /* Check if the list is beeing updated, dont update while its beeing updated */


   /* Not connected .. browse locally */
   if( ! updating && ! connected )
   {
      /* Do local right file actions .. button 2 or 3 pressed, clicked twice */ 
      if(event->type == GDK_2BUTTON_PRESS && (event->button == 2 || event->button == 3) ) 
      {
         filez=(char *)malloc(8192);
         bzero(filez, 8192);
         selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(right_treeview));
         gtk_tree_selection_set_mode(selection, GTK_SELECTION_SINGLE);
         gtk_tree_selection_get_selected(selection, &right_model, &iter);
         gtk_tree_model_get(right_model, &iter, 1, &filez, -1);
         if(filez==NULL)
         {
            free(filez);
            updating=0;
            return FALSE;
         }
         right_actions_window=create_right_actions_window();
         gtk_widget_show(right_actions_window);
         /* Add whats clicked to the rename box in the actions window */
         right_rename_entry = lookup_widget (GTK_WIDGET (right_actions_window), "right_rename_entry");
         gtk_entry_set_text(GTK_ENTRY(right_rename_entry), filez);
         free(filez);
         updating=0;
         return FALSE;
      }


      /* Button 1 clicked 2 times .. cd in local right  */
      if(event->type == GDK_2BUTTON_PRESS && event->button == 1) 
      {
         filez=(char *)malloc(8192);
         bzero(filez, 8192);
         attribz=(char *)malloc(8192);
         bzero(attribz, 8192);
         selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(right_treeview));
         gtk_tree_selection_set_mode(selection, GTK_SELECTION_SINGLE);
         gtk_tree_selection_get_selected(selection, &right_model, &iter);
         gtk_tree_model_get(right_model, &iter, 1, &filez, -1);
         gtk_tree_model_get(right_model, &iter, 3, &attribz, -1);

         /* Perform actions on single files. */
         if(strstr(attribz, "A"))
         {
            mimetypes(NULL, NULL, filez, right_path);
            updating=0;
            return FALSE;
	 }
	 
         if(filez==NULL)
         {
            free(filez);
            updating=0;
            return FALSE;
         }

         /* Action on a mountable device */
         if( strstr(attribz, "M") && strlen(right_mount)==0 )
         {
            strcpy(right_mount, "/mnt/");
	    strcat(right_mount, filez);
            /* Check if its listed in mtab(mounted), itll output "already mounted" for now */
            if((fp = fopen("/etc/mtab", "r"))==NULL)
            {
               printf("Error opening file /etc/mtab\n");
               return FALSE;
            }
            fseek(fp, 0, SEEK_END);
            siz=ftell(fp);
            rewind(fp);
            old_buffer=(char *)malloc(siz);
            bzero(old_buffer, siz);
            while(fgets(old_buffer, siz, fp))
            {
	       sscanf(old_buffer, "%*s %s", tempo);
               if( strstr(tempo, right_mount) && strlen(tempo) == strlen(right_mount) )
	       {
	          mounted=1;
	       }
            }
            fclose(fp);
	    free(old_buffer);
	 
	    if( ! mounted ) /* Check permissions */
	    {
	       strcpy(mount, "mount ");
	       strcat(mount, right_mount);
	       system(mount);
               /* Nautilus keeps popping up */
	       strcpy(mount, _("Mounted the device: "));
	       strcat(mount, right_mount);
	       strcat(mount, _(" CD up to unmount it."));
               right_status_entry = lookup_widget (GTK_WIDGET (left_treeview), "right_status_entry");
               gtk_entry_set_text(GTK_ENTRY(right_status_entry), mount);
               strcpy(right_path, "/mnt/");
	       strcat(right_path, filez);
               gtk_entry_set_text(GTK_ENTRY(right_path_entry), right_path);
	    }
	    else
	      {
                 strcpy(right_path, "/mnt/");
	         strcat(right_path, filez);
                 right_status_entry = lookup_widget (GTK_WIDGET (right_treeview), "right_status_entry");
                 gtk_entry_set_text(GTK_ENTRY(right_status_entry), _("The device is already mounted, browsing it."));
	      }
              /* update left treeview */
              list_right(right_treeview, NULL);
              free(filez); free(attribz);
              return FALSE;
         }


         /* CD up locally in the right treeview */
         if( strstr(filez, "..") && strlen(filez)==2 && strstr(attribz, "D") )
         {
	    if(strlen(right_path)==1)
	    {
	       free(filez); free(attribz);
	       return FALSE;
	    }
	    str=(char *)malloc(8192);
            bzero(str, 8192);
            str1=(char *)malloc(8192);
            bzero(str1, 8192);
            str2=(char *)malloc(8192);
            bzero(str2, 8192);
            cut=(char *)malloc(8192);
            bzero(cut, 8192);
            strcpy(str, right_path); 
            StrCut(str, 0, retPos(str,'/'), str1);
            strcpy(right_path, str1); /* copy it back after cutpath */
            free(str); free(str1); free(str2); free(cut); 

            if(strlen(right_path)==0 )
            strcpy(right_path, "/");
            strcat(right_entry, right_path);
            gtk_entry_set_text(GTK_ENTRY(right_path_entry), right_entry);

            /* If it has a mounted device and the other side isnt in it */
	    if( strlen(right_mount)>0 && strstr(right_path, "/mnt") 
	    &&  strlen(right_path)==4 )
            {
	       if( strstr(left_mount, right_mount) 
	       && strlen(left_mount)==strlen(right_mount) )
	       {
 	          strcpy(right_mount, "");
               }
	       else	          
	         {
	            strcpy(umount, "umount ");
	            strcat(umount, right_mount);
	            system(umount);
	            strcpy(umount, _("Unmounted the device: "));
	            strcat(umount, right_mount);
                    right_status_entry = lookup_widget (GTK_WIDGET (right_treeview), "right_status_entry");
                    gtk_entry_set_text(GTK_ENTRY(right_status_entry), umount);
 	            strcpy(right_mount, "");
	         }
            }



	 }
         else
	    if( strstr(attribz, "D") )
	    {
 	       /* CD down local right */
               if( strstr(filez, "dev") && strlen(filez)==3  && strlen(right_path)<2 )
	       {
                  left_status_entry = lookup_widget (GTK_WIDGET (right_path_entry), "left_status_entry");
                  gtk_entry_set_text(GTK_ENTRY(right_status_entry), _("CD /dev is not allowed"));
	          free(filez); free(attribz);
                  updating=0;
		  return FALSE;
	       }
	       
	       if(strlen(right_path)>1 )
               strcat(right_entry, "/");
	       strcat(right_entry, filez);
	       strcat(right_path, right_entry);
               gtk_entry_set_text(GTK_ENTRY(right_path_entry), right_path);
	    }    
            free(filez);
	    free(attribz);
            updating=0;
            list_right(right_treeview, NULL);
      }
   }  /* Browse local right */
   updating=0;
   return FALSE;
}



void
on_help_button_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
   help_window = create_help_window ();
   gtk_widget_show(help_window);  
}


void
on_right_rename_button_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
   FILE *fp;
   char *connect;
   char *filez, *attribz, *old_buffer;
   char status[8192]="";
   long siz;
   GtkTreeIter iter;
   GtkTreeModel *right_model;
   GtkTreeSelection *selection;
   G_CONST_RETURN gchar *gtk_ip;
   G_CONST_RETURN gchar *gtk_share;
   G_CONST_RETURN gchar *gtk_username;
   G_CONST_RETURN gchar *gtk_password;
   G_CONST_RETURN gchar *gtk_rename;

   selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(right_treeview));
   gtk_tree_selection_set_mode(selection, GTK_SELECTION_SINGLE);
   gtk_tree_selection_get_selected(selection, &right_model, &iter);
   gtk_tree_model_get(right_model, &iter, 1, &filez, -1);
   gtk_tree_model_get(right_model, &iter, 3, &attribz, -1);

   if( strlen(filez)==0 )
   return;

   right_path_entry  = lookup_widget (GTK_WIDGET (right_treeview), "right_path_entry");
   ip_entry  = lookup_widget (GTK_WIDGET (right_treeview), "ip_entry");
   share_entry  = lookup_widget (GTK_WIDGET (right_treeview), "share_entry");
   user_entry  = lookup_widget (GTK_WIDGET (right_treeview), "user_entry");
   password_entry  = lookup_widget (GTK_WIDGET (right_treeview), "password_entry");
   right_rename_entry = lookup_widget (GTK_WIDGET (right_actions_window), "right_rename_entry");

   gtk_ip = gtk_entry_get_text(GTK_ENTRY(ip_entry));
   gtk_share = gtk_entry_get_text(GTK_ENTRY(share_entry));
   gtk_username = gtk_entry_get_text(GTK_ENTRY(user_entry));
   gtk_password = gtk_entry_get_text(GTK_ENTRY(password_entry));
   gtk_rename = gtk_entry_get_text(GTK_ENTRY(right_rename_entry));

   if( strlen(gtk_rename)==0 )
   {
      gtk_entry_set_text(GTK_ENTRY(right_rename_entry), _("Specify a name"));
      return;
   }

   if( ( strlen(gtk_rename)==2 && strstr(gtk_rename, "..") ) || ( strstr(filez, "..") && strlen(filez)==2 ) )
   {
      gtk_entry_set_text(GTK_ENTRY(right_rename_entry), _("Cant rename \"..\""));
      return;
   }

   if(strstr(gtk_rename, "?") || strstr(gtk_rename, "$") || strstr(gtk_rename, "/") || strstr(gtk_rename, "\\") || strstr(gtk_rename, ":"))
   {
      gtk_entry_set_text(GTK_ENTRY(right_rename_entry), _("Cant use: ? $ / \\ : * <> \" |"));
      return;
   }
   if( strstr(gtk_rename, "*") || strstr(gtk_rename, "<") || strstr(gtk_rename, ">") || strstr(gtk_rename, "|") || strstr(gtk_rename, "\"")) 
   {
      gtk_entry_set_text(GTK_ENTRY(right_rename_entry), _("Cant use: ? $ / \\ : * <> \" |"));
      return;
   }

   /* Not connected .. Rename local right file or dir */
   if( ! connected )
   {
      connect=(char *)malloc(8192);
      bzero(connect, 8192);
      strcpy(connect, "mv \"");
      strcat(connect, right_path);
      strcat(connect, "/");
      strcat(connect, filez);
      strcat(connect, "\" \"");
      strcat(connect, right_path);
      strcat(connect, "/");
      strcat(connect, gtk_rename);
      strcat(connect, "\"");

      if(strstr(attribz, "A"))
      strcpy(status, _("Renaming file: "));
      else
      strcpy(status, _("Renaming Directory: "));

      strcat(status, filez);
      strcat(status, _(" please wait..."));
      left_status_entry  = lookup_widget (GTK_WIDGET (left_treeview), "left_status_entry");
      gtk_entry_set_text(GTK_ENTRY(right_status_entry), status);
      /* So it will have time to update the status entry */
      while(gtk_events_pending ())
      gtk_main_iteration ();
  
      if((fp = popen(connect, "w"))==NULL)
      {
         printf("\nError opening file\n");
         return;
      }
      pclose(fp);
      free(connect);
      strcpy(status, _("Renaming of: "));
      strcat(status, filez);
      strcat(status, _(" complete."));
      left_status_entry  = lookup_widget (GTK_WIDGET (left_treeview), "left_status_entry");
      gtk_entry_set_text(GTK_ENTRY(right_status_entry), status);
      list_right(right_treeview, NULL);
      if( strstr(right_path, left_path) && strlen(left_path)==strlen(right_path) )
      list_left(left_treeview, NULL);
      gtk_widget_destroy(right_actions_window);
      return;
   }

   /* Rename a file or directory on remote server */
   connect=(char *)malloc(8192);
   bzero(connect, 8192);
   strcpy(connect, "smbclient //");
   strcat(connect, gtk_ip);
   strcat(connect, "/\"");
   strcat(connect, gtk_share);
   strcat(connect, "\" -U ");
   strcat(connect, gtk_username);
   strcat(connect, "%");
   strcat(connect, gtk_password);
   strcat(connect, " -c \"cd \\\"");
   strcat(connect, right_path);
   strcat(connect, "\\\" ; lcd \\\"");
   strcat(connect, left_path);
   strcat(connect, "\\\" ; rename \\\"");
   strcat(connect, filez);
   strcat(connect, "\\\"");
   strcat(connect, " \\\"");
   strcat(connect, gtk_rename);
   strcat(connect, "\\\"\" > "); /* Read errors */
   strcat(connect, tempfile);
   if((fp = popen(connect, "w"))==NULL) /* Add permission detection */
   {
      printf("\nError opening file\n");
      updating=0;
      return;
   }
   pclose(fp);
   free(connect);
      
   if(strstr(attribz, "A"))
   {  
      strcpy(status, _("Renamed file: "));
      strcat(status, filez);
      strcat(status, _(" to: "));
      strcat(status, gtk_rename);
   }
   else
      {
         strcpy(status, _("Renamed directory: "));
         strcat(status, filez);
         strcat(status, _(" to: "));
         strcat(status, gtk_rename);
      }      
      gtk_widget_destroy(right_actions_window);

      /* If there are permission troubles show it */
      if((fp = fopen(tempfile, "r"))==NULL)
      {
         printf("\nError opening file on upload file\n");
         return; 
      }
      fseek(fp, 0, SEEK_END);
      siz=ftell(fp);
      rewind(fp);
      old_buffer=(char *)malloc(siz);
      bzero(old_buffer, siz);
      while((fgets(old_buffer, siz, fp)!=NULL))
      {
         if(strstr(old_buffer, "ERRSRV - ERRaccess")!=0) /* Windows 98 */
         {
            /* "could not rename it" instead of file / dir is just lazy :) */
            gtk_entry_set_text(GTK_ENTRY(right_status_entry), _("Wrong username/password combination, could not rename it."));
            fclose(fp);
            strcpy(old_buffer, "rm -f ");
	    strcat(old_buffer, tempfile);
	    system(old_buffer);
            free(old_buffer);	    
            return;
         }
         if(strstr(old_buffer, "ERRDOS - ERRnoaccess")!=0) /* Linux samba and w2k possibly */
         {
            gtk_entry_set_text(GTK_ENTRY(right_status_entry), _("Wrong username/password combination, could not rename it."));
            fclose(fp);
            strcpy(old_buffer, "rm -f ");
	    strcat(old_buffer, tempfile);
	    system(old_buffer);
            free(old_buffer);	    
            return;
         }
         if(strstr(old_buffer, "ERRbad")!=0)
         {
            gtk_entry_set_text(GTK_ENTRY(right_status_entry), _("Wrong username/password combination, could not rename it."));
            free(old_buffer);	    
            return;
         }
         if(strstr(old_buffer, "BAD_NETWORK_NAME")!=0)
         {
            gtk_entry_set_text(GTK_ENTRY(right_status_entry), _("Wrong username/password combination, could not rename it."));
            fclose(fp);
            strcpy(old_buffer, "rm -f ");
	    strcat(old_buffer, tempfile);
	    system(old_buffer);
            free(old_buffer);	    
            return;
         }
         if(strstr(old_buffer, "ACCESS_DENIED")!=0)
         {
            gtk_entry_set_text(GTK_ENTRY(right_status_entry), _("Wrong username/password combination, could not rename it."));
            fclose(fp);
            strcpy(old_buffer, "rm -f ");
	    strcat(old_buffer, tempfile);
	    system(old_buffer);
            free(old_buffer);	    
            return;
         }
      }
      fclose(fp);
      free(old_buffer);	    

      /* We get here if everything is ok */
      gtk_entry_set_text(GTK_ENTRY(right_status_entry), status);
      clear_right(right_treeview, NULL);
      right_model = gtk_tree_view_get_model(GTK_TREE_VIEW(right_treeview));
      list_remote(right_treeview, NULL);
}


void
on_right_mkdir_button_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
   FILE *fp;
   char *connect;
   char *filez, *attribz, *old_buffer;
   char status[8192]="";
   long siz;
   GtkTreeIter iter;
   GtkTreeModel *right_model;
   GtkTreeSelection *selection;
   G_CONST_RETURN gchar *gtk_ip;
   G_CONST_RETURN gchar *gtk_share;
   G_CONST_RETURN gchar *gtk_username;
   G_CONST_RETURN gchar *gtk_password;
   G_CONST_RETURN gchar *gtk_mkdir;

   selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(right_treeview));
   gtk_tree_selection_set_mode(selection, GTK_SELECTION_SINGLE);
   gtk_tree_selection_get_selected(selection, &right_model, &iter);
   gtk_tree_model_get(right_model, &iter, 1, &filez, -1);
   gtk_tree_model_get(right_model, &iter, 3, &attribz, -1);

   if( strlen(filez)==0 )
   return;

   right_path_entry  = lookup_widget (GTK_WIDGET (right_treeview), "right_path_entry");
   ip_entry  = lookup_widget (GTK_WIDGET (right_treeview), "ip_entry");
   share_entry  = lookup_widget (GTK_WIDGET (right_treeview), "share_entry");
   user_entry  = lookup_widget (GTK_WIDGET (right_treeview), "user_entry");
   password_entry  = lookup_widget (GTK_WIDGET (right_treeview), "password_entry");
   right_mkdir_entry = lookup_widget (GTK_WIDGET (right_actions_window), "right_mkdir_entry");

   gtk_ip = gtk_entry_get_text(GTK_ENTRY(ip_entry));
   gtk_share = gtk_entry_get_text(GTK_ENTRY(share_entry));
   gtk_username = gtk_entry_get_text(GTK_ENTRY(user_entry));
   gtk_password = gtk_entry_get_text(GTK_ENTRY(password_entry));
   gtk_mkdir = gtk_entry_get_text(GTK_ENTRY(right_mkdir_entry));

   if(strlen(gtk_mkdir)==0)
   {
      gtk_entry_set_text(GTK_ENTRY(right_mkdir_entry), _("Specify dir name"));
      return;
   }

   if(strstr(gtk_mkdir, "?") || strstr(gtk_mkdir, "$") || strstr(gtk_mkdir, "/") || strstr(gtk_mkdir, "\\") || strstr(gtk_mkdir, ":"))
   {
      gtk_entry_set_text(GTK_ENTRY(right_mkdir_entry), _("Cant use: ? $ / \\ : * <> \" |"));
      return;
   }
   if( strstr(gtk_mkdir, "*") || strstr(gtk_mkdir, "<") || strstr(gtk_mkdir, ">") || strstr(gtk_mkdir, "|") || strstr(gtk_mkdir, "\""))
   {
      gtk_entry_set_text(GTK_ENTRY(right_mkdir_entry), _("Cant use: ? $ / \\ : * <> \" |"));
      return;
   }

   /* Not connected .. make local right dir */
   if( ! connected )
   {
      connect=(char *)malloc(8192);
      bzero(connect, 8192);
      strcpy(connect, "mkdir \"");
      strcat(connect, right_path);
      strcat(connect, "/");
      strcat(connect, gtk_mkdir);
      strcat(connect, "\"");

      strcpy(status, _("Making directory: "));

      strcat(status, filez);
      strcat(status, _(" please wait..."));
      left_status_entry  = lookup_widget (GTK_WIDGET (left_treeview), "left_status_entry");
      gtk_entry_set_text(GTK_ENTRY(right_status_entry), status);
      /* So it will have time to update the status entry */
      while(gtk_events_pending ())
      gtk_main_iteration ();
  
      if((fp = popen(connect, "w"))==NULL)
      {
         printf("\nError opening file\n");
         return;
      }
      pclose(fp);
      free(connect);
      strcpy(status, _("Creation of directory: "));
      strcat(status, gtk_mkdir);
      strcat(status, _(" complete."));
      right_status_entry  = lookup_widget (GTK_WIDGET (right_treeview), "right_status_entry");
      gtk_entry_set_text(GTK_ENTRY(right_status_entry), status);
      list_right(right_treeview, NULL);
      if( strstr(right_path, left_path) && strlen(left_path)==strlen(right_path) )
      list_left(left_treeview, NULL);
      gtk_widget_destroy(right_actions_window);
      return;
   }

   /* Make a directory on remote server */
   connect=(char *)malloc(8192);
   bzero(connect, 8192);
   strcpy(connect, "smbclient //");
   strcat(connect, gtk_ip);
   strcat(connect, "/\"");
   strcat(connect, gtk_share);
   strcat(connect, "\" -U ");
   strcat(connect, gtk_username);
   strcat(connect, "%");
   strcat(connect, gtk_password);
   strcat(connect, " -c \"cd \\\"");
   strcat(connect, right_path);
   strcat(connect, "\\\" ; lcd \\\"");
   strcat(connect, left_path);
   strcat(connect, "\\\" ; mkdir \\\"");
   strcat(connect, gtk_mkdir);
   strcat(connect, "\\\"\" > ");
   strcat(connect, tempfile);

   strcpy(status, _("Created directory: "));
   strcat(status, gtk_mkdir);

   gtk_widget_destroy(right_actions_window);

   if((fp = popen(connect, "w"))==NULL) /* Add permission detection */
   {
      printf("\nError opening file\n");
      updating=0;
      return;
   }
   pclose(fp);
   free(connect);

   /* If there are permission troubles show it */
   if((fp = fopen(tempfile, "r"))==NULL)
   {
      printf("\nError opening file on upload file\n");
      return; 
   }
   fseek(fp, 0, SEEK_END);
   siz=ftell(fp);
   rewind(fp);
   old_buffer=(char *)malloc(siz);
   bzero(old_buffer, siz);
   while((fgets(old_buffer, siz, fp)!=NULL))
   {
      if(strstr(old_buffer, "ERRSRV - ERRaccess")!=0) /* Windows 98 */
      {
         gtk_entry_set_text(GTK_ENTRY(right_status_entry), _("Wrong username/password combination, could not make the directory"));
         free(old_buffer);	    
         return;
      }
      if(strstr(old_buffer, "ERRDOS - ERRnoaccess")!=0) /* Linux samba and w2k possibly */
      {
         gtk_entry_set_text(GTK_ENTRY(right_status_entry), _("Wrong username/password combination, could not make the directory"));
         free(old_buffer);	    
         return;
      }
      if(strstr(old_buffer, "ERRbad")!=0)
      {
         gtk_entry_set_text(GTK_ENTRY(right_status_entry), _("Wrong username/password combination, could not make the directory"));
         free(old_buffer);	    
         return;
      }
      if(strstr(old_buffer, "BAD_NETWORK_NAME")!=0)
      {
         gtk_entry_set_text(GTK_ENTRY(right_status_entry), _("Wrong username/password combination, could not make the directory"));
         free(old_buffer);	    
         return;
      }
      if(strstr(old_buffer, "ACCESS_DENIED")!=0)
      {
         gtk_entry_set_text(GTK_ENTRY(right_status_entry), _("Wrong username/password combination, could not make the directory"));
         free(old_buffer);	    
         return;
      }
   }
   fclose(fp);
   strcpy(old_buffer, "rm -f \"");
   strcat(old_buffer, homedirectory);
   strcat(old_buffer, "/.gfilemanager/");
   strcat(old_buffer, tempfile);
   strcat(old_buffer, "\"");
   system(old_buffer);
   free(old_buffer);	    
   left_status_entry  = lookup_widget (GTK_WIDGET (right_treeview), "left_status_entry");
   gtk_entry_set_text(GTK_ENTRY(right_status_entry), status);
   clear_right(right_treeview, NULL);
   right_model = gtk_tree_view_get_model(GTK_TREE_VIEW(right_treeview));
   list_remote(right_treeview, NULL);
}


/* add Errorcheck for local */
void
on_right_addfile_button_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
   FILE *fp;
   long siz;
   char *connect, *old_buffer;
   char *filez, *attribz;   //, *old_buffer; // permission checking same for siz
   char status[8192]="", mkfile[8192]="";
   GtkTreeIter iter;
   GtkTreeModel *right_model;
   GtkTreeSelection *selection;
   G_CONST_RETURN gchar *gtk_ip;
   G_CONST_RETURN gchar *gtk_share;
   G_CONST_RETURN gchar *gtk_username;
   G_CONST_RETURN gchar *gtk_password;
   G_CONST_RETURN gchar *gtk_addfile;

   selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(right_treeview));
   gtk_tree_selection_set_mode(selection, GTK_SELECTION_SINGLE);
   gtk_tree_selection_get_selected(selection, &right_model, &iter);
   gtk_tree_model_get(right_model, &iter, 1, &filez, -1);
   gtk_tree_model_get(right_model, &iter, 3, &attribz, -1);
   if( strlen(filez)==0 )
   {
      return;
   }
   right_path_entry  = lookup_widget (GTK_WIDGET (right_treeview), "right_path_entry");
   ip_entry  = lookup_widget (GTK_WIDGET (right_treeview), "ip_entry");
   share_entry  = lookup_widget (GTK_WIDGET (right_treeview), "share_entry");
   user_entry  = lookup_widget (GTK_WIDGET (right_treeview), "user_entry");
   password_entry  = lookup_widget (GTK_WIDGET (right_treeview), "password_entry");
   right_addfile_entry = lookup_widget (GTK_WIDGET (right_actions_window), "right_addfile_entry");

   gtk_ip = gtk_entry_get_text(GTK_ENTRY(ip_entry));
   gtk_share = gtk_entry_get_text(GTK_ENTRY(share_entry));
   gtk_username = gtk_entry_get_text(GTK_ENTRY(user_entry));
   gtk_password = gtk_entry_get_text(GTK_ENTRY(password_entry));
   gtk_addfile = gtk_entry_get_text(GTK_ENTRY(right_addfile_entry));

   if( strlen(gtk_addfile)==0 )
   {
      gtk_entry_set_text(GTK_ENTRY(right_addfile_entry), _("Specify a filename"));
      return;
   }
   /* Not connected .. make local right file */
   if( ! connected )
   {
      connect=(char *)malloc(8192);
      bzero(connect, 8192);
      strcpy(connect, "touch \"");
      strcat(connect, right_path);
      strcat(connect, "/");
      strcat(connect, gtk_addfile);
      strcat(connect, "\"");

      strcpy(status, _("Making file: "));
      strcat(status, filez);
      strcat(status, _(" please wait..."));
      left_status_entry  = lookup_widget (GTK_WIDGET (left_treeview), "left_status_entry");
      gtk_entry_set_text(GTK_ENTRY(right_status_entry), status);
      /* So it will have time to update the status entry */
      while(gtk_events_pending ())
      gtk_main_iteration ();
  
      if((fp = popen(connect, "w"))==NULL)
      {
         printf("\nError opening file\n");
         return;
      }
      pclose(fp);
      free(connect);
      strcpy(status, _("Creation of file: "));
      strcat(status, gtk_addfile);
      strcat(status, _(" complete."));
      right_status_entry  = lookup_widget (GTK_WIDGET (right_treeview), "right_status_entry");
      gtk_entry_set_text(GTK_ENTRY(right_status_entry), status);
      list_right(right_treeview, NULL);
      if( strstr(right_path, left_path) && strlen(left_path)==strlen(right_path) )
      list_left(left_treeview, NULL);
      gtk_widget_destroy(right_actions_window);
      return;
   }
   
   /* Make a new file on the sambaserver (touch in HOME/.gfilemanager/ then upload it) */
   strcpy(mkfile, "touch \"");
   strcat(mkfile, homedirectory);
   strcat(mkfile, "/.gfilemanager/");
   strcat(mkfile, gtk_addfile);
   strcat(mkfile, "\"");
   system(mkfile);

   connect=(char *)malloc(8192);
   bzero(connect, 8192);
   strcpy(connect, "smbclient //");
   strcat(connect, gtk_ip);
   strcat(connect, "/\"");
   strcat(connect, gtk_share);
   strcat(connect, "\" -U ");
   strcat(connect, gtk_username);
   strcat(connect, "%");
   strcat(connect, gtk_password);
   strcat(connect, " -c \"cd \\\"");
   strcat(connect, right_path);
   strcat(connect, "\\\" ; lcd \\\"");
   strcat(connect, homedirectory);
   strcat(connect, "/.gfilemanager");
   strcat(connect, "\\\" ; put \\\"");
   strcat(connect, gtk_addfile);
   strcat(connect, "\\\"\" > ");
   strcat(connect, tempfile);

   if((fp = popen(connect, "w"))==NULL) /* Add permission detection */
   {
      printf("\nError opening file\n");
      return;
   }
   pclose(fp);
   free(connect);

   /* If there are permission troubles show it */
   if((fp = fopen(tempfile, "r"))==NULL)
   {
      printf("\nError opening file on upload new file\n");
      return; 
   }
   fseek(fp, 0, SEEK_END);
   siz=ftell(fp);
   rewind(fp);
   old_buffer=(char *)malloc(siz);
   bzero(old_buffer, siz);
   while((fgets(old_buffer, siz, fp)!=NULL))
   {
      if(strstr(old_buffer, "ERRSRV - ERRaccess")!=0) /* Windows 98 */
      {
         gtk_entry_set_text(GTK_ENTRY(right_status_entry), _("Wrong username/password combination, could not make the file"));
         free(old_buffer);	    
         return;
      }
      if(strstr(old_buffer, "ERRDOS - ERRnoaccess")!=0) /* Linux samba and w2k possibly */
      {
         gtk_entry_set_text(GTK_ENTRY(right_status_entry), _("Wrong username/password combination, could not make the directory"));
         free(old_buffer);	    
         return;
      }
      if(strstr(old_buffer, "ERRbad")!=0)
      {
         gtk_entry_set_text(GTK_ENTRY(right_status_entry), _("Wrong username/password combination, could not make the directory"));
         free(old_buffer);	    
         return;
      }
      if(strstr(old_buffer, "BAD_NETWORK_NAME")!=0)
      {
         gtk_entry_set_text(GTK_ENTRY(right_status_entry), _("Wrong username/password combination, could not make the directory"));
         free(old_buffer);	    
         return;
      }
      if(strstr(old_buffer, "ACCESS_DENIED")!=0)
      {
         gtk_entry_set_text(GTK_ENTRY(right_status_entry), _("Wrong username/password combination, could not make the directory"));
         free(old_buffer);	    
         return;
      }
   }
   fclose(fp);
   free(old_buffer);	    
   strcpy(status, _("Created file: "));
   strcat(status, gtk_addfile);
   left_status_entry  = lookup_widget (GTK_WIDGET (right_treeview), "left_status_entry");
   gtk_entry_set_text(GTK_ENTRY(right_status_entry), status);
   clear_right(right_treeview, NULL);
   right_model = gtk_tree_view_get_model(GTK_TREE_VIEW(right_treeview));
   list_remote(right_treeview, NULL);
   gtk_widget_destroy(right_actions_window);
   strcpy(mkfile, "rm -f \"");
   strcat(mkfile, homedirectory);
   strcat(mkfile, "/.gfilemanager/");
   strcat(mkfile, gtk_addfile);
   strcat(mkfile, "\"");
   system(mkfile);
}

/* Fixme doesnt allow deleting nonempty directories or even a directory with just empty subdirectories */
/* Check for local errors */
void
on_right_delete_button_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
   FILE *fp;
   char *connect;
   char *filez, *attribz, *old_buffer;
   char status[8192]="";
   long siz;
   GtkTreeIter iter;
   GtkTreeModel *right_model;
   GtkTreeSelection *selection;
   G_CONST_RETURN gchar *gtk_ip;
   G_CONST_RETURN gchar *gtk_share;
   G_CONST_RETURN gchar *gtk_username;
   G_CONST_RETURN gchar *gtk_password;
   G_CONST_RETURN gchar *gtk_rename;

   selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(right_treeview));
   gtk_tree_selection_set_mode(selection, GTK_SELECTION_SINGLE);
   gtk_tree_selection_get_selected(selection, &right_model, &iter);
   gtk_tree_model_get(right_model, &iter, 1, &filez, -1);
   gtk_tree_model_get(right_model, &iter, 3, &attribz, -1);
   if( strlen(filez)==0 )
   {
      right_status_entry  = lookup_widget (GTK_WIDGET (right_treeview), "right_status_entry");
      gtk_entry_set_text(GTK_ENTRY(right_status_entry), _("This entry is broken (locale trouble)."));
      gtk_widget_destroy(right_actions_window);
      return;
   }
   if( strstr(filez, "..") && strlen(filez)==2 )
   {
      right_status_entry  = lookup_widget (GTK_WIDGET (right_treeview), "right_status_entry");
      gtk_entry_set_text(GTK_ENTRY(right_status_entry), _("Deletion of entry \"..\" denied."));
      gtk_widget_destroy(right_actions_window);
      return;
   }
   right_path_entry  = lookup_widget (GTK_WIDGET (right_treeview), "right_path_entry");
   ip_entry  = lookup_widget (GTK_WIDGET (right_treeview), "ip_entry");
   share_entry  = lookup_widget (GTK_WIDGET (right_treeview), "share_entry");
   user_entry  = lookup_widget (GTK_WIDGET (right_treeview), "user_entry");
   password_entry  = lookup_widget (GTK_WIDGET (right_treeview), "password_entry");
   right_rename_entry = lookup_widget (GTK_WIDGET (right_actions_window), "right_rename_entry");

   gtk_ip = gtk_entry_get_text(GTK_ENTRY(ip_entry));
   gtk_share = gtk_entry_get_text(GTK_ENTRY(share_entry));
   gtk_username = gtk_entry_get_text(GTK_ENTRY(user_entry));
   gtk_password = gtk_entry_get_text(GTK_ENTRY(password_entry));
   gtk_rename = gtk_entry_get_text(GTK_ENTRY(right_rename_entry));

   /* Not connected .. Delete local right file or dir */
   if( ! connected )
   {
      connect=(char *)malloc(8192);
      bzero(connect, 8192);
      strcpy(connect, "rm -rf \"");
      strcat(connect, right_path);
      strcat(connect, "/");
      strcat(connect, filez);
      strcat(connect, "\"");
      if(strstr(attribz, "A"))
      strcpy(status, _("Deleting file: "));
      else
      strcpy(status, _("Deleting directory: "));

      strcat(status, filez);
      strcat(status, _(" please wait..."));
      right_status_entry  = lookup_widget (GTK_WIDGET (right_treeview), "right_status_entry");
 
      if( strstr(filez,"..") )
      {
         gtk_entry_set_text(GTK_ENTRY(right_status_entry), _("Deletion of entry \"..\" is not allowed."));      
         free(connect);
	 return;
      }      
      
      gtk_entry_set_text(GTK_ENTRY(right_status_entry), status);
      /* So it will have time to update the status entry */
      while(gtk_events_pending ())
      gtk_main_iteration ();
  
      if((fp = popen(connect, "w"))==NULL)
      {
         printf("\nError opening file\n");
         return;
      }
      pclose(fp);
      free(connect);
      strcpy(status, _("Deletion of: "));
      strcat(status, filez);
      strcat(status, _(" complete."));
      right_status_entry  = lookup_widget (GTK_WIDGET (right_treeview), "right_status_entry");
      gtk_entry_set_text(GTK_ENTRY(right_status_entry), status);
      list_right(right_treeview, NULL);
      if( strstr(right_path, left_path) && strlen(left_path)==strlen(right_path) )
      list_left(left_treeview, NULL);
      gtk_widget_destroy(right_actions_window);
      return;
   }

   /* Delete a file or directory on remote server */
   strcpy(status, _("Deleting: "));
   strcat(status, filez);
   right_status_entry  = lookup_widget (GTK_WIDGET (right_treeview), "right_status_entry");
   gtk_entry_set_text(GTK_ENTRY(right_status_entry), status);
   while(gtk_events_pending ())
   gtk_main_iteration ();

   connect=(char *)malloc(8192);
   bzero(connect, 8192);
   strcpy(connect, "smbclient //");
   strcat(connect, gtk_ip);
   strcat(connect, "/\"");
   strcat(connect, gtk_share);
   strcat(connect, "\" -U ");
   strcat(connect, gtk_username);
   strcat(connect, "%");
   strcat(connect, gtk_password);
   strcat(connect, " -c \"cd \\\"");
   strcat(connect, right_path);
   strcat(connect, "\\\" ; lcd \\\"");
   strcat(connect, left_path);
      
   if( strstr(attribz, "D")==0 )
   {  
      strcat(connect, "\\\" ; del \\\"");
      strcat(connect, filez);
      strcat(connect, "\\\"\" > ");
      strcat(connect, tempfile);
      strcpy(status, "Deleted file: ");
      strcat(status, filez);
   }
   else
      {
         strcat(connect, "\\\" ; recurse ; del \\\""); /* Recurse deleting subdirectories (how) */
         strcat(connect, filez);
         strcat(connect, "\\\"");
         strcat(connect, " ; rmdir \\\""); /* How can i delete all the empty subdirectories ? */
         strcat(connect, filez);
         strcat(connect, "\\\"\" > ");
         strcat(connect, tempfile);
         strcpy(status, _("Deleted directory: "));
         strcat(status, filez);
      }      

      if((fp = popen(connect, "w"))==NULL) /* Add permission detection */
      {
         printf("\nError opening file\n");
         updating=0;
         return;
      }
      pclose(fp);
      free(connect);

      gtk_widget_destroy(right_actions_window);

      /* If there are permission troubles show it */
      if((fp = fopen(tempfile, "r"))==NULL)
      {
         printf("\nError opening file on upload file\n");
         return; 
      }
      fseek(fp, 0, SEEK_END);
      siz=ftell(fp);
      rewind(fp);
      old_buffer=(char *)malloc(siz);
      bzero(old_buffer, siz);
      while((fgets(old_buffer, siz, fp)!=NULL))
      {
         if(strstr(old_buffer, "ERRSRV - ERRaccess")!=0)
         {
            gtk_entry_set_text(GTK_ENTRY(right_status_entry), _("Wrong username/password combination, could not delete it (cant delete directories recursively)"));
            free(old_buffer);	    
            return;
         }
         if(strstr(old_buffer, "ERRDOS - ERRnoaccess")!=0)
         {
            gtk_entry_set_text(GTK_ENTRY(right_status_entry), _("Wrong username/password combination, could not delete it (cant delete directories recursively)"));
            free(old_buffer);	    
            return;
         }
         if(strstr(old_buffer, "ERRbad")!=0)
         {
            gtk_entry_set_text(GTK_ENTRY(right_status_entry), _("Wrong username/password combination, could not delete it"));
            free(old_buffer);	    
            return;
         }
         if(strstr(old_buffer, "BAD_NETWORK_NAME")!=0)
         {
            gtk_entry_set_text(GTK_ENTRY(right_status_entry), _("Wrong username/password combination, could not delete it"));
            free(old_buffer);	    
            return;
         }
         if(strstr(old_buffer, "ACCESS_DENIED")!=0)
         {
            gtk_entry_set_text(GTK_ENTRY(right_status_entry), _("Wrong username/password combination, could not delete it (cant delete directories recursively)"));
            free(old_buffer);	    
            return;
         }
      }
      fclose(fp);
      free(old_buffer);	    
      right_status_entry  = lookup_widget (GTK_WIDGET (right_treeview), "right_status_entry");
      gtk_entry_set_text(GTK_ENTRY(right_status_entry), status);
      clear_right(right_treeview, NULL);
      right_model = gtk_tree_view_get_model(GTK_TREE_VIEW(right_treeview));
      list_remote(right_treeview, NULL);
}


void
on_right_cancel_button_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
   gtk_widget_destroy(right_actions_window);
}


void
on_right_download_button_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
   FILE *fp;
   char *connect;
   char *filez, *attribz, *sizez;
   char status[8192]="";
   GtkTreeIter iter;
   GtkTreeModel *right_model;
   GtkTreeModel *left_model;
   GtkTreeSelection *selection;
   G_CONST_RETURN gchar *gtk_ip;
   G_CONST_RETURN gchar *gtk_share;
   G_CONST_RETURN gchar *gtk_username;
   G_CONST_RETURN gchar *gtk_password;
   selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(right_treeview));
   gtk_tree_selection_set_mode(selection, GTK_SELECTION_SINGLE);
   gtk_tree_selection_get_selected(selection, &right_model, &iter);
   gtk_tree_model_get(right_model, &iter, 1, &filez, -1);
   gtk_tree_model_get(right_model, &iter, 2, &sizez, -1);
   gtk_tree_model_get(right_model, &iter, 3, &attribz, -1);
   if( strlen(filez)==0 )
   {
      right_status_entry  = lookup_widget (GTK_WIDGET (right_treeview), "right_status_entry");
      gtk_entry_set_text(GTK_ENTRY(right_status_entry), _("Permission denied, entry has zero length."));
      gtk_widget_destroy(right_actions_window);
      updating=0;
      return;
   }
   if( strstr(filez, "..") && strlen(filez)==2 )
   {
      right_status_entry  = lookup_widget (GTK_WIDGET (right_treeview), "right_status_entry");
      gtk_entry_set_text(GTK_ENTRY(right_status_entry), _("Permission denied entry is \"..\"."));
      gtk_widget_destroy(right_actions_window);
      updating=0;
      return;
   }

   right_path_entry  = lookup_widget (GTK_WIDGET (right_treeview), "right_path_entry");
   gtk_ip = gtk_entry_get_text(GTK_ENTRY(ip_entry));
   gtk_share = gtk_entry_get_text(GTK_ENTRY(share_entry));
   gtk_username = gtk_entry_get_text(GTK_ENTRY(user_entry));
   gtk_password = gtk_entry_get_text(GTK_ENTRY(password_entry));

   /* Not connected .. copy file or dir from the right to the left treeview */
   if( ! connected )
   {
      connect=(char *)malloc(8192);
      bzero(connect, 8192);
      strcpy(connect, "cp -rf \"");
      strcat(connect, right_path);
      strcat(connect, "/");
      strcat(connect, filez);
      strcat(connect, "\"");
      strcat(connect, " \"");
      strcat(connect, left_path);
      strcat(connect, "\"");
      if(strstr(attribz, "A"))
      strcpy(status, _("Copying file: "));
      else
      strcpy(status, _("Copying Directory: "));
      strcat(status, filez);
      strcat(status, _(" please wait..."));
      right_status_entry  = lookup_widget (GTK_WIDGET (left_treeview), "right_status_entry");
      gtk_entry_set_text(GTK_ENTRY(right_status_entry), status);
      /* So it will have time to update the status entry */
      while(gtk_events_pending ())
      gtk_main_iteration ();
      if((fp = popen(connect, "w"))==NULL)
      {
         printf("\nError opening file\n");
         updating=0;
         return;
      }
      pclose(fp);
      free(connect);
      strcpy(status, _("Copying of: "));
      strcat(status, filez);
      strcat(status, _(" complete."));
      right_status_entry  = lookup_widget (GTK_WIDGET (left_treeview), "right_status_entry");
      gtk_entry_set_text(GTK_ENTRY(right_status_entry), status);
      clear_left(left_treeview, NULL);
      left_model = gtk_tree_view_get_model(GTK_TREE_VIEW(left_treeview));
      list_left(left_treeview, NULL);
      gtk_widget_destroy(right_actions_window);
      return;
   }

   /* Download a single file from remote server */
   if(strstr(attribz, "A"))
   {
      connect=(char *)malloc(8192);
      bzero(connect, 8192);
      strcpy(connect, "smbclient //");
      strcat(connect, gtk_ip);
      strcat(connect, "/\"");
      strcat(connect, gtk_share);
      strcat(connect, "\" -U ");
      strcat(connect, gtk_username);
      strcat(connect, "%");
      strcat(connect, gtk_password);
      strcat(connect, " -c \"cd \\\"");
      strcat(connect, right_path);
      strcat(connect, "\\\" ; lcd \\\"");
      strcat(connect, left_path);
      strcat(connect, "\\\" ; get \\\"");
      strcat(connect, filez);
      strcat(connect, "\\\"\" > ");
      strcat(connect, tempfile);

      strcpy(status, _("Downloading file: ")); /* If it can be read it can be downloaded */
      strcat(status, filez);
      strcat(status, _("please wait..."));
      right_status_entry  = lookup_widget (GTK_WIDGET (right_treeview), "right_status_entry");
      gtk_entry_set_text(GTK_ENTRY(right_status_entry), status);
      /* So it will have time to update the status entry */
      while(gtk_events_pending ())
      gtk_main_iteration ();

      if((fp = popen(connect, "w"))==NULL)
      {
         printf("\nError opening file\n");
         updating=0;
         return;
      }
      pclose(fp);
      free(connect);
      strcpy(status, _("Download of file: "));
      strcat(status, filez);
      strcat(status, _(" complete."));
      gtk_entry_set_text(GTK_ENTRY(right_status_entry), status);
      if(strlen(left_path)==0)
      strcpy(left_path,"/");
      clear_left(left_treeview, NULL);
      left_model = gtk_tree_view_get_model(GTK_TREE_VIEW(left_treeview));
      list_left(left_treeview, NULL);
   }

   /* Download an entire directory from the remote server */
   if(strstr(attribz, "D") || strstr(attribz, "DA"))
   {
      connect=(char *)malloc(8192);
      bzero(connect, 8192);
      strcpy(connect, "smbclient //");
      strcat(connect, gtk_ip);
      strcat(connect, "/\"");
      strcat(connect, gtk_share);
      strcat(connect, "\" -U ");
      strcat(connect, gtk_username);
      strcat(connect, "%");
      strcat(connect, gtk_password);
      strcat(connect, " -c \"cd \\\"");
      strcat(connect, right_path);
      strcat(connect, "\\\" ; lcd \\\"");
      strcat(connect, left_path);
      strcat(connect, "\\\" ; recurse ; prompt ; mget \\\"");
      strcat(connect, filez);
      strcat(connect, "\\\"\"");

      strcpy(status, _("Downloading directory: ")); /* If it can be read it can be downloaded */
      strcat(status, filez);
      strcat(status, _(" please wait..."));
      right_status_entry  = lookup_widget (GTK_WIDGET (right_treeview), "right_status_entry");
      gtk_entry_set_text(GTK_ENTRY(right_status_entry), status);
      /* So it will have time to update the status entry */
      while(gtk_events_pending ())
      gtk_main_iteration ();

      if((fp = popen(connect, "w"))==NULL)
      {
         printf("\nError opening file\n");
         updating=0;
         return;
      }
      pclose(fp);
      free(connect);

      strcpy(status, _("Download of directory: "));
      strcat(status, filez);
      strcat(status, _(" complete."));
      gtk_entry_set_text(GTK_ENTRY(right_status_entry), status);
      if(strlen(left_path)==0)
      strcpy(left_path,"/");
      clear_left(left_treeview, NULL);
      left_model = gtk_tree_view_get_model(GTK_TREE_VIEW(left_treeview));
      list_left(left_treeview, NULL);
   }
   gtk_widget_destroy(right_actions_window);
   updating=0;
}


void
on_left_rename_button_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
   FILE *fp;
   char *left_command;
   char *filez, *attribz;
   char status[8192]="";
   GtkTreeIter iter;
   GtkTreeModel *left_model;
   GtkTreeSelection *selection;
   G_CONST_RETURN gchar *gtk_ip;
   G_CONST_RETURN gchar *gtk_share;
   G_CONST_RETURN gchar *gtk_username;
   G_CONST_RETURN gchar *gtk_password;
   G_CONST_RETURN gchar *gtk_rename;

   selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(left_treeview));
   gtk_tree_selection_set_mode(selection, GTK_SELECTION_SINGLE);
   gtk_tree_selection_get_selected(selection, &left_model, &iter);
   gtk_tree_model_get(left_model, &iter, 1, &filez, -1);
   gtk_tree_model_get(left_model, &iter, 3, &attribz, -1);

   if( strlen(filez)==0 )
   return;

   right_path_entry  = lookup_widget (GTK_WIDGET (left_treeview), "right_path_entry");
   ip_entry  = lookup_widget (GTK_WIDGET (left_treeview), "ip_entry");
   share_entry  = lookup_widget (GTK_WIDGET (left_treeview), "share_entry");
   user_entry  = lookup_widget (GTK_WIDGET (left_treeview), "user_entry");
   password_entry  = lookup_widget (GTK_WIDGET (left_treeview), "password_entry");
   left_rename_entry = lookup_widget (GTK_WIDGET (left_actions_window), "left_rename_entry");

   gtk_ip = gtk_entry_get_text(GTK_ENTRY(ip_entry));
   gtk_share = gtk_entry_get_text(GTK_ENTRY(share_entry));
   gtk_username = gtk_entry_get_text(GTK_ENTRY(user_entry));
   gtk_password = gtk_entry_get_text(GTK_ENTRY(password_entry));
   gtk_rename = gtk_entry_get_text(GTK_ENTRY(left_rename_entry));

   if( strlen(gtk_rename)==0 )
   {
      gtk_entry_set_text(GTK_ENTRY(left_rename_entry), _("Specify a name"));
      return;
   }

   if( ( strlen(gtk_rename)==2 && strstr(gtk_rename, "..") ) || ( strstr(filez, "..") && strlen(filez)==2 ) )
   {
      gtk_entry_set_text(GTK_ENTRY(left_rename_entry), _("Cant rename \"..\""));
      return;
   }

   /* Rename a file or directory */
   left_command=(char *)malloc(8192);
   bzero(left_command, 8192);
   strcat(left_command, "mv \"");
   strcat(left_command, left_path);
   strcat(left_command, "/");
   strcat(left_command, filez);
   strcat(left_command, "\" \"");
   strcat(left_command, left_path);
   strcat(left_command, "/");
   strcat(left_command, gtk_rename);
   strcat(left_command, "\"");
   strcpy(status, _("Renamed: "));
   strcat(status, filez);
   strcat(status, _(" to: "));
   strcat(status, gtk_rename);

   if((fp = popen(left_command, "w"))==NULL) /* Add permission detection */
   {
      printf("\nError opening file\n");
      updating=0;
      return;
   }
   pclose(fp);
   free(left_command);
   left_status_entry  = lookup_widget (GTK_WIDGET (left_treeview), "left_status_entry");
   gtk_entry_set_text(GTK_ENTRY(left_status_entry), status);
   clear_left(left_treeview, NULL);
   left_model = gtk_tree_view_get_model(GTK_TREE_VIEW(left_treeview));
   list_left(left_treeview, NULL);
   if( ! connected && strstr(right_path, left_path) && strlen(left_path)==strlen(right_path) )
   list_right(right_treeview, NULL);
   gtk_widget_destroy(left_actions_window);
}


void
on_left_mkdir_button_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
   FILE *fp;
   char *left_command;
   char *filez, *attribz;
   char status[8192]="";
   GtkTreeIter iter;
   GtkTreeModel *left_model;
   GtkTreeSelection *selection;
   G_CONST_RETURN gchar *gtk_ip;
   G_CONST_RETURN gchar *gtk_share;
   G_CONST_RETURN gchar *gtk_username;
   G_CONST_RETURN gchar *gtk_password;
   G_CONST_RETURN gchar *gtk_mkdir;

   selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(left_treeview));
   gtk_tree_selection_set_mode(selection, GTK_SELECTION_SINGLE);
   gtk_tree_selection_get_selected(selection, &left_model, &iter);
   gtk_tree_model_get(left_model, &iter, 1, &filez, -1);
   gtk_tree_model_get(left_model, &iter, 3, &attribz, -1);

   if( strlen(filez)==0 )
   return;

   right_path_entry  = lookup_widget (GTK_WIDGET (left_treeview), "right_path_entry");
   ip_entry  = lookup_widget (GTK_WIDGET (left_treeview), "ip_entry");
   share_entry  = lookup_widget (GTK_WIDGET (left_treeview), "share_entry");
   user_entry  = lookup_widget (GTK_WIDGET (left_treeview), "user_entry");
   password_entry  = lookup_widget (GTK_WIDGET (left_treeview), "password_entry");
   left_mkdir_entry = lookup_widget (GTK_WIDGET (left_actions_window), "left_mkdir_entry");

   gtk_ip = gtk_entry_get_text(GTK_ENTRY(ip_entry));
   gtk_share = gtk_entry_get_text(GTK_ENTRY(share_entry));
   gtk_username = gtk_entry_get_text(GTK_ENTRY(user_entry));
   gtk_password = gtk_entry_get_text(GTK_ENTRY(password_entry));
   gtk_mkdir = gtk_entry_get_text(GTK_ENTRY(left_mkdir_entry));

   if( strlen(gtk_mkdir)==0 )
   {
      gtk_entry_set_text(GTK_ENTRY(left_mkdir_entry), _("Specify a directoryname"));
      return;
   }
   /* Make a new directory */
   left_command=(char *)malloc(8192);
   bzero(left_command, 8192);
   strcat(left_command, "mkdir \"");
   strcat(left_command, left_path);
   strcat(left_command, "/");
   strcat(left_command, gtk_mkdir);
   strcat(left_command, "\"");
   strcpy(status, _("Created directory: "));
   strcat(status, gtk_mkdir);

   if((fp = popen(left_command, "w"))==NULL) /* Add permission detection */
   {
      printf("\nError opening file\n");
      updating=0;
      return;
   }
   pclose(fp);
   free(left_command);
   left_status_entry  = lookup_widget (GTK_WIDGET (left_treeview), "left_status_entry");
   gtk_entry_set_text(GTK_ENTRY(left_status_entry), status);
   clear_left(left_treeview, NULL);
   left_model = gtk_tree_view_get_model(GTK_TREE_VIEW(left_treeview));
   list_left(left_treeview, NULL);
   if( ! connected && strstr(right_path, left_path) && strlen(left_path)==strlen(right_path) )
   list_right(right_treeview, NULL);
   gtk_widget_destroy(left_actions_window);
}


void
on_left_addfile_button_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
   FILE *fp;
   char *left_command;
   char *filez, *attribz;
   char status[8192]="";
   GtkTreeIter iter;
   GtkTreeModel *left_model;
   GtkTreeSelection *selection;
   G_CONST_RETURN gchar *gtk_ip;
   G_CONST_RETURN gchar *gtk_share;
   G_CONST_RETURN gchar *gtk_username;
   G_CONST_RETURN gchar *gtk_password;
   G_CONST_RETURN gchar *gtk_addfile;

   selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(left_treeview));
   gtk_tree_selection_set_mode(selection, GTK_SELECTION_SINGLE);
   gtk_tree_selection_get_selected(selection, &left_model, &iter);
   gtk_tree_model_get(left_model, &iter, 1, &filez, -1);
   gtk_tree_model_get(left_model, &iter, 3, &attribz, -1);

   if( strlen(filez)==0 )
   return;

   right_path_entry  = lookup_widget (GTK_WIDGET (left_treeview), "right_path_entry");
   ip_entry  = lookup_widget (GTK_WIDGET (left_treeview), "ip_entry");
   share_entry  = lookup_widget (GTK_WIDGET (left_treeview), "share_entry");
   user_entry  = lookup_widget (GTK_WIDGET (left_treeview), "user_entry");
   password_entry  = lookup_widget (GTK_WIDGET (left_treeview), "password_entry");
   left_addfile_entry = lookup_widget (GTK_WIDGET (left_actions_window), "left_addfile_entry");

   gtk_ip = gtk_entry_get_text(GTK_ENTRY(ip_entry));
   gtk_share = gtk_entry_get_text(GTK_ENTRY(share_entry));
   gtk_username = gtk_entry_get_text(GTK_ENTRY(user_entry));
   gtk_password = gtk_entry_get_text(GTK_ENTRY(password_entry));
   gtk_addfile = gtk_entry_get_text(GTK_ENTRY(left_addfile_entry));

   if( strlen(gtk_addfile)==0 )
   {
      gtk_entry_set_text(GTK_ENTRY(left_addfile_entry), _("Specify a filename"));
      return;
   }
   /* Make a new directory */
   left_command=(char *)malloc(8192);
   bzero(left_command, 8192);
   strcat(left_command, "touch \"");
   strcat(left_command, left_path);
   strcat(left_command, "/");
   strcat(left_command, gtk_addfile);
   strcat(left_command, "\"");
   strcpy(status, _("Created file: "));
   strcat(status, gtk_addfile);

   if((fp = popen(left_command, "w"))==NULL) /* Add permission detection */
   {
      printf("\nError opening file\n");
      updating=0;
      return;
   }
   pclose(fp);
   free(left_command);
   left_status_entry  = lookup_widget (GTK_WIDGET (left_treeview), "left_status_entry");
   gtk_entry_set_text(GTK_ENTRY(left_status_entry), status);
   clear_left(left_treeview, NULL);
   left_model = gtk_tree_view_get_model(GTK_TREE_VIEW(left_treeview));
   list_left(left_treeview, NULL);
   if( ! connected && strstr(right_path, left_path) && strlen(left_path)==strlen(right_path) )
   list_right(right_treeview, NULL);
   gtk_widget_destroy(left_actions_window);
}


void
on_left_delete_button_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
   FILE *fp;
   char *left_command;
   char *filez, *attribz;
   char status[8192]="";
   GtkTreeIter iter;
   GtkTreeModel *left_model;
   GtkTreeSelection *selection;
   G_CONST_RETURN gchar *gtk_ip;
   G_CONST_RETURN gchar *gtk_share;
   G_CONST_RETURN gchar *gtk_username;
   G_CONST_RETURN gchar *gtk_password;
   G_CONST_RETURN gchar *gtk_rename;
   selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(left_treeview));
   gtk_tree_selection_set_mode(selection, GTK_SELECTION_SINGLE);
   gtk_tree_selection_get_selected(selection, &left_model, &iter);
   gtk_tree_model_get(left_model, &iter, 1, &filez, -1);
   gtk_tree_model_get(left_model, &iter, 3, &attribz, -1);
   if( strlen(filez)==0 )
   {
      return;
   }
   if( strstr(filez, "..") && strlen(filez)==2 )
   {
      left_status_entry  = lookup_widget (GTK_WIDGET (left_treeview), "left_status_entry");
      gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("Deletion of entry \"..\" denied."));
      gtk_widget_destroy(left_actions_window);
      return;
   }
   right_path_entry  = lookup_widget (GTK_WIDGET (left_treeview), "right_path_entry");
   ip_entry  = lookup_widget (GTK_WIDGET (left_treeview), "ip_entry");
   share_entry  = lookup_widget (GTK_WIDGET (left_treeview), "share_entry");
   user_entry  = lookup_widget (GTK_WIDGET (left_treeview), "user_entry");
   password_entry  = lookup_widget (GTK_WIDGET (left_treeview), "password_entry");
   left_rename_entry = lookup_widget (GTK_WIDGET (left_actions_window), "left_rename_entry");

   gtk_ip = gtk_entry_get_text(GTK_ENTRY(ip_entry));
   gtk_share = gtk_entry_get_text(GTK_ENTRY(share_entry));
   gtk_username = gtk_entry_get_text(GTK_ENTRY(user_entry));
   gtk_password = gtk_entry_get_text(GTK_ENTRY(password_entry));
   gtk_rename = gtk_entry_get_text(GTK_ENTRY(left_rename_entry));

   strcpy(status, _("Deleting: "));
   strcat(status, filez);
   left_status_entry  = lookup_widget (GTK_WIDGET (left_treeview), "left_status_entry");
   gtk_entry_set_text(GTK_ENTRY(left_status_entry), status);
   while(gtk_events_pending ())
   gtk_main_iteration ();

   /* Delete a file or directory */
   left_command=(char *)malloc(8192);
   bzero(left_command, 8192);
      
   if( strstr(attribz, "A") )
   {  
      strcat(left_command, "rm -f \"");
      strcat(left_command, left_path);
      strcat(left_command, "/");
      strcat(left_command, filez);
      strcat(left_command, "\"");
      strcpy(status, _("Deleted file: "));
      strcat(status, filez);
   }
   else
      {
         strcat(left_command, "rm -rf \"");
         strcat(left_command, left_path);
         strcat(left_command, "/");
         strcat(left_command, filez);
	 strcat(left_command, "\"");
         strcpy(status, _("Deleted directory: "));
         strcat(status, filez);
      }      

      if((fp = popen(left_command, "w"))==NULL) /* Add permission detection */
      {
         printf("\nError opening file\n");
         updating=0;
         return;
      }
      pclose(fp);
      free(left_command);
      left_status_entry  = lookup_widget (GTK_WIDGET (left_treeview), "left_status_entry");
      gtk_entry_set_text(GTK_ENTRY(left_status_entry), status);
      clear_left(left_treeview, NULL);
      left_model = gtk_tree_view_get_model(GTK_TREE_VIEW(left_treeview));
      list_left(left_treeview, NULL);
      if( ! connected && strstr(right_path, left_path) && strlen(left_path)==strlen(right_path) )
      list_right(right_treeview, NULL);
      gtk_widget_destroy(left_actions_window);
}


void
on_left_cancel_button_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
   gtk_widget_destroy(left_actions_window);
}


void
on_left_upload_button_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
   FILE *fp;
   char *connect;
   char *filez, *attribz, *old_buffer;
   char status[8192]="";
   long siz;
   GtkTreeIter iter;
   GtkTreeModel *right_model;
   GtkTreeModel *left_model;
   GtkTreeSelection *selection;
   G_CONST_RETURN gchar *gtk_ip;
   G_CONST_RETURN gchar *gtk_share;
   G_CONST_RETURN gchar *gtk_username;
   G_CONST_RETURN gchar *gtk_password;
   G_CONST_RETURN gchar *gtk_right_path;

   selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(left_treeview));
   gtk_tree_selection_set_mode(selection, GTK_SELECTION_SINGLE);
   gtk_tree_selection_get_selected(selection, &left_model, &iter);
   gtk_tree_model_get(left_model, &iter, 1, &filez, -1);
   gtk_tree_model_get(left_model, &iter, 3, &attribz, -1);
   if(filez==NULL)
   {
      gtk_widget_destroy(left_actions_window);
      return;
   }

   right_path_entry  = lookup_widget (GTK_WIDGET (left_treeview), "right_path_entry");
   left_path_entry  = lookup_widget (GTK_WIDGET (left_treeview), "left_path_entry");
   gtk_ip = gtk_entry_get_text(GTK_ENTRY(ip_entry));
   gtk_share = gtk_entry_get_text(GTK_ENTRY(share_entry));
   gtk_username = gtk_entry_get_text(GTK_ENTRY(user_entry));
   gtk_password = gtk_entry_get_text(GTK_ENTRY(password_entry));
   gtk_right_path = gtk_entry_get_text(GTK_ENTRY(right_path_entry));

   /* Not connected .. copy left file or dir to the right treeview */
   if( ! connected )
   {
      connect=(char *)malloc(8192);
      bzero(connect, 8192);
      strcpy(connect, "cp -rf \"");
      strcat(connect, left_path);
      strcat(connect, "/");
      strcat(connect, filez);
      strcat(connect, "\" \"");
      strcat(connect, right_path);
      strcat(connect, "\"");

      if(strstr(attribz, "A"))
      strcpy(status, _("Copying file: "));
      else
      strcpy(status, _("Copying Directory: "));

      strcat(status, filez);
      strcat(status, _(" please wait..."));
      left_status_entry  = lookup_widget (GTK_WIDGET (left_treeview), "left_status_entry");
      gtk_entry_set_text(GTK_ENTRY(left_status_entry), status);
      /* So it will have time to update the status entry */
      while(gtk_events_pending ())
      gtk_main_iteration ();
  
      if((fp = popen(connect, "w"))==NULL)
      {
         printf("\nError opening file\n");
         return;
      }
      pclose(fp);
      free(connect);
      strcpy(status, _("Copying: "));
      strcat(status, filez);
      strcat(status, _(" complete."));
      left_status_entry  = lookup_widget (GTK_WIDGET (left_treeview), "left_status_entry");
      gtk_entry_set_text(GTK_ENTRY(left_status_entry), status);
      list_right(right_treeview, NULL);
      gtk_widget_destroy(left_actions_window);
      return;
   }

   /* Block requests to download an entire share */   
   if(strlen(gtk_right_path)==0)
   {
      left_status_entry  = lookup_widget (GTK_WIDGET (left_treeview), "left_status_entry");
      gtk_widget_destroy(left_actions_window);
      gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("You must step into the share you want to upload to"));
      return;
   }
   
   /* Upload a local (left) file to the smb server */
   if(strstr(attribz, "A"))
   {
      connect=(char *)malloc(8192);
      bzero(connect, 8192);
      strcpy(connect, "smbclient //");
      strcat(connect, gtk_ip);
      strcat(connect, "/\"");
      strcat(connect, gtk_share);
      strcat(connect, "\" -U ");
      strcat(connect, gtk_username);
      strcat(connect, "%");
      strcat(connect, gtk_password);
      strcat(connect, " -c \"cd \\\"");
      strcat(connect, right_path);
      strcat(connect, "\\\" ; lcd \\\"");
      strcat(connect, left_path);
      strcat(connect, "\\\" ; put \\\"");
      strcat(connect, filez);
      strcat(connect, "\\\"\" > "); /* Check for Errors */
      strcat(connect, tempfile);
      strcpy(status, _("Uploading file: "));
      strcat(status, filez);
      strcat(status, _(" please wait..."));
      left_status_entry  = lookup_widget (GTK_WIDGET (left_treeview), "left_status_entry");
      gtk_entry_set_text(GTK_ENTRY(left_status_entry), status);
      /* So it will have time to update the status entry */
      while(gtk_events_pending ())
      gtk_main_iteration ();
  
      if((fp = popen(connect, "w"))==NULL)
      {
         printf("\nError opening file\n");
         return;
      }
      pclose(fp);
      free(connect);

      /* If there are permission troubles show it */
      if((fp = fopen(tempfile, "r"))==NULL)
      {
         printf("\nError opening file on upload file\n");
         return; 
      }
      fseek(fp, 0, SEEK_END);
      siz=ftell(fp);
      rewind(fp);
      old_buffer=(char *)malloc(siz);
      bzero(old_buffer, siz);
      while((fgets(old_buffer, siz, fp)!=NULL))
      {
         if(strstr(old_buffer, "ERRSRV - ERRaccess")!=0) /* Windows 98 */
         {
            gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("Wrong username/password combination, could not upload the file"));
            gtk_widget_destroy(left_actions_window);
            free(old_buffer);	    
            return;
         }
         if(strstr(old_buffer, "ERRDOS - ERRnoaccess")!=0) /* Linux smbd and possibly w2k */
         {
            gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("Wrong username/password combination, could not upload the file"));
            gtk_widget_destroy(left_actions_window);
            free(old_buffer);	    
            return;
         }
         if(strstr(old_buffer, "ERRbad")!=0)
         {
            gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("Wrong username/password combination, could not upload the file"));
            gtk_widget_destroy(left_actions_window);
            free(old_buffer);	    
            return;
         }
         if(strstr(old_buffer, "BAD_NETWORK_NAME")!=0)
         {
            gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("Wrong username/password combination, could not upload the file"));
            gtk_widget_destroy(left_actions_window);
            free(old_buffer);	    
            return;
         }
         if(strstr(old_buffer, "ACCESS_DENIED")!=0)
         {
            gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("Wrong username/password combination, could not upload the file"));
            gtk_widget_destroy(left_actions_window);
            free(old_buffer);	    
            return;
         }
      }
      fclose(fp);
      free(old_buffer);	    
      /* we get here if the upload was ok */
      strcpy(status, _("Upload of file: "));
      strcat(status, filez);
      strcat(status, _(" complete."));
      gtk_entry_set_text(GTK_ENTRY(left_status_entry), status);
      clear_right(right_treeview, NULL);
      right_model = gtk_tree_view_get_model(GTK_TREE_VIEW(right_treeview));
      list_remote(right_treeview, NULL);
      gtk_widget_destroy(left_actions_window);
      return;
   }  /* if upload file */

   /* Upload an entire directory to the smb server */
   if(strstr(attribz, "D"))
   {
      connect=(char *)malloc(8192);
      bzero(connect, 8192);
      strcpy(connect, "smbclient //");
      strcat(connect, gtk_ip);
      strcat(connect, "/\"");
      strcat(connect, gtk_share);
      strcat(connect, "\" -U ");
      strcat(connect, gtk_username);
      strcat(connect, "%");
      strcat(connect, gtk_password);
      strcat(connect, " -c \"cd \\\"");
      strcat(connect, right_path);
      strcat(connect, "\\\" ; lcd \\\"");
      strcat(connect, left_path);
      strcat(connect, "\\\" ; recurse ; prompt ; mput \\\"");
      strcat(connect, filez);
      strcat(connect, "\\\"\" > "); /* Check for errors */
      strcat(connect, tempfile);
      strcpy(status, _("Uploading directory: "));
      strcat(status, filez);
      strcat(status, _(" please wait..."));
      left_status_entry  = lookup_widget (GTK_WIDGET (right_treeview), "left_status_entry");
      gtk_entry_set_text(GTK_ENTRY(left_status_entry), status);
      /* So it will have time to update the status entry */
      while(gtk_events_pending ())
      gtk_main_iteration ();
      if((fp = popen(connect, "w"))==NULL)
      {
         printf("\nError opening file\n");
         return;
      }
      pclose(fp);
      free(connect);

      /* If there are permission troubles show it */
      if((fp = fopen(tempfile, "r"))==NULL)
      {
         printf("\nError opening file\n");
         updating=0;
         return; 
      }
      fseek(fp, 0, SEEK_END);
      siz=ftell(fp);
      rewind(fp);
      old_buffer=(char *)malloc(siz);
      bzero(old_buffer, siz);
      while((fgets(old_buffer, siz, fp)!=NULL))
      {
         if(strstr(old_buffer, "ERRSRV - ERRaccess")!=0) /* Windows 98 */
         {
            gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("Wrong username/password combination, could not upload the directory"));
            gtk_widget_destroy(left_actions_window);
            free(old_buffer);	    
            return;
         }
         if(strstr(old_buffer, "ERRDOS - ERRnoaccess")!=0) /* Linux smbd and w2k */
         {
            gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("Wrong username/password combination, could not upload the directory"));
            gtk_widget_destroy(left_actions_window);
            free(old_buffer);	    
            return;
         }
         if(strstr(old_buffer, "ERRbad")!=0)
         {
            gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("Wrong username/password combination, could not upload the directory"));
            gtk_widget_destroy(left_actions_window);
            free(old_buffer);	    
            return;
         }
         if(strstr(old_buffer, "BAD_NETWORK_NAME")!=0)
         {
            gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("Wrong username/password combination, could not upload the directory"));
            gtk_widget_destroy(left_actions_window);
            free(old_buffer);	    
            return;
         }
         if(strstr(old_buffer, "ACCESS_DENIED")!=0)
         {
            gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("Wrong username/password combination, could not upload the directory"));
            gtk_widget_destroy(left_actions_window);
            free(old_buffer);	    
            return;
         }
      }
      fclose(fp);
      free(old_buffer);	    
      strcpy(status, _("Upload of directory: "));
      strcat(status, filez);
      strcat(status, _(" complete."));
      gtk_entry_set_text(GTK_ENTRY(left_status_entry), status);
      clear_right(right_treeview, NULL);
      right_model = gtk_tree_view_get_model(GTK_TREE_VIEW(right_treeview));
      list_remote(right_treeview, NULL);
      gtk_widget_destroy(left_actions_window);
      return;
   }
   gtk_widget_destroy(left_actions_window);
   return;
}


void
on_settings_cancel_button_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
   gtk_widget_destroy(settings_window);
}


void
on_settings_ok_button_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
   /* Save and use the new settings */
   FILE *fp;
   char *temp;
   G_CONST_RETURN gchar *gtemp;
   gboolean active;
   if((fp = fopen(settings, "w+"))==NULL)
   {
      printf("\nError opening the settings file.\n");
      gtk_widget_destroy(settings_window);
      left_status_entry  = lookup_widget (GTK_WIDGET (right_treeview), "left_status_entry");
      gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("Couldnt save the settings."));
      return; 
   }
   temp=(char *)malloc(1024);
   bzero(temp, 1024);
   
   strcpy(temp, "Music: ");
   strcat(temp, gtemp=gtk_entry_get_text(GTK_ENTRY(music_entry)));
   strcat(temp, "\n");
   fputs(temp, fp);

   strcpy(temp, "Video: ");
   strcat(temp, gtemp=gtk_entry_get_text(GTK_ENTRY(video_entry)));
   strcat(temp, "\n");
   fputs(temp, fp);
      
   strcpy(temp, "Graphics: ");
   strcat(temp, gtemp=gtk_entry_get_text(GTK_ENTRY(graphics_entry)));
   strcat(temp, "\n");
   fputs(temp, fp);

   strcpy(temp, "Text: ");
   strcat(temp, gtemp=gtk_entry_get_text(GTK_ENTRY(text_entry)));
   strcat(temp, "\n");
   fputs(temp, fp);
   
   strcpy(temp, "Document: ");
   strcat(temp, gtemp=gtk_entry_get_text(GTK_ENTRY(document_entry)));
   strcat(temp, "\n");
   fputs(temp, fp);

   strcpy(temp, "Spreadsheet: ");
   strcat(temp, gtemp=gtk_entry_get_text(GTK_ENTRY(spreadsheet_entry)));
   strcat(temp, "\n");
   fputs(temp, fp);

   strcpy(temp, "Websource: ");
   strcat(temp, gtemp=gtk_entry_get_text(GTK_ENTRY(html_entry)));
   strcat(temp, "\n");
   fputs(temp, fp);

   strcpy(temp, "Sourcecode: ");
   strcat(temp, gtemp=gtk_entry_get_text(GTK_ENTRY(sourcecode_entry)));
   strcat(temp, "\n");
   fputs(temp, fp);

   strcpy(temp, "showhidden: ");
   active = gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(hidden_checkbutton));
   if( active )
   strcat(temp, "1");
   if( ! active )
   strcat(temp, "0");
   strcat(temp, "\n");
   fputs(temp, fp);

   sprintf(temp, "subnets: %d", subnets);
   strcat(temp, "\n");
   fputs(temp, fp);

   sprintf(temp, "scantimeout: %d", scan_timeout);
   strcat(temp, "\n");
   fputs(temp, fp);

   /* Add a newline at the end */
   fputs("\n", fp);
   fclose(fp);
   free(temp);
   read_settings();
   gtk_widget_destroy(settings_window);
}


void
on_settings_window_map                 (GtkWidget       *widget,
                                        gpointer         user_data)
{
   /* Show the current settings */
   char textval[1024]="";
   music_entry = lookup_widget(GTK_WIDGET (widget), "music_entry");
   video_entry = lookup_widget(GTK_WIDGET (widget), "video_entry");
   graphics_entry = lookup_widget(GTK_WIDGET (widget), "graphics_entry");
   text_entry = lookup_widget(GTK_WIDGET (widget), "text_entry");
   document_entry = lookup_widget(GTK_WIDGET (widget), "document_entry");
   spreadsheet_entry = lookup_widget(GTK_WIDGET (widget), "spreadsheet_entry");
   html_entry = lookup_widget(GTK_WIDGET (widget), "html_entry");
   sourcecode_entry = lookup_widget(GTK_WIDGET (widget), "sourcecode_entry");

   hidden_checkbutton = lookup_widget(GTK_WIDGET (widget), "hidden_checkbutton");
   scanrange_spinbutton = lookup_widget(GTK_WIDGET (widget), "scanrange_spinbutton");
   scantimeout_spinbutton = lookup_widget(GTK_WIDGET (widget), "scantimeout_spinbutton");

   /* ScanRange .. This sends a toggle signal so to avoid updating the treeviews we (must) set a flag */
   toggle=0;
   gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(hidden_checkbutton), show_hidden);

   sprintf(textval, "%d", subnets);
   gtk_entry_set_text(GTK_ENTRY(scanrange_spinbutton), textval);

   /* ScanTimeout */
   sprintf(textval, "%d", scan_timeout);
   gtk_entry_set_text(GTK_ENTRY(scantimeout_spinbutton), textval);
      
   gtk_entry_set_text(GTK_ENTRY(music_entry), music_act);
   gtk_entry_set_text(GTK_ENTRY(video_entry), video_act);
   gtk_entry_set_text(GTK_ENTRY(graphics_entry), graphics_act);
   gtk_entry_set_text(GTK_ENTRY(text_entry), text_act);
   gtk_entry_set_text(GTK_ENTRY(document_entry), document_act);
   gtk_entry_set_text(GTK_ENTRY(spreadsheet_entry), spread_act);
   gtk_entry_set_text(GTK_ENTRY(html_entry), webcode_act);
   gtk_entry_set_text(GTK_ENTRY(sourcecode_entry), sourcecode_act);
   toggle=1;
}


void
on_settings_button_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
   /* Show the settings window */
   settings_window = create_settings_window ();
   gtk_widget_show(settings_window);
}


void
on_hidden_checkbutton_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
   gboolean active;
   if( ! toggle )
   {
     toggle=1;
     return;
   }
   active = gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(hidden_checkbutton));
   if( active ) 
   show_hidden=1;
   if( ! active )
   show_hidden=0;
   list_left(left_treeview, NULL);
   if( ! connected )
   list_right(right_treeview, NULL);
}


void
on_scanrange_spinbutton_value_changed  (GtkSpinButton   *spinbutton,
                                        gpointer         user_data)
{
    G_CONST_RETURN gchar *temp;
    temp = gtk_entry_get_text(GTK_ENTRY(scanrange_spinbutton));
    subnets = atoi(temp);
}

void
on_scantimeout_spinbutton_value_changed
                                        (GtkSpinButton   *spinbutton,
                                        gpointer         user_data)
{
    G_CONST_RETURN gchar *temp;
    temp = gtk_entry_get_text(GTK_ENTRY(scantimeout_spinbutton));
    scan_timeout = atoi(temp);
}

void
on_cancel_scan_button_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
   /* Stops the samba scanner */
   scan=0;
}


void
on_archive_install_button_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
   FILE *fp;
   long siz;
   char *buffy;
   char *temp;
   char filezpath[1024]="";
   gchar *utf8=NULL;
   GtkTextBuffer *text_buffy;

   /* Install .RPM */
   if( strstr(filetype, "rpm") )
   {
      gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("Installing rpm archive please wait..."));
      while(gtk_events_pending ())
      gtk_main_iteration ();
      strcpy(action, "rpm -Uvh \"");
      strcat(action, temppath);
      strcat(action, "/");
      strcat(action, tempfile);
      strcat(action, "\" > ");
      strcat(action, homedirectory);
      strcat(action, "/.gfilemanager/archive_result 2>&1");
   }

   /* Install .DEB .. UNTESTED */
   if( strstr(filetype, "deb") )
   {
      gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("Installing deb archive please wait..."));
      while(gtk_events_pending ())
      gtk_main_iteration ();
      strcpy(action, "dpkg --install \"");
      strcat(action, temppath);
      strcat(action, "/");
      strcat(action, tempfile);
      strcat(action, "\" > ");
      strcat(action, homedirectory);
      strcat(action, "/.gfilemanager/archive_result 2>&1");
   }

   /* Unpack .TAR.GZ file */
   if( strstr(filetype, ".tar.gz") )
   {
      gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("Unpacking archive please wait..."));
      while(gtk_events_pending ())
      gtk_main_iteration ();
      strcpy(action, "tar -xzvf \"");
      strcat(action, temppath);
      strcat(action, "/");
      strcat(action, tempfile);
      strcat(action, "\" --directory ");
      strcat(action, temppath);
      strcat(action, " > ");
      strcat(action, homedirectory);
      strcat(action, "/.gfilemanager/archive_result 2>&1");
   }

   /* Unpack .TAR.BZ2 file */
   if( strstr(filetype, ".tar.bz2") )
   {
      gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("Unpacking archive please wait..."));
      while(gtk_events_pending ())
      gtk_main_iteration ();
      strcpy(action, "bzip2 -cd \"");
      strcat(action, temppath);
      strcat(action, "/");
      strcat(action, tempfile);
      strcat(action, "\" | tar -xv --directory ");
      strcat(action, temppath);
      strcat(action, " > ");
      strcat(action, homedirectory);
      strcat(action, "/.gfilemanager/archive_result 2>&1");
   }

   /* UNTESTED, i hope it works ok */
   /* Unpack .GZ file */
   if( strstr(filetype, ".gz") && strlen(filetype)==3 )
   {
      gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("Unpacking archive please wait..."));
      while(gtk_events_pending ())
      gtk_main_iteration ();
      strcpy(action, "gunzip -cd \"");
      strcat(action, temppath);
      strcat(action, "/");
      strcat(action, tempfile);
      strcat(action, "\" ");
      strcat(action, " > ");
      strcat(action, homedirectory);
      strcat(action, "/.gfilemanager/archive_result 2>&1");
   }

   /* Unpack .TAR file */
   if( strstr(filetype, ".tar") && strlen(filetype)==4 )
   {
      gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("Unpacking archive please wait..."));
      while(gtk_events_pending ())
      gtk_main_iteration ();
      strcpy(action, "tar -xvf \"");
      strcat(action, temppath);
      strcat(action, "/");
      strcat(action, tempfile);
      strcat(action, "\" --directory ");
      strcat(action, temppath);
      strcat(action, " > ");
      strcat(action, homedirectory);
      strcat(action, "/.gfilemanager/archive_result 2>&1");
      /* If its this one make sure the .gz isnt matched */
      strcpy(filetype, "");
   }

   /* Unpack .ZIP file */
   if( strstr(filetype, "zip") )
   {
      gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("Unpacking archive please wait..."));
      while(gtk_events_pending ())
      gtk_main_iteration ();
      strcpy(action, "unzip \"");
      strcat(action, temppath);
      strcat(action, "/");
      strcat(action, tempfile);
      strcat(action, "\" -d ");
      strcat(action, temppath);
      strcat(action, " > ");
      strcat(action, homedirectory);
      strcat(action, "/.gfilemanager/archive_result 2>&1");
   }
 
   /* UNTESTED */
   /* Unpack .RAR file */
   if( strstr(filetype, "rar") )
   {
      gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("Unpacking archive please wait..."));
      while(gtk_events_pending ())
      gtk_main_iteration ();
      strcpy(action, "rar e \"");
      strcat(action, temppath);
      strcat(action, "/");
      strcat(action, tempfile);
      strcat(action, "\"");
      strcat(action, " > ");
      strcat(action, homedirectory);
      strcat(action, "/.gfilemanager/archive_result 2>&1");
   }

   /* Install/Unpack the archive and Show the installation result */
   system(action);
   strcpy(filezpath, homedirectory);
   strcat(filezpath, "/.gfilemanager/archive_result");
   if((fp = fopen(filezpath, "r"))==NULL)
   {
      printf("\nError opening file archive_result\n");
      return; 
   }
   fseek(fp, 0, SEEK_END);
   siz=ftell(fp);
   rewind(fp);
   /* Had to alloc like this, hmm */
   buffy=(char *)malloc(siz+8192);
   bzero(buffy, siz+8192);
   temp=(char *)malloc(siz+8192);
   bzero(temp, siz+8192);

   while((fgets(buffy, siz, fp)!=NULL))
   {
      strcat(temp, buffy);
   }
   fclose(fp);
   archive_window = lookup_widget(GTK_WIDGET (button), "archive_window");
   archive_textview = lookup_widget(GTK_WIDGET (archive_window), "archive_textview");
   text_buffy = gtk_text_view_get_buffer(GTK_TEXT_VIEW(archive_textview));
   utf8 = g_locale_to_utf8(temp, strlen(temp), NULL, NULL, NULL);
   gtk_text_buffer_set_text(text_buffy, utf8, strlen(utf8));


   if( strstr(filetype, "rpm") || strstr(filetype, "deb") )
   {
      strcpy(action, _("Installed: "));
   }
   else
     {
        strcpy(action, _("Unpacked: "));
        list_left(left_treeview, NULL);
        list_right(right_treeview, NULL);
     }


   strcat(action, tempfile);
   gtk_entry_set_text(GTK_ENTRY(left_status_entry), action);
   if( utf8 !=NULL )
   g_free(utf8);
   free(buffy); 
   free(temp);
   /* Delete the archive_result */
   strcpy(action, "rm -f ");
   strcat(action, filezpath);
   system(action);
}


void
on_archive_close_button_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
   gtk_widget_destroy(archive_window);
}


void
on_archive_textview_map                    (GtkWidget       *widget,
                                        gpointer         user_data)
{
   FILE *fp;
   long siz;
   char *buffy;
   char *temp;
   char filezpath[1024]="";
   char tempz[1024]="";
   gchar *utf8=NULL;
   GtkTextBuffer *text_buffy;
   strcpy(filezpath, homedirectory);
   strcat(filezpath, "/.gfilemanager/archive_query");
   if((fp = fopen(filezpath, "r"))==NULL)
   {
      printf("\nError opening file on archive query\n");
      return; 
   }
   fseek(fp, 0, SEEK_END);
   siz=ftell(fp);
   rewind(fp);
   buffy=(char *)malloc(siz);
   bzero(buffy, siz);
   temp=(char *)malloc(siz);
   bzero(temp, siz);
   while((fgets(buffy, siz, fp)!=NULL))
   {
      strcat(temp, buffy);
   }
   fclose(fp);

   archive_window = lookup_widget(GTK_WIDGET (widget), "archive_window");
   archive_textview = lookup_widget(GTK_WIDGET (archive_window), "archive_textview");
   text_buffy = gtk_text_view_get_buffer(GTK_TEXT_VIEW(archive_textview));
   utf8 = g_locale_to_utf8(temp, strlen(temp), NULL, NULL, NULL);
   gtk_text_buffer_set_text(text_buffy, utf8, strlen(utf8));
   gtk_entry_set_text(GTK_ENTRY(left_status_entry), _("Archive query complete."));
   if( utf8 !=NULL )
   g_free(utf8);
   free(buffy); 
   free(temp);
   /* Delete the archive query file */
   strcpy(tempz, "rm -f ");
   strcat(tempz, filezpath);
   system(tempz);
}


void
on_update_both_button_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
   GtkTreeModel *left_model;
   GtkTreeModel *right_model;
   if( ! connected )
   {
      clear_right(right_treeview, NULL);
      right_model = gtk_tree_view_get_model(GTK_TREE_VIEW(right_treeview));
      list_right(right_treeview, NULL);
   }
   else
     {
        clear_right(right_treeview, NULL);
        right_model = gtk_tree_view_get_model(GTK_TREE_VIEW(right_treeview));
        list_remote(right_treeview, NULL);
     }

     clear_left(left_treeview, NULL);
     left_model = gtk_tree_view_get_model(GTK_TREE_VIEW(left_treeview));
     list_left(left_treeview, NULL);
}


void
on_run_info_button_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
   run_info_window = create_run_info_window ();
   gtk_widget_show(run_info_window);
}


void
on_run_info_window_map                 (GtkWidget       *widget,
                                        gpointer         user_data)
{
   /* Show DiscUsage */
   FILE *fp;
   GtkListStore *model;
   GtkTreeIter iter;
   GtkCellRenderer *cell;
   GtkTreeViewColumn *mount_column, *free_column, *used_column, *total_column, *percent_column, *device_column;
   gchar *utf8=NULL;
   char buf[8192]="";
   char mount[1024]="", free[1024]="", used[1024]="", total[1024]="", percent[1024]="", device[1024]="";
   disc_treeview = lookup_widget (GTK_WIDGET (widget), "disc_treeview");
   model = gtk_list_store_new(6, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
   gtk_tree_view_set_model(GTK_TREE_VIEW(disc_treeview), GTK_TREE_MODEL (model));
   cell = gtk_cell_renderer_text_new();
   gtk_list_store_clear(model);
   mount_column = gtk_tree_view_column_new_with_attributes(_("Mounted on"), cell, "text", 0, NULL);
   free_column = gtk_tree_view_column_new_with_attributes(_("Free space"), cell, "text", 1, NULL);
   used_column = gtk_tree_view_column_new_with_attributes(_("Used space"), cell, "text", 2, NULL);
   total_column = gtk_tree_view_column_new_with_attributes(_("Total space"), cell, "text", 3, NULL);
   percent_column = gtk_tree_view_column_new_with_attributes(_("Percent used"), cell, "text", 4, NULL);
   device_column = gtk_tree_view_column_new_with_attributes(_("Device"), cell, "text", 5, NULL);

   if ( (fp = popen("df -h |grep /", "r")) == NULL)
   {
     printf("\nError running df -h\n");
     return;
   }
   fflush(stdin); /* stdio FILE streams are buffered */
   fflush(stdout);
   while(fgets(buf, BUFSIZ, fp)!=NULL)
   {
      sscanf(buf, "%s %s %s %s %s %s", device, total, used, free, percent, mount);
      gtk_list_store_append(GTK_LIST_STORE(model), &iter);
      utf8 = g_locale_to_utf8(mount, strlen(mount), NULL, NULL, NULL);
      gtk_list_store_set(GTK_LIST_STORE(model), &iter, 0, utf8, -1);
      utf8 = g_locale_to_utf8(free, strlen(free), NULL, NULL, NULL);
      gtk_list_store_set(GTK_LIST_STORE(model), &iter, 1, utf8, -1);
      utf8 = g_locale_to_utf8(used, strlen(used), NULL, NULL, NULL);
      gtk_list_store_set(GTK_LIST_STORE(model), &iter, 2, utf8, -1);
      utf8 = g_locale_to_utf8(total, strlen(total), NULL, NULL, NULL);
      gtk_list_store_set(GTK_LIST_STORE(model), &iter, 3, utf8, -1);
      utf8 = g_locale_to_utf8(percent, strlen(percent), NULL, NULL, NULL);
      gtk_list_store_set(GTK_LIST_STORE(model), &iter, 4, utf8, -1);
      utf8 = g_locale_to_utf8(device, strlen(device), NULL, NULL, NULL);
      gtk_list_store_set(GTK_LIST_STORE(model), &iter, 5, utf8, -1);
   }
   gtk_tree_view_append_column(GTK_TREE_VIEW(disc_treeview), GTK_TREE_VIEW_COLUMN(mount_column));
   gtk_tree_view_append_column(GTK_TREE_VIEW(disc_treeview), GTK_TREE_VIEW_COLUMN(free_column));
   gtk_tree_view_append_column(GTK_TREE_VIEW(disc_treeview), GTK_TREE_VIEW_COLUMN(used_column));
   gtk_tree_view_append_column(GTK_TREE_VIEW(disc_treeview), GTK_TREE_VIEW_COLUMN(total_column));
   gtk_tree_view_append_column(GTK_TREE_VIEW(disc_treeview), GTK_TREE_VIEW_COLUMN(percent_column));
   gtk_tree_view_append_column(GTK_TREE_VIEW(disc_treeview), GTK_TREE_VIEW_COLUMN(device_column));
   fclose(fp);
   if(utf8 !=NULL)
   g_free(utf8);
}


void
on_run_command_button_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
   FILE *fp;
   G_CONST_RETURN gchar *gtk_command;
   GtkTextBuffer *text_buffy;
   gchar *utf8=NULL;
   long siz;
   char *output;
   char *input; 
   char command[8192]="";
   run_command_entry = lookup_widget(GTK_WIDGET (button), "run_command_entry");
   gtk_command = gtk_entry_get_text(GTK_ENTRY(run_command_entry));

   strcpy(command, gtk_command);
   strcat(command, " > ");
   strcat(command, homedirectory);
   strcat(command, "/.gfilemanager/command_output");
   strcat(command, " 2>&1");
   system(command);
   
   strcpy(command, homedirectory);
   strcat(command, "/.gfilemanager/command_output");
   if((fp = fopen(command, "r"))==NULL)
   {
      printf("\nError opening file\n");
      return;
   }
   fseek(fp, 0, SEEK_END);
   siz=ftell(fp);
   rewind(fp);
   output=(char *)malloc(siz+8192);
   bzero(output, siz+8192);
   input=(char *)malloc(siz+8192);
   bzero(input, siz+8192);
   
   while((fgets(output, siz, fp)!=NULL))
   {
      strcat(input, output);
   }
   fclose(fp);
   run_command_textview = lookup_widget(GTK_WIDGET (button), "run_command_textview");
   text_buffy = gtk_text_view_get_buffer(GTK_TEXT_VIEW(run_command_textview));
   utf8 = g_locale_to_utf8(input, strlen(input), NULL, NULL, NULL);
   gtk_text_buffer_set_text(text_buffy, utf8, strlen(utf8));
   free(output); free(input);
   strcpy(command, "rm -f ");
   strcat(command, homedirectory);
   strcat(command, "/.gfilemanager/command_output");
   system(command);
}


void
on_close_run_info_button_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{
   gtk_widget_destroy(run_info_window);
}
