
#ifndef MERGE_CONGF_FROM_PACKAGE_H
#define MERGE_CONGF_FROM_PACKAGE_H

int merge_conf_from_package(char *package);

#endif
