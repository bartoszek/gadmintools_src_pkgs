/* GAdmin-Antivirus - An easy to use GTK+ frontend for clamav antivirus.
 * Copyright (C) 2010 - 2014 Magnus Loef <magnus-swe@telia.com> 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
*/

#include <gtk/gtk.h>

#define NUM_ENTRIES 4
#define NUM_COMBOS 2
#define NUM_SPINBUTTONS 3
#define NUM_CHECKBUTTONS 10


typedef struct w
{
    GtkWidget *main_window;
    GtkWidget *main_vbox;

    GtkWidget *main_notebook;
    GtkWidget *notebook_vbox1;
    GtkWidget *notebook_vbox2;

    GtkWidget *status_label;
    GtkWidget *version_label;

    /* The scan path treeview */
    GtkWidget *scan_treeview;
    GtkListStore *scan_store;

    GtkWidget *schedule_check_button[NUM_CHECKBUTTONS];
    GtkWidget *schedule_spin_button[NUM_SPINBUTTONS];

    GtkWidget *settings_entry[NUM_ENTRIES];
    GtkWidget *settings_combo[NUM_COMBOS];

    /* New scan window and entry */
    GtkWidget *new_scan_window;
    GtkWidget *new_scan_entry;

    /* Add scan data menu selection */
    GtkWidget *scan_menu_window;
    GtkWidget *path_filesel;

    GtkWidget *settings_scrolled_window;
    GtkWidget *settings_vbox;
    GtkWidget *settings_grid;

    /* The log windows widgets */
    GtkWidget *log_window;
    GtkWidget *log_treeview;
    GtkListStore *log_store;

    GtkWidget *progress_textview;

    GtkWidget *virus_treeview;
    GtkListStore *virus_store;
    GtkWidget *log_label;
    GtkCellRenderer *log_cell;

} wid;

