/*
 * Admin-Packages - A Package manager for sources.
 * Copyright (C) 2009 - 2011 Magnus Loef <magnus-swe@telia.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307, USA.
 *
 */


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "allocate.h"
#include "globals.h"
#include "file_exists.h"
#include "get_package_info.h"
#include "package_in_install_list.h"
#include "queue_package.h"

extern char package_queue[MAX_TEMP_PATH];
extern int global_verbose;


int queue_package_for_install(char *package)
{
    FILE *fp;
    char *conf;

    /* Return OK here */
    if( package == NULL )
    {
        if( global_verbose )
            printf("Package is NULL in queue_package_for_install\n");
        return 1;
    }

    if( strlen(package) < 2 )
    {
        if( global_verbose )
            printf("Package length is less then 2 in que_package_for_install\n");
        return 1;
    }

    /* Make sure it exists */
    if( ! file_exists(package_queue) )
    {
        if((fp=fopen(package_queue, "w+"))==NULL)
        {
            perror("fopen");
            printf("Package queue failed. Could not write to: %s\n", package_queue);
            return 0;
        }
        fclose(fp);
    }

    if( package_in_install_list(package) )
    {
        printf("Package already queued, not queued for install: %s\n", package);
        return 1;
    }

    /* Add this package conf to the install file */
    if((fp=fopen(package_queue, "a+"))==NULL)
    {
        perror("fopen");
        printf("Package queue failed. Could not write to: %s\n", package_queue);
        return 0;
    }

    /* Get conf from the temporary downloaded packages.conf */
    conf = get_conf_from_package(1, package);

    fputs(conf, fp);
    fputs("\n", fp);
    fclose(fp);

    free(conf);

    return 1;
}


int queue_package_for_uninstall(char *package)
{
    FILE *fp;
    char *conf;

    /* Return OK here */
    if( package == NULL )
    {
        if( global_verbose )
            printf("Package is NULL in queue_package_for_install\n");
        return 1;
    }

    if( strlen(package) < 2 )
    {
        if( global_verbose )
            printf("Package length is less then 2 in que_package_for_install\n");
        return 1;
    }

    /* Make sure it exists */
    if( ! file_exists(package_queue) )
    {
        if((fp=fopen(package_queue, "w+"))==NULL)
        {
            perror("fopen");
            printf("Package queue failed. Could not write to: %s\n", package_queue);
            return 0;
        }
        fclose(fp);
    }

    if( package_in_install_list(package) )
    {
        printf("Package already queued, not queued for install: %s\n", package);
        return 1;
    }

    /* Add this package conf to the install file */
    if((fp=fopen(package_queue, "a+"))==NULL)
    {
        perror("fopen");
        printf("Package queue failed. Could not write to: %s\n", package_queue);
        return 0;
    }

    /* Get conf from the installed package */
    conf = get_conf_from_package(2, package);

    fputs(conf, fp);
    fputs("\n", fp);
    fclose(fp);

    free(conf);

    return 1;
}
