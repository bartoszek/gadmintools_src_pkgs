
#ifndef MAIN_H
#define MAIN_H

/* Widget structure */
typedef struct w
{
    GtkWidget *main_window;
    /* 5 spinbuttons */
    GtkWidget *spinbutton[5];
    GtkWidget *combo;
    GtkWidget *textview;
}wid;

/* Function for placing spinbuttons in a table */
GtkWidget * make_spinbutton_with_label(GtkTable * table, const gchar * label_text,
                                       gint left_attach, gint right_attach,
                                       gint top_attach, gint bottom_attach,
                                       gint spinbutton_length, gint precision);

/* Function for placing combos in a table */
GtkWidget * make_combo_with_label(GtkTable * table,
                              const gchar * label_text, gint left_attach,
                              gint right_attach, gint top_attach,
                              gint bottom_attach);
#endif
