/*
 * Admin-Packages - A Package manager for sources.
 * Copyright (C) 2009 - 2011 Magnus Loef <magnus-swe@telia.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307, USA.
 *
 */


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "unpack_package.h"
#include "globals.h"
#include "allocate.h"
#include "get_package_info.h"
#include "run_command.h"

extern char build_directory[MAX_TEMP_PATH];


/* Unpack compressed archives and
   optionally remove the original archives */
int unpack_package(char *package)
{
    char *cmd;
    int i = 0, ret = 0;

    for(i=0; i < strlen(package); i++)
    if( package[i]=='\r' || package[i]=='\n' || package[i]=='\t' )
    {
        package[i]='\0';
        break;
    }

    if( ! strstr(package, ".tar.gz")
    &&  ! strstr(package, ".tgz")
    &&  ! strstr(package, ".tar.bz2") )
    {
         printf("Not uncompressing file: [%s]\n", package);
         /* Not a failure */
        return 1;
    }

    cmd = allocate(MAX_TEMP_PATH+strlen(package)+100);

    if( strstr(package, ".tar.gz") || strstr(package, ".tgz") )
    {
       sprintf(cmd, "cd %s && tar zxf %s", build_directory, package);
    }
    else
    if( strstr(package, ".tar.bz2") )
    {
       sprintf(cmd, "cd %s && tar xfj %s", build_directory, package);
    }
    /* Uncompress the package */
    printf("Uncompressing package: [%s/%s]\n", build_directory, package);
    if( ! run_command(cmd) )
        ret = 0;
    else
        ret = 1;

    /* Remove the original source package */
    printf("Removing compressed archive: [%s/%s]\n", build_directory, package);
    sprintf(cmd, "rm -f %s/%s", build_directory, package);
    if( ! run_command(cmd) )
        ret = 0;
    else
        ret = 1;

    free(cmd);

    return ret;
}
