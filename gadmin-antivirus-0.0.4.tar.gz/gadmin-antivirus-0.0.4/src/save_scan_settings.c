/* GAdmin-Antivirus - An easy to use GTK+ frontend for clamav antivirus.
 * Copyright (C) 2010 - 2014 Magnus Loef <magnus-swe@telia.com> 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
*/



#include "../config.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <gtk/gtk.h>
#include "gettext.h"
#include "widgets.h"
#include "show_info.h"
#include "save_scan_settings.h"
#include "functions.h"
#include "cron_functions.h"

extern gchar *global_settings_dir;
extern gchar *global_scripts_dir;
extern gchar *global_scan_name;

/* Error info */
int error_path = 1;


int
has_value(gchar * input)
{
    int ret = 0;

    if(input != NULL && strlen(input) > 0)
        ret = 1;

    return ret;
}


void
free_values(gchar * a1, gchar * a2, gchar * a3)
{
    if(a1 != NULL)
        g_free(a1);
    if(a2 != NULL)
        g_free(a2);
    if(a3 != NULL)
        g_free(a3);
}


/* For each in the scan treeview, save scan settings and scripts */
gboolean
save_foreach(GtkTreeModel * model, GtkTreePath * path, GtkTreeIter * iter,
    struct w *widgets)
{
    FILE *fp;
    gchar *settings_file, *setting = NULL, *script_file, *log_file, *info;

    gchar *scan_path = NULL, *include_files = NULL, *exclude_files = NULL;
    gint include_in_scan_script = 0;

    /* Get scan path */
    gtk_tree_model_get(model, iter, 0, &scan_path, -1);

    /* Get include files */
    gtk_tree_model_get(model, iter, 1, &include_files, -1);

    /* Get exclude files */
    gtk_tree_model_get(model, iter, 2, &exclude_files, -1);

    /* Get include in scan checkbox value */
    gtk_tree_model_get(model, iter, 3, &include_in_scan_script, -1);

    /* There must always be scan directory */
    if(!has_value(scan_path))
    {
        if(error_path)
        {
            error_path = 0;     /* Dont show this again */
            info =
                g_strdup_printf(_
                ("Error: This scan is missing a required scan path.\n"));
            show_info(info);
            g_free(info);
        }
    }

    /* Open the settings file for appending */
    settings_file = g_strdup_printf("%s/%s", global_settings_dir,
                                                 global_scan_name);
    if((fp = fopen(settings_file, "a")) == NULL)
    {
        info =
            g_strdup_printf(_("Error: Can not write settings here:\n%s\n"),
            settings_file);
        show_info(info);
        g_free(info);

        free_values(scan_path, include_files, exclude_files);

        if(settings_file != NULL)
            g_free(settings_file);

        return TRUE;   /* Stop iterating on write failure */
    }

    /* Append settings to the settings file */
    if(has_value(scan_path))
    {
        setting = g_strdup_printf("scan_path %s\n", scan_path);
        fputs(setting, fp);
        g_free(setting);
    }
    if(has_value(include_files))
    {
        setting = g_strdup_printf("include_files %s\n", include_files);
        fputs(setting, fp);
        g_free(setting);
    }
    if(has_value(exclude_files))
    {
        setting = g_strdup_printf("exclude_files %s\n", exclude_files);
        fputs(setting, fp);
        g_free(setting);
    }

    setting = g_strdup_printf("include_value %d\n", include_in_scan_script);
    fputs(setting, fp);
    g_free(setting);

    /* Separator for this scan selection */
    fputs("\n", fp);

    /* Close the settings file */
    fclose(fp);

    if(settings_file != NULL)
        g_free(settings_file);

    /* Return false if this scan should not be written
       to the scan script. Iteration will continue. */
    if(!include_in_scan_script)
    {
        free_values(scan_path, include_files, exclude_files);
        return FALSE;
    }

    /* Open the scan script file for appending */
    script_file = mk_scan_script_path(global_scan_name);
    if((fp = fopen(script_file, "a")) == NULL)
    {
        info =
            g_strdup_printf(_("Error: Can not write scan script here:\n%s\n"),
            script_file);
        show_info(info);
        g_free(info);

        if(script_file != NULL)
            g_free(script_file);

        free_values(scan_path, include_files, exclude_files);
        return TRUE;            /* Stop iterating on write failure */
    }

    /* Create the log file path */
    log_file = mk_log_path(global_scan_name);

    /* Append commands to the script file... */

    /* Show start time and date */
    setting = g_strconcat(
                 "DATE=`date +%Y-%m-%d_%H:%M:%S` ; echo -e ",
                 "\"\\nScan starting: $DATE\\n\" ; sleep 1\n", NULL);
    fputs(setting, fp);
    g_free(setting);

    /* Beginning of the clamscan command */
    setting = g_strdup_printf("%s -i -v --recursive", CLAMSCAN_BINARY);
    fputs(setting, fp);
    g_free(setting);

    /* Add a log for each scan */
    setting = g_strdup_printf(" --log=%s", log_file);
    fputs(setting, fp);
    g_free(setting);

    if(has_value(include_files))
    {
        fputs(" --include=\"", fp);
        fputs(include_files, fp);
        fputs("\"", fp);
    }

    if(has_value(exclude_files))
    {
        fputs(" --exclude=\"", fp);
        fputs(exclude_files, fp);
        fputs("\"", fp);
    }

    /* Add path last to the clamscan command */
    fputs(" '", fp);
    fputs(scan_path, fp);
    fputs("'\n", fp);

    /* Show end time and date */
    setting = g_strconcat(
                 "DATE=`date +%Y-%m-%d_%H:%M:%S` ; echo -e ",
                 "\"\\nScan ended: $DATE\\n\"\n", NULL);
    fputs(setting, fp);
    g_free(setting);

    fputs("\n", fp);

    /* Close the script file */
    fclose(fp);

    if(script_file != NULL)
        g_free(script_file);

    if(log_file != NULL)
        g_free(log_file);

    free_values(scan_path, include_files, exclude_files);

    /* Return false to keep the foreach func going */
    return FALSE;
}


/* Saves the scan settings */
void
save_scan_settings(struct w *widgets)
{
    FILE *fp;
    int i = 0;
    gchar *cmd, *info, *settings_file, *script_path, *script, *cron_line;
    char *script_days = NULL;
    G_CONST_RETURN gchar *script_month_day = NULL, *script_hour =
        NULL, *script_minute = NULL;

    /* Only show one error popup */
    error_path = 1;

    /* Get the scan name and use it as the filename */
    global_scan_name =
       gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(widgets->settings_combo[0]));

    if(global_scan_name == NULL || strlen(global_scan_name) < 3)
    {
        info = g_strdup_printf(
                     _("Error: The scan name is too short or missing.\n"));
        show_info(info);
        g_free(info);
        return;
    }

    /* Remove cron lines matching this scan from crontab */
    script_path = mk_scan_script_path(global_scan_name);
    if(script_path == NULL || strlen(script_path) < 3)
    {
        info = g_strdup_printf(_("Error: script path too short.\n"));
        show_info(info);
        g_free(info);

        g_free(script_path);
        return;
    }

    /* Remove the cron lines */
    del_cron(script_path);

    /* Make sure we have a script file before we begin appending to it */
    if((fp = fopen(script_path, "w+")) == NULL)
    {
        info =
            g_strdup_printf(_
            ("Error: Can not write the scan script here:\n%s\n"), script_path);
        show_info(info);
        g_free(info);
        g_free(script_path);
        return;
    }

    script = g_strconcat("#!/bin/bash\n\n", FRESHCLAM_BINARY, "\n\n", NULL);
    fputs(script, fp);
    fclose(fp);

    if(script != NULL)
        g_free(script);

    /* Chmod the script file to 755 so cron can run it. */
    cmd = g_strdup_printf("chmod 755 \"%s\"", script_path);
    if(!run_command(cmd))
    {
        info = g_strdup_printf(
                    _("Error: Can not make the scan script executable.\n"));
        show_info(info);
        g_free(info);
        /* Dont return */
    }
    if(cmd != NULL)
        g_free(cmd);

    /* Create an an empty settings file before we begin appending to it */
    settings_file = g_strdup_printf("%s/%s", global_settings_dir,
                                                 global_scan_name);
    if((fp = fopen(settings_file, "w+")) == NULL)
    {
        info = g_strdup_printf(
           _("Error: Can not write scan settings here:\n%s\n"), settings_file);
        show_info(info);
        g_free(info);
        g_free(settings_file);
        g_free(script_path);
        return;
    }
    fclose(fp);

    /* Iterate the treeview and write the settings and script files */
    gtk_tree_model_foreach(GTK_TREE_MODEL(widgets->scan_store),
        (GtkTreeModelForeachFunc) save_foreach, widgets);

    g_free(script_path);

    /* Append shedule_month, schedule_days and schedule_time
       values last in the settings file */
    if((fp = fopen(settings_file, "a")) == NULL)
    {
        info = g_strdup_printf(
           _("Error: Can not write scan schedule here:\n%s\n"), settings_file);
        show_info(info);
        g_free(info);
        g_free(settings_file);
        return;
    }

    /* Return if scheduling is disabled */
    if(!gtk_toggle_button_get_active(
                GTK_TOGGLE_BUTTON(widgets->schedule_check_button[0])))
    {
        /* The cron line has already been removed */
        g_free(settings_file);

        fclose(fp);
        return;
    }

    script_month_day =
        gtk_entry_get_text(GTK_ENTRY(widgets->schedule_spin_button[0]));
    /* Run every month is selected */
    if(gtk_toggle_button_get_active(
                 GTK_TOGGLE_BUTTON(widgets->schedule_check_button[1])))
    {
        fputs("schedule_every_month_day\n", fp);
        script_month_day = g_strdup_printf("%s", "*");
    }
    else
    {
        fputs("schedule_month_day ", fp);
        fputs(script_month_day, fp);
        fputs("\n", fp);
    }

    fputs("schedule_days ", fp);
    script_days = allocate(1024);
    for(i = 2; i < 9; i++)
    {
        if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON
                (widgets->schedule_check_button[i])))
        {
            fputs("1", fp);

            if(i == 2)
                strcat(script_days, "1,");
            if(i == 3)
                strcat(script_days, "2,");
            if(i == 4)
                strcat(script_days, "3,");
            if(i == 5)
                strcat(script_days, "4,");
            if(i == 6)
                strcat(script_days, "5,");
            if(i == 7)
                strcat(script_days, "6,");
            if(i == 8)
                strcat(script_days, "7");
        }
        else
            fputs("0", fp);
    }
    fputs("\n", fp);

    /* If there are no script days, add a single '*' for any day */
    if(script_days == NULL || strlen(script_days) < 1)
        snprintf(script_days, 2, "%s", "*");

    /* Remove single commas ',' at the end of script days */
    if(script_days[strlen(script_days) - 1] == ',')
        script_days[strlen(script_days) - 1] = '\0';

    /* Append schedule for hour and minute in the settings file */
    script_hour =
        gtk_entry_get_text(GTK_ENTRY(widgets->schedule_spin_button[1]));
    script_minute =
        gtk_entry_get_text(GTK_ENTRY(widgets->schedule_spin_button[2]));

    fputs("schedule_time ", fp);
    fputs(script_hour, fp);
    fputs(":", fp);
    fputs(script_minute, fp);
    fputs("\n", fp);

    /* Run every hour */
    if(gtk_toggle_button_get_active(
            GTK_TOGGLE_BUTTON(widgets->schedule_check_button[9])))
    {
        fputs("schedule_every_hour\n", fp);
        script_hour = g_strdup_printf("%s", "*");
    }

    /* Close the settings file */
    fclose(fp);
    g_free(settings_file);

    /* Schedule this scan in crontab */
    cron_line =
        g_strdup_printf("%s %s %s * %s root", script_minute, script_hour,
        script_month_day, script_days);
    free(script_days);

    /* Removes the old cron line, adds a new one and HUP's crond */
    schedule_cron(cron_line, global_scan_name);

    /* Enable clamav antivirus signature updates */
    enable_clamav();

    g_free(cron_line);
}

