/*
 * Admin-Packages - A Package manager for sources.
 * Copyright (C) 2009 - 2011 Magnus Loef <magnus-swe@telia.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307, USA.
 *
 */


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "globals.h"
#include "allocate.h"
#include "list_installed_packages.h"
#include "get_package_info.h"
#include "commented.h"


/* List all installed packages */
void list_installed_packages()
{
    FILE *fp;
    long num=0;
    int i;
    char *line, *pkg_name, *pkg_end, *version;
    long file_size=0;

    if((fp=fopen(PACKAGES_CONF, "r"))==NULL)
    {
        printf("Error opening: [%s]\n", PACKAGES_CONF);
        printf("Install a package first\n");
        return;
    }
    fseek(fp, 0, SEEK_END);
    file_size=ftell(fp);
    rewind(fp);

    line = allocate(file_size+1);
    pkg_name = allocate(MAX_PKG_LEN+3);
    pkg_end  = allocate(MAX_PKG_LEN+6);

    if( file_size > 1 )
    while(fgets(line, file_size, fp)!=NULL)
    {
        if( commented(line) )
            continue;

        if( strlen(line) > MAX_PKG_LEN-1 )
            continue;

        /* The first entry in a package profile is <package-name> */
        if( strstr(line, "<") && strstr(line, ">") )
        {
            for(i=0; i< MAX_PKG_LEN-1; i++)
            {
                if( line[i]=='<' && strlen(line) < MAX_PKG_LEN-1 )
                {
                    sprintf(pkg_name, "%s", &line[i+1]);
                    pkg_name[strlen(line)-3]='\0';

                    snprintf(pkg_end, MAX_PKG_LEN-1, "</%s>\n", pkg_name);

                    /* Get version from SYSCONFDIR/admin-packages/packages.conf */
                    version = get_version_from_package(2, pkg_name);

                    printf("%s-%s\n", pkg_name, version);
                    free(version);
                    num++;
                }
            }

            /* Scroll to the end of this profile </package-name> */
            if( file_size > 1 )
            while(fgets(line, file_size, fp)!=NULL)
            {
                if( commented(line) )
                    continue;

                if( strcmp(line, pkg_end) == 0 )
                    break;
            }
        }
    }
    fclose(fp);
    free(line);
    free(pkg_name);
    free(pkg_end);
    printf("Total number of installed packages: [%li]\n", num);
}
