
#ifndef SET_PROXY_H
#define SET_PROXY_H

int set_proxy(char *proxy);

#endif
