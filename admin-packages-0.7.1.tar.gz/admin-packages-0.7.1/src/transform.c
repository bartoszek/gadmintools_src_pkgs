/*
 * Admin-Packages - A Package manager for sources.
 * Copyright (C) 2009 - 2011 Magnus Loef <magnus-swe@telia.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307, USA.
 *
 */


#include "../config.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "allocate.h"
#include "globals.h"
#include "transform.h"
#include "get_package_info.h"

extern int global_verbose;

/* Returns NULL on failiure and the install
   procedure with the changed macros on success */

/* User defined macros begins with ":TMACRO-" and end with a ":".
   They can be defined in settings.conf as nfollows: 
   :TMACRO-ARCH:="i686"
   :TMACRO-TUNE:="native"
   :TMACRO-TEST:="echo Testing" */
/* :PVERSION:PackageName: transforms to
   the version of the referenced "PackageName" */
char * transform_install_variables(char *install_file)
{
    FILE *fp;
    char *transformed=NULL, *line, *macro, *setting, *temp, *part;
    long file_size = 0;
    int num_transformers=0, begin=0, i=0, z=0;

    if((fp=fopen(install_file, "r"))==NULL)
    {
        printf("Cannot open installation file: %s\n", install_file);
        return NULL;
    }
    fseek(fp, 0, SEEK_END);
    file_size = ftell(fp);
    rewind(fp);

    line = allocate(file_size+1);

    /* How many words should we transform... */
    if( file_size > 1 )
    while((fgets(line, file_size, fp)!=NULL))
    {
        if( strlen(line) > MAX_LINE_LEN-1 )
        {
            printf("Warning: Skipping an install line thats too long: %s\n", line);
            continue;
        }

        temp = strtok(line, " ");

        while( temp != NULL )
        {
            if( strstr(temp, ":TMACRO-") && strlen(temp) < MAX_LINE_LEN-1 )
                num_transformers++;

            if( strstr(temp, ":PVERSION:") && strlen(temp) < MAX_LINE_LEN-1 )
                num_transformers++;

            /* We pass NULL to strtok to get the next token in the string */
            temp = strtok(NULL, " ");
        }
    }
    free(line);

    if( global_verbose )
        printf("\nNumber of macros to be transformed in install file: %d\n", num_transformers);

    fseek(fp, 0, SEEK_END);
    file_size = ftell(fp);
    rewind(fp);

    line  = allocate(file_size+1);
    transformed = allocate(file_size+1+num_transformers*MAX_LINE_LEN+1);
    part = allocate(MAX_LINE_LEN+1);

    /* Change the install macros to real values */
    if( file_size > 1 )
    while((fgets(line, file_size, fp)!=NULL))
    {
        if( strlen(line) > MAX_LINE_LEN-1 || strlen(line) < 1 )
            continue;

        /* User defined macros from SYSCONFDIR/admin-packages/settings.conf */
        if( strstr(line, ":TMACRO-") && strlen(line) < MAX_LINE_LEN-1 )
        {
            for(i=0; i < strlen(line)-1; i++)
            {
                /* This is a macro */
                if( line[i]==':'   && line[i+1]=='T' && line[i+2]=='M'
                &&  line[i+3]=='A' && line[i+4]=='C' && line[i+5]=='R' && line[i+6]=='O' )
                {
                    /* Get the macro name */
                    begin = i;

                    macro = allocate(strlen(line)+1);
                    snprintf(macro, MAX_LINE_LEN-1, "%s", &line[begin]);

                    for(z=1; z < strlen(macro)-1; z++)
                        if( macro[z]==':' )
                            break;
                    macro[z+1]='\0';

                    setting = get_from_settings(macro);
                    free(macro);

                    if( setting != NULL )
                    {
                        strcat(transformed, setting);
                        free(setting);
                    }
                    else
                    {
                        printf("Error: Transforming settings.conf macros failed.\n");
                        exit(1);
                    }
                    /* Scroll past the macro */
                    i = i + z;
                }
                else
                {
                    snprintf(part, 2, "%s", &line[i]);
                    part[1]='\0';
                    strcat(transformed, part);
                }
            }
            strcat(transformed, "\n");
        }
        else
        /* Transform to package versions etc */
        if( strstr(line, ":PVERSION:") && strlen(line) < MAX_LINE_LEN-1 )
        {
            for(i=0; i < strlen(line)-1; i++)
            {
                /* This is a package version macro */
                if( line[i]==':'   && line[i+1]=='P' && line[i+2]=='V'
                &&  line[i+3]=='E' && line[i+4]=='R' && line[i+5]=='S'
                &&  line[i+6]=='I' && line[i+7]=='O' && line[i+8]=='N'
                &&  line[i+9]==':' )
                {
                    /* Get the package name */
                    begin = i+10;

                    macro = allocate(strlen(line)+1);
                    snprintf(macro, MAX_LINE_LEN-1, "%s", &line[begin]);

                    for(z=1; z < strlen(macro)-1; z++)
                        if( macro[z]==':' )
                            break;
                    macro[z]='\0';

                    setting = get_version_from_package(1, macro);
                    free(macro);

                    if( setting!=NULL )
                    {
                        strcat(transformed, setting);
                        free(setting);
                    }
                    else
                    {
                        printf("Error: Transforming :PVERSION: macro failed.\n");
                        exit(1);
                    }
                    /* Scroll past the macro */
                    i = begin + z;
                }
                else
                {
                    snprintf(part, 2, "%s", &line[i]);
                    part[1]='\0';
                    strcat(transformed, part);
                }
            }
            strcat(transformed, "\n");
        }
        else
            strcat(transformed, line);
    }
    free(part);
    free(line);
    fclose(fp);

    /* Write a new install file with transformed macros. */
    if((fp=fopen(install_file, "w+"))==NULL)
    {
        printf("Could not write installation file: %s\n", install_file);
        return NULL;
    }
    fputs(transformed, fp);
    fclose(fp);

    return transformed;
}


/* Transform version to something comparable to other versions */
char * transform_version(char *version)
{
    int i=0, y=0, z=0;
    char *transformed;
    char *tmp1;
    char *tmp2;
    char *tmp3;

    /* Double alloc for a = 1 .. z = 23 */
    transformed = allocate(MAX_VER_LEN+MAX_VER_LEN);

    if( version == NULL )
    {
        printf("No previous version of this package existed...\n");
        sprintf(transformed, "%s", "0");
        return transformed;
    }

    tmp1 = allocate(MAX_VER_LEN+MAX_VER_LEN);
    tmp2 = allocate(MAX_VER_LEN+MAX_VER_LEN);
    tmp3 = allocate(MAX_VER_LEN+MAX_VER_LEN);

    sprintf(tmp1, "%s", version);

    /* strip dots, '-' and '_' */
    for(i=0; i<MAX_VER_LEN && tmp1[i]!='\0'; i++)
    {
       if( tmp1[i]!='.' && tmp1[i]!='-' && tmp1[i]!='_' 
       && tmp1[i]!='\r' && tmp1[i]!='\n' && tmp1[i]!=' ' )
       {
           tmp2[y]=tmp1[i];
           y++;
       }
    }
    free(tmp1);


    /* Add 1 to all digits and translate chars to digits */
    z = 0;
    for(i=0; i<MAX_VER_LEN && tmp2[i]!='\0'; i++)
    {
        /* Digits */
        if( tmp2[i] == '0' ) tmp3[z]='1';

        if( tmp2[i] == '1' ) tmp3[z]='2';

        if( tmp2[i] == '2' ) tmp3[z]='3';

        if( tmp2[i] == '3' ) tmp3[z]='4';

        if( tmp2[i] == '4' ) tmp3[z]='5';

        if( tmp2[i] == '5' ) tmp3[z]='6';

        if( tmp2[i] == '6' ) tmp3[z]='7';

        if( tmp2[i] == '7' ) tmp3[z]='8';

        if( tmp2[i] == '8' ) tmp3[z]='9';

        if( tmp2[i] == '9' )
        {
           tmp3[z]='1'; ++z; tmp3[z]='0';
        }


        /* Chars */
        if( tmp2[i] == 'A' || tmp2[i] == 'a' ) tmp3[z]='1';

        if( tmp2[i] == 'B' || tmp2[i] == 'b' ) tmp3[z]='2';

        if( tmp2[i] == 'C' || tmp2[i] == 'c' ) tmp3[z]='3';

        if( tmp2[i] == 'D' || tmp2[i] == 'd' ) tmp3[z]='4';

        if( tmp2[i] == 'E' || tmp2[i] == 'e' ) tmp3[z]='5';

        if( tmp2[i] == 'F' || tmp2[i] == 'f' ) tmp3[z]='6';

        if( tmp2[i] == 'G' || tmp2[i] == 'g' ) tmp3[z]='7';

        if( tmp2[i] == 'H' || tmp2[i] == 'h' ) tmp3[z]='8';

        if( tmp2[i] == 'I' || tmp2[i] == 'i' ) tmp3[z]='9';

        if( tmp2[i] == 'J' || tmp2[i] == 'j' )
        {
            tmp3[z]='1'; ++z; tmp3[z]='0';
        }
        if( tmp2[i] == 'K' || tmp2[i] == 'k' )
        {
            tmp3[z]='1'; ++z; tmp3[z]='1';
        }
        if( tmp2[i] == 'L' || tmp2[i] == 'l' )
        {
            tmp3[z]='1'; ++z; tmp3[z]='2';
        }
        if( tmp2[i] == 'M' || tmp2[i] == 'm' )
        {
            tmp3[z]='1'; ++z; tmp3[z]='3';
        }
        if( tmp2[i] == 'N' || tmp2[i] == 'n' )
        {
            tmp3[z]='1'; ++z; tmp3[z]='4';
        }
        if( tmp2[i] == 'O' || tmp2[i] == 'o' )
        {
            tmp3[z]='1'; ++z; tmp3[z]='5';
        }
        if( tmp2[i] == 'P' || tmp2[i] == 'p' )
        {
            tmp3[z]='1'; ++z; tmp3[z]='6';
        }
        if( tmp2[i] == 'Q' || tmp2[i] == 'q' )
        {
            tmp3[z]='1'; ++z; tmp3[z]='7';
        }
        if( tmp2[i] == 'R' || tmp2[i] == 'r' )
        {
            tmp3[z]='1'; ++z; tmp3[z]='8';
        }
        if( tmp2[i] == 'S' || tmp2[i] == 's' )
        {
            tmp3[z]='1'; ++z; tmp3[z]='9';
        }
        if( tmp2[i] == 'T' || tmp2[i] == 't' )
        {
            tmp3[z]='2'; ++z; tmp3[z]='0';
        }
        if( tmp2[i] == 'U' || tmp2[i] == 'u' )
        {
            tmp3[z]='2'; ++z; tmp3[z]='1';
        }
        if( tmp2[i] == 'V' || tmp2[i] == 'v' )
        {
            tmp3[z]='2'; ++z; tmp3[z]='2';
        }
        if( tmp2[i] == 'W' || tmp2[i] == 'w' )
        {
            tmp3[z]='2'; ++z; tmp3[z]='3';
        }
        if( tmp2[i] == 'X' || tmp2[i] == 'x' )
        {
            tmp3[z]='2'; ++z; tmp3[z]='4';
        }
        if( tmp2[i] == 'Y' || tmp2[i] == 'y' )
        {
            tmp3[z]='2'; ++z; tmp3[z]='5';
        }
        if( tmp2[i] == 'Z' || tmp2[i] == 'z' )
        {
            tmp3[z]='2'; ++z; tmp3[z]='6';
        }

        ++z;
    }
    free(tmp2);

    sprintf(transformed, "%s", tmp3);
    free(tmp3);

    return transformed;
}
