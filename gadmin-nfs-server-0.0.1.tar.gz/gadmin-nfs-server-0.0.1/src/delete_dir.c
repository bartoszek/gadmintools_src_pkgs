/* GADMIN-NFS-SERVER - An easy to use GTK+ frontend for the NFS server.
 * Copyright (C) 2014 - 2014 Magnus Loef <magnus-swe@telia.com> 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
*/



#include <gtk/gtk.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "widgets.h"
#include "gettext.h"
#include "allocate.h"
#include "show_info.h"
#include "reread_conf.h"
#include "commented.h"

extern char global_nic[1024];


/* Delete the selected directory */
void delete_dir(struct w *widgets)
{
    FILE *fp;
    long file_size = 0;
    char *line;
    char *new_conf;
    gchar *info;

    gchar *dir = g_strdup_printf("%s ", global_nic);

    if( strlen(dir) == 0 )
    {
       info = g_strdup_printf(_("Missing directory for delete directory, directory not deleted\n"));
       show_info(info);
       g_free(info);
       return;
    }

    if((fp=fopen(NFSD_CONF, "r"))==NULL)
    {
        printf("Could not find exports file: %s\n", NFSD_CONF);
        return;
    }
    fseek(fp, 0, SEEK_END);
    file_size = ftell(fp);
    rewind(fp);

    new_conf = allocate(file_size+1);
    line = allocate(file_size+1);

    /* Find and remove the failover declaration */
    if( file_size > 1 )
    while(fgets(line, file_size, fp)!=NULL)
    {
	/* Scroll past the directory */
	if( strstr(line, dir) )
	{

	}
	else
	  strcat(new_conf, line);
    }
    fclose(fp);
    g_free(dir);

    /* Write the new configuration */
    if((fp=fopen(NFSD_CONF, "w+"))==NULL)
    {
        printf("Couldnt write: %s\n", NFSD_CONF);
	free(line);
	free(new_conf);
        return;
    }
    fputs(new_conf, fp);
    fclose(fp);

    free(line);
    free(new_conf);
}
