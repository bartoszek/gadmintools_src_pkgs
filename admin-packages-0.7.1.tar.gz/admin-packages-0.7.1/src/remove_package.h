
#ifndef REMOVE_PACKAGE_H
#define REMOVE_PACKAGE_H

int do_remove(char *package);
int remove_package(char *package);

#endif
