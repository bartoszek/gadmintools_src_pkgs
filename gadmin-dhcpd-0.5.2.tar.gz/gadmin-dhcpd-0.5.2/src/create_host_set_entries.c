/* GADMIN-DHCPD - An easy to use GTK+ frontend for ISC DHCPD.
 * Copyright (C) 2004 - 2011 Magnus Loef <magnus-swe@telia.com> 
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
*/



#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
#include "gettext.h"
#include "widgets.h"
#include "make_settings_entries.h"
#include "make_settings_textviews.h"



void create_host_set_entries(struct w *widgets)
{
    GtkWidget *frame;
    GtkWidget *table;
    GtkTooltips *tooltips;
    int a=0, b=1;
    
    tooltips = gtk_tooltips_new();

    frame = gtk_frame_new(_("Host settings"));

    /* A table with 16 settings and 2 columns */
    table = gtk_table_new(16, 2, FALSE);

    gtk_box_pack_start(GTK_BOX(widgets->host_set_scrolled_vbox), frame, TRUE, TRUE, 0);
    gtk_container_add(GTK_CONTAINER(frame), table);
						    			/* Max length and input 350 chars */
    widgets->host_set_entry[0] = make_entry_with_label(GTK_TABLE(table), _(" Hostname: "),       0,1,a,b,350);
    gtk_tooltips_set_tip(tooltips, widgets->host_set_entry[0], "computer-name", NULL);
    a++; b++;

    widgets->host_set_entry[1] = make_entry_with_label(GTK_TABLE(table), _(" IP-address: "),     0,1,a,b,350);
    gtk_tooltips_set_tip(tooltips, widgets->host_set_entry[1], "192.168.0.1", NULL);
    a++; b++;

    widgets->host_set_entry[2] = make_entry_with_label(GTK_TABLE(table), _(" Hardware address: "),    0,1,a,b,350);
    gtk_tooltips_set_tip(tooltips, widgets->host_set_entry[2], "00:20:ED:58:78:96", NULL);
    a++; b++;

    widgets->host_set_entry[3] = make_entry_with_label(GTK_TABLE(table), _(" Default lease time: "), 0,1,a,b,350);
    gtk_tooltips_set_tip(tooltips, widgets->host_set_entry[3], _("600 (seconds)"), NULL);
    a++; b++;

    widgets->host_set_entry[4] = make_entry_with_label(GTK_TABLE(table), _(" Max lease time: "),     0,1,a,b,350);
    gtk_tooltips_set_tip(tooltips, widgets->host_set_entry[4], _("7200 (seconds)"), NULL);
    a++; b++;

    widgets->host_set_entry[5] = make_entry_with_label(GTK_TABLE(table),_(" Domain name: "),         0,1,a,b,350);
    gtk_tooltips_set_tip(tooltips, widgets->host_set_entry[5], _("some.domain.org"), NULL);
    a++; b++;

    widgets->host_set_entry[6] = make_entry_with_label(GTK_TABLE(table),_(" Subnet mask: "),         0,1,a,b,350);
    gtk_tooltips_set_tip(tooltips, widgets->host_set_entry[6], "255.255.255.0", NULL);
    a++; b++;

    widgets->host_set_entry[7] = make_entry_with_label(GTK_TABLE(table),_(" Broadcast address: "),   0,1,a,b,350);
    gtk_tooltips_set_tip(tooltips, widgets->host_set_entry[7], "192.168.0.255", NULL);
    a++; b++;

    widgets->host_set_entry[8] = make_entry_with_label(GTK_TABLE(table),_(" Routers: "),             0,1,a,b,350);
    gtk_tooltips_set_tip(tooltips, widgets->host_set_entry[8], "192.168.0.101 , 192.168.0.102 , 192.168.0.103", NULL);
    a++; b++;

    widgets->host_set_entry[9] = make_entry_with_label(GTK_TABLE(table),_(" Domain name servers: "), 0,1,a,b,350);
    gtk_tooltips_set_tip(tooltips, widgets->host_set_entry[9], _("10.0.0.1 , 10.0.0.2 , 10.0.0.3"), NULL);
    a++; b++;

    widgets->host_set_entry[10] = make_entry_with_label(GTK_TABLE(table),_(" NIS domain: "),         0,1,a,b,350);
    gtk_tooltips_set_tip(tooltips, widgets->host_set_entry[10], _("my.nis.domain"), NULL);
    a++; b++;

    widgets->host_set_entry[11] = make_entry_with_label(GTK_TABLE(table),_(" Time offset: "),        0,1,a,b,350);
    gtk_tooltips_set_tip(tooltips, widgets->host_set_entry[11], _("Specifies the offset of the client's subnet in seconds from Coordinated Universal Time (UTC).\n-18000 is eastern standard time\n-3600 is central european standard time."), NULL);
    a++; b++;

    widgets->host_set_entry[12] = make_entry_with_label(GTK_TABLE(table),_(" NTP servers: "),        0,1,a,b,350);
    gtk_tooltips_set_tip(tooltips, widgets->host_set_entry[12], "192.168.0.43, 192.168.0.44 , 192.168.0.45", NULL);
    a++; b++;

    widgets->host_set_entry[13] = make_entry_with_label(GTK_TABLE(table),_(" Netbios name servers: "), 0,1,a,b,350);
    gtk_tooltips_set_tip(tooltips, widgets->host_set_entry[13], "192.168.0.46, 192.168.0.47 , 192.168.0.48", NULL);
    a++; b++;

    widgets->host_set_entry[14] = make_entry_with_label(GTK_TABLE(table),_(" Netboot GRUB menu: "), 0,1,a,b,350);
    gtk_tooltips_set_tip(tooltips, widgets->host_set_entry[14], _("(nd)/tftpboot/your_OS/menu.lst"), NULL);
    a++; b++;

    widgets->host_set_entry[15] = make_entry_with_label(GTK_TABLE(table),_(" Netboot file: "),  0,1,a,b,350);
    gtk_tooltips_set_tip(tooltips, widgets->host_set_entry[15], _("/tftpboot/your_OS/netboot_file"), NULL);
    a++; b++;

    widgets->host_set_entry[16] = make_entry_with_label(GTK_TABLE(table),_(" Netboot path: "),  0,1,a,b,350);
    gtk_tooltips_set_tip(tooltips, widgets->host_set_entry[16], _("192.168.0.100:/tftpboot/your_OS"), NULL);
    a++; b++;

    widgets->host_set_entry[17] = make_entry_with_label(GTK_TABLE(table),_(" Next netboot server: "),  0,1,a,b,350);
    gtk_tooltips_set_tip(tooltips, widgets->host_set_entry[17], _("TFTP/PXE ServerName or 192.168.0.100"), NULL);
    a++; b++;

    widgets->host_set_entry[18] = make_entry_with_label(GTK_TABLE(table),_(" X display manager: "),  0,1,a,b,350);
    gtk_tooltips_set_tip(tooltips, widgets->host_set_entry[18], _("ServerName or 192.168.0.100"), NULL);
    a++; b++;

    /* Create a host comment textview inside a scrolled window */
    widgets->host_comment_textview = make_textview_with_label(GTK_TABLE(table),_(" Host comment: "),  0,1,a,b);
    a++; b++;
}
